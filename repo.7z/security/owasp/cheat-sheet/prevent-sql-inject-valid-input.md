---
title: Defesa contra SQL inject - Validação de entrada da lista de permissões
---

Várias partes das consultas SQL não são locais válidos para o uso de variáveis ​​de ligação, como nomes de tabelas ou colunas e o indicador de ordem de classificação (ASC ou DESC). Em tais situações, a validação de entrada ou redesenho de consulta é a defesa mais apropriada. Para nomes de tabelas ou colunas, o ideal é que esses valores venham do código, e não dos parâmetros do usuário.

Mas se os valores dos parâmetros do usuário forem usados ​​para almejar nomes de tabelas e nomes de colunas diferentes, então os valores dos parâmetros devem ser mapeados para a tabela legal / esperada ou nomes de coluna para garantir que a entrada não validada do usuário não acabe na consulta. Observe que este é um sintoma de design ruim e uma reescrita completa deve ser considerada se o tempo permitir.

Aqui está um exemplo de validação de nome de tabela.

```sql

String tableName;

switch(PARAM):

  case "Value1": tableName = "fooTable";
                 break;

  case "Value2": tableName = "barTable";
                 break;

  default      : throw new InputValidationException("unexpected value provided"
                                                  + " for table name");

```

O `tableName` pode então ser anexado diretamente à consulta SQL, já que agora é conhecido como um dos valores legais e esperados para um nome de tabela nesta consulta. Lembre-se de que as funções de validação de tabela genérica podem levar à perda de dados, pois os nomes das tabelas são usados ​​em consultas em que não são esperados.

Para algo simples como uma ordem de classificação, seria melhor se a entrada fornecida pelo usuário fosse convertida em um booleano e, em seguida, esse booleano fosse usado para selecionar o valor seguro a ser anexado à consulta. Esta é uma necessidade muito padrão na criação de consultas dinâmicas.

Por exemplo:

```java

public String someMethod(boolean sortOrder) {
 String SQLquery = "some SQL ... order by Salary " + (sortOrder ? "ASC" : "DESC");`
 ...

```

Sempre que a entrada do usuário pode ser convertida em uma string não, como uma data, numérica, booleana, tipo enumerado, etc. antes de ser anexada a uma consulta ou usada para selecionar um valor a ser anexado à consulta, isso garante que seja seguro fazê-lo.

A validação de entrada também é recomendada como uma defesa secundária em TODOS os casos, mesmo ao usar variáveis ​​de vinculação, conforme discutido posteriormente neste artigo. Mais técnicas sobre como implementar a validação de entrada de lista de permissão forte são descritas na Folha de referências de validação de entrada .

### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)