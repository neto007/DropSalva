---
title: Permissão em banco de dados
---

As permissões atribuídas às contas de usuário do banco de dados devem ser baseadas no princípio do menor privilégio (ou seja, as contas devem ter apenas as permissões mínimas exigidas para o aplicativo funcionar). Isso pode ser aplicado em vários níveis de níveis cada vez mais granulares, dependendo da funcionalidade disponível no banco de dados. As etapas a seguir devem ser aplicáveis ​​a todos os ambientes:

* Não use o built-in root, sa, ou contas de sistema.
* Não conceda à conta direitos administrativos sobre a instância do banco de dados.
* Permitir apenas que a conta se conecte de hosts da lista de permissões.  Geralmente é localhost ou o endereço do servidor de aplicativos.
* Conceda à conta acesso apenas aos bancos de dados específicos de que ele precisa.
* Ambientes de desenvolvimento e produção devem usar bancos de dados e contas separados.
* Conceda apenas as permissões necessárias nos bancos de dados.
* A maioria dos aplicativos só precisa SELECT, UPDATE e DELETE.
* A conta não deve ser a proprietária do banco de dados, pois isso pode levar a vulnerabilidades de escalonamento de privilégios.
* Evite usar links de banco de dados ou servidores vinculados.
* Onde forem necessários, use uma conta que tenha acesso concedido apenas aos bancos de dados, tabelas e privilégios de sistema mínimos necessários.

Para aplicativos mais críticos para a segurança, é possível aplicar permissões em níveis mais granulares, incluindo:

* Permissões de nível de tabela.
* Permissões de nível de coluna.
* Permissões de nível de linha.
* Bloquear o acesso às tabelas subjacentes e exigir todo o acesso por meio de visualizações restritas.

## Referência externa
[OWASP - segurança em baco de dados](https://cheatsheetseries.owasp.org/cheatsheets/Database_Security_Cheat_Sheet.html)