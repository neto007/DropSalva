---
title: Cookies de sessão sem o atributo HttpOnly
---
## Descrição

Um sinalizador HttpOnly é uma opção que pode ser definida ao criar um cookie. Este   garante que o cookie não pode ser lido ou editado por JavaScript. Isso garante que um invasor não possa roubar esse cookie, pois uma vulnerabilidade de script entre sites está presente no aplicativo.

## Solução

O sinalizador HttpOnly deve ser definido para desativar o acesso do script malicioso aos valores do cookie, como o valor do ID da sessão. Além disso, desative os métodos de solicitação HTTP desnecessários, como a opção TRACE. A configuração incorreta dos cabeçalhos de solicitação HTTP pode levar ao roubo do cookie de sessão, embora a proteção HttpOnly esteja em vigor.