---
title: Implementação da função criptográfica
---
## Descrição

Sempre que uma função criptográfica não é implementada no lado do servidor, esses
funções criptográficas podem ser facilmente ignoradas por um invasor.

## Solução

Verifique se todas as funções criptográficas usadas para proteger segredos do aplicativo
usuário são implementados no lado do servidor.