---
title: Validar as contramedidas de segurança do Protocolo SAML
---

Contramedidas adicionais consideradas devem incluir:

Prefira a filtragem de IP quando apropriado. Por exemplo, essa contramedida poderia ter evitado a falha de segurança inicial do Google se o Google fornecesse a cada parceiro confiável um endpoint separado e configurasse um filtro de IP para cada endpoint. Esta etapa ajudará a combater os seguintes ataques:

- Declaração roubada
- Man-in-the-middle

Prefira tempos de vida curtos na resposta SAML. Esta etapa ajudará a combater os seguintes ataques:

- Declaração roubada

- Exposição do estado do navegador

Prefira OneTimeUse na resposta SAML. Esta etapa ajudará a combater os seguintes ataques:
Exposição do estado do navegador

- Repetir

Precisa de um diagrama arquitetônico? A visão geral técnica do [SAML contém os diagramas mais completos](https://www.oasis-open.org/committees/download.php/11511/sstc-saml-tech-overview-2.0-draft-03.pdf).


### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)
