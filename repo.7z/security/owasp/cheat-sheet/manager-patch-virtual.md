---
title: Gerenciamento de Patch Virtual
---

Apresentar uma estrutura concisa de `patching virtual` que as organizações podem seguir para maximizar a implementação oportuna de proteções de mitigação.

### Definição: Patching Virtual

Uma camada de aplicação da política de segurança que evita e relata a tentativa de exploração de uma vulnerabilidade conhecida.

O `patch virtual` funciona quando a camada de aplicação de segurança analisa transações e intercepta ataques em trânsito, para que o tráfego malicioso nunca alcance o aplicativo da web. O impacto resultante da correção virtual é que, embora o código-fonte real do aplicativo em si não tenha sido modificado, a tentativa de exploração não é bem-sucedida.


### Por que não apenas consertar o código

De uma perspectiva puramente técnica, a estratégia de remediação número um seria para uma organização corrigir a vulnerabilidade identificada dentro do código-fonte do aplicativo da web. Esse conceito é universalmente aceito por especialistas em segurança de aplicativos da web e proprietários de sistemas. Infelizmente, em situações de negócios do mundo real, surgem muitos cenários em que atualizar o código-fonte de um aplicativo da web não é fácil, como:

- Falta de recursos - Devs já estão alocados para outros projetos.

- Software de terceiros - o código não pode ser modificado pelo usuário.

- Outsourced App Dev - as alterações exigiriam um novo projeto.

O ponto importante é este - as correções de nível de código e patch virtual NÃO são mutuamente exclusivos . Eles são processos executados por equipes diferentes (OWASP Builders / Devs vs. OWASP Defenders / OpSec) e podem ser executados em conjunto.

### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)