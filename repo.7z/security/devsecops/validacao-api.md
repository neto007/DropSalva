---
title: Validação de APIs
---



## Objetivo

Com o intuito de aumentar a segurança de nossas APIs e diminuir os riscos da empresa.
Desenvolvemos um procedimento de validação de APIs no APIM (API Managament).

## Procedimento

* Validação de API:
    * Validação de police no APIM 
        * OCP-APIM
            * Verificação de existência da subscription-key
        * Query parameters
            * Validação das rotas que utilizam query parameters, para sanar uma vulnerabilidade já conhecida 
    * OWASP ZAP Zed Attack Proxy
        * Scan automatizado com foco em testes de APIs, utilizando o swagger como base.
    * Autorização
        * Realizar login (Cliente/Assessor)
        * Solicitar parâmetros adicionais para o desenvolvedor responsável
        * Ter um segundo usuário de login para a execução do teste

## Conclusão

Caso sejam identificadas vulnerabilidades críticas e altas a GMUD não será aprovada. 
As vulnerabilidades classificadas como média e baixa a squad pode optar por não solucionar na GMUD, porém será aberto um incidente no taylor com a sua respectiva criticidade.