---
title: Verifique a integridade usando somas de verificação
---
## Descrição

Sempre use checksum ao trabalhar com código interpretado, bibliotecas, executáveis,
e arquivos de configuração, quando um checksum não corresponde, você pode determinar que esses arquivos estão corrompidos ou em backdoor.

## Solução

Verifique se a integridade do código interpretado, bibliotecas, executáveis ​​e configuração
dos arquivos são verificados usando checksums ou hashes (não MD5).

