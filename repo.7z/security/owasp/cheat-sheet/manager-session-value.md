---
title: Conteúdo de ID de sessão
---


O conteúdo (ou valor) da ID da sessão deve ser insignificante para evitar ataques de divulgação de informações, em que um invasor é capaz de decodificar o conteúdo da ID e extrair detalhes do usuário, da sessão ou do funcionamento interno do aplicativo da web.

O ID da sessão deve ser simplesmente um identificador no lado do cliente e seu valor nunca deve incluir informações confidenciais (ou PII ).

O significado e a lógica de negócios ou aplicativo associados ao ID de sessão devem ser armazenados no lado do servidor e, especificamente, em objetos de sessão ou em um banco de dados ou repositório de gerenciamento de sessão.

As informações armazenadas podem incluir o endereço IP do cliente, Agente do Usuário, e-mail, nome de usuário, ID do usuário, função, nível de privilégio, direitos de acesso, preferências de idioma, ID da conta, estado atual, último login, tempo limite de sessão e outras sessões internas detalhes. Se os objetos e propriedades da sessão contiverem informações confidenciais, como números de cartão de crédito, é necessário criptografar e proteger devidamente o repositório de gerenciamento de sessão.

É recomendável criar IDs de sessão criptograficamente fortes por meio do uso de funções de hash criptográficas, como SHA256.


### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)