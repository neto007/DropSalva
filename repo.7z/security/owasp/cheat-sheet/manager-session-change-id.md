---
title: Mecanismos de troca de ID de sessão
---


Um aplicativo da web deve fazer uso de cookies para gerenciamento de troca de ID de sessão. Se um usuário enviar um ID de sessão por meio de um mecanismo de troca diferente, como um parâmetro de URL, o aplicativo da web deve evitar aceitá-lo como parte de uma estratégia defensiva para interromper a fixação da sessão.

NOTA :

Mesmo se um aplicativo da web usar cookies como seu mecanismo de troca de ID de sessão padrão, ele pode aceitar outros mecanismos de troca.
Portanto, é necessário confirmar por meio de testes completos todos os diferentes mecanismos atualmente aceitos pelo aplicativo da web ao processar e gerenciar IDs de sessão e limitar os mecanismos de rastreamento de IDs de sessão aceitos apenas para cookies.
No passado, alguns aplicativos da web usavam parâmetros de URL, ou mesmo trocavam de cookies para parâmetros de URL (via reescrita automática de URL), se certas condições fossem atendidas (por exemplo, a identificação de clientes da web sem suporte para cookies ou não aceitar cookies devido a preocupações com a privacidade do usuário).

### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)