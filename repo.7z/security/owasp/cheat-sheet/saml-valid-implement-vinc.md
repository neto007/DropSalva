---
title: SAML - Validar a implementação de vinculação
---

- Para uma vinculação de redirecionamento HTTP, consulte SAML Binding (3.4). Para ver um exemplo de codificação, você pode querer fazer referência a RequestUtil.java encontrado na implementação de referência do Google .

- Para uma ligação HTTP POST, consulte SAML Binding (3.5). As considerações de cache também são muito importantes. Se uma mensagem do protocolo SAML for armazenada em cache, ela poderá ser usada posteriormente como um ataque de asserção roubada (6.4.1) ou repetição (6.4.5).


### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)