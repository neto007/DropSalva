---
title: Intenção maliciosa
---
## Descrição

Antes de colocar um código ao vivo, você deve verificar se há códigos mal-intencionados no software para garantir que nenhum desenvolvedor com más intenções faça backdoors ou faça deliberadamente explorações.

Dependências e bibliotecas de terceiros também devem ser validadas contra códigos maliciosos. Essas dependências e bibliotecas também devem ser validadas para vulnerabilidades conhecidas (CVE)

## Solução

A execução do seu código por meio de um analisador de código estático ou ferramentas de auditoria pode dar a você a chance de encontrar trechos de código maliciosos que podem ser incorporados ao software. Além disso, se a funcionalidade nova ou ajustada for crítica, verifique-a manualmente na forma de uma revisão de código para verificar se há portas traseiras, ovos de Páscoa e falhas lógicas.

Isso também significa que os administradores autorizados devem ter a capacidade de verificar a integridade de todas as configurações relevantes à segurança para garantir que não tenham sido violadas.

Determine também que a lógica comercial das transações de alto valor não é importada de bibliotecas de terceiros não confiáveis.

>Nota: Estudos mostraram que backdoors escritos por funcionários com intenções maliciosas provavelmente o farão dentro do primeiro semestre de seu emprego. A implementação de portas traseiras tem pouco a ver com a satisfação de um funcionário com o empregador atual, provou ser uma característica de caráter, e não uma característica de descontentamento.
