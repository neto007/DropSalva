---
title: Documentos XML Formatados
---

A especificação W3C `XML` define um conjunto de princípios que os documentos `XML` devem seguir para serem considerados bem formados. Quando um documento viola algum desses princípios, deve ser considerado um erro fatal e os dados nele contidos são considerados malformados. Múltiplas táticas irão causar um documento malformado: remover uma tag final, reorganizar a ordem dos elementos em uma estrutura sem sentido, introduzir caracteres proibidos e assim por diante. O analisador `XML` deve parar a execução assim que detectar um erro fatal. O documento não deve sofrer nenhum processamento adicional e o aplicativo deve exibir uma mensagem de erro.

A recomendação para evitar essas vulnerabilidades é usar um processador `XML` que siga as especificações W3C e não leve um tempo adicional significativo para processar documentos malformados. Além disso, use apenas documentos bem formados e valide o conteúdo de cada elemento e atributo para processar apenas valores válidos dentro de limites predefinidos.


```xml

<element>
 <!-- one
  <!-- another comment
 comment -->
</element>

```

Certos analisadores podem considerar a normalização do conteúdo de suas `CDATA` seções. Isso significa que eles atualizarão os caracteres especiais contidos na `CDATA` seção para conter as versões seguras desses caracteres, embora não seja obrigatório:

```xml
<element>
 <![CDATA[<script>a=1;</script>]]>
</element>

```

A normalização de uma `CDATA` seção não é uma regra comum entre analisadores. `Libxml` poderia transformar este documento em sua versão canônica, mas embora bem formado, seu conteúdo pode ser considerado malformado dependendo da situação:

```xml

<element>
 &lt;script&gt;a=1;&lt;/script&gt;
</element>

```

## Análise Coercitiva

Um ataque coercitivo em `XML` envolve a análise de documentos `XML` profundamente aninhados sem suas tags de finalização correspondentes. A idéia é fazer a vítima usar - e eventualmente esgotar - os recursos da máquina e causar uma negação de serviço no alvo. Os relatórios de um ataque DoS no Firefox 3.67 incluíram o uso de 30.000 elementos `XML` abertos sem suas tags finais correspondentes. A remoção das marcas de fechamento simplificou o ataque, pois requer apenas metade do tamanho de um documento bem formado para obter os mesmos resultados. O número de tags sendo processadas eventualmente causou um estouro de pilha. Uma versão simplificada de tal documento teria a seguinte aparência:

```xml
<A1>
 <A2>
  <A3>
   ...
    <A30000>
```

### Violação das regras de especificação XML

Conseqüências inesperadas podem resultar da manipulação de documentos usando analisadores que não seguem as especificações W3C. Pode ser possível obter travamentos e / ou execução de código quando o software não verifica corretamente como lidar com estruturas `XML` incorretas. Alimentar o software com documentos `XML` difusos pode expor esse comportamento.

## Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/cheatsheets/XML_Security_Cheat_Sheet.html)