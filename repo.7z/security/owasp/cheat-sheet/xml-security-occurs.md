---
title: Ocorrências
---

As consequências de não definir um número máximo de ocorrências podem ser piores do que lidar com as consequências do que pode acontecer ao receber um número extremo de itens a serem processados. Dois atributos especificam limites mínimo e máximo: `minOccurs` e `maxOccurs`. O valor padrão para `minOccursos` `maxOccursatributos` é de 1, mas alguns elementos podem exigir outros valores. Por exemplo, se um valor for opcional, pode conter a `minOccurs` de 0 e, se não houver limite para o valor máximo, poderá conter a `maxOccursde unbounded`, como no exemplo a seguir:
```xml

<xs:schema xmlns:xs="http://www.w3.org/2001/XMLSchema">
 <xs:element name="operation">
  <xs:complexType>
   <xs:sequence>
    <xs:element name="buy" maxOccurs="unbounded">
     <xs:complexType>
      <xs:all>
       <xs:element name="id" type="xs:integer"/>
       <xs:element name="price" type="xs:decimal"/>
       <xs:element name="quantity" type="xs:integer"/>
      </xs:all>
     </xs:complexType>
    </xs:element>
  </xs:complexType>
 </xs:element>
</xs:schema>

```

O esquema anterior inclui um elemento raiz denominado `operation`, que pode conter uma `unbounded`quantidade ilimitada() de elementos de compra. Esta é uma descoberta comum, uma vez que os desenvolvedores normalmente não desejam restringir o número máximo de ocorrências. Os aplicativos que usam ocorrências ilimitadas devem testar o que acontece quando eles recebem uma quantidade extremamente grande de elementos para serem processados. Como os recursos computacionais são limitados, as consequências devem ser analisadas e, eventualmente, um número máximo deve ser usado em vez de um `unbounded` valor.

## Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/cheatsheets/XML_Security_Cheat_Sheet.html)