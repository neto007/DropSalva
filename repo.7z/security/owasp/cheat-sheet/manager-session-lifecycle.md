---
title: Ciclo de vida do ID da sessão
---

**Geração e verificação de ID de sessão: gerenciamento permissivo e estrito de sessão**

Existem dois tipos de mecanismos de gerenciamento de sessão para aplicativos da web, permissivos e estritos, relacionados a vulnerabilidades de fixação de sessão. O mecanismo permissivo permite que o aplicativo da web aceite inicialmente qualquer valor de ID de sessão definido pelo usuário como válido, criando uma nova sessão para ele, enquanto o mecanismo estrito impõe que o aplicativo da web aceite apenas valores de ID de sessão que foram gerados anteriormente pelo aplicativo da web.

Os tokens de sessão devem ser manipulados pelo servidor da web, se possível, ou gerados por meio de um gerador de números aleatórios criptograficamente seguro.

Embora o mecanismo mais comum em uso hoje seja o estrito (mais seguro, o padrão do PHP é permissivo ). Os desenvolvedores devem garantir que o aplicativo da web não use um mecanismo permissivo sob certas circunstâncias. Os aplicativos da Web nunca devem aceitar um ID de sessão que nunca geraram e, no caso de recebê-lo, devem gerar e oferecer ao usuário um novo ID de sessão válido. Além disso, esse cenário deve ser detectado como uma atividade suspeita e um alerta deve ser gerado.


### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)