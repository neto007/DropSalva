---
title: Gerador de números aleatórios
---
## Descrição

A falta de entropia disponível para, ou usada por, um gerador de números pseudo-aleatórios pode ser uma ameaça de estabilidade e segurança.

## Solução

Todos os números aleatórios, nomes de arquivos aleatórios, GUIDs aleatórios e aleatórios devem ser gerados usando o módulo criptográfico aprovado para geração de números aleatórios quando esses valores aleatórios são destinados a ser imprevisíveis por um invasor.