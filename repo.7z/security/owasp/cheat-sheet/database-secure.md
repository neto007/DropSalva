---
title: Segurança em banco de dados
---

## Conectando-se ao banco de dados

O banco de dados backend usado pelo aplicativo deve ser isolado o máximo possível, a fim de evitar que usuários mal-intencionados ou indesejáveis ​​possam se conectar a ele. Exatamente como isso é feito dependerá do sistema e da arquitetura da rede. As seguintes opções podem ser usadas para protegê-lo:

* Desativar o acesso à rede (TCP) e exigir todo o acesso por meio de um arquivo de socket local ou pipe nomeado.
* Configurando o banco de dados para ligar apenas no host local.
* Restringindo o acesso à porta de rede a hosts específicos com regras de firewall.
* Colocar o servidor de banco de dados em uma DMZ separada e isolada do servidor de aplicativos.
* Proteção semelhante deve ser implementada para proteger quaisquer ferramentas de gerenciamento baseadas na web usadas com o banco de dados, como o phpMyAdmin.

Quando um aplicativo está sendo executado em um sistema não confiável, ele sempre deve se conectar ao back-end por meio de uma API que pode impor o controle de acesso e restrições apropriados. As conexões diretas nunca devem ser feitas de um cliente para o banco de dados de backend.

## Referência externa
[OWASP - segurança em baco de dados](https://cheatsheetseries.owasp.org/cheatsheets/Database_Security_Cheat_Sheet.html)