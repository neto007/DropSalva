---
title: Prefixo do host
---
## Descrição

É possível o fortalecimento dos cookies de sessão usando o prefixo '__Host ". Com isso, podemos evitar a configuração incorreta de exemplo dos Path=/, Secure cookie e atributos de domínio.

## Solução

O prefixo '__Host' indica ao navegador que os atributos Path=/ e Secure são necessários,
e, ao mesmo tempo, que o atributo Domain pode não estar presente.