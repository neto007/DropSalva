---
title: Teste a configuração do servidor
---

Depois que o servidor for protegido, a configuração deve ser testada. O capítulo OWASP Testing Guide sobre SSL / TLS Testing contém mais informações sobre o teste.

Existem várias ferramentas online que podem ser usadas para validar rapidamente a configuração de um servidor, incluindo:

- [SSL Labs Server Test](https://www.ssllabs.com/ssltest)

- [CryptCheck](https://cryptcheck.fr/)

- [CypherCraft](https://www.cyphercraft.io/tls)

- [Hardenize](https://www.hardenize.com/)

- [ImmuniWeb](https://www.immuniweb.com/ssl/)

- [Observatory by Mozilla](https://observatory.mozilla.org/)

Além disso, existem várias ferramentas offline que podem ser usadas:

- [O-Saft - ferramenta forense avançada OWASP SSL](https://wiki.owasp.org/index.php/O-Saft)

- [CipherScan](https://github.com/mozilla/cipherscan)

- [CryptoLyzer](https://gitlab.com/coroner/cryptolyzer)

- [SSLScan - Fast SSL Scanner](https://github.com/rbsec/sslscan)

- [SSLyze](https://github.com/nabla-c0d3/sslyze)

- [testssl.sh - Testando qualquer criptografia TLS / SSL](https://testssl.sh/)

- [tls-scan](https://github.com/prbinu/tls-scan)

### Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/)