---
title: Use nomes de domínio corretos
---

O nome de domínio (ou assunto) do certificado deve corresponder ao nome totalmente qualificado do servidor que apresenta o certificado. Historicamente, isso era armazenado no `commonName` (CN) do certificado. No entanto, as versões modernas do Chrome ignoram o atributo CN e exigem que o FQDN esteja no `subjectAlternativeName` (SAN). Por motivos de compatibilidade, os certificados devem ter o FQDN principal no CN e a lista completa de FQDNs na SAN.

Além disso, ao criar o certificado, o seguinte deve ser levado em consideração:

- Considere se o subdomínio "www" também deve ser incluído.

- Não inclua nomes de host não qualificados.

- Não inclua endereços IP.

- Não inclua nomes de domínio internos em certificados externos.

- Se um servidor estiver acessível usando FQDNs internos e externos, configure-o com vários certificados.

### Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/)