---
title: Salting
---

Um salt é uma string única gerada aleatoriamente que é adicionada a cada senha como parte do processo de hashing. Como o salt é exclusivo para cada usuário, um invasor precisa quebrar os hashes um por vez usando o respectivo salt, em vez de poder calcular um hash uma vez e compará-lo com cada hash armazenado. Isso torna o cracking de um grande número de hashes significativamente mais difícil, pois o tempo necessário aumenta em proporção direta ao número de hashes.

Salting também fornece proteção contra hashes de pré-computação de invasores usando "tabelas de arco-íris" ou pesquisas baseadas em banco de dados. Por fim, salt significa que não é possível determinar se dois usuários têm a mesma senha sem quebrar os hashes, pois os diferentes satls resultarão em hashes diferentes, mesmo que as senhas sejam iguais.

Algoritmos de hash modernos, como Argon2 ou Bcrypt utilizam salt automaticamente, portanto, nenhuma etapa adicional é necessária ao usá-los. No entanto, se você estiver usando um algoritmo de hash de senha legado, o salt precisa ser implementado manualmente. As etapas básicas para fazer isso são:

* Gere um sal usando uma função criptograficamente segura.
    * O salt deve ter pelo menos 16 caracteres.
    * Codifique o salt em um conjunto de caracteres seguro, como hexadecimal ou Base64.
* Combine o salt com a senha.
    * Isso pode ser feito usando concatenação simples ou uma construção como um HMAC.
* Hash a senha combinada e salt.
* Armazene o salt e o hash da senha.

## Referência externa
[OWASP - Salt](https://cheatsheetseries.owasp.org/cheatsheets/Password_Storage_Cheat_Sheet.html#hashing-concepts)