---
title: Use uma autoridade de certificação apropriada para a base de usuários do aplicativo
---

Para serem confiáveis ​​pelos usuários, os certificados devem ser assinados por uma autoridade de certificação (CA) confiável. Para aplicativos voltados para a Internet, deve ser uma das CAs bem conhecidas e confiáveis ​​automaticamente pelos sistemas operacionais e navegadores.

O [LetsEncrypt CA](https://letsencrypt.org/) fornece certificados SSL validados por domínio gratuitos, que são confiáveis ​​para todos os principais navegadores. Como tal, considere se há algum benefício em comprar um certificado de uma CA.

Para aplicativos internos, um CA interno pode ser usado. Isso significa que o FQDN do certificado não será exposto (seja para uma CA externa ou publicamente nas listas de transparência de certificado). No entanto, o certificado só será confiável para usuários que importaram e confiaram no certificado CA interno que foi usado para assiná-los.

### Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/)