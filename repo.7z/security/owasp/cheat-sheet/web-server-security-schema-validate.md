---
title: Validação de esquema
---

A validação do esquema impõe restrições e sintaxe definidas pelo esquema.

**Regra:** os serviços da Web devem validar cargas úteis SOAP em sua definição de esquema XML ( XSD ) associada .

**Regra:** O XSD definido para um serviço da web SOAP deve, no mínimo, definir o comprimento máximo e o conjunto de caracteres de cada parâmetro permitido para entrar e sair do serviço da web.

**Regra:** O XSD definido para um serviço da web SOAP deve definir padrões de validação fortes (de preferência, lista branca) para todos os parâmetros de formato fixo (por exemplo, códigos postais, números de telefone, valores de lista, etc.).

## Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/)