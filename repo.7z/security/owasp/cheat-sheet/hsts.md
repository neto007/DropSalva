---
title: HSTS
---

O HTTP Strict Transport Security (também denominado HSTS ) é um aprimoramento de segurança  que é especificado por um aplicativo da web por meio do uso de um cabeçalho de resposta especial. Assim que um navegador com suporte receber esse cabeçalho, esse navegador impedirá que qualquer comunicação seja enviada por HTTP para o domínio especificado e, em vez disso, enviará todas as comunicações por HTTPS. Ele também evita cliques de HTTPS em prompts em navegadores.

A especificação foi lançada e publicada no final de 2012 como RFC 6797 (HTTP Strict Transport Security (HSTS)) pela IETF.

## Ameaças
O HSTS aborda as seguintes ameaças:

* O usuário adiciona favoritos ou digita manualmente http://example.come está sujeito a um atacante intermediário.
* O HSTS redireciona automaticamente as solicitações HTTP para HTTPS para o domínio de destino.
* O aplicativo da Web que se destina a ser puramente HTTPS contém inadvertidamente links HTTP ou fornece conteúdo por HTTP.
* O HSTS redireciona automaticamente as solicitações HTTP para HTTPS para o domínio de destino.
* Um invasor man-in-the-middle tenta interceptar o tráfego de um usuário vítima usando um certificado inválido e espera que o usuário aceite o certificado inválido.
* O HSTS não permite que um usuário substitua a mensagem de certificado inválido.

## Exemplos

Este exemplo é útil se todos os subdomínios presentes e futuros forem HTTPS. Esta é uma opção mais segura, mas bloqueará o acesso a certas páginas que só podem ser servidas por HTTP:

`Strict-Transport-Security: max-age=31536000; includeSubDomains`

## Recomendado:

Se o proprietário do site quiser que seu domínio seja incluído na lista de pré-carregamento do HSTS mantida pelo Chrome (e usada pelo Firefox e Safari).

`Strict-Transport-Security: max-age=31536000; includeSubDomains; preload`

O preload sinalização indica o consentimento do proprietário do site em ter seu domínio pré-carregado.

## Problemas
Os proprietários de sites podem usar o HSTS para identificar usuários sem cookies. Isso pode levar a um vazamento significativo de privacidade.

Os cookies podem ser manipulados a partir de subdomínios, portanto, omitir a opção **includeSubDomains** permite uma ampla gama de ataques relacionados a cookies que o HSTS evitaria ao exigir um certificado válido para um subdomínio. Garantir que o sinalizador esteja definido em todos os cookies também evitará alguns, mas não todos os ataques.