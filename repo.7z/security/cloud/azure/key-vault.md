---
title: Azure Key Vault
sidebar_label: Key Vault
---

**Proposta de melhores práticas de segurança para o uso de Key Vaut na Azure:**

O Azure Key Vault é um serviço de nuvem que protege segredos, chaves, certificados, strings de conexão e senhas. Como esses dados são confidenciais e comercialmente críticos, é necessário proteger o acesso aos Key Vaults permitindo apenas aplicativos e usuários autorizados.

O objetivo desse documento é descrever as melhores práticas de segurança, para a correta configuração dos Key Vaults nas assinaturas da Azure.

## Recomendações

**Recomendações de alto nível**
- É recomendada a criação de Key Vaults separados para cada Resource Group;
- Mantenha uma gestão de acessos restritiva, tanto ao Management Plane como ao Data Plane;
- Garanta backups regulares [[Referência](https://docs.microsoft.com/en-us/azure/key-vault/general/security-baseline#91-ensure-regular-automated-back-ups "https://docs.microsoft.com/en-us/azure/key-vault/general/security-baseline#91-ensure-regular-automated-back-ups")];
- Ative as opções de recuperação “Soft Delete” e “Purge Protection” [[Referência](https://docs.microsoft.com/en-us/azure/key-vault/general/soft-delete-overview "https://docs.microsoft.com/en-us/azure/key-vault/general/soft-delete-overview")];
- Ative os logs de acesso [[Referência](https://docs.microsoft.com/en-us/azure/key-vault/general/logging "https://docs.microsoft.com/en-us/azure/key-vault/general/logging")];
- Limite a exposição do Key Vault somente para redes que precisem deste acesso (utilizando Private Link ou Service Endpoint);
- Realizar a troca periódica das chaves.

**Gerenciamento de identidade e acesso**
- Centralizar a concessão de acesso através de contas do Active Directory;    
- Recomendamos que os novos Key Vaults sejam criados utilizando o modelo Azure role-based access control [[Referência]](https://docs.microsoft.com/en-us/azure/key-vault/general/rbac-guide "https://docs.microsoft.com/en-us/azure/key-vault/general/rbac-guide");  
- Manter a regra do menor privilegio;
- Limitar o número de usuários com acesso de “Contributor” ou superior, o usuário pode conceder a si mesmo o acesso aos segredos, definindo uma “Access Policies” do Key Vault.
        
**Redes**
- Não é permitido acesso público a Key Vault. Toda exceção deverá ser aprovada previamente pela equipe de Segurança da Informação.  
- Limite a exposição do Key Vault somente para redes que precisem deste acesso (utilizando Private Link ou Service Endpoint).  
- Recomendado o uso de private endpoint para comunicação com key vault através de redes internas;
        
**Monitoração**  
- Habilite o log do Azure Key Vault para garantir o registro de atividades executadas nos cofres (criação ou exclusão de cofres, chaves, segredos) [[Referência](https://docs.microsoft.com/en-us/azure/key-vault/general/logging "https://docs.microsoft.com/en-us/azure/key-vault/general/logging")];  
- Habilite o Diagnostics Logs, isso permite recriar trilhas de atividades para fins de investigação quando ocorre um incidente de segurança ou quando a rede é comprometida.
                
**Data Protection**
- Ative as opções “Soft Delete” e “Purge Protection” [[Referência](https://docs.microsoft.com/en-us/azure/key-vault/general/soft-delete-overview "https://docs.microsoft.com/en-us/azure/key-vault/general/soft-delete-overview")], elas permitirão a recuperação de cofres e objetos excluídos acidentalmente;

**Gerenciamento de chaves, segredos e certificados**
- Criar acessos restritivos para cada acesso/aplicação;
- Rotacionar as chaves, pois as chaves devem ser trocadas periodicamente para minimizar o período de exposição em caso de comprometimento da chave;

## Políticas de prevenção e detecção
Abaixo alguns campos para correta configuração do Key Vault. Os itens destacados já estão aplicados com as polices de prevenção.

![Políticas de prevenção e detecção](/assets/security/cloud/azure-key-vault.png)

Fontes:  
- [https://docs.microsoft.com/en-us/azure/key-vault/general/best-practices](https://docs.microsoft.com/en-us/azure/key-vault/general/best-practices "https://docs.microsoft.com/en-us/azure/key-vault/general/best-practices")
- [https://docs.microsoft.com/en-us/azure/key-vault/general/security-recommendations](https://docs.microsoft.com/en-us/azure/key-vault/general/security-recommendations "https://docs.microsoft.com/en-us/azure/key-vault/general/security-recommendations")
- [https://docs.microsoft.com/en-us/azure/key-vault/general/security-baseline](https://docs.microsoft.com/en-us/azure/key-vault/general/security-baseline "https://docs.microsoft.com/en-us/azure/key-vault/general/security-baseline")
- [https://docs.microsoft.com/en-us/azure/key-vault/general/secure-your-key-vault](https://docs.microsoft.com/en-us/azure/key-vault/general/secure-your-key-vault "https://docs.microsoft.com/en-us/azure/key-vault/general/secure-your-key-vault")
- [https://docs.microsoft.com/en-us/azure/security/benchmarks/overview](https://docs.microsoft.com/en-us/azure/security/benchmarks/overview "https://docs.microsoft.com/en-us/azure/security/benchmarks/overview")
- [https://docs.microsoft.com/en-us/azure/key-vault/general/security-baseline#91-ensure-regular-automated-back-ups](https://docs.microsoft.com/en-us/azure/key-vault/general/security-baseline#91-ensure-regular-automated-back-ups "https://docs.microsoft.com/en-us/azure/key-vault/general/security-baseline#91-ensure-regular-automated-back-ups")
- [https://docs.microsoft.com/en-us/azure/key-vault/general/rbac-guide](https://docs.microsoft.com/en-us/azure/key-vault/general/rbac-guide "https://docs.microsoft.com/en-us/azure/key-vault/general/rbac-guide")