---
title: Detecção de Ataques de Sessão
---

## Adivinhação de ID de sessão e detecção de força bruta

Se um invasor tentar adivinhar ou usar força bruta em um ID de sessão válido, ele precisará lançar várias solicitações sequenciais contra o aplicativo da Web de destino usando diferentes IDs de sessão de um único (ou conjunto de) endereços IP. Além disso, se um invasor tentar analisar a previsibilidade do ID da sessão (por exemplo, usando análise estatística), ele precisará lançar várias solicitações sequenciais de um único (ou conjunto de) endereços IP em relação ao aplicativo da web de destino para reunir novos IDs de sessão.

Os aplicativos da Web devem ser capazes de detectar ambos os cenários com base no número de tentativas de reunir (ou usar) diferentes IDs de sessão e alertar e / ou bloquear o (s) endereço (s) IP ofensivo (s).

## Detecção de anomalias de ID de sessão

Os aplicativos da Web devem se concentrar na detecção de anomalias associadas ao ID da sessão, como sua manipulação. O Projeto OWASP AppSensor fornece uma estrutura e metodologia para implementar recursos integrados de detecção de intrusão em aplicativos da web com foco na detecção de anomalias e comportamentos inesperados, na forma de pontos de detecção e ações de resposta. Em vez de usar camadas de proteção externas, às vezes os detalhes da lógica de negócios e inteligência avançada estão disponíveis apenas de dentro do aplicativo da web, onde é possível estabelecer vários pontos de detecção relacionados à sessão, como quando um cookie existente é modificado ou excluído, um novo cookie é adicionado, o ID da sessão de outro usuário é reutilizado ou quando a localização do usuário ou o Agente do Usuário muda no meio de uma sessão.

## Vinculando a ID da sessão a outras propriedades do usuário

Com o objetivo de detectar (e, em alguns cenários, proteger contra) comportamentos inadequados do usuário e sequestro de sessão, é altamente recomendável vincular o ID da sessão a outras propriedades do usuário ou cliente, como o endereço IP do cliente, Agente do Usuário ou cliente certificado digital baseado em Se o aplicativo da web detectar qualquer mudança ou anomalia entre essas diferentes propriedades no meio de uma sessão estabelecida, este é um bom indicador de manipulação de sessão e tentativas de sequestro, e este simples fato pode ser usado para alertar e / ou encerrar a sessão suspeita .

Embora essas propriedades não possam ser usadas por aplicativos da Web para uma defesa confiável contra ataques de sessão, elas aumentam significativamente os recursos de detecção (e proteção) de aplicativos da Web. No entanto, um invasor habilidoso pode ignorar esses controles reutilizando o mesmo endereço IP atribuído ao usuário vítima, compartilhando a mesma rede (muito comum em ambientes NAT, como hotspots Wi-Fi) ou usando o mesmo proxy de saída da web (muito comum em ambientes corporativos), ou modificando manualmente seu User-Agent para parecer exatamente como os usuários vítimas.

## Ciclo de vida das sessões de registro: monitoramento da criação, uso e destruição de IDs de sessão

Os aplicativos da Web devem aumentar seus recursos de registro, incluindo informações sobre o ciclo de vida completo das sessões. Em particular, é recomendado registrar eventos relacionados à sessão, como a criação, renovação e destruição de IDs de sessão, bem como detalhes sobre seu uso em operações de login e logout, alterações de nível de privilégio dentro da sessão, expiração de tempo limite, sessão inválida atividades (quando detectadas) e operações críticas de negócios durante a sessão.

Os detalhes do log podem incluir um carimbo de data / hora, endereço IP de origem, recurso de destino da web solicitado (e envolvido em uma operação de sessão), cabeçalhos HTTP (incluindo o Agente do Usuário e Referer), parâmetros GET e POST, códigos de erro e mensagens, nome de usuário (ou ID do usuário), mais o ID da sessão (cookies, URL, GET, POST ...).

Dados confidenciais, como o ID da sessão, não devem ser incluídos nos logs para proteger os logs da sessão contra divulgação local ou remota do ID da sessão ou acesso não autorizado. No entanto, algum tipo de informação específica da sessão deve ser registrada para correlacionar entradas de log a sessões específicas. É recomendável registrar um hash salgado do ID da sessão em vez do próprio ID da sessão para permitir a correlação de log específica da sessão sem expor o ID da sessão.

Em particular, os aplicativos da web devem proteger completamente as interfaces administrativas que permitem gerenciar todas as sessões ativas atuais. Freqüentemente, eles são usados ​​pela equipe de suporte para resolver problemas relacionados à sessão, ou mesmo problemas gerais, personificando o usuário e olhando para o aplicativo da web como o usuário o faz.

Os logs de sessão tornam-se uma das principais fontes de dados de detecção de intrusão de aplicativos da web e também podem ser usados ​​por sistemas de proteção contra intrusão para encerrar sessões automaticamente e / ou desativar contas de usuário quando (um ou vários) ataques são detectados. Se as proteções ativas forem implementadas, essas ações defensivas também devem ser registradas.

## Logons de sessão simultâneos

É a decisão de design do aplicativo da web determinar se vários logons simultâneos do mesmo usuário são permitidos do mesmo ou de diferentes endereços IP de cliente. Se o aplicativo da web não quiser permitir logons de sessão simultâneos, ele deve tomar ações eficazes após cada novo evento de autenticação, encerrando implicitamente a sessão disponível anteriormente ou perguntando ao usuário (por meio da antiga, nova ou ambas as sessões) sobre a sessão que deve permanecer ativo.

É recomendado para aplicativos da web adicionar recursos de usuário que permitem verificar os detalhes das sessões ativas a qualquer momento, monitorar e alertar o usuário sobre logons simultâneos, fornecer recursos de usuário para encerrar remotamente as sessões manualmente e rastrear o histórico de atividades da conta (diário de bordo) por meio de vários detalhes do cliente, como endereço IP, agente do usuário, data e hora de login, tempo ocioso, etc.

### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)