---
title: Envio de dados para dispositivos não confiáveis
---
## Descrição

Sempre que um aplicativo envia dados/parâmetros para dispositivos não confiáveis, esses dados podem ser comprometido se o dispositivo tiver intenções maliciosas.

## Solução

Verifique se o aplicativo minimiza o número de parâmetros enviados para sistemas não confiáveis, como campos ocultos, variáveis ​​Ajax, cookies e valores de cabeçalho.

Esses dispositivos não confiáveis ​​também devem ser documentados, se possível, e devem ser considerados conta ao desenvolver seu aplicativo para minimizar a possibilidade de enviar
dados confidenciais indesejados para esses dispositivos.

Itens recomendados da base de conhecimento:

- A arquitetura de alto nível deve ser definida
- Identifique todos os componentes do aplicativo