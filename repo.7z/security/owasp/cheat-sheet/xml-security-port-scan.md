---
title: Escaneamento porta
---

A quantidade e o tipo de informação dependerão do tipo de implementação. As respostas podem ser classificadas da seguinte maneira, de fácil a complexo:

**1) Divulgação completa:** o cenário mais simples e incomum, com divulgação completa você pode ver claramente o que está acontecendo ao receber as respostas completas do servidor que está sendo consultado. Você tem uma representação exata do que aconteceu ao se conectar ao host remoto.

**2) Com base em erro:** Se você não conseguir ver a resposta do servidor remoto, poderá usar a resposta de erro. Considere um serviço da web vazando detalhes sobre o que deu errado no elemento SOAP Fault ao tentar estabelecer uma conexão:

```java

java.io.IOException: Server returned HTTP response code: 401 for URL: http://192.168.1.1:80
 at sun.net.www.protocol.http.HttpURLConnection.getInputStream(HttpURLConnection.java:1459)
 at com.sun.org.apache.xerces.internal.impl.XMLEntityManager.setupCurrentEntity(XMLEntityManager.java:674)

```

**3) Com base em tempo limite:** os tempos limite podem ocorrer durante a conexão com portas abertas ou fechadas, dependendo do esquema e da implementação subjacente. Se os tempos limite ocorrerem enquanto você estiver tentando se conectar a uma porta fechada (o que pode levar um minuto), o tempo de resposta quando conectado a uma porta válida será muito rápido (um segundo, por exemplo). As diferenças entre portas abertas e fechadas tornam-se bastante claras.

**4) Baseado no tempo:** às vezes, as diferenças entre portas fechadas e abertas são muito sutis. A única maneira de saber o status de uma porta com certeza seria fazer várias medições do tempo necessário para alcançar cada host; em seguida, analise o tempo médio de cada porta para determinar o status de cada porta. Esse tipo de ataque será difícil de realizar quando executado em redes de latência mais alta.

### Força bruta

Depois que um invasor confirma que é possível executar uma varredura de porta, executar um ataque de força bruta é uma questão de incorporar `username`e `password` como parte do esquema de URI (http, ftp, etc). Por exemplo, o seguinte:

```xml 
<!DOCTYPE root [
 <!ENTITY user SYSTEM "http://username:password@example.com:8080">
]>
<root>&user;</root>
```

## Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/cheatsheets/XML_Security_Cheat_Sheet.html)