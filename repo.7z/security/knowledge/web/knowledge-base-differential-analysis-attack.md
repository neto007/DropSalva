---
title: Análise Diferencial Ataque
---
## Descrição

Sempre que um invasor envia uma solicitação ao servidor, por exemplo, por meio de
funcionalidade de autenticação, ele pode medir o tempo médio de resposta entre uma solicitação contendo um nome de usuário válido e uma solicitação que contém um nome de usuário inválido. O invasor agora pode usar esse diferencial no tempo de resposta para enumerar contas de usuário

## Solução

Verifique se todos os desafios de autenticação, com êxito ou com falha, devem responder
no mesmo tempo médio de resposta. Essa mesma metodologia se aplica a outras informações confidenciais que poderiam potencialmente ser recuperado com ataques diferenciais.