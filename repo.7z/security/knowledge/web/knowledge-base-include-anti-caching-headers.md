---
title: Inclua cabeçalhos anti-caching
---
## Descrição

Os cabeçalhos anti-cache têm a capacidade de informar ao navegador,
computador e proxies quais informações eles podem ou não armazenar na mídia intermediária

## Solução

Esses cabeçalhos também são conhecidos como: Controle de cache: sem armazenamento, sem cache e fornecem proteção de informações confidenciais quando implementadas no aplicativo ou servidor web. Os cabeçalhos anti caching corretamente configurados terão a seguinte aparência como resposta.

```html
Expires: Tue, 03 Jul 2001 06:00:00 GMT
Last-Modified: {now} GMT
Cache-Control: no-store, no-cache, must-revalidate, max-age=0
Cache-Control: post-check=0, pre-check=0
```