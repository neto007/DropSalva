---
title: Ataque de cookie entre subdomínios
---
## Descrição

Uma rápida visão geral de como funciona:

1. Um site www.example.com distribui subdomínios a terceiros não confiáveis
2. Uma dessas partes, John, que agora controla evil.example.com, atrai Alice para o site dela.
3. Uma visita a evil.example.com define um cookie de sessão com o domínio .example.com no navegador de Alice
4. Quando Alice visitar o site www.example.com, esse cookie será enviado com a solicitação, conforme as especificações dos cookies, e Alice terá a sessão especificada pelo cookie de John.
5. John agora pode usar a conta de Alice.

## Solução

Nesse cenário, alterar o ID da sessão no login não faz nenhuma diferença, pois
Alice já está logada quando visita a página do mal de John.

É uma boa prática usar um domínio completamente diferente para todas as atividades confiáveis.

Por exemplo, o Google usa google.com para atividades confiáveis ​​e * .googleusercontent.com para sites não confiáveis.

Além disso, ao configurar seus cookies para especificar quais domínios eles têm permissão para ser enviado. Especialmente no seu domínio confiável, se você não deseja vazar cookies para subdomínios. altamente recomendado é não usar curingas ao definir esta opção.