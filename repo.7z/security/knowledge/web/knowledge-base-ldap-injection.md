---
title: Injecção LDAP
---
## Descrição

A injeção LDAP (Lightweight Directory Access Protocol) é um ataque usado para explorar aplicativos baseados na Web que constroem instruções LDAP com base na entrada do usuário. Quando um aplicativo falha na limpeza adequada da entrada do usuário, é possível modificar as instruções LDAP usando um proxy local. Isso pode resultar na execução de comandos arbitrários, como concessão de permissões para consultas não autorizadas e modificação do conteúdo dentro da árvore LDAP. As mesmas técnicas avançadas de exploração disponíveis no SQL Injection podem ser aplicadas de maneira semelhante no LDAP Injection.

## Solução

A melhor maneira de impedir a injeção de LDAP é usar um esquema de validação positivo para garantir que os dados que entram nas suas consultas não contenham ataques. No entanto, em alguns casos, é necessário incluir caracteres especiais na entrada que é passada para uma consulta LDAP. Nesse caso, o uso de escape pode impedir que o intérprete LDAP pense que esses caracteres especiais são realmente parte da consulta LDAP.
