---
title: Injeção de script dinâmico
---
## Descrição

Quando a entrada do usuário é usada para avaliar o código de script, riscos de alta segurança podem ser introduzidos. Se a entrada não for escapada adequadamente, um invasor poderá injetar seu próprio código de script e obter acesso ao servidor.

## Solução

Não use entrada direta do usuário na função de script dinâmico. Você deveria primeiro
usar uma validação de entrada ou função de codificação nos dados enviados pelo usuário para limpar e sanitizar a entrada contra intenções maliciosas.