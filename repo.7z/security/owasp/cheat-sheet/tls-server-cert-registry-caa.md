---
title: Use registros CAA para restringir quais CAs podem emitir certificados
---

Os registros DNS da Autorização da Autoridade de Certificação (CAA) podem ser usados ​​para definir quais CAs têm permissão para emitir certificados para um domínio. Os registros contêm uma lista de CAs e qualquer CA que não esteja incluída nessa lista deve se recusar a emitir um certificado para o domínio. Isso pode ajudar a impedir que um invasor obtenha certificados não autorizados para um domínio por meio de uma CA de menor reputação. Onde é aplicado a todos os subdomínios, também pode ser útil de uma perspectiva administrativa, limitando quais CAs os administradores ou desenvolvedores podem usar e evitando que eles obtenham certificados curinga não autorizados.

### Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/)