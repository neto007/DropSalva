---
title: Comunicação interna insegura
---
## Descrição

Sempre que as organizações se comunicam por meio de conexões não criptografadas, um invasor
poderia facilmente detectar comunicações inseguras e acessar informações confidenciais.

## Solução

Use linhas de dados criptografadas TLS para todos os canais de comunicação internos.
Além disso, sua infraestrutura não deve utilizar links não criptografados ou com criptografia fraca. Porque, neste caso, toda a integridade e confidencialidade dos seus dados será perdida.
