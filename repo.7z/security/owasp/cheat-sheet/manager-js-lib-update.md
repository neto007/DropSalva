---
title: Manter as bibliotecas JavaScript atualizadas
---

[OWASP Top 10 2013 A9](https://wiki.owasp.org/index.php/Top_10_2013-A9-Using_Components_with_Known_Vulnerabilities) descreve o problema de usar componentes com vulnerabilidades conhecidas. Isso inclui bibliotecas JavaScript. As bibliotecas JavaScript devem ser mantidas atualizadas, pois a versão anterior pode ter vulnerabilidades conhecidas que podem fazer com que o site fique vulnerável a Cross Site Scripting . Existem várias ferramentas por aí que podem ajudar a identificar essas bibliotecas. Uma dessas ferramentas é a ferramenta gratuita de código aberto RetireJS

### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)