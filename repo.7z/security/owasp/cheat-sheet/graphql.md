---
title: GraphQL o que é?
---

GraphQL é uma linguagem de consulta de código aberto originalmente desenvolvida pelo Facebook que pode ser usada para construir APIs como uma alternativa para REST e SOAP. Ele ganhou popularidade desde seu início em 2012 por causa da flexibilidade nativa que oferece para aqueles que criam e chamam a API. Existem servidores e clientes GraphQL implementados em várias linguagens. Muitas empresas usam GraphQL, incluindo GitHub, Credit Karma, Intuit e PayPal.

Esta página fornece orientação sobre as várias áreas que precisam ser consideradas ao trabalhar com GraphQL:

* Aplique verificações de validação de entrada adequadas em todos os dados de entrada.
* Consultas longas podem levar à negação de serviço (DoS), então adicione verificações para limitar ou evitar consultas que são muito demoradas.
* Certifique-se de que a API tenha verificações de controle de acesso adequadas.
* Desabilite configurações padrão inseguras ( por exemplo , introspecção, GraphiQL, erros excessivos, etc.).

## Ataques Comuns

* Injeção de SQL e NoSQL.
* Injeção OS Command.
* Injeção de SSRF e CRLF.
* DoS (negação de serviço)
* Abuso de autorização: acesso impróprio ou excessivo.
* Ataques em lote, um método específico do GraphQL de ataque de força bruta.
* Abuso de configurações padrão inseguras.