---
title: Ataques offline em senhas
---
## Descrição

As senhas armazenadas localmente são frequentemente vulneráveis a ataques offline, como ataques de dicionário (lista de senhas conhecidas), bruteforce (permutação de todas as combinações possíveis) e tabelas arco-íris (geram hashes antecipadamente e pesquisam cada hash). Como pertencemos a uma geração de computadores de alta velocidade que executam esses ataques é uma tarefa bastante trivial para os invasores.

## Solução

A solução mais eficaz para eliminar ataques offline à senha é impor o uso de senhas fortes e usar de maneira muito proeminente os algoritmos de hash reconhecidos pela indústria com um mecanismo de salga. Temos hash de senhas porque, no caso de um invasor obter acesso de leitura ao nosso banco de dados, não queremos que ele recupere as senhas em texto simples. Um salt é um valor único e não secreto no banco de dados, que é anexado (dependendo do algoritmo usado) à senha antes de ser hash.

Alguns dos algoritmos de hash conhecidos são os seguintes:

MD5 (Crytographically Broken),
SHA1 (Crytographically Broken),
SHA2,
SHA3,
PBKDF2,
bcrypt (defacto standard)
e scrypt.