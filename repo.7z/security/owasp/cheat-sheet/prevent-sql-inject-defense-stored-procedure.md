---
title: Defesa contra SQL inject - Procedimento armazenados
---

s procedimentos armazenados nem sempre estão protegidos contra injeção de SQL. No entanto, certas construções de programação de procedimento armazenado padrão têm o mesmo efeito que o uso de consultas parametrizadas quando implementadas com segurança, o que é a norma para a maioria das linguagens de procedimento armazenado.

Eles exigem que o desenvolvedor apenas construa instruções SQL com parâmetros que são parametrizados automaticamente, a menos que o desenvolvedor faça algo fora do normal. A diferença entre instruções preparadas e procedimentos armazenados é que o código SQL para um procedimento armazenado é definido e armazenado no próprio banco de dados e, em seguida, chamado do aplicativo. Ambas as técnicas têm a mesma eficácia na prevenção da injeção de SQL, portanto, sua organização deve escolher qual abordagem faz mais sentido para você.

Nota: 'Implementado com segurança' significa que o procedimento armazenado não inclui nenhuma geração de SQL dinâmica não segura. Os desenvolvedores geralmente não geram SQL dinâmico dentro de procedimentos armazenados. No entanto, isso pode ser feito, mas deve ser evitado. Se não puder ser evitado, o procedimento armazenado deve usar validação de entrada ou escape adequado conforme descrito neste artigo para garantir que todas as entradas fornecidas pelo usuário para o procedimento armazenado não possam ser usadas para injetar código SQL na consulta gerada dinamicamente. Os auditores devem sempre procurar usos de `sp_execute`, `execute` ou `exec` nos procedimentos armazenados do SQL Server. Diretrizes de auditoria semelhantes são necessárias para funções semelhantes para outros fornecedores.

Existem também vários casos em que procedimentos armazenados podem aumentar o risco. Por exemplo, no servidor MS SQL, você tem 3 principais funções padrão: `db_datareader`, `db_datawriter`e `db_owner`. Antes de os procedimentos armazenados entrarem em uso, os DBAs davam direitos `db_datareader` ou `db_datawriter` ao usuário do serviço da web, dependendo dos requisitos. No entanto, os procedimentos armazenados requerem direitos de execução, uma função que não está disponível por padrão. Algumas configurações em que o gerenciamento de usuários foi centralizado, mas limitado a essas 3 funções, fazem com que todos os aplicativos da web sejam executados com direitos `db_owner` para que os procedimentos armazenados possam funcionar. Naturalmente, isso significa que, se um servidor for violado, o invasor terá todos os direitos sobre o banco de dados, onde antes eles poderiam ter apenas acesso de leitura.

Exemplo de procedimento armazenado de Java seguro :

O exemplo de código a seguir usa uma `CallableStatement` implementação do Java, interface de procedimento armazenado para executar a mesma consulta de banco de dados. O `sp_getAccountBalance` teria que ser predefinido no banco de dados e implementar a mesma funcionalidade da consulta definida acima.

```java

// This should REALLY be validated
String custname = request.getParameter("customerName");
try {
  CallableStatement cs = connection.prepareCall("{call sp_getAccountBalance(?)}");
  cs.setString(1, custname);
  ResultSet results = cs.executeQuery();
  // … result set handling
} catch (SQLException se) {
  // … logging and error handling
}

```

Exemplo de procedimento armazenado do VB .NET seguro :

O exemplo de código a seguir usa o `SqlCommand` do .NET da interface de procedimento armazenado para executar a mesma consulta de banco de dados. O `sp_getAccountBalance` teria que ser predefinido no banco de dados e implementar a mesma funcionalidade da consulta definida acima.

```vb

 Try
   Dim command As SqlCommand = new SqlCommand("sp_getAccountBalance", connection)
   command.CommandType = CommandType.StoredProcedure
   command.Parameters.Add(new SqlParameter("@CustomerName", CustomerName.Text))
   Dim reader As SqlDataReader = command.ExecuteReader()
   '...
 Catch se As SqlException
   'error handling
 End Try

```


### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)