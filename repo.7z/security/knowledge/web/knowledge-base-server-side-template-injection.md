---
title: Injeção De Template Do Lado Do Servidor
---
## Descrição

Sempre que a entrada fornecida pelo usuário é incorporada diretamente em um modelo quando o aplicativo faz uso de um mecanismo de modelagem (jinja2, twig, Freemarker), um invasor malicioso pode injetar e executar expressões de modelo. Mais frequentemente, a injeção de expressões de modelo acabará levando a vulnerabilidades de execução remota de código RCE.

Esse tipo de vulnerabilidade também é visto muito por meio de aplicativos que permitem ao usuário intencionalmente modificar o modelo para fornecer aos usuários uma maneira mais flexível de estilizar as páginas dos aplicativos, como uma página wiki ou sistema CMS.

## Solução

A entrada fornecida pelo usuário nunca deve ser usada diretamente em um modelo que usa um mecanismo de modelagem. O exemplo a seguir é uma pequena função de frasco python que renderiza a entrada fornecida pelo usuário como parte do modelo. Isso permite que um invasor malicioso execute comandos arbitrários quando.

```js
  @ app.errorhandler (404)
  def page_not_found (e):
      template = "" "
  <html>
  <p> {0} </p>
  </html>

  "" ".format (request.url)
      return render_template_string (template), 404
```

A maneira preferida de adicionar a entrada fornecida pelo usuário a este modelo seria:
```js
  @ app.errorhandler (404)
  def page_not_found (e):
    input = request.url
    return render_template ("errorpage.html", input = input), 404
```

Onde o conteúdo de errorpage.html ficaria

```js
  <html>
      <p> {input} </p>
  </html>
```