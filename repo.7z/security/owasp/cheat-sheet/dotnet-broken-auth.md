---
title: Autenticação segura em .Net
---

Use ASP.net Core Identity. O framework ASP.net Core Identity está bem configurado por padrão, onde usa hashes de senha seguros e um salt individual. A identidade usa a função de hash PBKDF2 para senhas e geram um salt aleatório por usuário.

Defina um política de senha segura. Por exemplo, ASP.net Core Identity:

```c#
//startup.cs
services.Configure<IdentityOptions>(options =>
{
 // Password settings
 options.Password.RequireDigit = true;
 options.Password.RequiredLength = 8;
 options.Password.RequireNonAlphanumeric = true;
 options.Password.RequireUppercase = true;
 options.Password.RequireLowercase = true;
 options.Password.RequiredUniqueChars = 6;


 options.Lockout.DefaultLockoutTimeSpan = TimeSpan.FromMinutes(30);
 options.Lockout.MaxFailedAccessAttempts = 3;

 options.SignIn.RequireConfirmedEmail = true;

 options.User.RequireUniqueEmail = true;
});
```
Defina uma política de cookies. Por exemplo:

```c#
//startup.cs
services.ConfigureApplicationCookie(options =>
{
 options.Cookie.HttpOnly = true;
 options.Cookie.Expiration = TimeSpan.FromHours(1)
 options.SlidingExpiration = true;
});
```
## Referência externa
[.Net security](https://cheatsheetseries.owasp.org/cheatsheets/DotNet_Security_Cheat_Sheet.html#a2-broken-authentication)