---
title: Pinagem de Certificado
---

Pinagem de certificado é o processo de associar um host ao certificado X509 ou chave pública esperados . Depois que um certificado ou chave pública é conhecido ou visto por um host, o certificado ou chave pública é associado ou 'fixado' ao host. Se mais de um certificado ou chave pública for aceitável, o programa terá um conjunto de certificado.

Um certificado ou chave pública de um host ou serviço pode ser adicionado a um aplicativo em tempo de desenvolvimento ou pode ser adicionado ao encontrar o certificado ou chave pública pela primeira vez. O primeiro - adicionar no momento do desenvolvimento - é preferível, pois o pré - carregamento do certificado ou da chave pública fora da banda normalmente significa que o invasor não pode corromper o pino.

### Quando realizar pinagem

Você deve fixá-lo sempre que quiser ter relativamente certeza da identidade do host remoto ou ao operar em um ambiente hostil. Como um ou ambos são quase sempre verdadeiros, você provavelmente deve fixar o tempo todo.

### Como fazer a pinagem

A ideia é reutilizar os protocolos e a infraestrutura existentes, mas usá-los de maneira reforçada. Para reutilização, um programa continuaria fazendo as coisas que costumava fazer ao estabelecer uma conexão segura.

Para fortalecer o canal, o programa aproveitaria o `OnConnectcallback` oferecido por uma biblioteca, framework ou plataforma. No retorno de chamada, o programa verificaria a identidade do host remoto validando seu certificado ou chave pública.

### O que deve ser pinado

A primeira coisa a decidir é o que deve ser fixado. Para esta escolha, você tem duas opções:

- Fixe o certificado.

- Fixe a chave pública.

Se você escolher as chaves públicas, terá duas opções adicionais:

- Fixar o subjectPublicKeyInfo.

- Pin um dos tipos de concreto, como RSAPublicKeyou DSAPublicKey.

**subjectPublicKeyInfo:**

![Pinning](/assets/devsecops/owasp/owasp-pining-1.png)

As três opções são explicadas abaixo com mais detalhes.

Eu encorajaria você a fixar o `subjectPublicKeyInfo` porque ele tem os parâmetros públicos (como `{e,n}` para uma chave pública RSA) e informações contextuais, como um algoritmo e OID. O contexto o ajudará a se orientar às vezes, e a figura à direita mostra as informações adicionais disponíveis.

**Certificado**

![Certificate](/assets/devsecops/owasp/owasp-pining-2.png)

O certificado é mais fácil de fixar. Você pode buscar o certificado fora da banda para o site da Web, fazer com que o pessoal de TI envie por e-mail o certificado da sua empresa para você, use `openssl s_client` para recuperar o certificado, etc. No tempo de execução, você recupera o certificado do site ou servidor no retorno de chamada. No retorno de chamada, você compara o certificado recuperado com o certificado incorporado no programa. Se a comparação falhar, o método ou função falhará.

Há uma desvantagem em fixar um certificado. Se o site alternar seu certificado regularmente, seu aplicativo precisará ser atualizado regularmente. Por exemplo, o Google alterna seus certificados, então você precisará atualizar seu aplicativo cerca de uma vez por mês (se depender dos serviços do Google). Mesmo que o Google alterne seus certificados, as chaves públicas subjacentes (dentro do certificado) permanecem estáticas.

**Chave Publica**

![key](/assets/devsecops/owasp/owasp-pining-3.png)

A fixação de chave pública é mais flexível, mas um pouco mais complicada devido às etapas extras necessárias para extrair a chave pública de um certificado. Como acontece com um certificado, o programa verifica a chave pública extraída com sua cópia incorporada da chave pública.

Existem duas desvantagens na fixação de chave pública. Primeiro, é mais difícil trabalhar com chaves (versus certificados), pois você deve extrair a chave do certificado. A extração é um pequeno inconveniente em Java e .Net, mas é desconfortável em Cocoa/CocoaTouch e OpenSSL. Em segundo lugar, a chave é estática e pode violar as políticas de rotação de chave.


### Exemplos de Pinagem

- [Android](manager-pinning-android.md)

- [IOS](manager-pinning-ios.md)

### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org)