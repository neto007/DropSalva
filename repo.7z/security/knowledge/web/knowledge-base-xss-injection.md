---
title: Injeção XSS
---
## Descrição

Cada vez que o aplicativo obtém uma entrada do usuário, seja mostrando na tela ou processando
esses dados no plano de fundo do aplicativo, esses parâmetros devem ser ignorados por
código para evitar injeções de script entre sites. Quando um invasor ganha a possibilidade de realizar uma injeção XSS, ele tem a oportunidade de injetar código HTML e JavaScript diretamente no inscrição. Isso pode fazer com que as contas sejam comprometidas pelo roubo de cookies de sessão ou diretamente afetar a operação do aplicativo de destino.

Apesar de mecanismos de modelagem (razor, twig, jinja, etc) e aplicativos sensíveis ao contexto (Angular, React, etc) faça muitos escapes automáticos para você. Essas estruturas sempre devem ser validadas quanto à eficácia.


## Solução

Para evitar injeções de XSS, todas as entradas do usuário devem ser escapadas ou codificadas.
Você pode começar limpando a entrada do usuário assim que for inserida no aplicativo,
de preferência usando um método denominado whitelisting. Isso significa que você não deve verificar se há conteúdo malicioso, como tags ou qualquer coisa, mas permite apenas a entrada esperada. Cada entrada que está fora da operação pretendida do aplicativo deve ser imediatamente detectado e o login rejeitado. Não tente ajudar a usar a entrada de nenhuma forma, pois isso poderia introduzir um novo tipo de ataque pela conversão de caracteres.

A segunda etapa seria codificar todos os parâmetros ou entrada do usuário antes de colocá-los
seu html com bibliotecas de codificação especialmente projetadas para esta finalidade.

Você deve levar em consideração que existem vários contextos para codificar a entrada do usuário para escapando de injeções XSS. Esses contextos são, entre outros:

* Codificação HTML, é para sempre que sua entrada do usuário é exibida diretamente em seu HTML.
* Codificação de atributo HTML, é o tipo de codificação / escape que deve ser aplicado
  sempre que sua entrada do usuário é exibida no atributo de suas tags HTML.
* Codificação de URL HTML, este tipo de codificação / escape deve ser aplicado sempre que você estiver usando a entrada do usuário em uma tag HREF.

A codificação JavaScript deve ser usada sempre que os parâmetros são renderizados via JavaScript; seu aplicativo detectará injeções normais no primeiro instante. Mas seu aplicativo ainda permanece vulnerável à codificação JavaScript, que não será detectada pelos métodos normais de codificação / escape.
