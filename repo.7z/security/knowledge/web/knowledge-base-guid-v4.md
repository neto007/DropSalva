---
title: GUID v4
---
## Descrição

Um identificador universalmente exclusivo (UUID) é um número de 128 bits usado para identificar informações em sistemas de computador. O termo identificador exclusivo global (GUID) também é usado, geralmente em software criado pela Microsoft.

## Solução

Um UUID da versão 4 é gerado aleatoriamente. Como em outros UUIDs, 4 bits são usados para indicar a versão 4 e 2 ou 3 bits para indicar a variante (102 ou 1102 para as variantes 1 e 2, respectivamente). Assim, para a variante 1 (ou seja, a maioria dos UUIDs), um UUID versão aleatória-4 terá 6 bits predeterminados de variante e versão, deixando 122 bits para a parte gerada aleatoriamente, para um total de 2122, ou 5,3 × 1036 (5,3 undecilhões), versão possível-4 UUIDs da variante-1. Existem metade do número possível de UUIDs da versão 4 e 2 (GUIDs herdados) porque há menos um bit aleatório disponível, sendo consumidos 3 bits para a variante.
