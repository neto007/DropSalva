---
title: Considere cuidadosamente o uso de certificados curinga
---


Os certificados curinga podem ser convenientes, no entanto, eles violam o principal de menor privilégio , pois um único certificado é válido para todos os subdomínios de um domínio (como `*.example.org`). Quando vários sistemas estão compartilhando um certificado curinga, a probabilidade de que a chave privada do certificado seja comprometida aumenta, pois a chave pode estar presente em vários sistemas. Além disso, o valor dessa chave é aumentado significativamente, tornando-a um alvo mais atraente para invasores.

Os problemas em torno do uso de certificados curinga são complicados e há várias outras discussões sobre eles online.

Ao avaliar o risco do uso de certificados curinga, as seguintes áreas devem ser consideradas:

- Use certificados curinga apenas onde houver uma necessidade genuína, e não por conveniência.

- Considere o uso do ACME para permitir que os sistemas solicitem e atualizem automaticamente seus próprios certificados.

- Nunca use certificados curinga para sistemas em diferentes níveis de confiança.

- Dois gateways VPN podem usar um certificado curinga compartilhado.

- Várias instâncias de um aplicativo da web podem compartilhar um certificado.

- Um gateway VPN e um servidor web público não devem compartilhar um certificado curinga.

- Um servidor da web público e um servidor interno não devem compartilhar um certificado curinga.

- Considere o uso de um servidor proxy reverso que executa a terminação TLS, de modo que a chave privada curinga esteja presente apenas em um sistema.

- Uma lista de todos os sistemas que compartilham um certificado deve ser mantida para permitir que todos sejam atualizados se o certificado expirar ou for comprometido.

- Limite o escopo de um certificado curinga emitindo-o para um subdomínio (como `*.foo.example.org`) ou para um domínio separado.

### Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/)