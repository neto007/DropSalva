---
title: Analisando formatos de troca de dados
---
## Descrição

Sempre que você estiver analisando formatos de troca de dados como XML, JSON, CSV etc., você deve garantir que sempre que esses arquivos de dados contenham código malicioso, isso não será executado pelo seu aplicativo. Você também não deve depender apenas do seu analisador para fazer toda a codificação e escape para você, pois sempre pode haver um caso extremo que executa determinados ataques.

## Solução

É altamente recomendável fazer sua própria codificação de escape, higienização e codificação em todos os dados antes de entrar no aplicativo. O risco também depende do contexto de onde você está colocando esses dados. Portanto, antes de fazer qualquer mutação nos seus dados após obtê-los dos recursos, verifique se você aplicou as atenuações corretas.

Além disso, outro motivo para criar uma camada extra de rotinas de escape, higienização e codificação em seu aplicativo é o registro que você deseja aplicar nos dados.


Itens recomendados da base de conhecimento:

- Rejeição de entrada
- Validação de entrada
- Logs de auditoria