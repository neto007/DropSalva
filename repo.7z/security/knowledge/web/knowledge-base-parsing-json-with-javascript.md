---
title: Analisando JSON com Javascript
---
## Descrição

A função eval() avalia ou executa um argumento.
Se o argumento for uma expressão, eval() avaliará a expressão. Se o argumento for uma ou mais instruções JavaScript, eval() executará as instruções.
Essa é exatamente a razão pela qual eval() NUNCA deve ser usado para analisar JSON ou outros formatos de dados que possam conter códigos maliciosos.

## Solução

Para fins de análise do JSON, recomendamos o uso da funcionalidade json.parse. Mesmo que essa função seja mais confiável, você sempre deve criar suas próprias verificações de segurança e rotinas de codificação em torno do json.parse antes de alterar os dados ou transmiti-los para uma exibição a ser exibida em seu HTML.