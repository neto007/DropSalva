---
title: STRIDE
---
## Descrição

STRIDE é um coletivo para uma série de vulnerabilidades que seus aplicativos devem
para aumentar a segurança de seus aplicativos.

STRIDE significa:
Spoofing
Adulteração
Repúdio
Divulgação de informação
Elevação de privilégio

## Solução

O STRIDE foi criado inicialmente como parte do processo de modelagem de ameaças. STRIDE é um modelo de ameaças, usado para ajudar a raciocinar e encontrar ameaças a um sistema. É usado em conjunto com um modelo do sistema de destino que pode ser construído em paralelo. Isso inclui uma análise completa de processos, armazenamentos de dados, fluxos de dados e limites de confiança. Hoje, é frequentemente usado por especialistas em segurança para ajudar a responder à pergunta "o que pode dar errado neste sistema em que estamos trabalhando?"
