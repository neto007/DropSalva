---
title: Ataques de injeções em .Net
---

ASP.NET MVC (Model – View – Controller) é uma estrutura de aplicativo da Web contemporânea que usa comunicação HTTP mais padronizada do que o modelo de postback de Web Forms. O OWASP Top 10 2017 lista as ameaças mais prevalentes e perigosas à segurança da web no mundo hoje e é revisado a cada 3 anos.

Esta seção é baseada nisso. Sua abordagem para proteger seu aplicativo da web deve ser começar na principal ameaça A1, isso irá garantir que qualquer tempo gasto com segurança seja gasto de forma mais eficaz e cobrir as principais ameaças primeiro e as ameaças menores depois.

## Injeção A1

### Injeção SQL

* Usar um mapeador relacional de objeto (ORM) ou procedimentos armazenados é a maneira mais eficaz de combater a vulnerabilidade de injeção SQL.
* Use consultas parametrizadas onde uma consulta sql direta deve ser usada. Mais informações podem ser encontradas aqui .

por exemplo, em estruturas de entidades:

```sql
var sql = @"Update [User] SET FirstName = @FirstName WHERE Id = @Id";
context.Database.ExecuteSqlCommand(
    sql,
    new SqlParameter("@FirstName", firstname),
    new SqlParameter("@Id", id));
```

>Não concatene strings em qualquer lugar do código e execute-as no banco de dados (conhecido como sql dinâmico). Você ainda pode fazer isso acidentalmente com ORMs ou procedimentos armazenados, então verifique em todos os lugares.

Por exemplo:

```sql
string strQry = "SELECT * FROM Users WHERE UserName='" + txtUser.Text + "' AND Password='"
                + txtPassword.Text + "'";
EXEC strQry // SQL Injection vulnerability!
```
* Pratique o mínimo privilégio - Conecte-se ao banco de dados usando uma conta com um conjunto mínimo de permissões necessárias para fazer o trabalho, ou seja, não a conta sa.

### Injeção de SO

Utilize `System.Diagnostics.Process.Start` para chamar funções subjacentes do sistema operacional.

Por exemplo:

```c#
System.Diagnostics.Process process = new System.Diagnostics.Process();
System.Diagnostics.ProcessStartInfo startInfo = new System.Diagnostics.ProcessStartInfo();
startInfo.FileName = "validatedCommand";
startInfo.Arguments = "validatedArg1 validatedArg2 validatedArg3";
process.StartInfo = startInfo;
process.Start();
```

* Utilize a validação da lista de permissões em todas as entradas fornecidas pelo usuário. A validação de entrada evita que dados formados incorretamente entrem em um sistema de informação.

Por exemplo:

```c#
//User input
string ipAddress = "127.0.0.1";

//check to make sure an ip address was provided
if (!string.IsNullOrEmpty(ipAddress))
{
 // Create an instance of IPAddress for the specified address string (in
 // dotted-quad, or colon-hexadecimal notation).
 if (IPAddress.TryParse(ipAddress, out var address))
 {
  // Display the address in standard notation.
  return address.ToString();
 }
 else
 {
  //ipAddress is not of type IPAddress
  ...
 }
    ...
}
```

## Referência externa
[.Net security](https://cheatsheetseries.owasp.org/cheatsheets/DotNet_Security_Cheat_Sheet.html)