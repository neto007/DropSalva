---
title: Solicitações indiretas
---

Para solicitações indiretas para sites gerenciadores / agregadores de tags que oferecem a GUI para configurar o javascript, eles também podem implementar:

Controles técnicos, como permitir apenas que o JavaScript acesse os valores da camada de dados, nenhum outro elemento DOM
Restringindo os tipos de tag implantados em um site host, por exemplo, desabilitando tags HTML personalizadas e código JavaScript
A empresa anfitriã também deve verificar as práticas de segurança do site do gerenciador de tags, como controles de acesso à configuração da tag para a empresa anfitriã. Também pode ser uma autenticação de dois fatores.

Permitir que o pessoal de marketing decida onde obter os dados que desejam pode resultar em XSS, porque eles podem obtê-los de um parâmetro de URL e colocá-los em uma variável que está em um local programável na página.


### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)