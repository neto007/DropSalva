---
title: Módulos criptográficos devem falhar com segurança
---
## Descrição

Sempre que um módulo criptográfico não falha com segurança, o dispositivo precisa apresentar estado de erro, para que não seja mais utilizável.

## Solução

Recomendamos o uso do padrão NIST (Instituto Nacional de Padrões e Tecnologia) para testar o módulo criptográfico, fazendo com que ele faça os autotestes para verificar se ele falha com segurança.