---
title: Instruções preparadas e parametrização de consulta
---
## Descrição

Todas as consultas SQL, HQL, OSQL, NOSQL e procedimentos armazenados, relacionados a procedimentos armazenados, devem ser protegidos pelo uso de parametrização de consulta.
Se um invasor puder injetar código malicioso nessas consultas e obter a capacidade de manipulá-las, poderá retirar, atualizar e excluir dados armazenados no banco de dados de destino.

## Solução

O uso de instruções preparadas e consultas parametrizadas é como todos os desenvolvedores devem primeiro ser ensinados a escrever consultas no banco de dados. Eles são simples de escrever e mais fáceis de entender do que as consultas dinâmicas. Consultas parametrizadas forçam o desenvolvedor a definir primeiro todo o código SQL e depois passe cada parâmetro para a consulta posteriormente. Esse estilo de codificação permite ao banco de dados distinguir entre código e dados, independentemente da entrada do usuário fornecida.