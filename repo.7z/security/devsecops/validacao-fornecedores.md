---
title: Processo de análise e avaliação dos Fornecedores 
sidebar_label: Análise de Fornecedores
---

## Descrição

Sempre que houver a contratação de um novo serviço ou produto de um Fornecedor externo às equipes de tecnologia da XP, faz-se necessária a avaliação tanto da empresa nos critérios administrativos/operacionais quanto em relação aos critérios de Segurança da Infomração.

Havendo a necessidade de tráfego de dados fora da rede ou do domínio lógico da XP (Ex.: utilização de APIs ou algum nível de integração de dados entre o domínio do fornecedor e o da XP) são observadas as seguintes premissas:

## Transporte

De modo a garantir que a informação trafegada não esteja acessível a um eventual atacante durante o processo, observam-se os seguintes requisitos:

- Utilização de protocolo considerado seguro (comunicação criptografada). Ex.: Https, o qual por meio de sua SSL garante que o dado seja criptografado antes de ser trafegado em qualquer dos sentidos.
    
- Validação dos Certificados: visando também garantir a viabilidade do protocolo de comunicação seguro, pede-se a confirmação do uso de certificados de segurança em ambas as pontas da comunicação.

## Autenticação

Com vistas a assegurar que a comunicação também se dê apenas por meio de usuários pré-determinados e que os mesmos não possam ser emulados por um atacante, observam-se os seguintes aspectos:

- credenciais de acesso: o método de autenticação utilizado para acesso à API ou recurso de disponibilização de dados precisa garantir que os dados trafegados na operação (usuário, senha, chave, etc.) estejam criptografados e não em clear text.
 - acesso específico: também relacionado ao usuário a executar a ação, este deve ter tido a sua solicitação de criação submetida a equipe de Gestão e Controle de Acessos e ter acesso específico também apenas aos recursos necessários a operação do projeto, não sendo autorizadas uso de contas built-in (ex.: admin, sa, etc.)

## Privacidade de Dados

Os dados de posse da XP a serem disponibilizados para tráfego externo ao projeto e os eventualmente preenchidos externamente a este ambiente e trazidos à XP devem obedecer aos critérios assinalados na [Política de Privacidade da XP](https://xpcorretora.sharepoint.com/sites/intranet/politicas-e-normas/PoliticasNormas/Pol%C3%ADtica%20de%20Privacidade%20de%20Dados.pdf).

Assim, ao constatar-se o tráfego de informações de uso de informações sensíveis de qualquer pessoa física ou jurídica sob posse e/ou responsabilidade da XP citados no documento acima (ex.: CPF, RG, endereço, etc.), deve ser acionada a equipe de Privacidade de Dados na pessoa do analista Bruno Stuani ou outro que execute sua validação.

## Armazenamento de Dados

Os aspectos a serem observados para o armazenamento do dado disponibilizado pela XP referem-se no apanhado dos três parágrafos acima citados, porém aplicados ao escopo do mecanismo de base de dados a ser utilizado para o projeto, ou seja.:

- Transporte: se na estrutura do cliente é protocolo seguro e certificado para comunicação;
- Autenticação: credenciais específicas para o serviço e autenticação seguro à abse de dados.
- Privacidade: se não são armazenados dados ditos sensíveis citados no parágrafo específico.

## Metodologia

Para que os aspectos acima sejam observados, é realizada a solicitação de preenchimento de um modelo de diagrama (Fig. 1) que aborda os seguintes aspectos:

- Componentes lógicos do projeto: representação de sistemas, APIs, clients, agents, ou qualquer outro item que, para entendimento da topologia e arquitetura da proposta de serviço/projeto devam ser elencados.

- Linhas tracejadas: indicam a delimitação do domínio lógico da XP (componentes sob nossa administração, estando estes hospedados em nossa infraestrutura física ou em provedores. As regras citadas nos parágrafos acima tem uma grau de importância muito maior quando nas ações que trespassam estas linhas, que é onde deve-se reforçar a obersvância das normas estabelecidas.

 - Postagens: as setas representadas entre os componentes citados indicam as ações realizadas entre um e outro compoente (ações como consultas, comandos CRUD, etc.). Nestas postagens é que são validados os critérios dos parágrafos anteriormente citados sobre transporte, autenticação, privacidade, armazenamento, etc.



![Exemplo de diagrama](/assets/devsecops/fornecedores/fornecedores-1.png)


Uma vez retornado o diagrama, é realizada a análise do cenário especificado e feitas recomendações ou exigências a cada um das áreas também acima descritas. Ex.:

- caso uma das comunicações entre uma representada no ambiente interno às linhas tracejadas (Domínio lógico da XP) e um sistema externo não obedeça o critério de utilização de protocolo de comunicação seguro, é retornado um texto solicitando ao fornecedor a correção daquele aspecto. 
    
- esta avaliação tem caráter excludente. Ou seja: na impossibilidade de correção do aspecto chave, é feita a comunicação à Governança de SI e ao solicitante que o projeto encontra-se vetado até que haja a possibilidade de correção da mesma. Caso não seja sob nenhuma circunstância possível a realização da correção, o projeto estará vetado em definitivo.
