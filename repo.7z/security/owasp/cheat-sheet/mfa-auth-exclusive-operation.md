---
title: Credenciais de autorização
---

Para evitar todos os tipos de ataques de repetição, as credenciais de autorização devem ser exclusivas para cada operação. Isso pode ser obtido usando métodos diferentes, dependendo do mecanismo de autorização de transação aplicado. Por exemplo: usando um carimbo de data / hora, um número de sequência ou um valor aleatório nos dados da transação assinada ou como parte de um desafio.

Deve considerar outros itens para identificar o melhor modelo de autenticação: 

- Quais transações devem ser autorizadas? Todas as transações ou apenas algumas delas. Cada aplicativo é diferente e o proprietário do aplicativo deve decidir se todas as transações devem ser autorizadas ou apenas algumas delas, considerando a análise de risco, a exposição ao risco de um determinado aplicativo e outras salvaguardas implementadas em um aplicativo.

- Recomendamos o uso de operações criptográficas para proteger as transações e garantir integridade, confidencialidade e não repúdio.

- Registro de dispositivo ou "emparelhamento" de um dispositivo de autorização externo (ou um aplicativo móvel) com a conta do usuário.

- O provisionamento e a proteção das chaves de assinatura do dispositivo, durante o "emparelhamento" do dispositivo, é tão crítico quanto o próprio protocolo de assinatura. 

- O malware pode tentar injetar / substituir ou roubar as chaves de assinatura.

- Conscientização do usuário. Por exemplo: para métodos de autorização de transação, quando um usuário digita dados de transação significativos em um componente de autorização (por exemplo, um dispositivo externo dedicado ou um aplicativo móvel), os usuários devem ser treinados para regravar os dados de transação de uma fonte confiável e não de uma tela de computador.

- Existem algumas soluções anti-malware que protegem contra ameaças de malware, mas essas soluções não garantem 100% de eficácia e devem ser usadas apenas como uma camada adicional de proteção.

- Proteção das chaves de assinatura usando um segundo fator, seja senha, biometria, etc.

- Proteção das chaves de assinatura alavancando elementos seguros (TEE, TPM, cartão inteligente ..)

### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)