---
title: Senha previsível e geração de token
---
## Descrição

Os tokens ou senhas usados no aplicativo devem conter alta entropia para impedir a previsão desses valores.

## Solução

Os tokens devem conter entropia e aleatoriedade de alto nível para impedir a geração previsível de tokens. Todos os números aleatórios, nomes de arquivos aleatórios, GUIDs aleatórios e aleatórios devem ser gerados usando o gerador de números aleatórios aprovado pelo módulo criptográfico quando esses valores aleatórios pretendem ser indiscutíveis por um invasor.
