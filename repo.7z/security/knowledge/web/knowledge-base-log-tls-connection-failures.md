---
title: Log de falhas na conexão TLS
---
## Descrição

As conexões TLS com falha sempre devem ser registradas. Este é um ótimo indicador de que 'algo' está errado.

## Solução

Verifique se as falhas de conexão TLS de back-end estão registradas.