---
title: Interfaces administrativas 
---
## Descrição

Sempre que não for necessário que as páginas administrativas sejam acessíveis ao público, as páginas devem ter acesso restrito aos usuários. Sempre que essas páginas são isoladas do resto do aplicativo em termos de acessibilidade, isso reduz o vetor de ataque de usuários mal-intencionados.

## Solução

A primeira solução é conceder acesso apenas de um determinado intervalo de IPs de origem para a interface administrativa. Se essa solução não for possível, é sempre recomendável ter uma autenticação adaptativa ou etapa para efetuar login na interface administrativa.