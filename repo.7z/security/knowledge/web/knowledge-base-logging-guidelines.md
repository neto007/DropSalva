---
title: Diretrizes de log
---
## Descrição

O registro deve conter algumas diretrizes para organizar seu arquivo de registro de forma a permitir uma investigação detalhada da linha do tempo quando um evento acontece.

## Solução

O arquivo de log deve conter pelo menos, um carimbo de data / hora de uma fonte confiável, nível de gravidade do evento, uma indicação de que este é um evento relevante para segurança (se misturado com outros logs), a identidade do usuário que causou o evento (se houver é um usuário associado ao evento), o endereço IP de origem da solicitação associada ao evento, se o evento foi bem-sucedido ou falhou, e uma descrição do evento. Verifique também se os campos de log de fontes confiáveis e não confiáveis são distinguíveis nas entradas de log, de preferência armazenadas em arquivos diferentes, para que não possam se contaminar sempre que ocorrer a injeção de log.

Verifique se o acesso a dados confidenciais é registrado, se os dados são coletados sob as diretivas relevantes de proteção de dados ou onde o registro de acessos é necessário.