---
title: Impedir o cache de dados confidenciais
---

Embora o TLS forneça proteção de dados enquanto eles estão em trânsito, ele não fornece nenhuma proteção para os dados uma vez que tenham chegado ao sistema solicitante. Como tal, essas informações podem ser armazenadas no cache do navegador do usuário ou por quaisquer proxies de interceptação configurados para realizar a descriptografia TLS.

Quando dados confidenciais são retornados nas respostas, cabeçalhos HTTP devem ser usados ​​para instruir o navegador e quaisquer servidores proxy a não armazenar em cache as informações, a fim de evitar que sejam armazenadas ou devolvidas a outros usuários. Isso pode ser feito configurando os seguintes cabeçalhos HTTP na resposta:

```js

Cache-Control: no-cache, no-store, must-revalidate
Pragma: no-cache
Expires: 0

```

### Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/)