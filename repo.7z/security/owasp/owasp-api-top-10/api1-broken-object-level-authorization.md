---
title: Broken Object Level Authorization
---

## A API está vulnerável?
O nível de autorização de objeto é um mecanismo de controle de acesso que usualmente é implementado ao nível de código para validar que um usuário pode apenas acessar objetos aos quais realmente tem permissão. Todo endpoint de API que recebe um ID de objeto, e executa qualquer tipo de ação sobre este objeto, deve implementar verificações de autorização de acesso ao nível deste objeto. A verificação deve validar que o usuário tem acesso para executar aquela ação no objeto requisitado. Falhas nesse mecanismo geralmente levam ao acesso não autorizado de informações, vazamento de dados, modificação ou destruição de dados.

## Cenários de exemplo de ataques

#### Cenário #1
Uma plataforma de e-commerce para lojas de compras online entrega uma listagem com os gráficos de receita
de suas lojas hospedadas. Inspecionando as requisições do navegador, o atacante pode identificar que os
endpoints utilizados como fonte de dados para os gráficos utiliza um padrão como: `/shops/{shopName}/revenue_data.json`. Utilizando outro endpoint da API, o atacante consegue uma lista de todos os nomes das lojas hospedadas na plataforma. Com um simples script o atacante pode agora, manipulando o nome substituindo o parâmetro {shopName} na URL, ganhar acesso aos dados das vendas de milhares de lojas que utilizam a plataforma de e-commerce.

#### Cenário #2
Enquanto monitora o tráfego de rede um wearable device, o atacante tem sua atenção despertada ao perceber o verbo HTTP PATCH possui o cabeçalho customizado `X-User-Id: 54796`. Substituindo o valor do cabeçalho o atacante recebe uma resposta HTTP válida, sendo possível portanto modificar os dados de outros usuários.

## Como prevenir
* Implementar mecanismo apropriado de autorização de acesso baseado em políticas e hierarquias.
* Utilizar uma autorização para verificar se o usuário pode acessar e executar ações nos registros em todas as funções que utiliza input do usuário para acessar dados.
* Prefira utilizar valores randômicos como GUIs para ids de registros.
* Escreva testes para avaliar seu mecanismo de autorização, não autorize deployment de mudanças de código que quebrem estes testes.