---
title: Geradores Aleatórios Seguros

---
## Descrição
Um gerador de número pseudo-aleatório criptograficamente seguro (CSPRNG) ou pseudo-aleatório criptográfico gerador de número (CPRNG) é um gerador de número pseudo-aleatório (PRNG) com propriedades que o tornam adequado para uso em criptografia.

A maioria dos aplicativos requer números aleatórios, por exemplo:

- geração de chave
- nonces
- salts

## Solução
Idealmente, a geração de números aleatórios em CSPRNGs usa entropia obtida de uma fonte de alta qualidade. A maioria das estruturas de desenvolvimento tem funções excelentes para gerar verdadeiros valores aleatórios seguros.

Para testar a entropia efetiva do token gerado, podemos utilizar a extensa ferramenta de análise da "versão da comunidade Burpsuite". mais informações sobre como testar a entropia efetiva de seus tokens podem ser encontradas aqui:

https://portswigger.net/burp/documentation/desktop/tools/equencer