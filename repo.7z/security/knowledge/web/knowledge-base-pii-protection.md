---
title: Proteção de PII (informação pessoal identificável)
---
## Descrição

Deve-se ter cuidado extra quando você estiver lidando com

- PII (informações pessoais identificáveis)

- Dados financeiros (histórico de crédito, registros fiscais, histórico de pagamentos, beneficiários)

- Dados de saúde (registros médicos, detalhes de dispositivos médicos ou registros de pesquisa sem anonimato)

Existem várias leis nos países que exigem proteção adequada por meio de SSL / TLS para quando os dados estiverem em trânsito e criptografados com o sistema de chave privada de pub quando armazenados no disco. Isso é necessário para proteger o usuário contra roubo de identidade e fraude.

## Solução

As informações de identificação pessoal precisam ser armazenadas criptografadas em repouso, idealmente em um ambiente seguro, como o seu cofre. Além de poder armazenar segredos, um Vault pode ser usado para criptografar/descriptografar dados armazenados em outro local. O principal uso disso é permitir que os aplicativos criptografem seus dados enquanto ainda os armazenam no repositório de dados primário.

A vantagem disso é que os desenvolvedores não precisam se preocupar com a criptografia correta dos dados. A responsabilidade da criptografia é do Vault e da equipe de segurança, e os desenvolvedores apenas criptografam/descriptografam os dados conforme necessário.

Além disso, garanta que toda a comunicação seja realizada por canais protegidos, como SSL/TLS.