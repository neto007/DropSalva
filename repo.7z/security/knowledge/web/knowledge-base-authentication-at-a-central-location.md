---
title: Autenticação na aplicação
---
## Descrição

A autenticação sempre deve ser realizada em um local central na aplicação, para impedir a falta de autenticação em determinados níveis da aplicação.

## Solução

Use um local central para autenticação. Se você quiser colocar restrições adicionais nos
usuários para acessar partes críticas da aplicação, é necessário implementar
mecanismos de autenticação adaptativos ou avançados.
Verifique se não existem caminhos de acesso alternativos e menos seguros.