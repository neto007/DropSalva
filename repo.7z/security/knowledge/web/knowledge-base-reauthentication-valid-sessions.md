---
title: Sessões válidas de nova autenticação
---
## Descrição

Se o aplicativo permitir que o usuário permaneça autenticado por um longo período de tempo, por exemplo, a funcionalidade "Permanecer conectado", que prolonga a sessão do usuário por mais tempo do que o tempo limite do servidor, aumenta a chance de um invasor repetir uma sessão válida depois de comprometer a sessão com êxito.


## Solução

Implemente a re-autenticação periódica quando usado ativamente ou após um período inativo, certificando-se de que os identificadores da sessão também sejam renovados.

Nível 1 - 30 dias
Nível 2 - 12 horas ou 30 minutos de inatividade, 2FA opcional
Nível 3 - 12 horas ou 15 minutos de inatividade, com 2FA