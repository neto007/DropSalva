---
title: Injeção de log
---
## Descrição

Problemas de injeção de log são um subconjunto de problemas de injeção, no qual entradas inválidas obtidas da entrada do usuário são inseridos em logs ou trilhas de auditoria, permitindo que um invasor induza em erro administradores ou cobrir vestígios de um ataque. Às vezes, a injeção de log também pode ser usada para sistemas de monitoramento de logs de ataque indiretamente, injetando dados que os sistemas de monitoramento interpretar mal.

## Solução

Você deve considerar esses três controles ao implementar sistemas de log.

- Design: Se possível, evite registrar dados provenientes de entradas externas.

- Implementação: verifique se todas as entradas de log são criadas estaticamente ou se devem
   registrar dados externos que a entrada é vigorosamente verificada na lista branca.

- Run time: Evite exibir logs com ferramentas que possam interpretar caracteres de controle no arquivo, como shells da linha de comando.

Verifique também se todos os símbolos não imprimíveis e separadores de campo estão codificados corretamente nas entradas de log, para impedir a injeção de log.