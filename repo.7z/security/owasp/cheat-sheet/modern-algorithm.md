---
title: Algoritmos modernos
---

Existem vários algoritmos de hash modernos que foram projetados especificamente para armazenar senhas com segurança. Isso significa que eles devem ser lentos (ao contrário de algoritmos como MD5 e SHA-1, que foram projetados para serem rápidos), e o quão lentos eles são podem ser configurados alterando o fator de trabalho.

Os três algoritmos principais que devem ser considerados estão listados abaixo.

### Argon2id
Argon2 é o vencedor da Competição de hash de senha de 2015 . Existem três versões diferentes do algoritmo e a variante de id do Argon2 deve ser usada quando disponível, pois fornece uma abordagem equilibrada para resistir a ataques de canal lateral e baseados em GPU.

Em vez de um fator de trabalho simples como outros algoritmos, o Argon2 tem três parâmetros diferentes que podem ser configurados, o que significa que é mais complicado ajustar corretamente para o ambiente. A especificação contém orientações sobre como escolher os parâmetros apropriados, no entanto, se você não estiver em uma posição para ajustá-la corretamente, um algoritmo mais simples como o Bcrypt pode ser uma escolha melhor.

### PBKDF2
PBKDF2 é recomendado pelo NIST e tem implementações validadas FIPS-140. Portanto, deve ser o algoritmo preferido quando for necessário. Além disso, ele é compatível com o padrão da estrutura .NET, por isso é comumente usado em aplicativos ASP.NET.

PBKDF2 pode ser usado com HMACs com base em vários algoritmos de hash diferentes. HMAC-SHA-256 é amplamente suportado e recomendado pelo NIST. O fator de trabalho para PBKDF2 é implementado por meio da contagem de iteração, que deve ser de pelo menos 10.000 (embora valores de até 100.000 possam ser apropriados em ambientes de segurança mais alta).

### Bcrypt
Bcrypt é o algoritmo mais amplamente suportado e deve ser a escolha padrão, a menos que haja requisitos específicos para PBKDF2 ou conhecimento apropriado para ajustar o Argon2. O fator de trabalho padrão para Bcrypt é 10 e geralmente deve ser aumentado para 12, a menos que esteja operando em sistemas mais antigos ou de baixa potência.