---
title: Insecure Data Storage
---

## O aplicativo está vulnerável?
Esta categoria de armazenamento de dados inseguro e vazamento de dados não intencional. Os dados armazenados de forma insegura incluem, mas não se limitam a:

* Bancos de dados SQL;
* Arquivos de log;
* Armazenamentos de dados XML ou arquivos de manifesto;
* Armazenamentos de dados binários;
* Armazenamento de cookies;
* Cartão SD;
* Nuvem sincronizada.

O vazamento de dados não intencional inclui, mas não se limita a, vulnerabilidades de:

* O sistema operacional;
* Frameworks;
* Ambiente de emulador;
* Novo hardware.
* Dispositivos "rootados" ou desbloqueados

Isso obviamente não é de conhecimento do desenvolvedor. Especificamente no desenvolvimento móvel, isso é mais visto em processos internos não documentados ou sub documentados, como:

* A maneira como o SO armazena dados, imagens, pressionamentos de tecla, registro e buffers em cache;
* A maneira como a estrutura de desenvolvimento armazena dados, imagens, pressionamentos de teclas, registro e buffers em cache;
* A forma ou quantidade de estruturas de anúncios, analíticas, sociais ou de capacitação armazenam dados em cache, imagens, pressionamentos de teclas, registro e buffers.

## Cenários de exemplo de ataques
Se um aplicativo armazenar por exemplo dados de usuário e senha em texto puro, isso é considerado uma vulnerabilidade de armazenamento inseguro.

>iGoat é um aplicativo móvel propositalmente vulnerável para a comunidade de segurança explorar esses tipos de vulnerabilidades.

## Como prevenir
É importante modelar o seu aplicativo móvel, sistema operacional, plataformas e estruturas para compreender os ativos de informação que o aplicativo processa e como as APIs lidam com esses ativos. É crucial ver como eles lidam com os seguintes tipos de recursos:

* Cache de URL (solicitação e resposta);
* Cache de imprensa de teclado;
* Copiar / colar o cache do buffer;
* Fundo do aplicativo;
* Dados intermediários
* Exploração madeireira;
* Armazenamento de dados HTML5;
* Objetos de cookies do navegador;
* Dados analíticos enviados a terceiros.
