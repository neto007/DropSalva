---
title: Política de processamento de dados confidenciais
---
## Descrição

Alguns dados em um aplicativo podem ser considerados confidenciais devido à sua importância:
- Número da Segurança Social
- Cartão de crédito ou informações bancárias
Ou pelo contexto da informação:
- Senha usada como senha de um aplicativo
- Dados restritos ou críticos da universidade

Nos aplicativos, os dados considerados confidenciais devem ser mantidos em segurança. A maneira como protegemos os dados pode ser definida por nós, mas algumas informações devem ser feitas de acordo com um padrão - ou seja, todos os aplicativos que manipulam as informações do cartão de crédito devem estar em conformidade com um dos padrões de PCI.


## Solução

Identifique a lista de dados confidenciais que estão sendo processados pelo aplicativo.
Estabeleça, mantenha e divulgue uma política de segurança para processar e armazenar dados confidenciais. Se as informações devem ser criptografadas, separadas em outro banco de dados, etc. Se existir, siga o padrão apropriado.