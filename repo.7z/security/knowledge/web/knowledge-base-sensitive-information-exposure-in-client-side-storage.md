---
title: Exposição de informações confidenciais no armazenamento do lado do cliente
---
## Descrição

O armazenamento do lado do cliente (também conhecido como armazenamento offline ou armazenamento na web) é uma funcionalidade fornecida pelos navegadores para permitir que os aplicativos salvem informações no computador do usuário e as recuperem quando necessário.
Como essas operações são executadas por linguagens de script do lado do cliente (principalmente Javascript), essas informações podem ser recuperadas por códigos de terceiros incluídos nas páginas da Web ou por ataques de script entre sites (XSS) executados por invasores. Além disso, atacantes com privilégios locais na máquina do usuário são capazes de acessar esses armazenamentos e, possivelmente, comprometer a sessão dos usuários.

## Solução

Dados confidenciais (como tokens de sessão ou informações de identificação pessoal) nunca devem ser armazenados em armazenamentos do lado do cliente. Isso significa verificar cuidadosamente se o aplicativo nunca salva em nenhum momento esse tipo de informação em:

* Armazenamento local
* Armazenamento de sessão
* Web SQL
* Armazenamento em cache
* Cache de aplicativo
* IndexDB