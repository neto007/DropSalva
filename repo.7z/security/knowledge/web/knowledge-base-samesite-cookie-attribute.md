---
title: Atributo de cookie do mesmo site
---
## Descrição

O atributo de cookie 'SameSite' ajuda os desenvolvedores a controlar se um cookie pode ser enviado juntamente com solicitações iniciadas por sites de terceiros ou entre sites, ajudando a impedir ataques do tipo CSRF (Cross-Site-Request-Forgery).
O atributo aceita 2 valores: estrito e relaxado.

- strict: o cookie NÃO será transmitido dentro de solicitações iniciadas por sites de terceiros, mesmo se iniciado por uma solicitação GET.

- lax: o cookie será enviado junto com a solicitação GET apenas se ocorrer uma navegação de nível superior.


## Solução

Ao criar um novo cookie no navegador, adicione o atributo 'SameSite'.