---
title: Usar o método de autorização para alterar o próprio método
---

Alguns aplicativos permitem que um usuário escolha entre vários métodos de autorização de transação. Nesses casos, o usuário deve autorizar a mudança no método de autorização usando seu método de autorização atual. Caso contrário, o malware pode alterar o método de autorização para o método mais vulnerável.

Além disso, o aplicativo deve informar ao usuário sobre os perigos potenciais associados ao método de autorização selecionado.


### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)