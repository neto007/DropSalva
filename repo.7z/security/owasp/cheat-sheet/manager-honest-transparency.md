---
title: Honestidade e Transparência
---

Se o aplicativo da web não puder fornecer proteções legais ou políticas suficientes para o usuário, ou se o aplicativo da web não puder evitar o uso indevido ou divulgação de informações confidenciais, como logs, a verdade deve ser contada aos usuários de uma forma clara e compreensível, para que os usuários possam fazer uma escolha informada sobre se eles devem ou não usar esse serviço específico.

Caso não viole a lei, informe aos usuários se suas informações estão sendo solicitadas para remoção ou investigação por entidades externas.

A honestidade contribui muito para cultivar uma cultura de confiança entre um aplicativo da web e seus usuários, e permite que muitos usuários em todo o mundo pesem suas opções com cuidado, evitando danos aos usuários em várias regiões contrastantes do mundo.
