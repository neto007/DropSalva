---
title: Informações Confidenciais Armazenadas no Código Fonte
---
## Descrição

Às vezes, ao desenvolver um aplicativo, um programador armazena uma senha ou outro
credenciais no código-fonte como um comentário para outros desenvolvedores
faça login no aplicativo. Quando esses comentários ainda existem em um ambiente ativo,
um invasor pode usar essas credenciais para obter acesso ao sistema.

## Solução

Procure no código-fonte comentários que contenham possíveis credenciais de usuário.
Você também deve verificar se não há segredos e se as chaves de API estão incluídas no
código-fonte ou acabar dentro do binário resultante.

Isso também se aplica ao fornecimento de informações sobre lógica de negócios e outras questões críticas em formação. Verifique se não há lógica de negócios confidencial, chaves secretas ou outros informações proprietárias no código do lado do cliente.