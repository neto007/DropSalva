---
title: Exposição de senha
---
## Descrição

A recuperação de credenciais nunca deve revelar ou enviar a senha atual ao usuário.

## Solução

É uma prática recomendada enviar uma URL ou uma URL exclusiva com um parâmetro exclusivo que permita ao usuário criar novas credenciais. Verifique se a URL expira em um tempo razoável e a URL / parâmetro se torna inválido assim que o usuário for reativado. Além disso, observe que as senhas não devem ser armazenadas em texto não criptografado no banco de dados de um aplicativo. Em vez disso, é uma prática recomendada armazenar hashes de senha e verificar os hashes ao autenticar o usuário.