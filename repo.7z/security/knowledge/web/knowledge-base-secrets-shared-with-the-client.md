---
title: Segredos compartilhados com o cliente
---
## Descrição

Chaves simétricas, senhas ou segredos de API compartilhados com o cliente
não deve ser usado para funções classificadas como críticas.
Sempre que um cliente é alvejado com êxito por um invasor malicioso, a integridade
dessas chaves não é mais garantida.

## Solução

Verifique se chaves simétricas, senhas ou segredos de API geradas
ou compartilhadas com clientes são usados ​​apenas na proteção de segredos de baixo risco,
como criptografar o armazenamento local ou usos efêmeros temporários, como ofuscação de parâmetros. Compartilhar segredos com os clientes é equivalente em texto não criptografado e a arquitetura deve ser tratada como tal.