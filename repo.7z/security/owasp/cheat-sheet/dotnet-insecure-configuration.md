---
title: Configuração incorreta em .Net
---

## Depuração e rastreamento de pilha
Certifique-se de que a depuração e o rastreio estejam desativados em produção. Isso pode ser aplicado usando web.config:

```c#
<compilation xdt:Transform="RemoveAttributes(debug)" />
<trace enabled="false" xdt:Transform="Replace"/>

//Não Use senhas padrão.
```

Utilize sempre https ao invés de http:

```c#
protected void Application_BeginRequest()
{
    #if !DEBUG
    // SECURE: Ensure any request is returned over SSL/TLS in production
    if (!Request.IsLocal && !Context.Request.IsSecureConnection) {
        var redirect = Context.Request.Url.ToString()
                        .ToLower(CultureInfo.CurrentCulture)
                        .Replace("http:", "https:");
        Response.Redirect(redirect);
    }
    #endif
}
```
Utilize tokens Anti-CSRF:

```c#
[HttpPost]
[ValidateAntiForgeryToken]
public ActionResult LogOff()

//Certifique-se de que os tokens sejam removidos completamente para invalidação no logout.

/// <summary>
/// SECURE: Remove any remaining cookies including Anti-CSRF cookie
/// </summary>
public void RemoveAntiForgeryCookie(Controller controller)
{
    string[] allCookies = controller.Request.Cookies.AllKeys;
    foreach (string cookie in allCookies)
    {
        if (controller.Response.Cookies[cookie] != null &&
            cookie == "__RequestVerificationToken")
        {
            controller.Response.Cookies[cookie].Expires = DateTime.Now.AddDays(-1);
        }
    }
}
```

## Referência externa
[.Net security](https://cheatsheetseries.owasp.org/cheatsheets/DotNet_Security_Cheat_Sheet.html)