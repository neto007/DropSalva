---
title: SAML - Validar regras de processamento de protocolo
---

Esta é outra área comum para brechas de segurança simplesmente por causa do grande número de etapas a serem declaradas.

Processar uma resposta SAML é uma operação cara, mas todas as etapas devem ser validadas:

Valide as regras de processamento do AuthnRequest. Consulte SAML Core (3.4.1.4) para todas as regras de processamento AuthnRequest. Esta etapa ajudará a combater os seguintes ataques:

- Man-in-the-middle (6.4.2)

Valide as regras de processamento de resposta. Consulte Perfis SAML (4.1.4.3) para todas as regras de processamento de resposta. Esta etapa ajudará a combater os seguintes ataques:

- Declaração roubada (6.4.1)

- Man-in-the-middle (6.4.2)

- Asserção Forjada (6.4.3)

- Exposição do estado do navegador (6.4.4)


### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)