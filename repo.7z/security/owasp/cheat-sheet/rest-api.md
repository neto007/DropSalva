---
title: Chaves API
---

Os serviços REST públicos sem controle de acesso correm o risco de serem agrupados, resultando em contas excessivas de largura de banda ou ciclos de computação. As chaves de API podem ser usadas para mitigar esse risco. Eles também são frequentemente usados ​​por organizações para monetizar APIs; em vez de bloquear as chamadas de alta frequência, os clientes têm acesso de acordo com um plano de acesso adquirido.

As chaves de API podem reduzir o impacto de ataques de negação de serviço. No entanto, quando são emitidos para clientes terceiros, são relativamente fáceis de comprometer.

- Exigir chaves de API para cada solicitação ao endpoint protegido.

- Retorne o 429 Too Many Requestscódigo de resposta HTTP se as solicitações chegarem muito rapidamente.

- Revogue a chave API se o cliente violar o contrato de uso.

- Não dependa exclusivamente de chaves de API para proteger recursos confidenciais, críticos ou de alto valor.


## Controle de acesso

Os serviços REST não públicos devem executar controle de acesso em cada terminal da API. Os serviços da Web em aplicativos monolíticos implementam isso por meio da autenticação do usuário, lógica de autorização e gerenciamento de sessão. Isso tem várias desvantagens para arquiteturas modernas que compõem vários microsserviços seguindo o estilo RESTful.

- a fim de minimizar a latência e reduzir o acoplamento entre os serviços, a decisão de controle de acesso deve ser tomada localmente pelos terminais REST

- a autenticação do usuário deve ser centralizada em um provedor de identidade (IdP), que emite tokens de acesso
