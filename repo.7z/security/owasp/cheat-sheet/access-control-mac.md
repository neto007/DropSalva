---
title: Controle de acesso - MAC
---

O Controle de Acesso Obrigatório (MAC) garante que a aplicação da política de segurança organizacional não dependa da conformidade voluntária do usuário do aplicativo da web. O MAC protege as informações atribuindo rótulos de sensibilidade às informações e comparando isso ao nível de sensibilidade em que um usuário está operando. O MAC geralmente é apropriado para sistemas extremamente seguros, incluindo aplicativos militares seguros de vários níveis ou aplicativos de dados de missão crítica.

### As vantagens de usar esta metodologia

* O acesso a um objeto é baseado na sensibilidade do objeto
* O acesso com base na necessidade de saber é estritamente respeitado e o alargamento do escopo tem possibilidade mínima
* Apenas um administrador pode conceder acesso

### Problemas que podem ser encontrados ao usar esta metodologia

* Difícil e caro de implementar
* Não ágil

### As áreas de cautela ao usar o MAC são

* Classificação e atribuição de sensibilidade em um nível apropriado e pragmático
* A garantia do MAC deve ser realizada para garantir que a classificação dos objetos esteja no nível apropriado.

## Referência externa
[OWASP - Controle de acesso MAC](https://cheatsheetseries.owasp.org/cheatsheets/Access_Control_Cheat_Sheet.html#mandatory-access-control-mac)