---
title: Uso de certificados do lado do cliente
---

Em uma configuração típica, o TLS é usado com um certificado no servidor para que o cliente possa verificar a identidade do servidor e fornecer uma conexão criptografada entre eles. No entanto, existem dois pontos fracos principais com essa abordagem:

- O servidor não possui nenhum mecanismo para verificar a identidade do cliente

- A conexão pode ser interceptada por um invasor capaz de obter um certificado válido para o domínio.

- Isso é mais comumente usado por empresas para realizar a inspeção do tráfego TLS instalando um certificado CA confiável nos sistemas cliente.

Os certificados de cliente tratam de ambos os problemas exigindo que o cliente prove sua identidade ao servidor com seu próprio certificado. Isso não apenas fornece autenticação forte da identidade do cliente, mas também evita que uma parte intermediária execute a descriptografia TLS, mesmo que tenha um certificado CA confiável no sistema do cliente.

Certificados de cliente raramente são usados ​​em sistemas públicos devido a uma série de problemas:

- A emissão e gerenciamento de certificados de cliente introduzem sobrecargas administrativas significativas.

- Usuários não técnicos podem ter dificuldade para instalar certificados de cliente.

- A descriptografia TLS usada por muitas organizações fará com que a autenticação do certificado do cliente falhe.

No entanto, eles devem ser considerados para aplicativos ou APIs de alto valor, especialmente onde há um pequeno número de usuários tecnicamente sofisticados ou onde todos os usuários fazem parte da mesma organização.


### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)