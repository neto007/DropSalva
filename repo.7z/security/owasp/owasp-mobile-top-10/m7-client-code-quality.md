---
title: Poor Code Quality
---

## O aplicativo está vulnerável?
Este é o resumo dos problemas de implementação em nível de código no cliente móvel. Isso é diferente dos erros de codificação do lado do servidor. Isso captura os riscos que vêm de vulnerabilidades como estouro de buffer, vulnerabilidades de string de formato e vários outros erros de nível de código em que a solução é reescrever algum código que está sendo executado no dispositivo móvel.

Isso é diferente de Uso impróprio da plataforma porque geralmente se refere à própria linguagem de programação (por exemplo, Java, Swift, Objective C, JavaScript). Um estouro de buffer em C ou um XSS baseado em DOM em um aplicativo móvel Webview seria um problema de qualidade de código.

A principal característica desse risco é que o código está sendo executado no dispositivo móvel e o código precisa ser alterado de forma bastante localizada. Corrigir a maioria dos riscos requer alterações de código, mas no caso de qualidade de código, o risco vem de usar a API errada, usar uma API de forma insegura, usar construções de linguagem inseguras ou algum outro problema de nível de código. Importante: este não é um código em execução no servidor. Este é um risco que captura código inválido executado no próprio dispositivo móvel.

## Cenários de exemplo de ataques
Cenário # 1: Exemplo de estouro de buffer:

```c
include <stdio.h>

 int main(int argc, char **argv)
 {
    char buf[8]; // buffer for eight characters
    gets(buf); // read from stdio (sensitive function!)
    printf("%s\n", buf); // print out data stored in buf
    return 0; // 0 as return value
 }
```
Neste exemplo, retirado desta página, devemos evitar o uso da função gets para evitar um estouro de buffer. Este é um exemplo do que a maioria das ferramentas de análise estática relatará como um problema de qualidade de código.

## Como prevenir
Em geral, os problemas de qualidade do código podem ser evitados fazendo o seguinte:

Manter padrões de codificação consistentes com os quais todos na organização concordem;
Escreva um código fácil de ler e bem documentado;
Ao usar buffers, sempre verifique se os comprimentos de quaisquer dados do buffer de entrada não excederão o comprimento do buffer de destino;
Via automação, identifique estouros de buffer e vazamentos de memória por meio do uso de ferramentas de análise estática de terceiros; e
Priorize a resolução de estouros de buffer e vazamentos de memória em relação a outros problemas de "qualidade do código".
