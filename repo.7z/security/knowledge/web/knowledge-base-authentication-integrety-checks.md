---
title: Verificações de integridade de autenticação
---

## Descrição

Sempre que os logs de segurança puderem ser modificados por usuários não autorizados, invasores em potencial poderão usar esses privilégios para apagar e cobrir seus ataques contra a aplicação ou simplesmente poluir os arquivos de log.

## Solução

Use sistemas de detecção de intrusão de host (software de monitoramento de integridade de arquivos ou detecção de alterações) nos logs para garantir que os dados de log existentes ou outros arquivos importantes não possam ser alterados sem gerar alertas, dependendo do contexto de um arquivo de log os novos dados adicionados não devem causar um alerta.