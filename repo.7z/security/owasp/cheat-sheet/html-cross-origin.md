---
title: Recursos de origem cruazada HTML
---

* Valide as URLs passados ​​para `XMLHttpRequest.open`. Os navegadores atuais permitem que essas URLs sejam de vários domínios; esse comportamento pode levar à injeção de código por um invasor remoto. Preste atenção extra as URLs absolutas.
* Certifique-se de que as URLs que respondem com `Access-Control-Allow-Origin`, não incluam nenhum conteúdo confidencial ou informação que possa ajudar o invasor em ataques futuros.
* Permitir apenas domínios selecionados e confiáveis ​​no cabeçalho **Access-Control-Allow-Origin**. Prefira domínios na lista de permissões em vez de listas de proibições ou permitindo qualquer domínio (não use * curinga nem retorne cegamente o conteúdo do cabeçalho sem qualquer verificação).
* Lembre-se de que o CORS não impede que os dados solicitados sejam enviados para um local não autenticado. Ainda é importante que o servidor execute a prevenção CSRF usual.
* Embora a RFC recomende uma solicitação "pré-voo" com o verbo OPTIONS, as implementações atuais podem não realizar essa solicitação, por isso é importante que as solicitações "comuns" ( GET e POST) executem qualquer controle de acesso necessário.
* Descarte as solicitações recebidas por HTTP simples com origens HTTPS para evitar erros de conteúdo misto.
* Não confie apenas no cabeçalho Origin para verificações de controle de acesso. O navegador sempre envia esse cabeçalho em solicitações CORS, mas pode ser falsificado fora do navegador. Protocolos de nível de aplicativo devem ser usados ​​para proteger dados confidenciais.