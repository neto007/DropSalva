---
title: Informações detalhadas da versão
---
## Descrição

Revelar dados do sistema ou informações de depuração ajuda um adversário a aprender sobre o sistema e formular um plano de ataque. Um vazamento de informações ocorre quando dados do sistema ou as informações de depuração deixam o programa por meio de um fluxo de saída ou função de registro.

## Solução

Verifique se os cabeçalhos HTTP não expõem informações detalhadas da versão dos componentes do sistema. Para cada tipo diferente de servidor, existem guias de proteção dedicados especialmente para este tipo de vazamento de dados. O mesmo se aplica a qualquer outro vazamento de informações de versão, como a versão de sua linguagem de programação ou outros serviços em execução para fazer seu aplicativo funcionar.