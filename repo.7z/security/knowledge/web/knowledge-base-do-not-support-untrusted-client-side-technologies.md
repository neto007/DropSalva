---
title: Tecnologias não confiáveis ​​do lado do cliente
---
## Descrição

Ao usar tecnologias do lado do cliente não suportadas que não são suportadas nativamente via Padrões do navegador W3C. Seu aplicativo pode estar aberto a diferentes tipos de ataques.

## Solução

Não use Flash, Active-X, Silverlight, NACL, Java do lado do cliente ou outras tecnologias do lado do cliente não é suportado nativamente pelos padrões do navegador W3C.