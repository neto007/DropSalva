---
title: Taxa de transferência de mensagem
---

A taxa de transferência representa o número de solicitações de serviço da web atendidas durante um período de tempo específico.

**Regra:** A configuração deve ser otimizada para rendimento máximo de mensagens para evitar a execução em situações semelhantes a DoS.

## Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/)