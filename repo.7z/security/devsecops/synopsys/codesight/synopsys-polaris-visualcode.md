---
title: Instalação Plugin Synopsys Code Sight
sidebar_label: Visual Studio Code - Code Sight
---

Abaixo serão apresentados os passos-a-passo da instalação do plugin para utilização no editor de texto Visual Studio Code

## Criação de Variável
Primeiramente vamos criar duas variáveis necessárias para a instalação do motor de análise polaris:

**SYNOPSYS_HOME**
![Criação de Variável ](/assets/devsecops/synopsys/variavel.png)

 Crie também um diretorio local chamado **Synopsys** em **C:\\**:  

**SYNOPSYS_DESKTOP_NO_TEMP_OUTPUT_DIR_IN_BUILD_COMMAND**
![Criação de Variável ](/assets/devsecops/synopsys/variavel_02.png)

## Instalação do Plugin Visual Studio

Acesse o marketplace do Visual Studio Code e busque pela extensão  **Synopsys Code Sight**:

![marketplace](/assets/devsecops/synopsys/visualcode/01.png)

Clique em **install**

    Aguarde a instalação esse pacote possui aproximadamente 1.8gb

## Configuração do Plugin

Abra na lateral do seu VSCode a extensão do Synopsys.

Em **Coverity (SAST)** cline na linha **Server** para editar:

![Coverity (SAST)](/assets/devsecops/synopsys/visualcode/03.png)

## Configuração Local

Vá ate a pasta **"C:\Users\ **XXXX** \AppData\Roaming\Coverity"** e inclua as seguintes configurações:

Obs: nos arquivos existentes a propriedade Setting já existe, **inclua** apenas o **cov_run_desktop**

``` yml
{
  "type": "Coverity configuration",
  "format_version": 1,
  "settings": {
    "cov_run_desktop": {
        "analysis_args": [
            "--enable-audit-mode",
            "--webapp-security"
        ]
    }
  }
}
```

## Autenticação

A Autenticação permite que a análise compartilhe dados de triagem com um servidor central.
Isso também permite baixar varreduras de projeto completo diretamente do servidor, o que melhora a qualidade de análise local.

Conforme solicitado, insira seu nome de usuário(e-mail) e insira o URL para o servidor:

![Autenticação](/assets/devsecops/synopsys/visualcode/04.png)

**Em URL insira:** https://xpinvestimentos.polaris.synopsys.com

Clique em: **Change Credentials**

Será aberto uma página solicitando um **Personal Acess Token** para conectar ao servidor do Polaris:

#### Criação  de Acess Token

Acesse [POLARIS XP](https://xpinvestimentos.polaris.synopsys.com) -> User Profile -> Access Tokens e clique em **Create New Token**:

![Acess Token](/assets/devsecops/synopsys/visualstudio/07.png)

#### Sign In

com seu token em mãos, insira no campo solicitado pelo **Code Sight** e clique em continuar para finalizar a instalação e autenticação: 

![Acess Token](/assets/devsecops/synopsys/visualcode/05.png)

## Scaneando Projeto

Certifique-se que seu projeto possua o arquivo polais.yml configurado em seu repositório.

### Issues

Na opção issues será apresentado a lista de Vulnerabilidades locais (Current Files ou All Scanned Files) ou arquivos que foram enviados para análise (Dismissed):

Para que seja listado todos os itens encontrados vamos remover o filtro: **Exclude if Found by Full-scan Only**:

![Issues](/assets/devsecops/synopsys/visualcode/07.png)

### Status

#### Notification

    Notificações sobre possíveis ações a serem tomadas

#### Scans  

    Arquivos que estão sendo analisados conforme são inseridas novas linhas de código ou arquivos abertos/Salvos.

## Referência

- https://sig-docs.synopsys.com/codesight/index.html
- https://community.synopsys.com/s/getting-started-with-synopsys/getting-started-with-code-sight


