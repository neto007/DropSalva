---
title: Desserialização
---

## O que é desserialização

Serialização é o processo de transformar algum objeto em um formato de dados que pode ser restaurado posteriormente. Frequentemente, as pessoas serializam objetos para salvá-los no armazenamento ou para enviar como parte das comunicações.

A desserialização é o reverso desse processo, pegando dados estruturados de algum formato e reconstruindo-os em um objeto. Hoje, o formato de dados mais popular para serializar dados é JSON. Antes era XML.

No entanto, muitas linguagens de programação oferecem um recurso nativo para serializar objetos. Esses formatos nativos geralmente oferecem mais recursos do que JSON ou XML, incluindo personalização do processo de serialização.

Infelizmente, os recursos desses mecanismos nativos de desserialização podem ser reaproveitados para fins maliciosos ao operar em dados não confiáveis. Descobriu-se que os ataques contra desserializadores permitem ataques de negação de serviço, controle de acesso e execução remota de código (RCE).