---
title: Invalidar sessão remotas
---

Caso o equipamento do usuário seja perdido, roubado ou confiscado, ou sob suspeita de roubo de cookie; pode ser muito benéfico para os usuários poderem ver suas sessões online atuais e desconectar / invalidar quaisquer sessões remanescentes suspeitas, especialmente aquelas que pertencem a dispositivos roubados ou confiscados. A invalidação de sessão remota também pode ajudar se um usuário suspeitar que os detalhes de sua sessão foram roubados em um ataque Man-in-the-Middle.

Para obter detalhes sobre o gerenciamento de sessão, consulte:

- [Folha de referências do gerenciamento de sessão OWASP](https://cheatsheetseries.owasp.org/cheatsheets/Session_Management_Cheat_Sheet.html)


### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)

