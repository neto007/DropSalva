---
title: Segurança em banco de dados (Armazenamento)
---

## Armazenamento de credenciais de banco de dados
As credenciais do banco de dados nunca devem ser armazenadas no código-fonte do aplicativo, especialmente se não forem criptografadas. Em vez disso, eles devem ser armazenados em um arquivo de configuração que:

* Está fora do webroot.
* Tem permissões apropriadas para que só possa ser lido pelo(s) usuário(s) necessário(s).
* Não é verificado em repositórios de código-fonte.

Sempre que possível, essas credenciais também devem ser criptografadas ou protegidas de outra forma usando a funcionalidade interna, como o web.config criptografado disponível no ASP.NET.

## Referência externa
[OWASP - segurança em baco de dados](https://cheatsheetseries.owasp.org/cheatsheets/Database_Security_Cheat_Sheet.html)