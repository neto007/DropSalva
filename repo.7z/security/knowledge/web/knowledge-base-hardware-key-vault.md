---
title: Cofre de chaves de hardware
---
## Descrição

As chaves devem permanecer em um cofre de chaves protegido o tempo todo. Em particular, garantir que exista uma lacuna entre os vetores de ameaças que têm acesso direto aos dados e a ameaça vetores que têm acesso direto às chaves. Isso implica que as chaves não devem ser armazenadas no aplicativo ou servidor web (assumindo que os invasores do aplicativo fazem parte do modelo de ameaça relevante).

## Solução

Verifique se todos os consumidores de serviços criptográficos não têm acesso direto ao material principal. Isole os processos criptográficos, incluindo os segredos principais e considere o uso de um cofre de chaves de hardware (HSM).