---
title: Proteção de controle de acesso agregado
---
## Descrição

Verifique se o sistema pode proteger contra agregação ou acesso contínuo de
funções, recursos ou dados seguros. Por exemplo, possivelmente pelo uso de um
administrador de recursos para limitar o número de edições por hora ou para impedir o banco de dados inteiro de ser "raspado" por um usuário individual.

## Solução

O sistema deve conter um contador que possa acompanhar o número de vezes que um determinado usuário aborda tabelas de banco de dados e deve ser rejeitado quando ele passa um número razoável. Essa violação também deve ser relatada, pois pode indicar que um invasor está raspando o conteúdo da tabela ou roubando informações da empresa.