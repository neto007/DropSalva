---
title: Restrições gerais de dados
---

Depois de selecionar o tipo de dados apropriado, os desenvolvedores podem aplicar restrições adicionais. Às vezes, apenas um determinado subconjunto de valores dentro de um tipo de dados será considerado válido:

### Valores Prefixados

Certos tipos de valores devem ser restritos apenas a conjuntos específicos: os semáforos terão apenas três tipos de cores, apenas 12 meses estão disponíveis e assim por diante. É possível que o esquema tenha essas restrições em vigor para cada elemento ou atributo. Este é o cenário de lista de desbloqueio mais perfeito para um aplicativo: apenas valores específicos serão aceitos. Essa restrição é chamada `enumeration` no esquema XML. O exemplo a seguir restringe o conteúdo do elemento mês a 12 valores possíveis:

```xml

<xs:element name="month">
 <xs:simpleType>
  <xs:restriction base="xs:string">
   <xs:enumeration value="January"/>
   <xs:enumeration value="February"/>
   <xs:enumeration value="March"/>
   <xs:enumeration value="April"/>
   <xs:enumeration value="May"/>
   <xs:enumeration value="June"/>
   <xs:enumeration value="July"/>
   <xs:enumeration value="August"/>
   <xs:enumeration value="September"/>
   <xs:enumeration value="October"/>
   <xs:enumeration value="November"/>
   <xs:enumeration value="December"/>
  </xs:restriction>
 </xs:simpleType>
</xs:element>

```

Limitando o valor do elemento mês a qualquer um dos valores anteriores, o aplicativo não estará manipulando strings aleatórias.

## Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/cheatsheets/XML_Security_Cheat_Sheet.html)