---
title: Extraneous Functionality
---

## O aplicativo está vulnerável?
Freqüentemente, os desenvolvedores incluem funcionalidade de backdoor oculta ou outros controles internos de segurança de desenvolvimento que não devem ser lançados em um ambiente de produção. Por exemplo, um desenvolvedor pode incluir acidentalmente uma senha como um comentário em um aplicativo híbrido. Outro exemplo inclui a desativação da autenticação de dois fatores durante o teste.

A característica definidora desse risco é deixar a funcionalidade ativada no aplicativo que não deveria ser lançada.

## Cenários de exemplo de ataques
#### Cenário #1 -  Endpoint administrativo exposto:

Como parte do teste de endpoint móvel, os desenvolvedores incluíram uma interface oculta dentro do aplicativo móvel que exibia um painel administrativo. Este painel acessou as informações do administrador por meio do servidor API back-end. Na versão de produção do código, os desenvolvedores não incluíram o código que exibia o painel em nenhum momento. No entanto, eles incluíram o código subjacente que poderia acessar a API administrativa de back-end. Um invasor executou uma análise de tabela de string do binário e descobriu a URL codificada para um endpoint administrativo REST. O invasor posteriormente usou 'curl' para executar a funcionalidade administrativa de back-end.

Os desenvolvedores devem ter removido todo o código estranho, incluindo o código que não pode ser acessado diretamente pela interface nativa.

#### Cenário #2 -  Sinalizador de depuração no arquivo de configuração:

Um invasor tenta adicionar manualmente “debug = true” a um arquivo .properties em um aplicativo local. Na inicialização, o aplicativo está gerando arquivos de log que são excessivamente descritivos e úteis para o invasor entender os sistemas de back-end. O invasor posteriormente descobre vulnerabilidades no sistema de back-end como resultado do log.

Os desenvolvedores devem ter evitado a ativação do "modo de depuração" em uma versão de produção do aplicativo móvel.

## Como prevenir
A melhor maneira de evitar essa vulnerabilidade é realizar uma revisão de código seguro manual usando campeões de segurança ou especialistas no assunto mais bem informados com esse código. Eles devem fazer o seguinte:

Examine as definições de configuração do aplicativo para descobrir quaisquer interruptores ocultos;
Verifique se todo o código de teste não está incluído na versão de produção final do aplicativo;
Examine todos os terminais de API acessados ​​pelo aplicativo móvel para verificar se esses terminais estão bem documentados e disponíveis publicamente;
Examine todas as instruções de log para garantir que nada muito descritivo sobre o back-end esteja sendo gravado nos logs;
