---
title: Ataque de Repúdio
---
## Descrição

Um ataque de repúdio ocorre quando um aplicativo ou sistema não adota controles para
rastrear e registrar adequadamente as ações dos usuários, permitindo assim a manipulação ou falsificação maliciosa a identificação de novas ações. Este ataque pode ser usado para alterar a autoria informações de ações executadas por um usuário mal-intencionado para registrar dados incorretos nos arquivos de log. Seu uso pode ser estendido à manipulação geral de dados em nome de terceiros, de maneira semelhante à falsificação de mensagens de correio. Se esse ataque ocorrer, os dados armazenados nos arquivos de log podem ser considerados inválidos ou enganosos.

## Solução

Esse tipo de dado sempre deve ser processado fora do alcance do usuário e deve ser
verificado e imposto do lado do servidor.