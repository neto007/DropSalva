---
title: Registro De Nível De Aplicativo Único
---
## Descrição

Sempre que o aplicativo contém uma única implementação de registro em nível de aplicativo, ele torna-se claro, transparente e fácil de manter. Também reduz a possibilidade de você
ignorar o registro de alta prioridade.

## Solução

Verifique se há uma única implementação de registro em nível de aplicativo que é usada por
o software.