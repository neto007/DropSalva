---
title: Aplicar técnicas anti-debug
---
## Descrição

Um invasor pode usar as ferramentas de depuração para descobrir como o aplicativo está funcionando e impedir o possível superfície de ataque usando ferramentas como GDB ou executando o aplicativo em um emulador. Usando esse tipo de ferramenta, o invasor pode aprender muito sobre a ferramenta e atacar com êxito o aplicativo e tem uma maior chance de êxito.

## Solução

O aplicativo deve fazer uso de técnicas anti-debug que sejam suficientes para
dissuadir ou atrasar prováveis ​​invasores de injetar depuradores no aplicativo. 
Também o aplicativo precisa perceber se foi executado em um emulador ou em um aplicativo especialmente projetado dispositivo de hardware que não foi projetado para ser usado e para impedir que o invasor obtenha conhecimento sobre a aplicação.