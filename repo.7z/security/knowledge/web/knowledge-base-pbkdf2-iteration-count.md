---
title: Contagem de Iteração PBKDF2
---
## Descrição

PBKDF2, é uma função para criar uma chave criptográfica a partir de uma senha. O objetivo da função é criar uma chave para que ataques de dicionário (onde o invasor apenas tenta uma variedade de senhas possíveis) sejam inviáveis. Para fazer isso, o PBKDF2 aplica uma função pseudo-aleatória (PRF) à senha várias vezes. Além disso, a função pode receber um parâmetro "salt" para tornar cada operação de derivação de chave exclusiva. Um desenvolvedor que usa PBKDF2 deve escolher cuidadosamente os valores dos parâmetros para o salt, o PRF e o número de iterações, ou seja, o número de vezes que o PRF será aplicado à senha ao derivar a chave.

## Solução

Um desenvolvedor de aplicativos usando PBKDF2 deve garantir que a contagem de iterações DEVE ser tão grande quanto o desempenho do servidor de verificação permitir, normalmente pelo menos 100.000 iterações.