const top10 = require('./owasp-top-10/sidebars')
const api = require('./owasp-api-top-10/sidebars')
const mobile = require('./owasp-mobile-top-10/sidebars')
const cheatsheet = require('./cheat-sheet/sidebars')

module.exports = {
    type: "category",
    label: "OWASP",
    items: [
        top10,
        api,
        mobile,
        cheatsheet
    ],
};