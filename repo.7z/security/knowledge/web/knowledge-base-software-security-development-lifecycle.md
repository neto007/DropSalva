---
title: Ciclo De Vida De Desenvolvimento De Segurança De Software
---
## Descrição

Na engenharia de software, um processo de desenvolvimento de software é o processo de divisão do desenvolvimento de software trabalhe em fases distintas para melhorar o design, o gerenciamento de produtos e o gerenciamento de projetos. Também é conhecido como ciclo de vida de desenvolvimento de software. A metodologia pode incluir o pré-definição de entregas e artefatos específicos que são criados e concluídos por um equipe do projeto para desenvolver ou manter um aplicativo.

Neste ciclo de vida de desenvolvimento de segurança de software, também podemos integrar automação de teste de segurança e outros pilares de qualidade para segurança.

## Solução

O ciclo de vida de desenvolvimento de software seguro consiste idealmente em 5 estágios diferentes, a saber:

* Treinamento e conscientização
* Requisitos de segurança
* Automação de teste (teste de unidade, sonarqube, teste e2e, etc)
* Automação de teste de segurança (SAST, DAST, IAST, RASP, ETC)
* Revisão de código seguro, teste de penetração

Há muitas maneiras de conseguir um bom (S) SDLC, a coisa mais importante a se manter
consideração é que você precisa ter uma solução escalonável que funcione em diferentes CI
ambientes. Além disso, lembre-se de que o pipeline de CI / CD é um ambiente de produção que
oferece ambientes de produção. Portanto, seus pipelines de CI / CD devem ser reforçados, assim como qualquer outro
inscrição. Tenha em consideração coisas como

- Monitoramento em seu pipeline
- Gerenciamento de segredo
- Endurecimento de recipientes
- Endurecimento do seu ambiente de CI
- etc