---
title: Expiração automática da sessão
---

**Tempo Limite Inativo**

Todas as sessões devem implementar um tempo limite de inatividade ou ociosidade. Este tempo limite define a quantidade de tempo que uma sessão permanecerá ativa caso não haja atividade na sessão, fechando e invalidando a sessão no período inativo definido desde a última solicitação HTTP recebida pelo aplicativo da web para um determinado ID de sessão.

O tempo limite inativo limita as chances de um invasor adivinhar e usar uma ID de sessão válida de outro usuário. No entanto, se o invasor for capaz de sequestrar uma determinada sessão, o tempo limite ocioso não limita as ações do invasor, pois ele pode gerar atividade na sessão periodicamente para mantê-la ativa por períodos mais longos.

O gerenciamento e a expiração do tempo limite da sessão devem ser aplicados no lado do servidor. Se o cliente for usado para impor o tempo limite da sessão, por exemplo, usando o token de sessão ou outros parâmetros do cliente para rastrear referências de tempo (por exemplo, número de minutos desde o tempo de login), um invasor pode manipulá-los para estender a duração da sessão.

**Tempo Limite Absoluto**

Todas as sessões devem implementar um tempo limite absoluto, independentemente da atividade da sessão. Este tempo limite define a quantidade máxima de tempo que uma sessão pode estar ativa, fechando e invalidando a sessão no período absoluto definido desde que a sessão dada foi inicialmente criada pelo aplicativo da web. Após invalidar a sessão, o usuário é forçado a (re) autenticar novamente no aplicativo da web e estabelecer uma nova sessão.

A sessão absoluta limita a quantidade de tempo que um invasor pode usar uma sessão sequestrada e se passar pelo usuário vítima.

**Tempo Limite de Renovação**

Alternativamente, o aplicativo da web pode implementar um tempo limite de renovação adicional após o qual o ID da sessão é automaticamente renovado, no meio da sessão do usuário e independentemente da atividade da sessão e, portanto, do tempo limite de inatividade.

Após um período específico de tempo desde que a sessão foi inicialmente criada, o aplicativo da web pode gerar novamente um novo ID para a sessão do usuário e tentar configurá-lo ou renová-lo no cliente. O valor do ID da sessão anterior ainda seria válido por algum tempo, acomodando um intervalo de segurança, antes que o cliente tome conhecimento do novo ID e comece a utilizá-lo. Nesse momento, quando o cliente muda para o novo ID na sessão atual, o aplicativo invalida o ID anterior.

Este cenário minimiza a quantidade de tempo que um determinado valor de ID de sessão, potencialmente obtido por um invasor, pode ser reutilizado para sequestrar a sessão do usuário, mesmo quando a sessão do usuário vítima ainda está ativa. A sessão do usuário permanece ativa e aberta no cliente legítimo, embora seu valor de ID de sessão associado seja renovado de forma transparente e periódica durante a duração da sessão, sempre que o tempo limite de renovação expirar. Portanto, o tempo limite de renovação complementa os tempos limite ocioso e absoluto, especialmente quando o valor do tempo limite absoluto se estende significativamente ao longo do tempo (por exemplo, é um requisito do aplicativo para manter as sessões do usuário abertas por longos períodos de tempo).

Dependendo da implementação, pode haver uma condição de corrida em que o invasor com um ID de sessão anterior ainda válido envia uma solicitação antes do usuário vítima, logo após o tempo limite de renovação ter acabado, e obtém primeiro o valor para o ID de sessão renovado. Pelo menos neste cenário, o usuário vítima pode estar ciente do ataque, pois sua sessão será encerrada repentinamente porque seu ID de sessão associado não é mais válido.


### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)