---
title: Restrição do usuário para dados confidenciais
---
## Descrição

Sempre aplique várias camadas de segurança sempre que quiser proteger dados/arquivos confidenciais em sua aplicação. Se uma camada falhar, as outras camadas devem impedir os invasores de ter sucesso.

## Solução

Sempre que dados confidenciais são armazenados no servidor, armazene os dados em uma pasta separada com regras de permissão para evitar que usuários não autorizados leiam os arquivos. Como uma solução aprofundada, você também pode verificar se a sessão do usuário tem privilégios suficientes para ler os arquivos de acordo com o nível de autorização.

Item recomendado da base de conhecimento:

* Falta de autenticação ou autorização
* Limpe dados confidenciais rapidamente da memória