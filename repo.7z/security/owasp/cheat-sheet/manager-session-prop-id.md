---
title: Propriedades de ID de sessão
---

Para manter o estado autenticado e rastrear o progresso dos usuários no aplicativo da web, os aplicativos fornecem aos usuários um identificador de sessão (ID da sessão ou token) que é atribuído no momento da criação da sessão e é compartilhado e trocado pelo usuário e o aplicativo da web durante a sessão (é enviado em cada solicitação HTTP). O ID da sessão é um name=valuepar.

Com o objetivo de implementar IDs de sessão segura, a geração de identificadores (IDs ou tokens) deve atender às seguintes propriedades.

### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)