---
title: CSP
---
## Descrição

O principal uso do CSP em inglês (Content Security Polici) ou cabeçalho da política de segurança de conteúdo é detectar, relatar e rejeitar ataques XSS. O principal problema em relação aos ataques XSS é a incapacidade do navegador distinguir entre um script que deve fazer parte do seu aplicativo e um script que foi injetado maliciosamente por terceiros. Com o uso do CSP (política de segurança de conteúdo), podemos dizer ao navegador qual script é seguro para executar e quais scripts provavelmente foram injetados por um invasor.

## Solução

Uma prática recomendada para implementar o CSP em seu aplicativo seria externalizar todos JavaScript nas páginas da web.

Então esse código:
```javascript
    <script>
      function doSomething() {
        alert('Something!');
      }
	</script>

	<button onclick='doSomething();'>foobar!</button>
```
Deve ser assim:
```javascript
	<script src='doSomething.js'></script>
	<button id='somethingToDo'>Let's foobar!</button>
```
O header deve ser algo parecido com esse exemplo:
```javascript
    Content-Security-Policy: default-src'self'; object-src'none'; script-src'https://mycdn.com'
```
Como não é totalmente realista implementar todo o JavaScript em páginas externas, podemos aplicar uma espécie de token de falsificação de solicitação entre sites ao seu JavaScript embutido. Dessa forma, o navegador pode novamente distinguir a diferença entre o código que faz parte do aplicativo e o provável código injetado mal-intencionado. No CSP, isso é chamado de 'nonce'. Obviamente, esse método também é muito aplicável ao seu código e design existentes. Agora, para usar esse nonce, você deve fornecer suas tags de script embutidas com o atributo nonce. Em primeiro lugar, é importante que o nonce mude para cada resposta. Caso contrário, o nonce se tornaria adivinhado. Portanto, ele também deve conter uma entropia alta e deve ser difícil de prever. Semelhante à operação dos tokens CSRF, o nonce torna-se impossível para o invasor prever dificultando a execução de um ataque XSS bem-sucedido.


Inline JavaScript exemplo contendo nonce:
```javascript
	<script nonce=sfsdf03nceI23wlsgle9h3sdd21>
    
    </script>
```
Exemplo header:
```javascript
    Content-Security-Policy: script-src 'nonce-sfsdf03nceI23wlsgle9h3sdd21'
```
Há muito mais para aprender sobre o cabeçalho CSP para uma implementação detalhada em seu aplicativo. Esse item da base de conhecimento apenas a superfície e é altamente recomendável obter um conhecimento mais profundo sobre esse cabeçalho poderoso

## Muito importante:
Ao aplicar o cabeçalho CSP, embora bloqueie ataques XSS. Seu
O aplicativo ainda permanece vulnerável a HTML e outras injeções de código.
Portanto, isso não substitui a validação, a limpeza e a codificação da entrada do usuário.