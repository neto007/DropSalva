---
title: OWASP ASVS
---
## Descrição

O projeto OWASP Application Security Verification Standard (ASVS) fornece uma base para testar os controles técnicos de segurança de aplicativos web e também fornece aos desenvolvedores uma lista de requisitos para desenvolvimento seguro.

O objetivo principal do projeto OWASP Application Security Verification Standard (ASVS) é normalizar o alcance da cobertura e o nível de rigor disponíveis no mercado quando se trata de executar a verificação de segurança de aplicativos web usando um padrão aberto comercialmente viável. O padrão fornece uma base para testar os controles técnicos de segurança do aplicativo, bem como quaisquer controles técnicos de segurança no ambiente, para a proteção contra vulnerabilidades, como XSS (Cross-Site Scripting) e injeção de SQL. Esse padrão pode ser usado para estabelecer um nível de confiança na segurança de aplicativos web.

Os requisitos foram desenvolvidos com os seguintes objetivos em mente:

* Use como uma métrica - forneça aos desenvolvedores e proprietários de aplicativos um critério para avaliar o grau de confiança nos seus aplicativos web,
* Use como orientação - forneça orientações aos desenvolvedores de controle de segurança sobre o que criar nos controles de segurança para atender aos requisitos de segurança do aplicativo; e
* Use durante a compra - forneça uma base para especificar os requisitos de verificação de segurança do aplicativo nos contratos.

## Solução

Confira a lista de verificação OWASP-ASVS no aplicativo OWASP-SKF ou faça o download da versão em PDF do ASVS:
LINK: https://www.owasp.org/images/3/33/OWASP_Application_Security_Verification_Standard_3.0.1.pdf