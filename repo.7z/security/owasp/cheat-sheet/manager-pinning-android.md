---
title: Pinagem de Certificado - Android
---

Desde o Android N, a maneira preferida de implementar a fixação é aproveitando o recurso de [configuração de segurança](https://developer.android.com/training/articles/security-config.html) de rede do Android , que permite que os aplicativos personalizem suas configurações de segurança de rede em um arquivo de configuração declarativo e seguro sem modificar o código do aplicativo.

Para habilitar a fixação, a `<pin-set>` [definição de configuração](https://developer.android.com/training/articles/security-config.html#CertificatePinning) pode ser usada.

Se os dispositivos que executam uma versão do Android anterior a N precisarem de suporte, um backport da funcionalidade de fixação de configuração de segurança de rede está disponível por meio da biblioteca [TrustKit Android](https://github.com/datatheorem/TrustKit-Android).

Como alternativa, você pode usar métodos como a fixação de OkHTTP para definir pinos específicos de forma programática, conforme explicado no [MSTG](https://github.com/OWASP/owasp-mstg/blob/master/Document/0x05g-Testing-Network-Communication.md#network-libraries-and-webviews) e na documentação do [OKHttp](https://square.github.io/okhttp/3.x/okhttp/okhttp3/CertificatePinner.html).

A documentação do Android fornece um exemplo de como a validação SSL pode ser personalizada dentro do código do aplicativo (para implementar a fixação) no documento de implementação de CA desconhecido . No entanto, a implementação da validação de pinning do zero deve ser evitada, pois os erros de implementação são extremamente prováveis ​​e geralmente levam a vulnerabilidades graves.

Por fim, se você deseja validar se a fixação foi bem-sucedida, siga as instruções da introdução do Guia de teste de segurança móvel para [testar a comunicação de rede](https://github.com/OWASP/owasp-mstg/blob/master/Document/0x04f-Testing-Network-Communication.md#testing-network-communication) e o [teste de rede específico](https://github.com/OWASP/owasp-mstg/blob/master/Document/0x05g-Testing-Network-Communication.md#android-network-apis) do [Android](https://github.com/OWASP/owasp-mstg/blob/master/Document/0x05g-Testing-Network-Communication.md#android-network-apis).

