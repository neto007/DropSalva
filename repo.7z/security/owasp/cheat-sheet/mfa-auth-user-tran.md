---
title: Autorização de transação deve permitir que um usuário identifique e reconheça dados de transação significativos
---

Os computadores do usuário não são confiáveis ​​devido a ameaças de `malware`. Portanto, um método que evita que um usuário identifique a transação em um dispositivo externo não pode ser considerado seguro. Os dados da transação devem ser apresentados e confirmados usando um componente de autorização externo.

Esses componentes de autorização de transação devem ser construídos usando o princípio O que você vê é o que você assina . Quando um usuário autoriza uma transação, ele precisa saber o que está autorizando. Com base neste princípio, um método de autorização deve permitir que um usuário identifique e reconheça os dados que são significativos para uma determinada transação. Por exemplo, no caso de uma transferência eletrônica: a conta de destino e o valor.

A decisão sobre quais dados de transação podem ser considerados significativos deve ser escolhida com base em:

- O risco real

- As capacidades técnicas e restrições do método de autorização escolhido,

- Experiência positiva do usuário.

Por exemplo, quando uma mensagem SMS é usada para enviar dados de transação significativos, é possível enviar a conta de destino, o valor e o tipo de transferência. No entanto, para um leitor CAP não conectado , é considerado inconveniente para um usuário inserir esses dados. Nesses casos, inserir apenas os dados de transação mais significativos (por exemplo, número e valor da conta de destino parcial) pode ser considerado suficiente.

Em geral, dados de transação significativos devem sempre ser apresentados como uma parte inerente do processo de autorização de transação. Considerando que a experiência do usuário deve ser projetada para encorajar os usuários a verificar os dados da transação.

Se um processo de autenticação de transação requer que um usuário insira dados de transação em um dispositivo externo, o usuário deve ser solicitado a fornecer um valor específico (por exemplo, um número de conta de destino). A inserção de um valor sem prompt significativo pode ser facilmente abusada por `malware` usando técnicas de engenharia social, conforme descrito no exemplo no parágrafo 1.4. Além disso, para uma discussão mais detalhada dos problemas de sobrecarga de entrada.

### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)