---
title: Tipo de dados numéricos
---

Definir o tipo de dados correto para números pode ser mais complexo, pois há mais opções do que para strings.

### Restrições negativas e positivas

Os tipos de dados numéricos do esquema XML podem incluir diferentes intervalos de números. Eles podem incluir:

`negativeInteger` : Somente números negativos
`nonNegativeInteger` : Números negativos e o valor zero
`PositiveInteger` : Apenas números positivos
`nonPositiveInteger` : números positivos e o valor zero

O exemplo de documento a seguir define um id para um produto, um price e um quantity valor que está sob o controle de um invasor:

```xml

<buy>
 <id>1</id>
 <price>10</price>
 <quantity>1</quantity>
</buy>

```

Para evitar a repetição de erros antigos, um esquema XML pode ser definido para evitar o processamento da estrutura incorreta nos casos em que um invasor deseja introduzir elementos adicionais:

```xml

<xs:schema xmlns:xs="http://www.w3.org/2001/XMLSchema">
 <xs:element name="buy">
  <xs:complexType>
   <xs:sequence>
    <xs:element name="id" type="xs:integer"/>
    <xs:element name="price" type="xs:decimal"/>
    <xs:element name="quantity" type="xs:integer"/>
   </xs:sequence>
  </xs:complexType>
 </xs:element>
</xs:schema>

```

O elemento denominator agora está restrito a inteiros positivos. Isso significa que apenas valores maiores que zero serão considerados válidos. Se você vir qualquer outro tipo de restrição sendo usado, poderá disparar um erro se o denominador for zero.

### Valores especiais: infinito e não é um número

Os tipos de dados `float` e `double` contem números reais e alguns valores especiais: `-Infinity` ou `-INF`, `NaN` e `+Infinity` ou `INF`. Essas possibilidades podem ser úteis para expressar certos valores, mas às vezes são mal utilizadas. O problema é que geralmente são usados ​​para expressar apenas números reais, como preços. Este é um erro comum visto em outras linguagens de programação, não apenas restrito a essas tecnologias. Não considerar todo o espectro de valores possíveis para um tipo de dados pode fazer com que os aplicativos subjacentes falhem. Se os valores especiais `Infinity`e  `NaN` não forem necessários e apenas números reais forem esperados, o tipo de dados `decimal` é recomendado:


<xs:schema xmlns:xs="http://www.w3.org/2001/XMLSchema">
 <xs:element name="buy">
  <xs:complexType>
   <xs:sequence>
    <xs:element name="id" type="xs:integer"/>
    <xs:element name="price" type="xs:decimal"/>
    <xs:element name="quantity" type="xs:positiveInteger"/>
   </xs:sequence>
  </xs:complexType>
 </xs:element>
</xs:schema>

O valor do preço não acionará nenhum erro quando definido em `Infinity` ou `NaN`, porque esses valores não serão válidos. Um invasor pode explorar esse problema se esses valores forem permitidos.

## Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/cheatsheets/XML_Security_Cheat_Sheet.html)