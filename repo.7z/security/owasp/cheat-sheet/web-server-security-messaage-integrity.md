---
title: Integridade da Mensagem
---

Isso é para dados em repouso. A integridade dos dados em trânsito pode ser facilmente fornecida pelo TLS .

Ao usar criptografia de chave pública , a criptografia garante a confidencialidade, mas não garante a integridade, uma vez que a chave pública do receptor é pública. Pelo mesmo motivo, a criptografia não garante a identidade do remetente.

**Regra:** Para dados XML, use assinaturas digitais XML para fornecer integridade de mensagem usando a chave privada do remetente. Essa assinatura pode ser validada pelo destinatário usando o certificado digital do remetente (chave pública).

## Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/)
