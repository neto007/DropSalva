---
title: Falsificação De Solicitação Do Lado Do Servidor
---
## Descrição

Ataque Server Side Request Forgery (SSRF), em que um invasor abusa da funcionalidade de um
aplicativo da web vulnerável para enviar solicitação de crafter que lê ou atualiza
Recursos. O invasor pode atacar uma rede interna ou aplicativo atrás do firewall com
este ataque que normalmente não é acessível através de rede externa e até mesmo ataca o
aplicativos da web de rede interna.

O ataque SSRF pode ser usado para fazer solicitações a outros recursos internos para acessar o metadados e para executar uma porta pode na rede interna. Esquema de URL, como arquivo: // pode ser usado para ler o arquivo do servidor. Os invasores podem usar esquemas de URL legados, como dict, gopher, expect etc que pode até causar a execução remota de código.

## Solução

Desative os esquemas de URL não utilizados que são perigosos, como expect: //, file: ///, ftp: //, gopher: //. Lista branca adequada do domínio ou endereço IP que você precisa acessar. Resposta recebida de servidor interno não deve ser mostrado ao invasor. Alguns serviços como Memcached, Redis, Elasticsearch e MongoDB não requerem autenticação por padrão, então precisamos habilitar autenticação para esses serviços.