---
title: Expiração da sessão de logout
---
## Descrição

Uma vez que o usuário pressiona o botão de logout ou é desconectado por inatividade, é esperado que o aplicativo encerre a sessão do usuário e expire os identificadores da sessão corretamente. No entanto, há situações em que o aplicativo simplesmente redireciona o usuário para a página de logon. Além disso, os aplicativos modernos dependem do armazenamento do lado do cliente, como arquivos de cache, armazenamento da sessão do navegador, cookies como IndexedDB, que podem conter informações confidenciais e relacionadas à sessão. No entanto, aplicativos complexos que dependem de mecanismos de logon único (SSO) podem deixar a sessão do aplicativo de origem como aberta. Nos cenários descritos, um invasor que acessa um computador compartilhado ou usa um computador autônomo pode retomar a sessão e operar o aplicativo em nome do usuário.


## Solução

Verifique se o logout absoluto e de tempo limite invalida ou apaga qualquer armazenamento de sessão do lado do cliente ou do servidor, de modo que o botão Voltar ou uma parte confiante a jusante não retome uma sessão autenticada, inclusive entre as partes confiantes. Além disso, verifique se os identificadores de sessão expiraram e não podem ser reutilizados.