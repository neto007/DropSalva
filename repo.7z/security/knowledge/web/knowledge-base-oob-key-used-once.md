---
title: Chave OOB usada uma vez
---
## Descrição

Se um aplicativo permitir que o usuário tente autenticação fora de banda usando uma chave de autenticação fora de banda antiga, aumenta a probabilidade de ataques de repetição e pode ajudar na composição de uma sessão do usuário.

## Solução

A solução mais eficaz é rejeitar tentativas de autenticação fora de banda após 10 minutos e também garantir que a chave de autenticação fora de banda possa ser usada apenas uma vez. O sistema que fornece material de codificação de autenticação fora da banda deve descartar a chave assim que usada.