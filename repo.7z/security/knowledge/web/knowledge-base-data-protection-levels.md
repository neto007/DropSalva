---
title: Níveis de proteção de dados
---
## Descrição

A tríade da CIA de confidencialidade, integridade e disponibilidade está no centro da segurança da informação.

### Confidencialidade
Na segurança da informação, a confidencialidade "é a propriedade, dessa informação
não é disponibilizado ou divulgado a indivíduos, entidades ou processos não autorizados ".
Embora parecidas com "privacidade", as duas palavras não são intercambiáveis. Pelo contrário, confidencialidade é um componente de privacidade implementado para proteger nossos dados de visualizadores não autorizados. Exemplos de confidencialidade de dados eletrônicos comprometidos incluem roubo de laptop, roubo de senha ou e-mails confidenciais enviados para as pessoas incorretas.

### Integridade
Na segurança da informação, integridade de dados significa manter e garantir a precisão
e integridade dos dados durante todo o ciclo de vida. Isso significa que os dados não podem ser modificado de maneira não autorizada ou não detectada. Isso não é a mesma coisa que integridade referencial nos bancos de dados, embora possa ser visto como um caso especial de consistência conforme entendido no modelo ACID clássico de processamento de transações. Os sistemas de segurança da informação geralmente fornecem a integridade da mensagem e a confidencialidade.

### Disponibilidade
Para que qualquer sistema de informações atenda a sua finalidade, as informações devem estar disponíveis quando necessárias. Isso significa que os sistemas de computação usados para armazenar e processar as informações, os controles de segurança usados para protegê-lo e os canais de comunicação usados para acessá-lo deve estar funcionando corretamente. Os sistemas de alta disponibilidade visam permanecer disponíveis sempre, impedindo interrupções no serviço devido a falta de energia, falhas de hardware,
e atualizações do sistema. Garantir a disponibilidade também envolve a prevenção de ataques de negação de serviço, como uma enxurrada de mensagens recebidas no sistema de destino, forçando-o a desligar.


## Solução

Com base na CIA, determine um nível de proteção e defina contramedidas que pertencem àquele nível de proteção, como mas não limitado a.

- Requisitos de criptografia
- Requisitos de integridade
- Retenção
- Privacidade

e outros requisitos de confidencialidade, e que eles sejam aplicados na arquitetura.