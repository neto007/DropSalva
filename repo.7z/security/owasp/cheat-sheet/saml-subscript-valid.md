---
title: Validar Assinatura do Protocolo SAML
---

Vulnerabilidades em implementações de SAML devido a ataques `XML Signature Wrapping` foram descritas em **2012, On Breaking SAML: Be Who You Want to Be .**

As seguintes recomendações foram propostas em resposta (validação segura de SAML para evitar ataques de empacotamento de assinatura XML):

- Sempre execute a validação de esquema no documento XML antes de usá-lo para quaisquer fins relacionados à segurança:

- Sempre use cópias locais e confiáveis ​​de esquemas para validação.

- Nunca permita o download automático de esquemas de locais de terceiros.

- Se possível, inspecione os esquemas e execute a proteção do esquema para desativar possíveis tipos de curinga ou instruções de processamento relaxadas.

**Valide com segurança a assinatura digital:**

- Se você espera apenas uma chave de assinatura, use `StaticKeySelector`. Obtenha a chave diretamente do provedor de identidade, armazene-a no arquivo local e ignore todos os KeyInfo elementos do documento.

- Se você espera mais de uma chave de assinatura, use `X509KeySelector`(a variante JKS). Obtenha essas chaves diretamente dos provedores de identidade, armazene-as no JKS local e ignore quaisquer `KeyInfo` elementos do documento.

- Se você espera documentos assinados heterogêneos (muitos certificados de muitos provedores de identidade, caminhos de validação de vários níveis), implemente o modelo de estabelecimento de confiança total baseado em PKIX e certificados raiz confiáveis.

- Evite ataques de quebra de assinatura.

- Nunca use `getElementsByTagName` para selecionar elementos relacionados à segurança em um documento XML sem validação prévia.
Sempre use expressões XPath absolutas para selecionar elementos, a menos que um esquema reforçado seja usado para validação.

### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)