---
title: Editores Wysiwyg
---

## Intodução:

Wysiwyg é uma sigla em inglês formada pelas iniciais da expressão “What You See Is What You Get” e quer dizer “O que você vê é o que você obtém”. O termo é usado para classificar ferramentas de edição e desenvolvimento que permitem visualizar, em tempo real, exatamente aquilo que será publicado ou impresso.

## Descrição

Editores WYSIWYG podem ser um grande risco para seu aplicativo da web, pois permitem
HTML como entrada para fazer o usuário estilizar seus envios. É por isso que
O editor deve ser submetido a um protocolo estrito de saneamento para prevenir injeções.

A primeira coisa a levar em consideração sempre que quiser usar editores WYSIWYG em
seu aplicativo da web deve usar o máximo possível de opções limitadas. Apenas as opções que
são necessários para seus aplicativos, a operação pretendida deve ser aplicada. Isso diminui
o vetor de ataque dos atacantes drasticamente e deixa menos espaço para erros em seu WYSIWYG
editor em termos de saneamento de HTML.

Ao fornecer seu aplicativo da web com um editor WYSIWYG, você também deve observar que
a maioria das pessoas quer apenas usar marcadores, colocar o texto em negrito ou sublinhar algum texto. Eles principalmente não compreendo metade das funcionalidades que os editores estão oferecendo.

## Solução

Baixe um sanitizer HTML e configure-o de acordo com suas necessidades específicas. Ao configurar o higienizador, certifique-se de você desabilita todos os componentes não utilizados. Quanto menos opções um invasor tiver para inserir em seu aplicativo, menor sua superfície de ataque se torna. Além disso, antes de implementar este sanitizer HTML em um ambiente de produção, primeiro é examinado minuciosamente por testadores de segurança, uma vez que é uma função muito delicada.