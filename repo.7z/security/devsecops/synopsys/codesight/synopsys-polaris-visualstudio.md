---
title: Instalação Plugin Synopsys Code Sight
sidebar_label: IDE Visual Studio - Code Sight
---

Abaixo serão apresentados os passos-a-passo da instalação do plugin para utilização na IDE Visual Studio. 

## Criação de Variável

Primeiramente vamos criar duas variáveis necessárias para a instalação do motor de análise polaris:

![Criação de Variável ](/assets/devsecops/synopsys/variavel.png)

 Crie também um diretorio local chamado **Synopsys** em **C:\\**:  

![Criação de Variável ](/assets/devsecops/synopsys/variavel_02.png)

## Instalação do Plugin Visual Studio

Selecione Ferramentas> Extensões e Atualizações. (No Visual Studio 2019, a escolha é extensões>
Gerenciar extensões.) no campo de busca preencha **Synopsys Code Sight** clique em **Baixar**:

![Gerneciador de extensão](/assets/devsecops/synopsys/visualstudio/02.png)

Agora, um ícone do Installer VSIX aparece na barra de tarefas e uma caixa de diálogo VSIX Installer é aberta logo após isso.

![Installer VSIX](/assets/devsecops/synopsys/visualstudio/03.png)

Na caixa de diálogo VSIX Installer, clique em Instalar.

- O instalador do VSIX instala o plug-in.
- Na caixa de diálogo VSIX Installer, clique em Fechar.
- Inicie o Visual Studio mais uma vez.

Depois que o IDE é iniciado novamente, a interface de Code Sight aparece dentro dela.

## Configuração do Plugin

Ao abrir o Visual Studio em Synopsys Code Sight irá aparecer duas caixas de instalação: 

Clique em install dentro de **Coverity (SAST)**:

![Coverity (SAST)](/assets/devsecops/synopsys/visualstudio/04.png)

    Aguarde a instalação esse pacote possui aproximadamente 1.8gb

Após término clique em **Skip Additional Tool**

![Coverity (SAST)](/assets/devsecops/synopsys/visualstudio/04_01.png)

## Configuração Local

Vá ate a pasta **"C:\Users\ **XXXX** \AppData\Roaming\Coverity"** e inclua as seguintes configurações.

Obs: nos arquivos existente a propriedade Setting já existe, **inclua** apenas o objeto **cov_run_desktop**

``` yml
{
  "type": "Coverity configuration",
  "format_version": 1,
  "settings": {
    "cov_run_desktop": {
        "build_cmd": ["msbuild", "/t:Build"],
        "build_options": [
            "--instrument"
        ],
        "clean_cmd": ["msbuild", "/t:Clean"],
        "analysis_args": [
            "--enable-audit-mode",
            "--webapp-security"
        ]
    }
  }
}
```
    Caso o comando para executar sua aplicação seja diferente de **msbuild** o mesmo deverá ser ajustado para o comando correto.

## Autenticação

A Autenticação permite que a análise compartilhe dados de triagem com um servidor central.
Isso também permite baixar varreduras de projeto completo diretamente do servidor, o que melhora a qualidade de análise local.

Conforme solicitado, insira seu nome de usuário(e-mail) e insira o URL para o servidor:

![Autenticação](/assets/devsecops/synopsys/visualstudio/05.png)

**Em URL insira:** https://xpinvestimentos.polaris.synopsys.com

Clique em: **Continue**

Será aberto uma página solicitando um **Acess Token** pessoal para conectar ao servidor do Polaris.

#### Criação  de Acess Token

Acesse [POLARIS XP](https://xpinvestimentos.polaris.synopsys.com) -> User Profile -> Access Tokens e clique em **Create New Token**:

![Acess Token](/assets/devsecops/synopsys/visualstudio/07.png)

#### Sign In

com seu token em mãos, insira no campo solicitado pelo **Code Sight** e clique em continuar para finalizar a instalação e autenticação:

![Acess Token](/assets/devsecops/synopsys/visualstudio/09.png)

## Scaneando Projeto

Certifiqui-se que seu projeto possua o arquivo polais.yml configurado em seu repositorio.

Caso seu projeto não esteja scaneado no Polares será necessesario executar um **Start full Scan** (_clique em Status ->  Notification-> Start full Scan_):

![Start full Scan](/assets/devsecops/synopsys/visualstudio/15.png)

### Issues

Na opção issues será apresentado a lista de Vulnerabilidades locais (Current Files ou All Scanned Files) ou arquivos que foram enviados para analise (Dismissed):

![Issues-Dismissed](/assets/devsecops/synopsys/visualstudio/10.png)

### Status

#### Notification

    Notificações sobre possíveis ações a serem tomadas

#### Scans  

    Arquivos que estão sendo analisados comforme são inseridas novas linhas de codigo ou arquivos abertos/Salvos.

## Sistemas suportados

 - https://sig-docs.synopsys.com/codesight/topics/support_matrix/r_code_sight_support_matrix.html 

## Referência

- https://sig-docs.synopsys.com/codesight/index.html
- https://community.synopsys.com/s/getting-started-with-synopsys/getting-started-with-code-sight
