---
title: Validação de Conteúdo
---

**Regra:** como qualquer aplicativo da web, os serviços da web precisam validar a entrada antes de consumi-la. A validação de conteúdo para entrada XML deve incluir:

- Validação contra entidades XML malformadas.
- Validação contra ataques de bomba XML.
- Validando entradas usando uma forte lista branca.
- Validando contra ataques a entidades externas.

## Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/)
