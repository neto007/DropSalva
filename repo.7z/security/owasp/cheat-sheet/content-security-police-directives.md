---
title: Diretivas content-security Police (CSP)
---

Existem vários tipos de diretivas que permitem ao desenvolvedor controlar granularmente o fluxo das políticas. As diretivas de busca informam ao navegador os locais dos quais confiar e carregar os recursos. A maioria das diretivas de busca tem uma certa lista de fallback especificada em w3 . Esta lista permite o controle granular da origem de scripts, imagens, arquivos, etc.

* child-src: permite que o desenvolvedor controle contextos de navegação e contextos de execução do trabalhador.
* frame-src: especifica os URLs que podem ser carregados em contextos de navegação ( por exemplo `<iframe>` ).
* worker-src: especifica os URLs que podem ser carregados como trabalhador, trabalhador compartilhado ou trabalhador de serviço. Fallback script-srctambém.
* connect-src: fornece controle sobre solicitações de busca, conexões XHR, eventsource, beacon e websockets.
* font-src: especifica de quais URLs carregar fontes.
* img-src: especifica os URLs dos quais as imagens podem ser carregadas.
* manifest-src: especifica os URLs dos quais os manifestos do aplicativo podem ser carregados.
* media-src: especifica os URLs a partir dos quais os recursos de trilha de vídeo, áudio e texto podem ser carregados.
* prefetch-src: especifica os URLs a partir dos quais os recursos podem ser pré-buscados.
* object-src: especifica os URLs a partir dos quais os plug-ins podem ser carregados.
* script-src: especifica os locais a partir dos quais um script pode ser executado. É uma diretiva de fallback para outras diretivas semelhantes a script.
* script-src-elem: controla o local a partir do qual a execução de solicitações e bloqueios de script pode ocorrer.
* script-src-attr: controla a execução de manipuladores de eventos.
* style-src: controles de onde os estilos são aplicados a um documento. Isso inclui `<link>`elementos e solicitações originadas de um Linkcampo de cabeçalho de resposta HTTP.
* style-src-elem: controla estilos, exceto para atributos embutidos.
* style-src-attr: controla atributos de estilos.
* default-src: é uma diretiva de fallback para as outras diretivas de busca. As diretivas especificadas não têm herança, mas as diretivas não especificadas terão o valor de default-src.