---
title: Dados seguros em .Net
---

O .NET Framework é o conjunto de APIs que oferecem suporte a um sistema de tipo avançado, dados, gráficos, rede, manipulação de arquivos e muito do que é necessário para escrever aplicativos empresariais no ecossistema da Microsoft. É uma biblioteca quase onipresente, fortemente nomeada e versionada no nível do assembly.

## Acesso aos dados

* Use comandos SQL parametrizados para todos os acessos aos dados, sem exceção.
* Não use SqlCommand com um parâmetro de string composto de uma String SQL concatenada.
* Coloque na lista de permissões os valores permitidos vindos do usuário. Use enums, TryParse ou valores de pesquisa para garantir que os dados vindos do usuário sejam os esperados.
* Enums ainda são vulneráveis ​​a valores inesperados porque .NET só valida uma conversão bem-sucedida para o tipo de dados subjacente, inteiro por padrão. `"Enum.IsDefined"` pode validar se o valor de entrada é válido dentro da lista de constantes definidas.
* Aplique o princípio do menor privilégio ao configurar o usuário do banco de dados no banco de dados de sua escolha. O usuário do banco de dados só deve ser capaz de acessar itens que façam sentido para o caso de uso.
* O uso do Entity Framework é um mecanismo de prevenção de injeção de SQL é muito eficaz. Lembre-se de que construir suas próprias consultas ad hoc no Entity Framework é tão suscetível ao SQLi quanto uma consulta SQL simples.
* Ao usar SQL Server, preferir a autenticação integrada sobre a autenticação SQL.
* Use "Always Encrypted" sempre que possível para dados confidenciais (SQL Server 2016 e SQL Azure).

## Referência externa
[.Net security](https://cheatsheetseries.owasp.org/cheatsheets/DotNet_Security_Cheat_Sheet.html)