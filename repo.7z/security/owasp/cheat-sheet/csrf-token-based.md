---
title: Mitigação baseada em token
---

Essa defesa é um dos métodos mais populares e recomendados para mitigar a CSRF. Ele pode ser obtido com o estado ( padrão de token do sincronizador ) ou sem estado ( criptografado ou padrão de token baseado em hash ).

- Use implementações CSRF integradas ou existentes para proteção CSRF

As defesas do token do sincronizador foram integradas a muitas estruturas. É altamente recomendável pesquisar se a estrutura que você está usando tem uma opção para obter proteção contra CSRF por padrão antes de tentar construir seu sistema de geração de token personalizado. Por exemplo, o .NET tem proteção interna que adiciona um token aos recursos vulneráveis ​​CSRF. Você é responsável pela configuração adequada (como gerenciamento de chaves e gerenciamento de tokens) antes de usar essas proteções CSRF integradas que geram tokens para proteger recursos vulneráveis ​​de CSRF.

Componentes externos que adicionam defesas CSRF a aplicativos existentes também são recomendados. Exemplos:

- Para Java: OWASP CSRF Guard ou Spring Security
- Para PHP e Apache: Projeto CSRFProtector
- Para AngularJS: Proteção Cross-Site Request Forgery (XSRF)


### Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/)