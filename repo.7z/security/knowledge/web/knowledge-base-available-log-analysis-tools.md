---
title: Ferramentas de análise de log disponíveis
---

## Descrição

Com uma ferramenta de análise de logs instalada, você pode fazer análise forense de maneira fácil e rápida assim que observar que sua aplicação está sendo atacado por invasores e bloqueá-los.

## Solução

Você pode encontrar uma lista de ferramentas recomendadas pela OWASP em
https://www.owasp.org/index.php/Log_review_and_management#Logging_Tools
