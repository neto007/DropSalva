---
title: Mensagem de erro detalhada
---
## Descrição

Um aspecto importante do desenvolvimento de aplicativos seguros é evitar o vazamento de informações. As mensagens de erro fornecem ao invasor uma grande visão do funcionamento interno de um aplicativo.

O objetivo de revisar o código de tratamento de erros é garantir que o aplicativo falhe com segurança em todas as possíveis condições de erro, esperadas e inesperadas. Nenhuma informação sensível deve ser apresentada ao usuário quando ocorre um erro.

Quando uma exceção ou erro é lançado, também precisamos registrar essa ocorrência. Às vezes, isso é devido ao desenvolvimento, mas pode ser o resultado de um ataque ou algum outro serviço em que seu aplicativo depende da falha.

Todos os caminhos de código que podem causar o lançamento de uma exceção devem verificar o sucesso para a exceção para não ser lançado.

## Solução

Devemos usar uma string de descrição localizada em cada exceção, um motivo de erro amigável, como “Erro do sistema - tente novamente mais tarde”. Quando o usuário vê uma mensagem de erro, ela será derivada desta string de descrição da exceção que foi lançada, e nunca da classe de exceção que pode conter um rastreamento de pilha, o número da linha onde o erro ocorreu, nome da classe ou nome do método.

Não exponha informações confidenciais em mensagens de exceção. Informações como caminhos no sistema de arquivos local são consideradas informações privilegiadas; qualquer informação interna do sistema deve ser ocultada do usuário. Conforme mencionado antes, um invasor pode usar essas informações para coletar informações privadas do usuário do aplicativo ou dos componentes que o constituem.

Não coloque nomes de pessoas ou quaisquer informações de contato interno em mensagens de erro. Não coloque nenhuma informação "humana", o que levaria a um nível de familiaridade e uma exploração de engenharia social.

Outro bom exemplo seria que as funções de esquecimento de senha gerassem uma mensagem de erro genérica quando um endereço de e-mail  é ou não conhecido no sistema. Isso deve evitar a enumeração de endereços de e-mail.