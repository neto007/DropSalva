---
title: Segurança no HTML
---

## Web Messaging

O Web Messaging (também conhecido como Cross Domain Messaging) fornece um meio de enviar mensagens entre documentos de diferentes origens de uma forma que geralmente é mais segura do que os vários hacks usados ​​no passado para realizar essa tarefa. No entanto, ainda existem algumas recomendações a serem consideradas:

* Ao postar uma mensagem, indique explicitamente a origem esperada como o segundo argumento para, em postMessage afim de evitar o envio da mensagem para uma origem desconhecida após um redirecionamento ou algum outro meio de alteração da origem da janela de destino.
* Verifique a origem do atributo do remetente para verificar se os dados são originários do local esperado.
* Execute a validação de entrada no atributo do evento para garantir que esteja no formato desejado.
* Não presuma que você tem controle sobre o atributo. Uma única falha de Cross Site Scripting na página de envio permite que um invasor envie mensagens de qualquer formato.
* Ambas as páginas devem interpretar as mensagens trocadas apenas como dados. Nunca avalie mensagens passadas como código (por exemplo, via `eval()`) ou insira-o em uma página DOM (por exemplo, via `innerHTML`), pois isso criaria uma vulnerabilidade XSS baseada em DOM.
* Para atribuir o valor dos dados a um elemento, em vez de usar um método inseguro como `element.innerHTML=data;`, use a opção mais segura: `element textContent=data;`.
* Verifique a origem corretamente para corresponder ao(s) FQDN s) que você espera. Observe que o código a seguir: `if(message.origin.indexOf(".owasp.org")!=-1) { /* ... */ }` é muito inseguro e não terá o comportamento desejado como owasp.org.attacker.com corresponderá.
* Se você precisar incorporar conteúdo externo/gadgets não confiáveis ​​e permitir scripts controlados pelo usuário (o que é altamente desencorajado), considere o uso de uma estrutura de reescrita de JavaScript, como o Google Caja, ou verifique as informações em frames em sandbox.