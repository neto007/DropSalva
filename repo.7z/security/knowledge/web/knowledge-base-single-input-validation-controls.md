---
title: Controles De Validação De Entrada Única
---
## Descrição

A validação de entrada se refere ao processo de validação de todas as entradas de um aplicativo antes de usá-lo. A validação de entrada é absolutamente crítica para a segurança do aplicativo, e a maioria dos riscos de aplicativos envolvem entrada contaminada em algum nível.

## Solução

Verifique se um único controle de validação de entrada é usado pelo aplicativo para cada
tipo de dados aceitos. Desta forma, seus controles de validação permanecem claros, transparentes e gerenciável. Este método deixa menos margem para erros.