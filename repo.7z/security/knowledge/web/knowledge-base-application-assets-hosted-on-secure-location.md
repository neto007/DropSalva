---
title: Recursos do aplicativo hospedados em local seguro
---
## Descrição

Sempre que ativos de aplicativos, como bibliotecas JavaScript ou CSS stylesheets não estiverem hospedados no próprio aplicativo, mas em uma CDN externa que não esteja sob seu controle, essas CDNs podem introduzir vulnerabilidades de segurança. 
Sempre que um desses CDN é comprometido, os invasores podem incluir scripts maliciosos. Além disso, sempre que uma dessas CDNs ficar fora de serviço isso pode afetar a operação do aplicativo e até causar uma negação de serviço.

## Solução

Verifique se todos os ativos do aplicativo estão hospedados no aplicativo, como bibliotecas JavaScript, CSS stylesheets e fontes web são hospedadas pelo aplicativo em vez de depender de uma CDN ou fornecedor externo.