---
title: As Informações Da Sessão Não São Armazenadas No Servidor
---
## Descrição

Sempre que as informações da sessão não são armazenadas no lado do servidor, um invasor pode facilmente adulterar e manipular esses valores. Esta é sempre uma má ideia e você não deve fazer isso!

## Solução

As informações da sessão sempre devem ser armazenadas no lado do servidor por meio de uma linguagem do lado do servidor.