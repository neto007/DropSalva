---
title: Autorização sensível ao contexto
---
## Descrição

Sempre que conceder aos usuários diferentes tipos de autorização em todo o aplicativo
as concessões de autorização devem ser concedidas e aplicadas fora do escopo do invasor.
ou seja, sempre que um usuário recebe suas concessões de autorização por meio de um cookie que diz:

```plain
auth = admin ou auth = user
```

Essas concessões de autorização são facilmente manipuláveis.


## Solução

As concessões de autorização devem ser concedidas e aplicadas fora do escopo do invasor.

ou seja:

O usuário efetua login no aplicativo, o ID do usuário é armazenado em uma variável local. O aplicativo armazena concessões (privilégios / atributos / reivindicações) no banco de dados e para cada função que o usuário chama, o aplicativo obtém as concessões do banco de dados usando a variável local e verifica se o usuário tem acesso a esta função.