---
title: Confidencialidade de transporte
---

A confidencialidade do transporte protege contra espionagem e ataques `man-in-the-middle` contra comunicações de serviço da web de / para o servidor.

**Regra:** todas as comunicações com e entre os serviços da web que contêm recursos confidenciais, uma sessão autenticada ou transferência de dados confidenciais devem ser criptografados usando TLS bem configurado . Isso é recomendado mesmo se as próprias mensagens forem criptografadas porque o TLS fornece vários benefícios além da confidencialidade do tráfego, incluindo proteção de integridade, defesas de reprodução e autenticação de servidor. Para obter mais informações sobre como fazer isso corretamente, consulte a Folha de Dicas sobre Proteção da Camada de Transporte .

## Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/)