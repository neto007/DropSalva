const azure = require('./azure/sidebars')

module.exports = {
    type: "category",
    label: "Cloud",
    items: [    
        azure
    ],
};