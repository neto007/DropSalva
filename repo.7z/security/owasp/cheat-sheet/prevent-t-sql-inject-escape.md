---
title: Defesa contra SQL inject - Escapando de todas as entradas fornecidas pelo usuário
---

Esta técnica só deve ser usada como último recurso, quando nenhuma das opções acima for viável. A validação de entrada é provavelmente uma escolha melhor, pois esta metodologia é frágil em comparação com outras defesas e não podemos garantir que irá impedir toda injeção de SQL em todas as situações.

Essa técnica evita a entrada do usuário antes de colocá-la em uma consulta. É muito específico para banco de dados em sua implementação. Normalmente, é recomendado apenas adaptar o código legado quando a implementação da validação de entrada não é econômica. Os aplicativos criados do zero ou que exigem baixa tolerância a riscos devem ser criados ou reescritos usando consultas parametrizadas, procedimentos armazenados ou algum tipo de Mapeador Relacional de Objeto (ORM) que constrói suas consultas para você.

Essa técnica funciona assim. Cada DBMS suporta um ou mais esquemas de escape de caractere específicos para certos tipos de consultas. Se você então escapar de todas as entradas fornecidas pelo usuário usando o esquema de escape adequado para o banco de dados que você está usando, o SGBD não confundirá essa entrada com o código SQL escrito pelo desenvolvedor, evitando assim quaisquer possíveis vulnerabilidades de injeção de SQL.

O OWASP Enterprise Security API (ESAPI) é uma biblioteca de controle de segurança de aplicativos da Web gratuita e de código aberto que torna mais fácil para os programadores escreverem aplicativos de baixo risco. As bibliotecas ESAPI são projetadas para tornar mais fácil para os programadores adaptarem a segurança aos aplicativos existentes. As bibliotecas ESAPI também servem como uma base sólida para novos desenvolvimentos:

Detalhes completos sobre o [ESAPI estão disponíveis no OWASP](https://owasp.org/www-project-enterprise-security-api/).

- O javadoc para [ESAPI](https://www.javadoc.io/doc/org.owasp.esapi/esapi/2.1.0/index.html) 2.x (Legacy) está disponível. 

- O [ESAPI](https://github.com/ESAPI/esapi-java-legacy) legado para Java no GitHub ajuda a entender o uso existente dele quando o Javadoc parece insuficiente.

- Uma tentativa de outro [ESAPI](https://github.com/ESAPI/esapi-java) para Java GitHub tem outras abordagens e nenhum teste ou codecs concretos.


**ORACLE ESCAPING**

Essas informações são baseadas nas informações do caractere Oracle Escape .

Escapando de consultas dinâmicas

Usar um `codec` de banco de dados ESAPI é muito simples. Um exemplo da Oracle é semelhante a:


`ESAPI.encoder().encodeForSQL( new OracleCodec(), queryparam );`

Então, se você tivesse uma consulta dinâmica existente sendo gerada em seu código que estava indo para o Oracle, que se parecia com isto:

```java

String query = "SELECT user_id FROM user_data WHERE user_name = '"
              + req.getParameter("userID")
              + "' and user_password = '" + req.getParameter("pwd") +"'";
try {
    Statement statement = connection.createStatement( … );
    ResultSet results = statement.executeQuery( query );
}
```

Você reescreveria a primeira linha para ficar assim:

```java

Codec ORACLE_CODEC = new OracleCodec();
String query = "SELECT user_id FROM user_data WHERE user_name = '"
+ ESAPI.encoder().encodeForSQL( ORACLE_CODEC, req.getParameter("userID"))
+ "' and user_password = '"
+ ESAPI.encoder().encodeForSQL( ORACLE_CODEC, req.getParameter("pwd")) +"'";

```

### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)