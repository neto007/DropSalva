---
title: Implementação TLS
---
## Descrição

Sempre que informações confidenciais estiverem sendo enviadas pela aplicação, o TLS deve ser aplicado para evitar que invasores mal-intencionados espionem a rede, podendo examinar e manipular as informações sensíveis.

## Solução

Verifique se o TLS é usado para todas as conexões (incluindo conexões externas e de back-end)
que são autenticados ou que envolvem dados ou funções confidenciais e não voltam para
protocolos inseguros ou não criptografados. Certifique-se de que a alternativa mais forte é o algoritmo preferido.

Como a criptografia moderna depende de um custo computacional alto para quebrar, padrões específicos podem ser definidos pelo tamanho das chaves que fornecerão a garantia de que, com a tecnologia e a compreensão de hoje, vai demorar muito para descriptografar uma mensagem tentando todas as chaves possíveis.

Portanto, precisamos garantir que tanto o algoritmo quanto o tamanho da chave sejam levados em consideração ao selecionar um algoritmo. 
Mesmo que a computação evolua, os padrões de escolha de um novo algoritmo também evolui.
