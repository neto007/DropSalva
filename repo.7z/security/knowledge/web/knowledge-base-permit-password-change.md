---
title: Permitir alteração de senha
---
## Descrição

Os usuários devem poder atualizar suas senhas sempre que necessário. Por exemplo, considere o cenário em que eles tendem a usar a mesma senha para várias finalidades. Se essa senha vazar, os usuários deverão atualizar imediatamente suas credenciais em todos os aplicativos registrados. Portanto, se o aplicativo não fornecer uma funcionalidade de atualização de senha acessível a um usuário, existe o risco de que sua conta seja invadida.

## Solução

Os aplicativos devem fornecer ao usuário uma funcionalidade que permita a alteração de sua própria senha.
