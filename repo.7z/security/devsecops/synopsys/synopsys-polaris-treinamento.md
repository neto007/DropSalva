---
title: Treinamento Synopsys 
---
import StreamVideo from '@theme/StreamVideo'

Caso não tenha participado das sessões de treinamentos, compartilhamos abaixo os videos gravados para duas turmas de desenvolvedores.

## Treinamento Primeira Turma

<StreamVideo videoId='4089a2be-185f-44d0-b748-5ee4ec689df7' />

## Treinamento Segunda Turma

<StreamVideo videoId='c9ecec97-1b8e-42d0-8586-35bbf1a73970' />