---
title: Evite o uso de contas padrão e conhecidas/previsíveis
---
## Descrição

Sempre que houver contas padrão ou previsíveis disponíveis em uma aplicação/servidor, isso poderá levar um invasor a comprometer esses serviços. Verifique se todos os padrões e contas conhecidas/previsíveis estão desativadas ou excluídas dos serviços.

## Solução

Verifique se todas as chaves e senhas são substituíveis e se são geradas ou
substituídas após um período de tempo.