---
title: Insufficient Logging & Monitoring
---


## A API está vulnerável?
A API está vulnerável se:
* Não produz qualquer tipo de log, ou se o nível de log não é configurado adequadamente, ou ainda, se as
mensagens de log não incluem informações suficientes.
* A integridade do log não é garantida (ex.: Injeção de Log).
* Logs não estão em contínuo monitoramento.
* A infraestrutura da API não é continuamente monitorada.. 


## Cenários de exemplo de ataques

#### Cenário #1
Chaves de acesso de administração da API são vazados em um repositório público. O proprietário do repositório é notificado por e-mail a respeito do provável vazamento, mas, até que uma ação seja realizada em reposta ao incidente se passaram 48 horas. Em razão de logs insuficientes, a companhia não é capaz de identificar quais informações foram acessadas durante o período por atores maliciosos..

#### Cenário #2
Uma plataforma de compartilhamento de vídeos foi atingida por um ataque de credential stuffing de larga escala. Mesmo com os logins que falharam sendo logados, não houveram alertas disparados durante o tempo de duração do ataque. Como uma resposta à reclamação dos usuários, os logs de API foram analisados e o ataque foi detectado. A companhia fez um anúncio público solicitando aos seus usuários que façam atualização de suas senhas, e reportam o incidente às autoridades regulatórias..

## Como prevenir
* Faça log de todas tentativas de logon mal sucedidas, acessos negados e erros de validação de entradas de usuários.
* Logs devem ser escritos em um formato apropriado para serem consumidos por soluções de gerenciamento de logs, e devem incluir detalhes suficientes para ajudar a identificar o ator malicioso.
* Logs devem ser manipulados como dados sensíveis, e sua integridade deve ser garantida tanto em trânsito como em repouso.
* Configure o sistema de monitoramento a monitorar continuamente a infraestrutura, rede e o funcionamento da API.
* Utilize um SIEM (Security Information and Event Management) para agregar e gerenciar logs oriundos de todos componentes da arquitetura da API e seus hosts.
* Configure painéis de controle e alertas, possibilitando de atividades suspeitas sejam detectadas e respondidas de forma breve.. 