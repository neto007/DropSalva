---
title: Html 5 Api Web Storage
---

O Grupo de Trabalho de Tecnologia de Aplicativos de Hipertexto da Web (WHATWG) descreve as APIs de armazenamento da Web HTML5 `localStorage` e `sessionStorage`, como mecanismos para armazenar pares nome-valor do lado do cliente. Ao contrário dos cookies HTTP, o conteúdo de `localStorage` e `sessionStorage` não é compartilhado automaticamente em solicitações ou respostas pelo navegador e é usado para armazenar dados do lado do cliente.

## A API localStorage

**Escopo**

Os dados armazenados usando a localStorageAPI são acessíveis por páginas que são carregadas da mesma origem, que é definida como o esquema ( https://), host ( example.com), porta ( 443) e domínio / realm ( example.com). Isso fornece acesso a esses dados semelhante ao que seria obtido usando o secure sinalizador em um cookie, o que significa que os dados armazenados de httpsnão poderiam ser recuperados via http. Devido ao potencial acesso simultâneo de janelas / threads separados, os dados armazenados usando localStorage podem ser suscetíveis a problemas de acesso compartilhado (como condições de corrida) e devem ser considerados sem bloqueio ( Web Storage API Spec ).

**Duração**

Os dados armazenados usando a localStorageAPI são mantidos nas sessões de navegação, estendendo o período de tempo em que podem estar acessíveis a outros usuários do sistema.

**Acesso offline**

Os padrões não exigem que os localStoragedados sejam criptografados em repouso, o que significa que pode ser possível acessar esses dados diretamente do disco.

**Caso de uso**

O WHATWG sugere o uso de localStoragepara dados que precisam ser acessados ​​em janelas ou guias, em várias sessões e onde grandes volumes (de vários megabytes) de dados podem precisar ser armazenados por motivos de desempenho.

## A API sessionStorage

**Escopo**

A sessionStorageAPI armazena dados dentro do contexto da janela a partir do qual foi chamada, o que significa que a guia 1 não pode acessar os dados armazenados na guia 2. Além disso, como a localStorageAPI, os dados armazenados usando a sessionStorageAPI são acessíveis por páginas carregadas da mesma origem , que é definido como o esquema ( https://), host ( example.com), porta ( 443) e domínio / realm ( example.com). Isso fornece acesso a esses dados semelhante ao que seria obtido usando o secure sinalizador em um cookie, o que significa que os dados armazenados de https não poderiam ser recuperados via http.

**Duração**

A sessionStorageAPI armazena dados apenas durante a sessão de navegação atual. Depois que a guia é fechada, esses dados não podem mais ser recuperados. Isso não impede necessariamente o acesso, caso uma guia do navegador seja reutilizada ou deixada aberta. Os dados também podem persistir na memória até um evento de coleta de lixo.

**Acesso offline**

Os padrões não exigem que os sessionStoragedados sejam criptografados em repouso, o que significa que pode ser possível acessar esses dados diretamente do disco.

**Caso de uso**

WHATWG sugere o uso de sessionStoragepara dados que são relevantes para uma instância de um fluxo de trabalho, como detalhes para uma reserva de bilhete, mas onde vários fluxos de trabalho podem ser executados em outras guias simultaneamente. A natureza do limite da janela / guia evitará que os dados vazem entre os fluxos de trabalho em guias separadas.

### Riscos de Segurança

Em geral, dados seguros ou confidenciais não devem ser armazenados persistentemente em armazenamentos de dados do navegador, pois isso pode permitir vazamento de informações em sistemas compartilhados. Como os mecanismos de armazenamento da Web são APIs, isso também permite o acesso de scripts injetados, tornando-os menos seguros do que cookies com o httponlysinalizador aplicado. Embora possa ser feito um caso para armazenar dados específicos de fluxo de trabalho sessionStoragepara uso por essa guia / janela específica em recarregamentos, as APIs de armazenamento da Web devem ser tratadas como armazenamento inseguro. Por causa disso, se uma solução de negócios requer o uso do localStorageousessionStoragepara armazenar dados confidenciais, tal solução deve codificar os dados e aplicar proteções de reprodução. Devido ao potencial de acesso às APIs de armazenamento da Web por meio de um ataque XSS, os identificadores de sessão devem ser armazenados usando cookies não persistentes, com os sinalizadores apropriados para proteger contra problemas de acesso inseguro ( Secure), XSS ( HttpOnly) e CSRF ( SameSite).


### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)

- [APIs de armazenamento da web](https://developer.mozilla.org/en-US/docs/Web/API/Web_Storage_API/Using_the_Web_Storage_API)

- [API LocalStorage](https://developer.mozilla.org/en-US/docs/Web/API/Window/localStorage)

- [API SessionStorage](https://developer.mozilla.org/en-US/docs/Web/API/Window/sessionStorage)

- [Especificação de armazenamento da Web WHATWG](https://html.spec.whatwg.org/multipage/webstorage.html#webstorage)