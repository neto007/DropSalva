---
title: Limitação de recursos
---

Durante a operação normal, os serviços da web requerem poder computacional, como ciclos de CPU e memória. Devido ao mau funcionamento ou durante um ataque, um serviço da Web pode exigir muitos recursos, deixando o sistema host instável.

**Regra:** Limite a quantidade de ciclos de CPU que o serviço da web pode usar com base na taxa de serviço esperada, para ter um sistema estável.

**Regra:** Limite a quantidade de memória que o serviço da web pode usar para evitar que o sistema fique sem memória. Em alguns casos, o sistema host pode começar a eliminar processos para liberar memória.

**Regra:** Limite o número de arquivos abertos simultâneos, conexões de rede e processos iniciados.

## Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/)
