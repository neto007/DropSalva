---
title: Política para gerenciar chaves de criptografia
---
## Descrição

Quando não há uma política para gerenciar suas chaves criptográficas, chaves expiradas ou revogadas que poderiam ser usadas sem saber novamente, tornando-se uma ameaça para seus dados criptografados.

## Solução

Verifique se há uma política explícita sobre como as chaves criptográficas são gerenciadas (por exemplo, geradas, distribuídas, revogadas, expiradas). Verifique se esta política é aplicada corretamente.