---
title: Padrão de registro do usuário
---
## Descrição

Sempre que você permite que usuários se registrem em seu sistema, há algumas coisas que você precisa levar em consideração para garantir um alto nível de segurança.

Para obter informações mais detalhadas sobre esses itens, você deve verificar a base de conhecimento sobre:

1. Injeção SQL de truncamento de coluna (para bancos de dados MySQL)
2. Controles de validação de entrada única
3. Registros de auditoria
4. Impedir o vazamento de senha
5. Senha previsível e/ou geração de token
6. Todas as senhas são hash, aleatórias e cumpridas
7. O aplicativo exige o uso de senhas seguras?


## Solução

Os itens apontados antes devem ser analisados ​​e levados em consideração
sempre que você estiver permitindo que os usuários se registrem em seu sistema, a fim de impor um alto nível de segurança.

Aqui estão as etapas descritas resumidamente.
Para obter informações mais detalhadas, você deve examinar esses itens na base de conhecimento.

- Em primeiro lugar, você impõe limites ao comprimento dos envios dos usuários no lado do servidor para impedi-lo de truncar suas submissões. Esses limites têm que se correlacionar com os limites que você define em sua coluna no banco de dados.

- Em segundo lugar, você deve criar uma única classe de controle de validação de entrada do usuário que deve validar os valores de entrada esperados para verificar se o usuário não está adulterando os dados ou injetando código malicioso em sua aplicação. Todas as infrações devem ser registradas e deve haver repercussões sempre que essas infrações forem frequentes.

- Terceiro, nunca exiba a senha do usuário em qualquer lugar da tela.

- Quarto, sempre que você gerar uma senha para seus usuários, essa senha deve sempre
ser suficientemente randomizados.

- Quinto, criptografe suas senhas por padrões criptográficos comprovados ao armazená-las.

- Sexto, aplique senhas seguras implementando boas políticas de senha.