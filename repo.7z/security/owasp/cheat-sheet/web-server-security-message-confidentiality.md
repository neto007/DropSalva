---
title: Confidencialidade da mensagem
---

Os elementos de dados que devem ser mantidos confidenciais devem ser criptografados usando uma cifra de criptografia forte com um comprimento de chave adequado para impedir o uso de força bruta.

**Regra:** as mensagens que contêm dados confidenciais devem ser criptografadas usando uma cifra de criptografia forte. Isso pode ser criptografia de transporte ou criptografia de mensagem.

**Regra:** mensagens contendo dados confidenciais que devem permanecer criptografados em repouso após o recebimento devem ser criptografadas com criptografia de dados forte, não apenas criptografia de transporte.

## Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/)