---
title: Desserialização segura em PHP
---

Orientação para desserializar objetos com segurança
A orientação específica do idioma a seguir tenta enumerar metodologias seguras para desserializar dados que não são confiáveis.

PHP
Análise WhiteBox
Verifique o uso da função `unserialize()` e revise como os parâmetros externos são aceitos. Use um formato de intercâmbio de dados padrão e seguro, como JSON (via `json_decode()` e `json_encode()`) se precisar passar dados serializados para o usuário.

```php
<?php

class utkarsh {

    public $logfile = "delete.txt";
    public $logdata = "test1";

    function check()
    {
        echo "Services are good to go <br>";    
    }

    function __destruct()
    {
        if (file_put_contents(__DIR__ . '/'. $this->logfile, $this->logdata));
        echo "File contents has been uploaded";
    }
}

$v1 = unserialize(@$_GET['data']);

$object =  new utkarsh();
$object->check();
?>
```

## Referência externa
[OWASP - Desserialização PHP](https://cheatsheetseries.owasp.org/cheatsheets/Deserialization_Cheat_Sheet.html#php)