---
title: Presença de conhecimento
---
## Descrição

Evite o uso de respostas baseadas no conhecimento (as chamadas "perguntas secretas"). Devido ao uso predominante das mídias sociais, ao poder dos mecanismos de pesquisa na Internet e ao acesso a registros públicos via Internet, suas informações pessoais ficam a apenas alguns toques de tecla, permitindo que um invasor redefina sua senha ou recupere informações confidenciais.

## Solução

Como uma verificação de uso alternativo por telefone, onde o usuário deve enviar a chave exclusiva que ele recebeu ou implementar o uso de um serviço de senha única como o Google Authenticator.