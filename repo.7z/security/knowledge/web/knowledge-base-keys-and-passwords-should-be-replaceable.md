---
title: Chaves e Senhas Devem ser Substituíveis
---
## Descrição

Sempre pode acontecer que você precise das chaves ou das senhas do aplicativo ou dos componentes necessários ao aplicativo para trabalhar em um estado seguro. Quando essas chaves precisam ser revogadas porque a senha vazou ou um administrador saiu da empresa, é sempre bom ter a possibilidade de revogar as chaves ou senhas sem complicações.

## Solução

Verifique no aplicativo e nos componentes que ele usa se é possível substituir as chaves usadas e senhas. Substitua também as chaves e senhas padrão após a instalação do aplicativo.
