---
title: A2 Broken authentication
---

## A Aplicação é Vulnerável?

A confirmação da identidade do utilizador, autenticação e gestão da sessão são críticas para a defesa contra ataques
relacionados com autenticação. A sua aplicação poderá ter problemas na autenticação se:
* Permite ataques automatizados tais como credential stuffing ou força bruta.
* Permite palavras-passe padrão, fracas ou conhecidas, tais como "Password1" ou "admin/admin".
* Usa processos fracos ou ineficazes de recuperação de credenciais e recuperação de palavra-passe e.g. "perguntas baseadas em conhecimento", que podem não ser seguras. 
* Usa as palavras-passe em claro, encriptação ou resumos (hash) fracas (veja A3:2017 Exposição de Dados Sensíveis).
* Não possui autenticação multi-fator ou o mesmo não funciona corretamente.
* Expõe os identificadores de sessão no URL (e.g. quando o endereço é reescrito).
* Não renova os identificadores de sessão após o processo de autenticação ter sido bem sucedido.
* Não invalida convenientemente os identificadores de sessão. As sessões do utilizador ou os tokens de autenticação (em particular os de single sign-on (SSO)) não são invalidados convenientemente durante o processo de término de sessão (logout) ou após um período de inatividade

## Exemplos de Cenários de Ataque

#### Cenário #1: 
Credential stuffing é um ataque comum que consiste na utilização de listas de palavras-passe conhecidas.
Se uma aplicação não implementar um automatismo de proteção contra o teste exaustivo de credenciais, esta pode ser usada como um oráculo de palavras-passe para determinar se as credenciais são válidas.

#### Cenário #2: 
A maioria dos ataques de autenticação ocorrem devido ao fato de se usarem as palavras-passe como único fator. 
Outrora consideradas boas práticas, a rotatividade das palavras-passe e a complexidade das mesmas são hoje vistas como fatores para encorajar os utilizadores a usar e reutilizar palavras-passe fracas. Recomenda-se às organizações
deixarem de usar estas práticas (NIST 800-63) e passarem a usar autenticação multi-fator.

#### Cenário #3: 
O tempo de expiração das sessões não é definido de forma correta. Um utilizador utiliza um computador público
para aceder a uma aplicação. Ao invés de fazer logout o utilizador simplesmente fecha o separador do navegador e vaise embora. Um atacante usa o mesmo computador uma hora depois e o utilizador está ainda autenticado.

## Como Prevenir

* Sempre que possível, implementar autenticação multi-fator por forma a prevenir ataques automatizados de credential stuffing,
força bruta e reutilização de credenciais roubadas.
* Não disponibilizar a aplicação com credenciais pré-definidas, em especial para utilizadores com perfil de administrador.
* Implementar verificações de palavras-chave fracas, tais como comparar as palavras-passe novas ou alteradas com a lista das Top 10000 piores palavras-passe.
* Seguir as recomendações do guia NIST 800-63 B na secção 5.1.1 para Memorized Secrets ou outras políticas modernas para palavras-passe, baseadas em evidências.
* Assegurar que o registo, recuperação de credenciais e API estão preparados para resistir a ataques de enumeração de contas usando as mesmas mensagens para todos os resultados (sucesso/insucesso).
* Limitar o número máximo de tentativas de autenticação falhadas ou atrasar progressivamente esta operação. Registar todas as falhas e alertar os administradores quando detetados ataques de teste exaustivo, força bruta ou outros.
* Usar, no servidor, um gestor de sessões seguro que gere novos identificadores de sessão aleatórios e com elevado
nível de entropia após a autenticação. Os identificadores de sessão não devem constar no URL, devem ser guardados de
forma segura e invalidados após o logout, por inatividade e ao fim dum período de tempo fixo.