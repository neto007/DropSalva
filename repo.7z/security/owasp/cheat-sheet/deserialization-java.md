---
title: Desserialização segura em java
---

As técnicas a seguir são boas para evitar ataques contra a desserialização contra o formato serializável do Java.

## Conselhos de implementação:

### Análise WhiteBox
Esteja ciente dos seguintes usos da API Java para vulnerabilidade potencial de serialização.

1. XMLdecoder com parâmetros definidos pelo usuário externo.
2. XStream com o método "fromXML" (versão xstream <= v1.46 é vulnerável ao problema de serialização).
3. ObjectInputStream com readObject.
4. Usos de readObject, readObjectNodData,  readResolve ou readExternal.
5. ObjectInputStream.readUnshared
6. Serializable

### Avaliação do BlackBox
Se os dados de tráfego capturados incluírem os seguintes padrões, pode sugerir que os dados foram enviados em fluxos de serialização Java.

* `AC ED 00 05` em Hex.
* `rO0` em Base64.
* Content-type cabeçalho de uma resposta HTTP definido como application/x-java-serialized-object.

### Evite vazamento de dados e destruição de campos confiáveis.
Se houver membros de dados de um objeto que nunca devem ser controlados pelos usuários finais durante a desserialização ou expostos aos usuários durante a serialização, eles devem ser declarados como a "transient word" - chave (seção Protegendo informações confidenciais ). Para uma classe definida como Serializable, a variável de informações confidenciais deve ser declarada como "private transient".

Por exemplo, a classe 'myAccount', as variáveis ​​'profit' e 'margin' foram declaradas como transitórias para evitar a serialização:

```java
public class myAccount implements Serializable
{
    private transient double profit; // declared transient

    private transient double margin; // declared transient
    ....
}
```

### Impedir a desserialização de objetos de domínio
Alguns de seus objetos de aplicativo podem ser forçados a implementar Serializable devido à sua hierarquia. Para garantir que seus objetos de aplicativo não possam ser desserializados, um método `readObject()` deve ser declarado (com um modificador final) que sempre lança uma exceção:

```java
private final void readObject(ObjectInputStream in) throws java.io.IOException {
    throw new java.io.IOException("Cannot be deserialized");
}
```

### Proteja seu próprio java.io.ObjectInputStream
A classe `java.io.ObjectInputStream` é usada para desserializar objetos. É possível fortalecer seu comportamento criando uma subclasse:

* Você pode alterar o código que faz a desserialização.
* Você sabe quais classes espera desserializar
* A ideia geral é substituir `ObjectInputStream.html#resolveClass()` para restringir quais classes podem ser desserializadas.

Como essa chamada ocorre antes do `readObject()`ser chamado, você pode ter certeza de que nenhuma atividade de desserialização ocorrerá, a menos que o tipo seja aquele que você deseja permitir.

Um exemplo simples disso mostrado aqui, onde a classe `LookAheadObjectInputStream` tem a garantia de não desserializar qualquer outro tipo além da classe `Bicycle`.

```java
public class LookAheadObjectInputStream extends ObjectInputStream {

    public LookAheadObjectInputStream(InputStream inputStream) throws IOException {
        super(inputStream);
    }

    /**
    * Only deserialize instances of our expected Bicycle class
    */
    @Override
    protected Class<?> resolveClass(ObjectStreamClass desc) throws IOException, ClassNotFoundException {
        if (!desc.getName().equals(Bicycle.class.getName())) {
            throw new InvalidClassException("Unauthorized deserialization attempt", desc.getName());
        }
        return super.resolveClass(desc);
    }
}
```

>Implementações mais completas desta abordagem foram propostas por vários membros da comunidade:

* NibbleSec - uma biblioteca que permite whitelisting e blacklisting de classes que podem ser desserializadas
* IBM - a proteção seminal, escrita anos antes que os cenários de exploração mais devastadores fossem concebidos.
* Classes de IO do Apache Commons

## Reforce todo o uso de java.io.ObjectInputStream com um agente

Conforme mencionado acima, a classe `java.io.ObjectInputStreamclasse` é usada para desserializar objetos. É possível fortalecer seu comportamento criando uma subclasse. No entanto, se você não possui o código ou não pode esperar por um patch, usar um agente para fazer a proteção `java.io.ObjectInputStream` é a melhor solução.

A mudança global do `ObjectInputStream` só é segura para a lista de bloqueio de tipos mal-intencionados conhecidos, porque não é possível saber para todos os aplicativos quais são as classes que devem ser desserializadas. Felizmente, existem muito poucas classes necessárias na lista de bloqueio para se proteger de todos os vetores de ataque conhecidos hoje.

É inevitável que mais classes de "gadgets" sejam descobertas e possam ser abusadas. No entanto, existe uma quantidade incrível de software vulnerável exposto hoje, que precisa de uma correção. Em alguns casos, "consertar" a vulnerabilidade pode envolver a reformulação da arquitetura de sistemas de mensagens e a quebra da compatibilidade com versões anteriores, à medida que os desenvolvedores não aceitam objetos serializados.

## Referência externa
[OWASP - desserialização em java](https://cheatsheetseries.owasp.org/cheatsheets/Deserialization_Cheat_Sheet.html#java)