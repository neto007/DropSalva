---
title: Implementações de gerenciamento de sessão integrado
---


Estruturas de desenvolvimento da Web, como J2EE, ASP .NET, PHP e outros, fornecem seus próprios recursos de gerenciamento de sessão e implementação associada. É recomendável usar essas estruturas integradas em vez de construir uma caseira do zero, já que são usadas mundialmente em vários ambientes da web e foram testadas pelas comunidades de desenvolvimento e segurança de aplicativos da web ao longo do tempo.

No entanto, esteja ciente de que essas estruturas também apresentaram vulnerabilidades e fraquezas no passado, por isso é sempre recomendado usar a versão mais recente disponível, que potencialmente corrige todas as vulnerabilidades conhecidas, bem como revisar e alterar a configuração padrão para melhorar sua segurança seguindo as recomendações descritas ao longo deste documento.

Os recursos de armazenamento ou repositório usados ​​pelo mecanismo de gerenciamento de sessão para salvar temporariamente os IDs de sessão devem ser seguros, protegendo os IDs de sessão contra divulgação local ou remota acidental ou acesso não autorizado.


### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)