---
title: Tokens De Sessão Stateless
---
## Descrição

JSON Web Token (JWT) é um padrão aberto (RFC 7519) que define uma forma compacta e independente para transmitir informações com segurança entre as partes como um objeto JSON. Esta informação pode ser verificada e confiável porque é assinado digitalmente. Os JWTs podem ser assinados usando um segredo (com o algoritmo HMAC) ou um par de chaves pública / privada usando RSA.

JSON Web Token é usado para transportar informações relacionadas à identidade e às características (reivindicações) de um cliente. Este "container" é assinado pelo servidor para evitar que um cliente o adultere para alterar, por exemplo, a identidade ou quaisquer características (exemplo: mudar a função de usuário simples para administrador ou alterar o login do cliente).

Este token é criado durante a autenticação (é fornecido em caso de autenticação bem-sucedida) e é verificado pelo servidor antes de qualquer processamento. É usado por um aplicativo para permitir que um cliente apresente ao servidor um token que representa sua "carteira de identidade" (recipiente com todas as informações sobre ele) e permite que o servidor verifique a validade e integridade do token de forma segura, todos os isso em uma abordagem sem estado e portátil (portátil da maneira que as tecnologias de cliente e servidor podem ser diferentes, incluindo também o canal de transporte, mesmo se o HTTP for o mais usado).

## Solução

Para obter mais informações sobre todas as diferentes falhas de implementação do JWT, consulte:

https://github.com/OWASP/CheatSheetSeries/blob/master/cheatsheets/JSON_Web_Token_Cheat_Sheet_for_Java.md