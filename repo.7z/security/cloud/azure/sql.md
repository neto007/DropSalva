---
title: Azure SQL 
sidebar_label: SQL
---

**Proposta de melhores práticas de segurança para o uso do serviço SQL na Azure:**

Azure SQL é uma família de produtos gerenciados, seguros e inteligentes que usam o mecanismo de banco de dados do SQL Server na nuvem do Azure. Esse documento tem foco no produto **Azure SQL Database** que oferece suporte a aplicativos de nuvem com um serviço de banco de dados gerenciado e inteligente (DBaaS).

O objetivo desse documento é descrever as melhores práticas de configuração do SQL Database nas assinaturas da Azure.

## Recomendações de alto nível:

- É recomendada a criação de SQL Database separado por ambientes (Desenvolvimento, Homologação e Produção).
- Garanta backups regulares [[Referência](https://docs.microsoft.com/en-us/azure/key-vault/general/security-baseline#91-ensure-regular-automated-back-ups "https://docs.microsoft.com/en-us/azure/key-vault/general/security-baseline#91-ensure-regular-automated-back-ups")].
- Ative os logs de acesso [[Referência](https://docs.microsoft.com/en-us/azure/key-vault/general/logging "https://docs.microsoft.com/en-us/azure/key-vault/general/logging")].
- Limite a comunicação com SQL DB somente para redes que precisam do acesso (utilizando Private Link ou Service Endpoint).
    
## Pontos importantes sobre a estrutura proposta:

**Redes**
- Não é permitido o acesso público ao SQL DB. Qualquer exceção deverá ser avaliada previamente pela equipe de Segurança da Informação;
- Garantir que toda restrição de firewall seja realizada apenas a nível de SQL Server;
- Não é permitido o uso do firewall a nível de Database;
- Garantir a restrição de comunicação com SQL DB utilizando o Private Endpoint;
- Quando não for possível a utilização do Private Endpoint, utilize o firewall com as opções de regra de VNET;
- Garantir que a opção “**Allow Azure Services and resources to access this server”** fique desabilitada. Esta opção configura o firewall para permitir todas as conexões do Azure, incluindo conexões de assinaturas de outros empresas;  
        
**Monitoração**
- Habilite a auditoria do banco de dados SQL para rastrear eventos de banco de dados;
- Configure a retenção dos logs do SQL de acordo com os requerimentos de compliance do ambiente;
- Recomendado o uso do Advanced Threat Protection para monitoração e alertas de atividades anômalas;  
        
**Gerenciamento de identidade e acesso**
- Garantir que o SQL está configurado com a autenticação de administrador utilizando o Azure AD;
- Utilize o RBAC (role based access control) para controle de acesso aos recursos;
- Respeitar as regras de menor privilegio no acesso aos recursos;  
        
**Proteção de dados**
- Utilize TAG nos recursos para identificação de SQL DB que tratam informações sensíveis;
- Garantir a ativação dos isolamentos e proteções com uso do Private Endpoint para os bancos de dados que tratam informações sensíveis;
- Recomendado o uso de solução para descoberta e classificação de dados sensíveis;
- Garantir a criptografia dos dados em repouso;  
        
**Gerenciamento de vulnerabilidades**
- Recomendado a ativação do Azure Defender para o SQL Database para execução do assesment de vulnerabilidade;  
        
**Configurações de segurança**
- Utilize o Azure Key Vault para armazenamento das chaves de criptografia do SQL DB;
- Recomendado o uso de Manage Identities para comunicação com os recurso da Azure;

**Recuperação de dados**
- Garantir o backup regular no bancos de dados SQL;
- Avaliar se os padrões de backup da solução atendem aos requerimentos de compliance do ambiente;
- Garantir o backup das chaves de criptografia dos bancos de dados SQL.

#### Políticas de prevenção e detecção:

Abaixo alguns campos para correta configuração do SQL DB. Os itens destacados já estão aplicados junto as polices de prevenção.

![Azure SQL](/assets/security/cloud/azure-sql.png)
