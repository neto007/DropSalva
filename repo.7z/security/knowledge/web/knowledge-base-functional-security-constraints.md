---
title: Restrições funcionais de segurança
---
## Descrição

As restrições de segurança funcional ajudam os desenvolvedores de software a determinar o nível de concessões/autorizações que os usuários têm sobre o aplicativo.

## Solução

Verifique se todas as histórias e recursos do usuário contêm restrições de segurança funcionais, como "Como usuário, devo poder visualizar e editar meu perfil. Não consigo visualizar ou editar o perfil de mais ninguém"
