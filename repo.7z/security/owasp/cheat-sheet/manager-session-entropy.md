---
title: Entropia de ID de sessão
---


O ID da sessão deve ser imprevisível (aleatório o suficiente) para evitar ataques de adivinhação, onde um invasor é capaz de adivinhar ou predizer o ID de uma sessão válida por meio de técnicas de análise estatística. Para tal, deve ser utilizado um bom CSPRNG (Cryptographically Secure Pseudorandom Number Generator).

O valor do ID da sessão deve fornecer pelo menos 64 bitsentropia (se um bom PRNG for usado, esse valor é estimado em metade do comprimento do ID da sessão).

Além disso, um ID de sessão aleatório não é suficiente; também deve ser exclusivo para evitar IDs duplicados. Um ID de sessão aleatório ainda não deve existir no espaço de ID de sessão atual.

NOTA :

A entropia do ID de sessão é realmente afetada por outros fatores externos e difíceis de medir, como o número de sessões ativas simultâneas que o aplicativo da web geralmente tem, o tempo limite de expiração de sessão absoluto, a quantidade de suposições de ID de sessão por segundo que o invasor pode fazer e o o aplicativo da web de destino pode oferecer suporte, etc.
Se um ID de sessão com uma entropia de 64 bitsfor usado, um invasor levará pelo menos 292 anos para adivinhar com sucesso um ID de sessão válido, supondo que o invasor possa tentar 10.000 tentativas por segundo com 100.000 sessões simultâneas válidas disponíveis no aplicativo da web.
Mais informações aqui .

### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)