---
title: .Net security
---

Esta página tem como objetivo fornecer dicas básicas de segurança .NET para desenvolvedores.

O .NET Framework é a principal plataforma da Microsoft para desenvolvimento empresarial. É a API de suporte para ASP.NET, aplicativos do Windows Desktop, serviços do Windows Communication Foundation, SharePoint, Ferramentas do Visual Studio para Office e outras tecnologias.

## Atualizando o Framework
O .NET Framework é mantido atualizado pela Microsoft com o serviço Windows Update. Os desenvolvedores normalmente não precisam executar atualizações separadas para o Framework. O Windows Update pode ser acessado no Windows Update ou no programa Windows Update em um computador Windows.

Estruturas individuais podem ser mantidas atualizadas usando o NuGet. Conforme o Visual Studio solicita atualizações, inclua-as em seu ciclo de desenvolvimento. Lembre-se de que as bibliotecas de terceiros devem ser atualizadas separadamente e nem todas usam NuGet.

## Anúncios de Segurança
Receba notificações de segurança selecionando o botão "Assistir" nos seguintes repositórios:

* Anúncios de segurança do .NET Core
* Anúncios de segurança do núcleo do ASP.NET Core e Entity Framework

## Referência externa
[.Net security](https://cheatsheetseries.owasp.org/cheatsheets/DotNet_Security_Cheat_Sheet.html)