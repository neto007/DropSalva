---
title: Envenenamento de Esquema
---

Quando um invasor é capaz de introduzir modificações em um esquema, pode haver várias consequências de alto risco. Em particular, o efeito dessas consequências será mais perigoso se os esquemas estiverem usando DTD (por exemplo, recuperação de arquivo, negação de serviço). Um invasor pode explorar esse tipo de vulnerabilidade em vários cenários, sempre dependendo da localização do esquema.

### Envenenamento de esquema local

O envenenamento de esquema local ocorre quando os esquemas estão disponíveis no mesmo host, estejam ou não incorporados no mesmo documento XML.

### Esquema embutido

O tipo mais trivial de envenenamento de esquema ocorre quando o esquema é definido no mesmo documento XML. Considere o seguinte exemplo, inconscientemente vulnerável, fornecido pelo W3C:


```xml

<?xml version="1.0"?>
<!DOCTYPE note [
 <!ELEMENT note (to,from,heading,body)>
 <!ELEMENT to (#PCDATA)>
 <!ELEMENT from (#PCDATA)>
 <!ELEMENT heading (#PCDATA)>
 <!ELEMENT body (#PCDATA)>
]>
<note>
 <to>Tove</to>
 <from>Jani</from>
 <heading>Reminder</heading>
 <body>Don't forget me this weekend</body>
</note>

```

Todas as restrições ao elemento nota podem ser removidas ou alteradas, permitindo o envio de qualquer tipo de dados ao servidor. Além disso, se o servidor estiver processando entidades externas, o invasor pode usar o esquema, por exemplo, para ler arquivos remotos do servidor. Esse tipo de esquema serve apenas como sugestão para o envio de um documento, mas deve conter uma forma de verificar a integridade do esquema embutido para ser usado com segurança. Ataques por meio de esquemas integrados são comumente usados ​​para explorar expansões de entidades externas. Os esquemas XML incorporados também podem ajudar em varreduras de portas de hosts internos ou ataques de força bruta.

### Permissões incorretas

Muitas vezes, você pode evitar o risco de usar versões adulteradas remotamente, processando um esquema local.

```xml

<!DOCTYPE note SYSTEM "note.dtd">
<note>
 <to>Tove</to>
 <from>Jani</from>
 <heading>Reminder</heading>
 <body>Don't forget me this weekend</body>
</note>

```

No entanto, se o esquema local não contiver as permissões corretas, um invasor interno pode alterar as restrições originais. A linha a seguir exemplifica um esquema usando permissões que permitem a qualquer usuário fazer modificações:

```bash

-rw-rw-rw-  1 user  staff  743 Jan 15 12:32 note.dtd

```

As permissões definidas em `name.dtd` permitem que qualquer usuário no sistema faça modificações. Esta vulnerabilidade claramente não está relacionada à estrutura de um XML ou esquema, mas como esses documentos são comumente armazenados no sistema de arquivos, vale a pena mencionar que um invasor pode explorar esse tipo de problema.

## Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/cheatsheets/XML_Security_Cheat_Sheet.html)