---
title: Grampeamento OCSP
---
## Descrição

O grampeamento OCSP, conhecido formalmente como extensão de Solicitação de status de certificado TLS, é uma abordagem alternativa ao OCSP (Online Certificate Status Protocol) para verificar o status de revogação de certificados digitais X.509. Ele permite que o apresentador de um certificado arque com o custo do recurso envolvido no fornecimento de respostas OCSP anexando ("grampeando") uma resposta OCSP com carimbo de data e hora assinada pela CA ao TLS Handshake inicial, eliminando a necessidade de os clientes entrarem em contato com a CA

## Solução

O grampeamento basicamente significa que o detentor do certificado consulta o servidor OCSP em intervalos regulares, obtendo uma resposta OCSP com carimbo de data / hora assinado. Quando os visitantes do site tentam se conectar ao site, essa resposta é incluída ("grampeada") com o Handshake TLS / SSL por meio da resposta da extensão Certificate Request Request (observação: o cliente TLS deve incluir explicitamente uma extensão Certificate Certificate Request em seu ClientHello Mensagem de handshake TLS / SSL). Embora possa parecer que permitir que o operador do site controle as respostas de verificação permita que um site fraudulento emita uma verificação falsa para um certificado revogado, as respostas grampeadas não podem ser falsificadas, pois precisam ser assinadas diretamente pela autoridade de certificação, não pelo servidor . Se o cliente não receber uma resposta grampeada, ele entrará em contato apenas com o servidor OCSP. No entanto, se o cliente receber uma resposta grampeada inválida, interromperá a conexão. O único risco aumentado de grampeamento OCSP é que a notificação de revogação de um certificado possa ser adiada até que a última resposta OCSP assinada expire.

Para obter informações mais detalhadas sobre especificação, implantação e limitação, visite:
https://en.wikipedia.org/wiki/OCSP_stapling
