---
title: Segurança em Ajax
---

#### Lado do cliente (JavaScript)
Use .innerText em vez de .innerHtml
O uso de .innerText evitará a maioria dos problemas de XSS, pois codificará automaticamente o texto.

#### Não use eval
A função eval() é ruim, nunca a use. A necessidade de usar eval geralmente indica um problema em seu projeto.

#### Não confie na lógica do cliente para segurança
Pelo menos você esqueceu que o usuário controla a lógica do lado do cliente. Posso usar vários conectores de navegador para definir pontos de interrupção, pular código, alterar valores, etc. Nunca confie na lógica do cliente.

#### Não confie na lógica de negócios do cliente
Certifique-se de que todas as regras/lógicas de negócios interessantes sejam duplicadas no lado do servidor, a menos que o usuário ignore a lógica necessária e faça algo bobo, ou pior, caro.

#### Evite escrever código de serialização
Isso é difícil e até mesmo um pequeno erro pode causar grandes problemas de segurança. Já existem muitos frameworks para fornecer essa funcionalidade.

#### Evite construir XML ou JSON dinamicamente
Assim como construir HTML ou SQL, você causará bugs de injeção XML, portanto, fique longe disso ou pelo menos use uma biblioteca de codificação ou uma biblioteca JSON ou XML segura para tornar os atributos e dados de elementos seguros.

#### Nunca transmita segredos ao cliente
Qualquer coisa que o cliente saiba, o usuário também saberá, portanto, mantenha todas essas coisas secretas no servidor, por favor.

#### Não execute criptografia no código do cliente
Use TLS/SSL e criptografe no servidor!

#### Não execute lógica de impacto de segurança no lado do cliente
Pode ser facilmente burlada com um programa que sirva como proxy.