---
title: Proteções para CSS
---

O objetivo desta folha de dicasCSS (não XSS , mas em cascata ) é informar aos programadores, testadores, analistas de segurança, desenvolvedores front-end e qualquer pessoa interessada em segurança de aplicativos da Web a usar essas recomendações ou requisitos para obter melhor segurança durante a autoria Cascading Style Sheets.

Vamos demonstrar esse risco com um exemplo:

Santhosh é um programador que trabalha para uma empresa chamada X e cria uma Cascading Style Sheet para implementar o estilo do aplicativo da web. O aplicativo para o qual ele está escrevendo código CSS tem várias funções, como estudante , professor , Super User e Administrator e essas funções têm permissões diferentes (`PBAC - Permission Based Access Control`) e funções (`RBAC - Role Based Access Control`). Essas funções não apenas têm controles de acesso diferentes, mas também podem ter estilos diferentes para páginas da web que podem ser específicas para um indivíduo ou grupo de funções.

Santhosh acha que seria uma ótima ideia otimizada criar um arquivo CSS de "estilo global" que tivesse todos os seletores / estilos CSS para todas as funções. De acordo com sua função, um recurso específico ou elemento de interface do usuário será renderizado. Por exemplo, administrador terá características diferentes em relação ao estudante ou professor ou superusuário . No entanto, algumas permissões ou recursos podem ser comuns a algumas funções.

Exemplo: as configurações de perfil serão aplicáveis ​​a todos os usuários aqui, enquanto a adição ou exclusão de usuários é aplicável apenas para o administrador .

Exemplo:

- `.login`
- `.profileStudent`
- `.changePassword`
- `.addUsers`
- `.deleteUsers`
- `.addNewAdmin`
- `.deleteAdmin`
- `.exportUserData`
- `.exportProfileData`

Agora, vamos examinar quais são os riscos associados a esse estilo de codificação.

### Risco #1

Atacantes motivados sempre dão uma olhada nos `*.CSS` arquivos para aprender os recursos do aplicativo, mesmo sem estar logado.

Por exemplo: Jim é um atacante motivado e sempre tenta examinar os arquivos CSS do View-Source antes mesmo de outros ataques. Quando Jim olha para o arquivo CSS, ele vê que existem diferentes recursos e funções diferentes com base nos seletores CSS, como .profileSettings, .editUser, .addUser, .deleteUser e assim por diante. Jim pode usar o CSS para reunir informações para ajudar a obter acesso a funções confidenciais. Essa é uma forma de diligência devida do invasor, mesmo antes de tentar realizar ataques perigosos para obter acesso ao aplicativo da web.

Resumindo, ter um estilo global pode revelar informações confidenciais que podem ser benéficas para o invasor.

### Risco #2

Digamos que Santhosh tenha o hábito de escrever nomes de seletores descritivos como .profileSettings, exportUserData, .changePassword, .oldPassword, .newPassword, .confirmNewPassword etc. Bons programadores gostam de manter o código legível e utilizável por outros revisores de código da equipe. O risco é que os invasores possam mapear esses seletores para recursos reais de um aplicativo da web.

### Mecanismos defensivos para atenuar a motivação do atacante

**Mecanismo de defesa**

Como um codificador/programador CSS, sempre mantenha o CSS isolado por nível de controle de acesso. Com isso, significa que o Aluno terá um arquivo CSS diferente chamado `StudentStyling.CSS` enquanto o Administrador tem `AdministratorStyling.CSS` e assim por diante. Certifique-se de que esses `*.CSS` arquivos sejam acessados ​​apenas por um usuário com o nível de controle de acesso adequado. Somente usuários com o nível de controle de acesso adequado devem ser capazes de acessar seus *.CSS arquivos.

Se um usuário autenticado com a função de aluno tentar acessar `AdministratorStyling.CSS` por meio de navegação forçada, um alerta de que uma intrusão está ocorrendo deve ser registrado.

**Mecanismo de Defesa #2**

Sendo um programador ou um testador, tome cuidado com as convenções de nomenclatura de seus seletores CSS (Cascading Style Sheet). Ofusque os nomes do seletor de forma que os invasores não sejam informados a que link um seletor específico está vinculado.

Exemplo: Seletores CSS para `addUser`, `addAdmin`, `profileSettings`, `changePassword` podem ser nomeados `aHj879JK`, `bHjsU`, `ahkrrE`, `lOiksn` respectivamente. Esses nomes também podem ser gerados aleatoriamente por usuário.

Este pacote NPM pode ser usado para realizar a renomeação do seletor CSS.

**Mecanismo de Defesa #3**

Os aplicativos da Web que permitem aos usuários criar conteúdo por meio de entrada de HTML podem ser vulneráveis ​​ao uso malicioso de CSS. O HTML carregado pode usar estilos permitidos pelo aplicativo da web, mas pode ser usado para finalidades diferentes das pretendidas, o que pode causar riscos de segurança.

Exemplo: Você pode ler sobre como o LinkedIn tinha uma vulnerabilidade que permitia o uso malicioso de CSS que levava à criação de uma página em que toda a página era clicável, incluindo a substituição dos elementos de navegação padrão do LinkedIn.

### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)