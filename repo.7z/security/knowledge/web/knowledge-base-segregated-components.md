---
title: Componentes Segregados
---
## Descrição

É sempre possível que um invasor encontre uma falha de segurança e abuse dela para obter acesso para o servidor. A partir daqui, o invasor tenta se infiltrar ainda mais na rede e em outros componentes importantes do aplicativo, por exemplo, o banco de dados. Este banco de dados deve ser protegido por firewall corretamente para que não seja acessível pela Internet. Além disso, este banco de dados tem seu próprio servidor e está em um
segmento diferente da rede. Sempre aplique a filtragem INGRESS e EGRESS para todos os servidores usados.

## Solução

Verifique se os componentes estão separados uns dos outros por meio de um controle de segurança definido, como segmentação de rede, regras de firewall ou grupos de segurança baseados em nuvem.