---
title: Hash vs criptografia
---

**Hashing e criptografia** são dois termos frequentemente confundidos ou usados ​​incorretamente. A principal diferença entre elas é que hashing é uma uma forma de função (isto é, não é possível "descriptografar" um hash e obter o valor original), ao passo que a encriptação é uma função de duas vias.

Em quase todas as circunstâncias, as senhas devem ser hashes em vez de criptografadas, pois isso torna difícil ou impossível para um invasor obter as senhas originais dos hashes.

A criptografia deve ser usada apenas em casos extremos em que é necessário obter a senha original. Alguns exemplos de onde isso pode ser necessário são:

* Se o aplicativo precisar usar a senha para autenticar em um sistema legado externo que não oferece suporte a SSO.
* Se for necessário recuperar caracteres individuais da senha.

A capacidade de descriptografar senhas representa um sério risco à segurança, portanto, deve ser totalmente avaliado o risco. Sempre que possível, uma arquitetura alternativa deve ser usada para evitar a necessidade de armazenar senhas em uma forma criptografada.

## Referência externa
[OWASP Hash vs criptografia](https://cheatsheetseries.owasp.org/cheatsheets/Password_Storage_Cheat_Sheet.html#hashing-vs-encryption)