---
title: Referências Inseguras a Objetos Diretos
---
## Descrição

Os aplicativos freqüentemente usam o nome real ou a chave de um objeto ao gerar páginas da web. Os aplicativos nem sempre verificam se o usuário está autorizado para o objeto de destino. Isso resulta em uma falha de segugrança de referência direta ao objeto. Os testadores podem manipular facilmente os valores de parâmetros para detectar essas falhas e a análise de código mostra rapidamente se a autorização é verificada corretamente.

O aplicativo usa dados não verificados em uma chamada SQL que está acessando informações da conta:

```java
String query = "SELECT * FROM conta WHERE conta =?";
PreparedStatement pstmt = connection.prepareStatement (query, ...);
pstmt.setString (1, request.getParameter ("acct"));
ResultSet results = pstmt.executeQuery ();
```

O invasor simplesmente modifica o parâmetro "acct" no navegador para enviar qualquer
número da conta que eles queiram. Se não for verificado, o invasor pode acessar a conta de qualquer usuário, em vez de somente a conta do cliente pretendido.

http://example.com/app/accountInfo?acct=notmyacct



## Solução

Evitar referências inseguras a objetos diretos requer a seleção de uma abordagem
para proteger cada objeto acessível ao usuário (por exemplo, número do objeto, nome do arquivo)

Use referências de objeto indireto por usuário ou sessão. Isso impede que os atacantes de mirar diretamente em recursos não autorizados. Por exemplo, em vez de usar a chave de banco de dados do recurso, uma lista suspensa de seis recursos autorizados para o usuário atual poder usar os números de 1 a 6 para indicar qual valor o usuário selecionou. O aplicativo precisa mapear a referência indireta por usuário de volta à chave do banco de dados real no servidor.

Verifique o acesso. Cada uso de uma referência direta a objetos de uma fonte não confiável deve incluir uma verificação de controle de acesso para assegurar que o usuário está autorizado para o objeto solicitado.
