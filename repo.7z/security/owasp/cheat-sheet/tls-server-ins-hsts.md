---
title: Use HTTP Strict Transport Security
---

O `HTTP Strict Transport Security (HSTS)` instrui o navegador do usuário a sempre solicitar o site por `HTTPS` e também impede que o usuário ignore os avisos de certificado. 


### Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/)