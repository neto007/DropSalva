---
title: Ferramentas para analisar dependências
---

Várias ferramentas que podem ser usadas para analisar as dependências usadas por um projeto para detectar as vulnerabilidades.

É importante garantir, durante o processo de seleção de uma ferramenta de detecção de dependência vulnerável, que esta:

- Usa várias fontes de entrada confiáveis ​​para lidar com as duas formas de divulgação de vulnerabilidade.

- Suporte para sinalizar um problema levantado em um componente como um falso positivo .

**Open Source**

[Verificação de dependência OWASP](https://owasp.org/www-project-dependency-check/)

- Suporte completo: Java, .Net.
- Suporte experimental: Python, Ruby, PHP (compositor), NodeJS, C, C ++.

[Auditoria NPM](https://docs.npmjs.com/cli/v6/commands/npm-audit/)

- Suporte completo: NodeJS, JavaScript.
- Relatório HTML disponível através deste módulo .

[O OWASP Dependency Track](https://dependencytrack.org/) pode ser usado para gerenciar dependências vulneráveis ​​em uma organização.

**Comercial**

[Snyk](https://snyk.io/) (código aberto e opção gratuita disponível):

- Suporte completo para vários idiomas e gerenciador de pacotes.

[JFrog XRay](https://jfrog.com/xray/) 

- Suporte completo para vários idiomas e gerenciador de pacotes.

[Renovar](https://www.whitesourcesoftware.com/free-developer-tools/renovate) (permitir detectar dependências antigas):
- Suporte completo para vários idiomas e gerenciador de pacotes.

[Requer.io](https://requires.io/) (permite detectar dependências antigas - código aberto e opção - gratuita disponível):
- Suporte total : somente Python.


### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/cheatsheets/Vulnerable_Dependency_Management_Cheat_Sheet.html)
