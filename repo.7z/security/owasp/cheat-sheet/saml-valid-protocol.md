---
title: Validar o uso do protocolo SAML
---

Esta é uma área comum para brechas de segurança. Seu perfil SSO era vulnerável a um ataque man-in-the-middle de um SP malicioso (provedor de serviços).

Essa falha de segurança específica foi exposta porque a resposta SAML não continha todos os elementos de dados necessários para uma troca segura de mensagens. Seguir os requisitos de uso do Perfil SAML para AuthnRequest (4.1.4.1) e Resposta (4.1.4.2) ajudará a contar esse ataque.

A equipe AVANTSSAR sugeriu que os seguintes elementos de dados devem ser exigidos:

- **AuthnRequest (ID, SP)**: Um AuthnRequest deve conter e IDe SP. Onde ID é uma string que identifica exclusivamente a solicitação e um service provider identifica quem iniciou a solicitação. Além disso, o ID atributo de solicitação deve ser retornado na resposta ( `InResponseTo="<requestId>"`). `InResponseTo` ajuda a garantir a autenticidade da resposta do `IdP` confiável. Esse era um dos atributos ausentes que deixavam o SSO do Google vulnerável.

- **Resposta (ID, SP, IdP, {AA} K -1 / IdP)**: Uma resposta deve conter todos esses elementos. Onde ID está uma string que identifica exclusivamente a resposta. SP identifica o destinatário da resposta. IdP identifica o provedor de identidade que autoriza a resposta. `{AA} K -1/IdP` é a declaração assinada digitalmente com a chave privada do IdP.

- **AuthAssert (ID, C, IdP, SP)**: uma declaração de autenticação deve existir na resposta. Ele deve conter um ID, um cliente (C), um provedor de identidade (IdP)e um (SP)identificador de provedor de serviços .


### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)