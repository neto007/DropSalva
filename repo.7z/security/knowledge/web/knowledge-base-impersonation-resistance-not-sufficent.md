---
title: Resistência insuficiente contra personificação
---
## Descrição

Se sua aplicação não tiver resistência adequada contra personificação contra ataques de phishing, os usuários poderão ser um alvo fácil para o invasor. Assim o mesmo poderá se passar pelas vitimas, obtendo algum acesso indevido.


## Solução

É recomendável empregar um (ou mais) dos seguintes itens: multiplos fatores de autenticação, dispositivos criptografados ou certificados do lado do cliente (client-side).
