---
title: Seqüestro de sessão
---
## Descrição

Quando um invasor obtém um cookie de sessão do usuário, ele pode roubar a identidade do
usuário ao qual o cookie de sessão pertence.

## Solução

Assim que uma sessão for definida para um usuário autenticado,
o servidor deve acompanhar o endereço IP em que o usuário usou quando iniciou a sessão.
Quando o servidor descobre uma alteração no endereço IP, por exemplo, quando um invasor seqüestra um sessão de usuários. O servidor deve negar o acesso, destruir a sessão e redirecionar o 'sequestrador' para a página de login.