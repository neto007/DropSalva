---
title: GraphQL prevenção DoS
---

DoS é um ataque contra a disponibilidade e estabilidade da API que pode torná-la lenta, sem resposta ou completamente indisponível. Esta página detalha vários métodos para limitar a possibilidade de um ataque DoS no nível do aplicativo e outras camadas da pilha de tecnologia.

Aqui estão recomendações específicas para GraphQL para limitar o potencial ataque de DoS:

* Adicionar limitação de profundidade às consultas recebidas.
* Adicionar limite de quantidade às consultas recebidas.
* Adicione paginação para limitar a quantidade de dados que podem ser retornados em uma única resposta.
* Adicione tempos limites razoáveis ​​na camada de aplicativo, camada de infraestrutura ou ambas.
* Considere realizar uma análise de custo de consulta e impor um custo máximo permitido por consulta.
* Impor limite de taxa nas solicitações recebidas por IP ou usuário (ou ambos) para evitar ataques DoS básicos.
* Implemente a técnica de envio em lote e cache no lado do servidor (o DataLoader do Facebook pode ser usado para isso).
