---
title: Tamanho da Mensagem
---

Os serviços da Web, como os aplicativos da Web, podem ser alvos de ataques DOS, enviando automaticamente aos serviços da Web milhares de mensagens SOAP de grande porte . Isso prejudica o aplicativo, tornando-o incapaz de responder a mensagens legítimas, ou pode desligá-lo completamente.

**Regra:** O tamanho das mensagens SOAP deve ser limitado a um limite de tamanho apropriado. Um limite de tamanho maior (ou nenhum limite) aumenta as chances de um ataque DoS bem-sucedido.

## Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/)