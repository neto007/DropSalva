---
title: Armazenamento de Dados Inseguro
---
## Descrição

Sempre que dados confidenciais são armazenados em texto não criptografado, esses dados são comprometidos assim que
cai nas mãos de um atacante.


## Solução

Os dados confidenciais de todas as formas devem sempre ser armazenados de maneira criptografada.
Recomendamos seguir a folha de dicas "Secure Cryptographic datastorage" encontrada no OWASP.

https://www.owasp.org/index.php/Cryptographic_Storage_Cheat_Shee
