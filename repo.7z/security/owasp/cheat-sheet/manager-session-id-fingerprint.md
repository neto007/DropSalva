---
title: Impressão digital do nome do ID da sessão
---


O nome usado pelo ID da sessão não deve ser extremamente descritivo nem oferecer detalhes desnecessários sobre a finalidade e o significado do ID.

Os nomes de ID de sessão usados ​​pelas estruturas de desenvolvimento de aplicativos da Web mais comuns podem ser facilmente impressos digitalmente , como PHPSESSID(PHP), JSESSIONID(J2EE), CFID& CFTOKEN(ColdFusion), ASP.NET_SessionId(ASP .NET), etc. Portanto, o nome de ID de sessão pode revelar o tecnologias e linguagens de programação usadas pela aplicação web.

Recomenda-se alterar o nome de ID de sessão padrão da estrutura de desenvolvimento da web para um nome genérico, como id.


### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)