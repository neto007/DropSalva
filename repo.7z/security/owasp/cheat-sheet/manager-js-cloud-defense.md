---
title: Considerações de defesa de segurança
---

O mecanismo direto do servidor é um bom padrão de segurança para gerenciamento, implantação e execução de JavaScript de terceiros. Uma boa prática para a página host é criar uma camada de dados de objetos DOM.

A camada de dados pode realizar qualquer validação dos valores, especialmente valores de objetos DOM expostos ao usuário, como parâmetros de URL e campos de entrada, se forem necessários para a análise de marketing.

Um exemplo de declaração para um documento padrão corporativo é 'A tag JavaScript só pode acessar valores na camada de dados do host. A tag JavaScript nunca pode acessar um parâmetro de URL.

Você, o desenvolvedor da página host, deve concordar com os fornecedores terceirizados ou o gerenciador de tags sobre qual atributo na camada de dados terá qual valor, para que eles possam criar o JavaScript para ler esse valor.

As tags da interface do usuário não podem ser protegidas usando a arquitetura da camada de dados porque sua função (ou uma de suas funções) é alterar a interface do usuário no cliente, não enviar dados sobre as ações do usuário.

As tags analíticas podem ser tornadas seguras usando a arquitetura da camada de dados porque a única ação necessária é enviar dados da camada de dados para terceiros. Apenas o código original é executado; primeiro para preencher a camada de dados (geralmente no carregamento da página); então, o manipulador de eventos JavaScript envia todos os dados necessários dessa página para o banco de dados ou gerenciador de tags de terceiros.

Esta também é uma solução muito escalonável. Grandes sites de comércio eletrônico podem facilmente ter centenas de milhares de combinações de URL e parâmetro, com diferentes conjuntos de URLs e parâmetros sendo incluídos em diferentes campanhas de análise de marketing. A lógica de marketing pode ter 30 ou 40 tags de fornecedores diferentes em uma única página.

Por exemplo, as ações do usuário em páginas sobre cidades específicas, de locais específicos em dias especificados devem enviar os elementos 1, 2 e 3 da camada de dados. As ações do usuário em páginas sobre outras cidades devem enviar os elementos 2 e 3 da camada de dados apenas. Como o código do manipulador de eventos para enviar dados da camada de dados em cada página é controlado pelos desenvolvedores de host ou tecnólogos de marketing usando a interface do desenvolvedor do gerenciador de tags, a lógica de negócios sobre quando e quais elementos da camada de dados são enviados ao servidor do gerenciador de tags pode ser alterada e implantado em minutos. Nenhuma interação é necessária com terceiros; eles continuam recebendo os dados que esperam, mas agora vêm de contextos diferentes que os tecnólogos de marketing de host escolheram.

Alterar fornecedores terceirizados significa apenas alterar as regras de disseminação de dados no servidor do gerenciador de tags; nenhuma alteração é necessária no código do host. Os dados também vão diretamente para o gerenciador de tags para que a execução seja rápida. O manipulador de eventos JavaScript não precisa se conectar a vários sites de terceiros.

- [Solicitações indiretas](manager-js-indirect-request)

- [Conteúdo de sandbox](manager-js-sandbox)

- [Manter as bibliotecas JavaScript atualizadas](manager-js-lib-update)

- [Sandbox com iframe](manager-js-sandbox-iframe)


### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)