---
title: Controle de acesso
---

## O que é controle/autorização de acesso?

Autorização é o processo em que as solicitações de acesso a um determinado recurso devem ser concedidas ou negadas. Deve-se observar que autorização não é equivalente a autenticação - já que esses termos e suas definições são frequentemente confundidos. A autenticação está fornecendo e validando a identidade. A autorização inclui as regras de execução que determinam quais funcionalidades e dados o usuário (ou Principal) pode acessar, garantindo a alocação adequada de direitos de acesso após a autenticação ser bem-sucedida.

Os aplicativos da Web precisam de controles de acesso para permitir que os usuários (com privilégios variados) usem o aplicativo. Eles também precisam de administradores para gerenciar as regras de controle de acesso do aplicativo e a concessão de permissões ou direitos a usuários e outras entidades. Várias metodologias de projeto de controle de acesso estão disponíveis. Para escolher o mais apropriado, uma avaliação de risco deve ser realizada para identificar ameaças e vulnerabilidades específicas ao seu aplicativo, de modo que a metodologia de controle de acesso apropriada seja apropriada para seu aplicativo.

## Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/)