---
title: Suporta HTTP Strict Transport Security
---

`HTTP Strict Transport Security (HSTS)` é um cabeçalho `HTTP` definido pelo servidor que indica ao agente do usuário que apenas conexões seguras (`HTTP`S) são aceitas, solicitando que o agente do usuário altere todos os links `HTTP` inseguros para `HTTP`S e forçando o agente do usuário compatível para à prova de falhas, recusando qualquer conexão `TLS/SSL` que não seja confiável para o usuário.

O `HSTS` tem suporte médio para agentes de usuários populares, como Mozilla Firefox e Google Chrome. No entanto, continua a ser muito útil para usuários que têm medo constante de espionagem e de ataques do Homem no Meio.

Se for impraticável forçar o `HSTS` em todos os usuários, os desenvolvedores da web devem pelo menos dar aos usuários a opção de ativá-lo, caso desejem fazer uso dele.

Para obter mais detalhes sobre `HSTS`, visite:

- [HTTP Strict Transport Security](https://en.wikipedia.org/wiki/HTTP_Strict_Transport_Security)

- [IETF para HSTS RFC](https://tools.ietf.org/html/rfc6797)

- [OWASP Appsec Tutorial](https://www.youtube.com/watch?v=zEV3HOuM_Vw)

### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/cheatsheets/Vulnerable_Dependency_Management_Cheat_Sheet.html)

```

```