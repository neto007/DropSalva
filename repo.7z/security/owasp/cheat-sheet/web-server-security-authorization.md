---
title: Autorização
---

Os serviços da web precisam autorizar clientes de serviços da web da mesma forma que os aplicativos da web autorizam os usuários. Um serviço da web precisa ter certeza de que um cliente de serviço da web está autorizado a executar uma determinada ação (granulação grossa) nos dados solicitados (granulação fina).

**Regra:** Um serviço da web deve autorizar seus clientes se eles têm acesso ao método em questão. Após a autenticação, o serviço da web deve verificar os privilégios da entidade solicitante se eles têm acesso ao recurso solicitado. Isso deve ser feito em cada solicitação.

**Regra:** Certifique-se de que o acesso às funções de administração e gerenciamento no aplicativo de serviço da web seja limitado aos administradores de serviço da web. Idealmente, qualquer recurso administrativo estaria em um aplicativo completamente separado dos serviços da web gerenciados por esses recursos, separando assim completamente os usuários normais dessas funções confidenciais.

## Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/)