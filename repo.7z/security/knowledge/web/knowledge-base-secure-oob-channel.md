---
title: Canal OOB seguro
---
## Descrição

A ideia essencial por trás da autenticação out-of-band é que, usando dois canais diferentes, os sistemas de autenticação podem proteger contra usuários fraudulentos que podem ter acesso apenas a um desses canais. Um dos exemplos mais comuns de autenticação fora de banda é em transações bancárias. Normalmente, um cliente que deseja fazer uma transação bancária online receberá uma mensagem SMS por telefone celular com uma senha. Desta forma, quaisquer hackers ou ladrões de identidade que tenham acesso através de key loggers ou outro equipamento não serão capazes de acessar aquela senha específica, porque ela é enviada por uma rede sem fio 3G ou 4G em vez de ser enviada pela Internet. Vale a pena certifique-se de que o canal entre as partes em comunicação seja por meio de um canal confiável e seguro.

## Solução

A solução mais eficaz é mudar para um canal mais seguro e implementar mecanismos como TLS mútuo entre as partes que interagem, sempre que possível.