---
title: Linguagem de modelo
---
## Descrição

Conteúdo de linguagem de modelo de expressão ou script fornecido pelo usuário, como Markdown,
Folhas de estilo CSS ou XSL, BBCode ou semelhantes são projetadas para dar aos usuários a opção para adicionar muito estilo sofisticado ao aplicativo. No entanto, sempre que esses modelos não filtrar por ataques prejudiciais, esses modelos podem ser usados ​​para alavancar
Ataques XSS.


## Solução

Verifique se o aplicativo higieniza, desativa ou aplica sandboxes conteúdo de linguagem de modelo de expressão ou script fornecido pelo usuário, como Markdown, Folhas de estilo CSS ou XSL, BBCode ou semelhante.
A maneira mais eficaz de fazer isso depende da estrutura e da biblioteca que você
estão escolhendo incorporar. É aconselhável investigar como colocar restrições
para traduzir essas sintaxes de modelo para tags HTML e no que sua segurança
implicará.