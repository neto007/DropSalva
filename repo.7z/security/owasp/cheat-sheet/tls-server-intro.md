---
title: Proteção da camada de transporte
---

Esta página de dicas fornece orientação sobre como implementar a proteção da camada de transporte para um aplicativo usando `Transport Layer Security (TLS)`. Quando implementado corretamente, o TLS pode fornecer uma série de benefícios de segurança:

- Confidencialidade - proteção contra a leitura de conteúdo do tráfego por um invasor.

- Integridade - proteção contra o tráfego de modificação de um invasor.

- Prevenção de reprodução - proteção contra solicitações de repetição de um invasor no servidor.

- Autenticação - permite ao cliente verificar se está conectado ao servidor real (observe que a identidade do cliente não é verificada a menos que sejam usados ​​certificados de cliente).

O TLS é usado por muitos outros protocolos para fornecer criptografia e integridade e pode ser usado de várias maneiras diferentes. Este cheatsheet está focado principalmente em como usar TLS para proteger clientes que se conectam a um aplicativo da web por HTTPS; embora muitas das orientações também sejam aplicáveis ​​a outros usos do TLS.

- [Configuração do Servidor](./tls-server-setting)

- [Certificados](./tls-server-cert)

- [Teste as configurações](./tls-test-settings)

- [Aplicação](./tls-server-page-tls)

### Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/)