---
title: Proteção de recursos e acessos
---
## Descrição

Os aplicativos geralmente têm maneiras diferentes de conceder acesso a recursos protegidos; às vezes, estes são feito com base em uma função definida em um banco de dados ou usando uma permissão do Active Directory. Além disso, serviços de autorização podem ser implementados e necessários para a aplicação. Com todas essas maneiras diferentes para proteger recursos e o acesso a esses ativos, erros serão facilmente cometidos.

## Solução

Implementar um mecanismo centralizado onde todos os diferentes tipos de recursos e acesso gradativo a esses recursos (incluindo bibliotecas que chamam serviços de autorização externos) estão localizados. Deste jeito é mais fácil de manter e menor a complexidade. Essa solução centralizada também deve conter registro e monitoramento suficientes para detectar abusos ou violações da conta.
