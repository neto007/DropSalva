---
title: Comunicação entre componentes
---
## Descrição

Se as contas de comunicação entre componentes tiverem concedido mais privilégios do que
necessário, essas contas podem impor uma grande ameaça sempre que um desses componentes
for comprometido pelos atacantes.

Por exemplo, um aplicativo Web em execução nos privilégios de root que possui uma vulnerabilidade de "Path Traversal" pode ser usado para ler o arquivo "etc/passwd" e também para ler o arquivo "etc/shadow". Esses arquivos podem ser usados ​​em ataques de quebra de senha offline para recuperar contas no servidor

## Solução

Comunicações entre componentes, como entre o servidor de aplicativos e o banco de dados
o servidor deve ser autenticado usando uma conta com os privilégios mínimos.