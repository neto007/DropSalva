---
title: Use parâmetros Diffie-Hellman fortes
---

Quando cifras que usam a troca de chave Diffie-Hellman efêmera estão em uso (representadas pelas strings "DHE" ou "EDH" no nome da cifra), parâmetros `Diffie-Hellman` suficientemente seguros (pelo menos 2048 bits) devem ser usados

O seguinte comando pode ser usado para gerar parâmetros de `2048 bits`:

`openssl dhparam 2048 -out dhparam2048.pem`

O [Weak DH](https://weakdh.org/sysadmin.html) fornece orientação sobre como vários servidores da web podem ser configurados para usar esses parâmetros gerados.

### Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/)