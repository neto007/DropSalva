---
title: A9 Using components with known vulnerabilities
---

## A Aplicação é Vulnerável?
A aplicação pode ser vulnerável se:

* Não conhecer as versões de todos os componentes que utiliza (tanto no âmbito do cliente como no servidor). Isto engloba componentes que utiliza diretamente, bem como as suas dependências.
* O software é vulnerável, deixou de ser suportado, ou está desatualizado. Isto inclui o SO, servidor web ou da aplicação,
sistemas de gestão de base de dados (SGBDs), aplicações, APIs e todos os componentes, ambientes de execução, e bibliotecas.
* Não examinar regularmente os componentes que utiliza quanto à presença de vulnerabilidades e não subscrever relatórios de segurança relacionados com os mesmos.
* Não corrigir ou atualizar a plataforma base, frameworks e dependências de forma oportuna numa abordagem baseada no risco. Isto é um padrão comum em ambientes nos quais novas versões são lançadas mensalmente ou trimestralmente, levando a que as organizações fiquem expostas à exploração de vulnerabilidades já corrigidas, durante dias ou meses.
* Os programadores não testarem a compatibilidade com as novas versões, atualizações ou correções das bibliotecas.
* Não garantir a segurança das configurações dos componentes (ver A6:2017-Configurações de Segurança Incorretas).

## Exemplos de Cenários de Ataque

#### Cenário #1: 
Tipicamente os componentes executam com os mesmos privilégios da aplicação onde se inserem, portanto quaisquer vulnerabilidades nos componentes podem resultar num impacto sério. Falhas deste tipo podem ser acidentais (ex. erro de programação) ou intencional (ex. backdoor no componente). Exemplos de abuso de vulnerabilidades em componentes são:

* CVE-2017-5638, a execução remota de código relacionado com uma vulnerabilidade Struts 2, a qual permite a execução de código arbitrário no servidor, foi responsável por várias quebras de segurança graves.
* Apesar da dificuldade é imperativo manter redes como Internet of Things (IoT) atualizadas (e.g. dispositivos biomédicos). Existem ferramentas automáticas que ajudam os atacantes a encontrar sistemas mal configurados ou com erros. Por exemplo, o motor de busca Shodan pode ajudar a facilmente encontrar dispositivos que possam ainda estar vulneráveis a Heartbleed, vulnerabilidade esta que já foi corrigida em Abril de 2014.

## Como Prevenir
O processo de gestão de correções e atualizações deve:

* Remover dependências não utilizadas assim como funcionalidades, componentes, ficheiros e documentação desnecessários.
* Realizar um inventário das versões dos componentes ao nível do cliente e do servidor (ex. frameworks, bibliotecas) e das suas dependências, usando para isso ferramentas como versions, DependencyCheck, retire.js, etc. Monitorize regularmente fontes como Common Vulnerabilities and Exposures (CVE) e National Vulnerability Database (NVD) em busca de vulnerabilidades em componentes. Automatize o processo. Subscreva alertas via e-mail sobre vulnerabilidades de segurança relacionadas com componentes utilizados.
* Obter componentes apenas de fontes oficiais e através de ligações seguras, preferindo pacotes assinados de forma a mitigar componentes modificados ou maliciosos.
* Monitorizar bibliotecas e componentes que não sofram manutenção ou cujas versões antigas não são alvo de atualizações de segurança. Considere aplicar correções virtuais quando necessário. As organizações deve manter um plano ativo de monitorização, triagem e aplicação de atualizações ou mudanças na configuração das aplicações ao longo do ciclo de vida.

