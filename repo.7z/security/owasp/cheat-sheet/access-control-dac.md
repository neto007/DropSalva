---
title: Controle de acesso - DAC
---

O Controle de Acesso Discricionário (DAC) é um meio de restringir o acesso às informações com base na identidade dos usuários e/ou participação em certos grupos. As decisões de acesso são normalmente baseadas nas autorizações concedidas a um usuário com base nas credenciais apresentadas no momento da autenticação (nome de usuário, senha, token de hardware/software, etc.). Na maioria dos modelos DAC típicos, o proprietário das informações ou de qualquer recurso pode alterar suas permissões a seu critério (daí o nome).

Uma estrutura DAC pode fornecer aos administradores de segurança de aplicativos da Web a capacidade de implementar um controle de acesso refinado. Este modelo pode ser uma base para implementação de controle de acesso baseado em dados

### As vantagens de usar este modelo

* Fácil de usar
* Fácil de administrar
* Alinha-se com o princípio de privilégios mínimos.
* O proprietário do objeto tem controle total sobre o acesso concedido

### Problemas que podem ser encontrados ao usar esta metodologia

* A documentação das funções e acessos deve ser mantida rigorosamente.
* A multilocação não pode ser implementada de forma eficaz, a menos que haja uma maneira de associar as funções aos requisitos de capacidade de multilocação, por exemplo, OU no Active Directory
* Há uma tendência de aumento do escopo, por exemplo, mais acessos e privilégios podem ser dados do que o pretendido.

### As áreas de cautela ao usar o DAC são:

* Ao conceder relações de confiança
* A garantia do DAC deve ser realizada usando análises de controle de acesso rigorosas.

## Referência externa
[OWASP - Controle de acesso DAC](https://cheatsheetseries.owasp.org/cheatsheets/Access_Control_Cheat_Sheet.html#discretionary-access-control-dac)