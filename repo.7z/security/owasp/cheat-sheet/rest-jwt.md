---
title: JWT 
---

Parece haver uma convergência em relação ao uso de JSON Web Tokens (JWT) como formato para tokens de segurança. JWTs são estruturas de dados JSON contendo um conjunto de declarações que podem ser usadas para decisões de controle de acesso. Uma assinatura criptográfica ou código de autenticação de mensagem (MAC) pode ser usado para proteger a integridade do [JWT](https://tools.ietf.org/html/rfc7519#section-6.1).

- Certifique-se de que os JWTs sejam protegidos por uma assinatura ou MAC. Não permita que os JWTs inseguros: {"alg":"none"}.

- Em geral, as assinaturas devem ser preferidas aos MACs para proteção de integridade de JWTs.

Se MACs forem usados ​​para proteção de integridade, todo serviço capaz de validar JWTs também pode criar novos JWTs usando a mesma chave. Isso significa que todos os serviços que usam a mesma chave devem confiar mutuamente uns nos outros. Outra consequência disso é que o comprometimento de qualquer serviço também compromete todos os outros serviços que compartilham a mesma chave. Veja [aqui](https://tools.ietf.org/html/rfc7515#section-10.5) para informações adicionais.

### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)

- [JSON Web Signature](https://tools.ietf.org/html/rfc7515#section-10.5)