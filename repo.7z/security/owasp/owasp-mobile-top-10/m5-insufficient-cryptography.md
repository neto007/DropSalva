---
title: Insufficient Cryptography
---

## O aplicativo está vulnerável?
O uso inseguro de criptografia é comum na maioria dos aplicativos móveis que utilizam criptografia. Existem duas maneiras fundamentais pelas quais a criptografia quebrada se manifesta nos aplicativos móveis. Primeiro, o aplicativo móvel pode usar um processo por trás da criptografia/descriptografia que é fundamentalmente falho e pode ser explorado pelo adversário para descriptografar dados confidenciais. Em segundo lugar, o aplicativo móvel pode implementar ou aproveitar um algoritmo de criptografia/descriptografia de natureza fraca e pode ser descriptografado diretamente pelo adversário. As subseções a seguir exploram esses dois cenários com mais profundidade:

Dependência de processos de criptografia de código integrados
Por padrão, os aplicativos iOS são protegidos (em teoria) da engenharia reversa por meio de criptografia de código. O modelo de segurança do iOS requer que os aplicativos sejam criptografados e assinados por fontes confiáveis ​​para serem executados em ambientes sem jailbreak. Após a inicialização, o carregador de aplicativo iOS irá descriptografar o aplicativo na memória e continuar a executar o código após sua assinatura ter sido verificada pelo iOS. Esse recurso, em teoria, evita que um invasor conduza ataques binários contra um aplicativo móvel iOS.

Usando ferramentas disponíveis gratuitamente como ClutchMod ou GBD, um adversário irá baixar o aplicativo criptografado em seu dispositivo com jailbreak e tirar um instantâneo do aplicativo descriptografado assim que o carregador do iOS carregá-lo na memória e descriptografá-lo (pouco antes do carregador iniciar a execução). Depois que o adversário tira o instantâneo e o armazena no disco, ele pode usar ferramentas como IDA Pro ou Hopper para realizar facilmente análises estáticas/dinâmicas do aplicativo e conduzir outros ataques binários.

Ignorar algoritmos de criptografia de código integrados é, na melhor das hipóteses, trivial. Sempre suponha que um adversário será capaz de contornar qualquer criptografia de código integrada oferecida pelo sistema operacional móvel subjacente. Para obter mais informações sobre etapas adicionais que você pode seguir para fornecer camadas adicionais de prevenção de engenharia reversa, consulte M9.

Processos de gerenciamento de chaves ruins

Os melhores algoritmos não importam se você manuseia mal suas chaves. Muitos cometem o erro de usar o algoritmo de criptografia correto, mas implementando seu próprio protocolo para empregá-lo. Alguns exemplos de problemas aqui incluem:

Incluir as chaves no mesmo diretório legível pelo invasor que o conteúdo criptografado;
Disponibilizar as chaves para o invasor;
Evite o uso de chaves codificadas dentro de seu binário; e
As chaves podem ser interceptadas por meio de ataques binários. Consulte M10 para obter mais informações sobre como evitar ataques binários.
Criação e uso de protocolos de criptografia personalizados

Não há maneira mais fácil de lidar incorretamente com a criptografia - móvel ou não - do que tentar criar e usar seus próprios algoritmos ou protocolos de criptografia.

Sempre use algoritmos modernos que sejam aceitos como sólidos pela comunidade de segurança e, sempre que possível, aproveite as APIs de criptografia de última geração em sua plataforma móvel. Ataques binários podem resultar na identificação do adversário das bibliotecas comuns que você usou junto com quaisquer chaves codificadas permanentemente no binário. Em casos de requisitos de segurança muito altos em torno da criptografia, você deve considerar fortemente o uso da criptografia de caixa branca. Consulte M10 para obter mais informações sobre como evitar ataques binários que podem levar à exploração de bibliotecas comuns.

Uso de Algoritmos Inseguros e/ou Obsoletos

Muitos algoritmos e protocolos criptográficos não devem ser usados ​​porque demonstraram ter pontos fracos significativos ou são insuficientes para os requisitos de segurança modernos. Esses incluem:

* RC2
* MD4
* MD5
* SHA1

## Cenários de exemplo de ataques
None

## Como prevenir
É melhor fazer o seguinte ao lidar com dados confidenciais:

Evite o armazenamento de dados confidenciais em um dispositivo móvel, sempre que possível.
Aplicar padrões criptográficos que resistirão ao teste do tempo por pelo menos 10 anos no futuro; e
Siga as diretrizes do NIST sobre algoritmos recomendados (consulte as referências externas).
