---
title: Azure Virtual Machine 
sidebar_label: Virtual Machine
---

**Proposta de melhores práticas de segurança para o uso de máquinas virtuais na Azure:**

O Azure Virtual Machine é um dos vários tipos de recursos de computação sob demanda escalonáveis oferecidos pelo Azure. Uma VM do Azure oferece a flexibilidade da virtualização sem a necessidade de comprar e manter o hardware físico que a executa. No entanto, você ainda precisa manter a VM executando tarefas, como configurar, corrigir e instalar o software que será executado nela.

Para garantir que o recurso Azure VM esteja sendo executado com segurança é necessário que o mesmo atenda a uma série de recomendações e melhores práticas.

O objetivo desse documento é descrever essas recomendações garantindo um recurso devidamente configurado e protegido no ambiente.

## Recomendações

**Geral**
-   Sistema Operacional - Garantir que o sistema operacional utilizado foi previamente homologado e aprovado pela equipe de Segurança da informação;
    
-   Hardening SO - Garantir que o sistema operacional utilizado está com o hardening devidamente aplicado;
    
-   Imagens base - Garantir que as imagens base estão com o hardening devidamente aplicado e com as últimas atualizações de segurança instaladas. Sempre instale as atualizações mais recentes para o sistema operacional e para todos os aplicativos que serão parte da sua imagem;
    
-   Atualização de VMs - Garantir a atualização periódica das máquinas virtuais em execução na Azure;
    
-   Backup - Garantir o backup atualizado de suas máquinas virtuais e a inclusão da mesma nos testes de restore;
    
-   Extensions - Utilizar somente “_Extensions”_ previamente homologadas e aprovadas pela equipe de Segurança da informação;
    
-   Disponibilidade - Recomendado o uso de “_Availability set”_ ou “_Availability zone”_ para os sistemas de alta criticidade, garantindo uma melhor disponibilidade do ambiente;
    
-   BCDR - Recomendado que os serviços de alta criticidade estejam cobertos com uma estratégia de BCDR (Business Continuity and Disaster Recovery).
    
-   ARM Templates - É recomendado o uso de ARM templates na criação de máquinas virtuais reduzindo a variação de tipos de configuração de máquinas virtuais criadas no ambiente;

**Segurança de dados**

-   Antivírus (Kaspersky) - Garantir que o antivírus (Kaspersky) esteja devidamente instalada e atualizada na máquina virtual;
    
-   EDR (Forescout) - Garantir que o EDR (Forescout) esteja devidamente instalada e atualizada na máquina virtual;
    
-   Splunk - Garantir que o agente do Splunk esteja devidamente instalado e atualizado na máquina virtual;
    
-   BigFix - Garantir que o agente do BigFix esteja devidamente instalado e atualizado na máquina virtual;
    
-   Armazenamento de chaves e segredos - Não armazene chaves e segredos dentro de sua máquina virtual. Utilize o recurso do Azure Key Vault para armazenamento dessas informações de forma segura;
    
-   Criptografia de discos - É recomendado a criptografia dos discos para que usuários não autorizados obtenham acesso aos dados dos discos da VM. Importante: O _“Azure Disk Encryption”_ precisa que o Azure Key Vault e a VM façam parte da mesma região;
    
-   Separação por ambiente - Garanta que a máquina virtual será instalada no escopo adequado ao seu ambiente de execução (Produção, Homologação ou Desenvolvimento);
    
-   Instale apenas o necessário - Evitar a instalação de softwares que não serão utilizados para o funcionamento de sua solução. Isso reduz a superfície de ataque da solução.

**Gerenciamento de identidade e de acesso**

-   Uso do Active Directory - Centralizar a gestão das contas e acessos com o uso do Active Directory.
    
-   Menor privilégio - Garantir que as pessoas que terão acesso a máquina virtual, terão acesso somente aos recursos necessários para desempenhar suas funções. Ex.: Virtual Machine Contributor podem gerenciar o recurso VM, mas não pode gerenciar a VNET ou Storage Account que ela está conectada;
    
-   Criação de Snapshots - Restringir a lista de usuários com permissões para realizar snapshots. Esse acesso pode ser utilizado por usuários mal intencionados para obter acesso as configurações da máquina virtual;
    
-   Prevenção de acesso não autorizado - Utilizar o RBAC da Azure para garantir que somente o grupo responsável pelo gerenciamento de rede tenha permissão para realizar alterações nos recursos de rede da VM, como liberações de regras no NSG;
    
-   Execução do _“Run Command”_ - Restringir e monitorar o acesso ao privilégio "run command", pois esta ação pode ser executada por usuários mal intencionados para obter acesso indevido com privilégio de root na máquina virtual;
    
-   Acesso restrito as imagens base - Restringir e monitorar o acesso as imagens base, garantindo que somente os usuários autorizados poderão acessar as imagens;
    
-   Senha na chave de acesso a VM - Recomendado o uso de senhas como uma camada adicional no uso de chaves de acesso as VMs. O objetivo é prevenir uso indevido em caso de comprometimento da chave.

> **Note:** Atualmente os times autorizados a criar máquinas virtuais na Azure são Cloud e DevOps.


**Monitoramento**

 - Monitoramento - Garantir que suas máquinas estejam sendo monitoradas adequadamente, evitando problemas de desempenho, perda de dados, downtime e etc;

## Políticas de prevenção e detecção aplicadas

![Políticas de prevenção e detecção aplicadas](/assets/security/cloud/azure-virtual-machine-regras.png)
