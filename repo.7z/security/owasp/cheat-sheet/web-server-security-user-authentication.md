---
title: Autenticação de usuário
---

A autenticação do usuário verifica a identidade do usuário ou do sistema que está tentando se conectar ao serviço. Essa autenticação geralmente é uma função do contêiner do serviço da web.

**Regra:** se usada, a autenticação básica deve ser conduzida por TLS , mas a autenticação básica não é recomendada.

**Regra:** A autenticação de certificado de cliente usando TLS é uma forma forte de autenticação recomendada.

## Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/)