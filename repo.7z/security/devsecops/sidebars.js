const synopsys = require('./synopsys/sidebars')
module.exports = {
    type: "category",
    label: "Processos DevSecOps",
    items: [    
        "chapters/security/devsecops/validacao-api",
        "chapters/security/devsecops/validacao-fornecedores",
        "chapters/security/devsecops/dependabot",
        synopsys
    ],
};