---
title: Autenticação Avançada Ou Adaptativa
---
## Descrição

Sempre que um usuário navega em uma seção de um aplicativo baseado na web que contém informações confidenciais, o usuário deve ser desafiado a se autenticar novamente usando uma credencial de garantia mais alta para ter acesso a essas informações. Isso evita que invasores leiam informações confidenciais após sequestrarem uma conta de usuário.

## Solução

Verifique se o aplicativo tem autorização adicional (como autenticação progressiva ou adaptativa) para que o usuário seja desafiado antes de receber acesso a informações confidenciais. Esta regra também se aplica para fazer alterações críticas em uma conta ou ação. A segregação de funções deve ser aplicada para aplicativos de alto valor para impor controles antifraude de acordo com o risco de aplicativo e fraude passada.