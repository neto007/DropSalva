---
title: Xml Inválido
---

Os invasores podem introduzir valores inesperados em documentos para tirar proveito de um aplicativo que não verifica se o documento contém um conjunto válido de valores. Os esquemas especificam restrições que ajudam a identificar se os documentos são válidos. Um documento válido é bem formado e está em conformidade com as restrições de um esquema, e mais de um esquema pode ser usado para validar um documento. Essas restrições podem aparecer em vários arquivos, usando uma única linguagem de esquema ou contando com os pontos fortes das diferentes linguagens de esquema.

A recomendação para evitar essas vulnerabilidades é que cada documento XML deve ter um esquema XML precisamente definido (não DTD ) com todas as informações adequadamente restritas para evitar problemas de validação de dados inadequada. Use uma cópia local ou um bom repositório conhecido em vez da referência de esquema fornecida no documento XML. Além disso, execute uma verificação de integridade do arquivo de esquema XML que está sendo referenciado, tendo em mente a possibilidade de que o repositório possa estar comprometido. Nos casos em que os documentos XML estão usando esquemas remotos, configure os servidores para usar apenas comunicações seguras e criptografadas para evitar que invasores espionem o tráfego da rede.

## Documento sem Esquema

Considere um livreiro que usa um serviço da web por meio de uma interface da web para fazer transações. O documento XML para transações é composto por dois elementos: um id valor relacionado a um item e um determinado price. O usuário só pode inserir um determinado idv alor usando a interface da web:


```xml

<buy>
 <id>123</id>
 <price>10</price>
</buy>
```

Se não houver controle sobre a estrutura do documento, o aplicativo também pode processar diferentes mensagens bem formadas com consequências indesejadas. O documento anterior poderia conter tags adicionais para afetar o comportamento do aplicativo subjacente que processa seu conteúdo:


```xml

<buy>
 <id>123</id><price>0</price><id></id>
 <price>10</price>
</buy>
```

Observe novamente como o valor 123 é fornecido como um id, mas agora o documento inclui tags adicionais de abertura e fechamento. O invasor fechou o id elemento e define um price elemento falso com o valor 0. A etapa final para manter a estrutura bem formada é adicionar um id elemento vazio . Depois disso, o aplicativo adiciona a tag de fechamento para ide define o price para 10. Se o aplicativo processar apenas os primeiros valores fornecidos para o ID e o valor sem realizar qualquer tipo de controle na estrutura, pode beneficiar o invasor, fornecendo a capacidade comprar um livro sem realmente pagar por ele.

### Esquema Unrestrictive

Certos esquemas não oferecem restrições suficientes para o tipo de dados que cada elemento pode receber. Isso é o que normalmente acontece ao usar o `DTD`; ele tem um conjunto muito limitado de possibilidades em comparação com o tipo de restrições que podem ser aplicadas em documentos XML. Isso poderia expor o aplicativo a valores indesejados em elementos ou atributos que seriam fáceis de restringir ao usar outras linguagens de esquema. No exemplo a seguir, uma pessoa age é validada em relação a um esquema `DTD inline`:

```xml

<!DOCTYPE person [
 <!ELEMENT person (name, age)>
 <!ELEMENT name (#PCDATA)>
 <!ELEMENT age (#PCDATA)>
]>
<person>
 <name>John Doe</name>
 <age>11111..(1.000.000digits)..11111</age>
</person>

```

O documento anterior contém um `DTD` embutido com um elemento raiz denominado person. Este elemento contém dois elementos em uma ordem específica: name e então age. O elemento name é então definido para conter `PCDATA`, bem como o elemento age. Após esta definição começa o documento XML válido e bem formado. O nome do elemento contém um valor irrelevante, mas o age elemento contém um milhão de dígitos. Uma vez que não há restrições quanto ao tamanho máximo para o age, esta string de um milhão de dígitos pode ser enviada ao servidor para este elemento. Normalmente, este tipo de elemento deve ser restrito para conter não mais do que uma certa quantidade de caracteres e restrito a um determinado conjunto de caracteres (por exemplo, dígitos de 0 a 9, o sinal + e o sinal -). Se não forem restritos adequadamente, os aplicativos podem lidar com valores potencialmente inválidos contidos em documentos. Como não é possível indicar restrições específicas (comprimento máximo para o elemento name ou intervalo válido para o elemento age), esse tipo de esquema aumenta o risco de afetar a integridade e a disponibilidade dos recursos.

## Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/cheatsheets/XML_Security_Cheat_Sheet.html)