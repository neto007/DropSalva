---
title: Criptografia Forte
---

Qualquer plataforma online que lida com identidades de usuários, informações privadas ou comunicações deve ser protegida com o uso de criptografia forte. As comunicações do usuário devem ser criptografadas em trânsito e armazenamento. Os segredos do usuário, como senhas, também devem ser protegidos por meio de algoritmos de hash fortes e resistentes a colisões com fatores de trabalho crescentes, a fim de reduzir significativamente os riscos de credenciais expostas, bem como o controle de integridade adequado.

Para proteger os dados em trânsito, os desenvolvedores devem usar e aderir às práticas recomendadas de `TLS/SSL`, como certificados verificados, chaves privadas protegidas adequadamente, uso apenas de criptografias fortes, avisos informativos e claros para os usuários, bem como comprimentos de chave suficientes. Os dados privados devem ser criptografados em armazenamento usando chaves com comprimentos suficientes e sob condições estritas de acesso, tanto técnicas quanto procedimentais. As credenciais do usuário devem ter hash, independentemente de serem criptografadas ou não no armazenamento.

Para guias detalhados sobre criptografia forte e práticas recomendadas, leia as seguintes referências OWASP:

- Armazenamento criptográfico

- Autenticação

- Proteção da camada de transporte

- Guia para criptografia

- Testando para TLS/SSL


### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/cheatsheets/User_Privacy_Protection_Cheat_Sheet.html)
