---
title: Autenticação explicita em servidores
---
## Descrição

Sempre que o servidor ao qual seu aplicativo da web está se conectando não está usando qualquer forma de autenticação explícita e voltada para a Internet, isso significa que o servidor Não se pode confiar. Isso ocorre porque o servidor pode pertencer e ser gerenciado por todos, incluindo hackers.

## Solução

Sempre que o aplicativo da web está voltado para a Internet, terceiros tentando
acesso deve sempre usar uma forma de autenticação para obter acesso.