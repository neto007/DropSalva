---
title: Restrições no lado do cliente
---
## Descrição

Sempre que as restrições impostas no lado do cliente não forem aplicadas no lado do servidor, essas restrições podem ser facilmente contornadas por meio de um proxy interceptador. Ou seja, sempre que o usuário não deva editar um formulário desativando apenas os campos de entrada, um invasor em potencial pode editar essas entradas e campos no lado do cliente como editáveis ​​e ainda enviam o formulário.

O mesmo princípio se aplica sempre que certas partes do aplicativo devem estar inacessíveis. Escondendo-se simplesmente as páginas da camada de apresentação são inseguras, pois o invasor pode enumerar por força bruta ou mexendo em páginas diferentes. Novamente, os controles de acesso também devem ser aplicados no lado do servidor.

## Solução

Toda lógica crítica de tomada de decisão deve ser aplicada no lado do servidor fora do escopo de um potencial atacante. As restrições do lado do cliente podem ser facilmente contornadas.