---
title: A1 injection
---

## A Aplicação é Vulnerável?

Uma aplicação é vulnerável a este ataque quando:
* Os dados fornecidos pelo utilizador não são validados,filtrados ou limpos pela aplicação.
* Dados hostis são usados diretamente em consultas dinâmicas ou invocações não parametrizadas para um interpretador sem terem sido processadas de acordo com o seu contexto.
* Dados hostis são usados como parâmetros de consulta ORM, por forma a obter dados adicionais ou sensíveis.
* Dados hostis são usados diretamente ou concatenados em consultas SQL ou comandos, misturando a estrutura e os dados hostis em consultas dinâmicas, comandos ou procedimentos armazenados.

Algumas das injeções mais comuns são SQL, NoSQL,comandos do sistema operativo, ORM, LDAP, Linguagens de Expressão (EL) ou injeção OGNL. O conceito é idêntico entre todos os interpretadores. A revisão de código é a melhor forma de detetar se a sua aplicação é vulnerável a injeções, complementada sempre com testes automáticos que cubram todos os parâmetros, cabeçalhos, URL, cookies, JSON, SOAP e dados de entrada para XML. 
As organizações podem implementar ferramentas de análise estática (SAST) e dinâmica (DAST) de código no seu processo de CI/CD por forma a identificar novas falhas relacionadas com injeção antes de colocar as aplicações em ambiente de produção.

## Exemplos de Cenários de Ataque

#### Cenário #1: 
Uma aplicação usa dados não confiáveis na construção da seguinte consulta SQL vulnerável:
`String query = "SELECT * FROM accounts WHERE  custID='" + request.getParameter("id") + "'";`

#### Cenário #2: 
De forma semelhante, a confiança cega de uma aplicação em frameworks pode resultar em consultas que são
igualmente vulneráveis, (e.g. Hibernate Query Language (HQL)):
`Query HQLQuery = session.createQuery("FROM accounts WHERE custID='" + request.getParameter("id") + "'");`

Em ambos os casos, um atacante modifica o valor do parâmetro id no seu browser para enviar: `' or '1'='1`.
Por exemplo: `http://example.com/app/accountView?id=' or '1'='1`
Isto altera o significado de ambas as consultas para que retornem todos os registos da tabela "accounts". Ataques mais
perigosos podem modificar dados ou até invocar procedimentos armazenados

## Como Prevenir
Prevenir as injeções requer que os dados estejam separados dos comandos e das consultas.

* Optar por uma API que evite por completo o uso do interpretador ou que ofereça uma interface parametrizável, ou
então usar uma ferramenta ORM - Object Relational Mapping. N.B.: Quando parametrizados, os procedimentos armazenados podem ainda introduzir injeção de SQL se o PL/ SQL ou T-SQL concatenar consulta e dados, ou executar dados hostis com EXECUTE IMMEDIATE ou exec().
* Validação dos dados de entrada do lado do servidor usando whitelists, isto não representa uma defesa completa uma vez
que muitas aplicações necessitam de usar caracteres especiais, tais como campos de texto ou APIs para aplicações
móveis.
* Para todas as consultas dinâmicas, processar os caracteres especiais usando sintaxe especial de processamento para o
interpretador específico (escaping). N.B.: Estruturas de SQL tais como o nome das tabelas e colunas, entre outras, não podem ser processadas conforme descrito acima e por isso todos os nomes de estruturas fornecidos pelos utilizadores são perigosos. Este é um problema comum em software que produz relatórios.
* Usar o LIMIT e outros controlos de SQL dentro das consultas para prevenir a revelação não autorizada de grandes volumes
de registos em caso de injeção de SQL.
