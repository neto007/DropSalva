---
title: Não permitir senhas antigas
---
## Descrição

Isso é uma atenuação do risco de que uma senha possa vazar por qualquer meio para um possível invasor. Devido à reutilização da senha, isso pode acontecer não apenas devido a um vazamento no seu site. Alterar a senha para uma nova minimiza o dano.

Além disso, os usuários realmente não gostam de alterar suas senhas. Então, o que os usuários costumavam fazer quando eram forçados a alterar sua senha era alterá-la duas vezes - uma vez para uma senha temporária e depois uma segunda vez para a senha original.

## Solução

Mantenha um número de entradas de hashes de senha maiores que o número de vezes que a execução da funcionalidade de alteração de senha é permitida e valide que o novo hash de senha não seja uma dessas entradas.