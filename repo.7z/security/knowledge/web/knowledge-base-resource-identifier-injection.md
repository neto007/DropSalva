---
title: Injeção do Identificador de Recursos
---
## Descrição

Uma injeção de identificador de recurso significa basicamente que o invasor pode determinar qual recursos são carregados no aplicativo da web.
Um invasor pode, portanto, influenciar a operação do aplicativo Web e redirecionar usuários
para outros sites. Esse ataque consiste em alterar os identificadores de recursos usados ​​por um aplicação para executar uma tarefa maliciosa. Quando um aplicativo permite que um usuário entrada para definir um recurso, como um nome de arquivo ou número de porta,
esses dados podem ser manipulados para executar ou acessar diferentes recursos.
Para ser executado corretamente, o invasor deve ter a possibilidade de especificar um
identificador de recurso através do formulário de inscrição e a inscrição deve permitir a execução.

O tipo de recurso afetado pela entrada do usuário indica o tipo de conteúdo que pode ser exposto. Por exemplo, um aplicativo que permite a inserção de caracteres especiais como ponto, barra, e a folga é arriscada quando usada em métodos que interagem com o sistema de arquivos. O ataque de injeção de recursos se concentra no acesso a outros recursos além do local sistema de arquivos, que é uma técnica de ataque diferente, conhecida como ataque de manipulação de caminho.

## Solução

O uso seguro de identificadores de recursos pode ser feito executando verificações de autorização se o identificador pertence ao usuário.