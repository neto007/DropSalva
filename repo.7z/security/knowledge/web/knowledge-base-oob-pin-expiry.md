---
title: Expiração do PIN OOB
---
## Descrição

Se um aplicativo permitir ao usuário tentar autenticação fora de banda após um intervalo de tempo definido, aumentará a chance de um invasor reproduzir uma chave de autenticação válida fora de banda após comprometer a sessão com êxito.

## Solução

A solução mais eficaz é rejeitar tentativas de autenticação fora de banda após 10 minutos e também garantir que a chave de autenticação fora de banda possa ser usada apenas uma vez.