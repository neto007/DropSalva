---
title: Escalação de privilégios
---
## Descrição

Os invasores com baixos direitos de acesso sempre tentarão elevar seus privilégios para obter informações/funcionalidades mais sensíveis à sua disposição. Isso pode ser alcançado, por exemplo:

 - Funções que não conseguem verificar a autorização
 - Funções/serviços comprometidos executados com privilégios mais altos
 - Contas de usuário comprometidas com privilégios mais altos

Esses exemplos apenas arranham a superfície do que os invasores tentam para elevar seus privilégios em seu aplicativo/sistema. Portanto, é muito importante levar em consideração essa recomendação.

## Solução

A verificação se um usuário tem autorização suficiente para executar determinada solicitação deve sempre ser aplicada no lado do servidor. Além disso, você pode aplicar o privilégio Princípio do mínimo, o princípio do menor privilégio recomenda que as contas tenham a menor quantidade de privilégios necessária para executar seus processos de negócios. Isso abrange direitos do usuário, permissões de recursos, como limites de CPU, memória, rede e permissões do sistema de arquivos. Por exemplo, se um usuário requer apenas acesso à rede, acesso de leitura a uma tabela de banco de dados e capacidade de gravar em um log, isso descreve todas as permissões que devem ser concedidas. Sob nenhuma circunstância o usuário deve receber privilégios administrativos.