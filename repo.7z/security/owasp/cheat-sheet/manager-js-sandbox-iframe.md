---
title: Sandbox com iframe
---

Você também pode colocar o JavaScript do fornecedor em um iframe de domínio diferente (por exemplo, host de dados estáticos). Ele funcionará como uma "prisão" e o JavaScript do fornecedor não terá acesso direto ao DOM e aos cookies da página do host.

A página principal do host e o iframe da sandbox podem se comunicar por meio do mecanismo postMessage .

Além disso, os iframes podem ser protegidos com o atributo iframe sandbox .

Para aplicativos de alto risco, considere o uso de Política de Segurança de Conteúdo (CSP) , além do sandbox de iframe. O CSP torna a proteção contra XSS ainda mais forte.

```js

<!-- Some host, e.g. somehost.com, HTML code here -->
 <html>
   <head></head>
     <body>
       ...
       <!-- Include iframe with 3rd party vendor javascript -->
       <iframe
       src="https://somehost-static.net/analytics.html"
       sandbox="allow-same-origin allow-scripts">
       </iframe>
   </body>
 </html>

<!-- somehost-static.net/analytics.html -->
 <html>
   <head></head>
     <body>
       ...
       <script>
       window.addEventListener("message", receiveMessage, false);
       function receiveMessage(event) {
         if (event.origin !== "https://somehost.com:443") {
           return;
         } else {
          // Make some DOM here and initialize other
          //data required for 3rd party code
         }
       }
       </script>
       <!-- 3rd party vendor javascript -->
       <script src="https://analytics.vendor.com/v1.1/script.js"></script>
       <!-- /3rd party vendor javascript -->
   </body>
 </html>
```

### Contenção de iframe virtual

Essa técnica cria iframes que são executados de forma assíncrona em relação à página principal. Ele também fornece seu próprio JavaScript de contenção que automatiza a implementação dinâmica dos iframes protegidos com base nos requisitos de tag de marketing.

### Contratos de fornecedor

Você pode ter o acordo ou solicitação de proposta com terceiros para exigir evidências de que eles implementaram codificação segura e segurança geral de acesso ao servidor corporativo. Mas, em particular, você precisa determinar o monitoramento e o controle de seu código-fonte para prevenir e detectar alterações maliciosas nesse JavaScript.


### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)