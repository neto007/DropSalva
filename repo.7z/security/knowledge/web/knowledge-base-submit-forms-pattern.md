---
title: Enviar padrão de formulários
---
## Descrição

Sempre que um usuário enviar um formulário em seu sistema, você deve considerar a implementação o seguinte mecanismo de defesa para garantir a segurança de alto nível.

1. Controles de validação de entrada de usuário único e registros de auditoria
2. Tokens CSRF
3. Princípio do menor privilégio
4. Solicitações GET/POST

## Solução

Aqui estão as etapas descritas resumidamente.
Para obter informações mais detalhadas, você deve examinar esses itens na base de conhecimento.

- Primeiro, você deve criar uma única classe de controle de validação de entrada do usuário que deve validar os valores de entrada esperados para verificar se o usuário não está adulterando os dados ou está injetando código malicioso em seu aplicativo. Todas as infrações devem ser registradas e deve haver investigações sempre que essas infrações forem frequentes.

- Em segundo lugar, sempre que um usuário autenticado estiver enviando o formulário, certifique-se de que os formulários contenham tokens CSRF para evitar falsificação de solicitação entre sites.

- Terceiro, sempre que houver usuários autenticados com funções/privilégios diferentes, você deve impor restrições no lado do servidor no envio/processamento de seus formulários para evitar o aumento de privilégios. Você deve aplicar o princípio do menor privilégio para garantir um nível mais alto de segurança.

- Quarto, sempre que o aplicativo estiver enviando dados confidenciais por meio do formulário submit, esses dados devem ser sempre enviados por meio de uma variável POST em vez de GET, pois um GET vazará esses dados pela URL, por exemplo, o referrer header (no português, cabeçalho do referenciador).
