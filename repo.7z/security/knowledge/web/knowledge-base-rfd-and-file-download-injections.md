---
title: Injeções de download de arquivos
---
## Descrição

O download reflexivo do arquivo ocorre sempre que um invasor pode "forjar" um download por configuração incorreta nos cabeçalhos "disposição" e "tipo de conteúdo". Em vez de fazer com que o invasor carregue um arquivo inválido no servidor da Web, ele pode agora forçar o navegador a baixar um arquivo malicioso, abusando desses cabeçalhos e definindo a extensão do arquivo para o tipo que ele desejar.

Agora, sempre que houver também a entrada do usuário refletida no download, ela poderá ser usada para forjar ataques malignos. O invasor pode apresentar um arquivo maligno para as vítimas ignorantes que confiam no domínio em que o download foi apresentado.

A injeção de download de arquivo é um tipo semelhante de ataque, exceto que esse ataque é possível sempre que houver entrada do usuário refletida no parâmetro "filename =" no cabeçalho "disposição". O atacante novamente pode forçar o navegador a baixar um arquivo com sua própria escolha de extensão e definir o conteúdo desse arquivo injetando-o diretamente na resposta como filename = evil.bat% 0A% 0D% 0A% 0DinsertEvilStringHere

Sempre que o usuário abre o arquivo baixado, o atacante pode obter controle total sobre o dispositivo do alvo.


## Solução

Primeiro, nunca use a entrada do usuário diretamente em seus cabeçalhos, pois agora um invasor pode assumir o controle.

Em segundo lugar, você deve verificar se um nome de arquivo realmente existe antes de apresentá-lo aos usuários. Você também pode criar uma lista de permissões de todos os arquivos que podem ser baixados e encerrar solicitações sempre que não corresponderem.

Além disso, você deve desativar o uso de "parâmetros de caminho". Aumenta o vetor de ataque do invasor e esses parâmetros também causam muitas outras vulnerabilidades.
E por último, você deve limpar e codificar todas as suas entradas do usuário, tanto quanto possível. Os downloads de arquivos refletivos dependem da entrada do usuário refletida no cabeçalho da resposta. Sempre que essa entrada tiver sido higienizada e codificada, ela não deverá prejudicar nenhum sistema em que esteja sendo executada.