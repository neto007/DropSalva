---
title: Infraestrutura como código
---
## Descrição

Infraestrutura como código (IaC) é o processo de gerenciamento e provisionamento de 
aplicativos e infra-estrutura por meio de arquivos de definição legíveis por máquina,
em vez de configuração de hardware físico ou ferramentas de configuração interativas


## Solução

Verifique se os processos de criação e implantação de aplicativos são executados
de maneira segura e repetível, como automação de CI/CD,
gerenciamento de configuração automatizado e scripts de implantação automatizados.

Ao fazer isso, sua implantação de infraestrutura e aplicativos também se torna imutável
e é mais fácil de corrigir e manter. Além disso, ter seu provisionamento
do aplicativo/infraestrutura como código também significa que ele possui controle de versão
e outros benefícios importantes de ter um sistema de controle de versão em vigor.

Outros grandes benefícios são:

- Velocidade e simplicidade: 
  - O IaC permite criar uma arquitetura de infraestrutura inteira executando um script.
  
- Consistência de configuração:
  - Os procedimentos operacionais padrão podem ajudar a manter alguma consistência no processo de implantação da infraestrutura

- Reversão rápida:
  - Quando um erro ou paz de código vulnerável é enviado para um ambiente de produção com o IaC, é fácil reverter para uma versão estável/segura.
