---
title: Spamming automatizado através de scripts de feedback
---
## Descrição

Um hacker não deve ter a capacidade de explorar da funcionalidade de email de uma aplicação por meios de scripts que disparam emails de spam automatizados.

## Solução

Esse problema pode ser evitado com a implementação de CAPTCHA ou mecanismos de limitação de frequência (rate-limit).