---
title: Implementar Autenticação 2Fa
---
## Descrição

Para verificar se o usuário é quem ele afirma ser, a fim de recuperar uma senha esquecida, um mecanismo de autenticação de dois fatores deve ser implementado.

## Solução

Para verificar a senha esquecida e outros caminhos de recuperação, use um TOTP (Time Based One Time Password) como o autenticador do Google ou outro token virtual, envio móvel ou outro mecanismo de recuperação offline.