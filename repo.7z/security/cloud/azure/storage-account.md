---
title: Azure Storage Account
sidebar_label: Storage Account
---

**Proposta de melhores práticas de segurança para o uso de Storage Account na Azure:**

O objetivo desse documento é descrevermos as melhores práticas de configuração dos storage accounts nas assinaturas da Azure.

## Recomendações

**Gerenciamento de identidade e acesso**
- Garantir que o acesso público de usuários anônimos em containers e blobs esteja desabilitado. Qualquer necessidade de exceção deverá ser comunicada ao time de NetSec em Segurança da Informação através de chamado no Taylor;
- Garantir a regra do menor privilegio nos acessos aos recursos do Storage Account;
- Recomendado a centralização de acessos ao storage account através de contas do Active Directory;
- Recomendado que o uso do “Shared Key Authorization” esteja desabilitado no Storage Account;
- Em caso de necessidade do uso do Shared Key Authorization o time de NetSec em Segurança da Informação deverá ser comunicado através de chamado no Taylor;
- Garantir que no caso de uso de chaves de acesso, as mesmas estarão armazenadas no Azure Key Vault com as devidas configurações de acesso e segurança aplicadas;
- Recomendado a troca das chaves de acesso dentro do prazo de 365 dias;  
        
**Redes**
- Garantir que o storage account será criado como privado, onde toda exceção deverá ser aprovada previamente pela equipe de Segurança da Informação;
- Se aprovado o acesso público, o storage account deverá estar protegido por WAF com objetivo de detectar/bloquear acessos de IP maliciosos;
- Garantir que o firewall de storage account esteja habilitado concedendo acesso somente as redes autorizadas;
- Garantir que a opção **“Secure Transfer required”** esteja habilitada;
- Garantir o uso da versão mais atualizada do TLS para criptografar na comunicação com os clientes;
- Recomendado o uso de private endpoint para comunicação com o storage account através de redes internas;           
        
**Monitoração**
- Garantir que o Azure storage Logging esteja habilitado para registro dos logs de acesso;  
        
**Data Protection**
- Recomendado o de uso de ferramentas para scan do conteúdo e identificação de dados sensíveis;
- Recomendado o tageamento do storage account em caso de armazenamento de dados sensíveis;
- Em caso de armazenamento de dado sensível, respeitar a todas as regras de restrição como limitar o acesso somente para recursos específicos, bloquear a comunicação externa, limitar o controle de acesso, criptografar os dados “in transit” e “at rest”, etc;
- Recomendado o uso do recurso da configuração de “Immutable Blob Storage” quando armazenado dados críticos que não podem ser apagados dentro de um período e que também não possam ser modificados.

## Políticas de prevenção e detecção

Abaixo alguns campos para correta configuração do storage account. Os itens destacados já estão aplicados junto as polices de prevenção.

![Políticas de prevenção e detecção](/assets/security/cloud/azure-storage-account.png)
