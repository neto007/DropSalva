---
title: Senhas em hash, aleatórias e longas
---
## Descrição

Verifique se as senhas da conta são hash e se existe um fator suficiente
para derrotar ataques de força bruta e recuperação de hash de senha.

## Solução

Recomendadas para uso de senha são as funções PBKDF. PBKDF2 usa uma função pseudo-aleatória e um número configurável de iterações para derivar uma chave criptográfica de uma senha. Como esse processo é difícil de reverter (semelhante a uma função hash criptográfica) mas também pode ser configurado para ser lento na computação, as funções de derivação de chave são idealmente adequado para casos de uso de hash de senha.

Outra alternativa seria bcrypt. Bcrypt é uma função de hash de senha criada por
Niels Provos e David Mazières, baseados na cifra Blowfish, e apresentados na USENIX em
1999. Além de incorporar um 'random' para proteger contra os ataques da mesa do arco-íris(Rainbow Table), o bcrypt é uma função adaptativa: com o tempo, a contagem de iterações pode ser aumentada para torná-la mais lenta, portanto, permanece resistente a ataques de busca por força bruta, mesmo com o aumento do poder computacional.
