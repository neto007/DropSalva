---
title: Padrão De Sessões
---
## Descrição

Ao trabalhar com sessões, há algumas coisas que você precisa considerar para implementá-las com segurança em todo o sistema. Para obter informações mais detalhadas sobre esses itens, você deve verificar a base de conhecimento sobre:

1. Controle de gerenciamento de sessão
2. Cookies de sessão sem o sinalizador Seguro
3. Cookies de sessão sem o sinalizador HTTP Only
4. Roubo de sessão externa
5. Transmissão insegura de cookies de sessão
6. As informações da sessão não são armazenadas no lado do servidor
7. Os ids de sessão devem ser gerados com entropia suficiente, o método preferido é a implementação do controle de gerenciamento de sessão padrão do framework é usado pelo aplicativo
8. Os IDs de sessão gerados pelo usuário devem ser rejeitados pelo servidor
9. A funcionalidade de logout deve revogar a sessão completa
10. A funcionalidade de login deve sempre gerar (e usar) um novo id de sessão
11. Os IDs de sessão não expiram. (Inativo)
12. Sessão absoluta expirou
13. Verifique se o id da sessão nunca é divulgado
14. Cookies de sessão (domínio)

## Solução

Os itens apontados antes devem ser analisados ​​e levados em consideração
sempre que você estiver trabalhando com sessões em seu sistema, a fim de impor um
alto nível de segurança. Embora existam mais de dez padrões de design relacionados à sessão, todos eles precisam ser implementados. Se qualquer um for deixado de fora para implementação, toda a camada de gerenciamento de sessão não é segura e pode ser derrotada por invasores.