---
title: Considerações ao usar vários cookies
---


Se o aplicativo da web usa cookies como o mecanismo de troca de ID de sessão e vários cookies são definidos para uma determinada sessão, o aplicativo da web deve verificar todos os cookies (e impor relacionamentos entre eles) antes de permitir o acesso à sessão do usuário.

É muito comum que os aplicativos da web configurem uma pré-autenticação de cookie do usuário sobre HTTP para rastrear usuários não autenticados (ou anônimos). Depois que o usuário se autentica no aplicativo da web, um novo cookie seguro pós-autenticação é definido por HTTPS e uma ligação entre os cookies e a sessão do usuário é estabelecida. Se o aplicativo da web não verificar os dois cookies para sessões autenticadas, um invasor pode usar o cookie desprotegido de pré-autenticação para obter acesso à sessão de usuário autenticado (veja aqui e aqui ).

Os aplicativos da Web devem tentar evitar o mesmo nome de cookie para diferentes caminhos ou escopos de domínio no mesmo aplicativo da Web, pois isso aumenta a complexidade da solução e potencialmente introduz problemas de escopo.

### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)