---
title: Perda de controle sobre as alterações no aplicativo cliente
---

Esse risco surge do fato de que geralmente não há garantia de que o código hospedado no terceiro permanecerá o mesmo visto pelos desenvolvedores e testadores: novos recursos podem ser colocados no código de terceiros a qualquer momento, portanto, potencialmente quebrar a interface ou fluxos de dados e expor a disponibilidade de seu aplicativo para seus usuários / clientes.

As defesas típicas incluem, mas não estão restritas a: espelhamento de script interno (para evitar alterações por terceiros), integridade de sub-recursos (para permitir a interceptação no nível do navegador) e transmissão segura do código de terceiros (para evitar modificações enquanto em trânsito). Veja abaixo para mais detalhes.

### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)