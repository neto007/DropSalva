---
title: Prevenção de falsificação de solicitações do servidor
---

O objetivo da folha de dicas é fornecer conselhos sobre a proteção contra ataques Server Side Request Forgery (SSRF).

Esta folha de dicas enfocará o ponto de vista defensivo e não explicará como realizar este ataque. Esta palestra do pesquisador de segurança Orange Tsai , bem como este documento, fornecem técnicas sobre como realizar esse tipo de ataque.

### Contexto

SSRF é um vetor de ataque que abusa de um aplicativo para interagir com a rede interna / externa ou a própria máquina. Um dos capacitadores desse vetor é o manuseio incorreto de URLs, conforme mostrado nos exemplos a seguir:

Imagem em servidor externo ( por exemplo, o usuário insere o URL da imagem de seu avatar para o aplicativo baixar e usar).
WebHook personalizado (o usuário deve especificar manipuladores de WebHook ou URLs de retorno de chamada).
Solicitações internas para interagir com outro serviço para atender a uma determinada funcionalidade. Na maioria das vezes, os dados do usuário são enviados para serem processados ​​e, se mal tratados, podem realizar certos ataques de injeção.


### Visão geral de um fluxo comum SSRF

![Fluxo SSRF](/assets/devsecops/owasp/server_side_request_forgery_prevention_ssrf_common_flow.png)


**Notas:**

- SSRF não se limita ao protocolo HTTP, apesar do fato de que, em geral, a primeira solicitação o aproveita, mas a segunda solicitação é realizada pelo próprio aplicativo e, portanto, pode estar usando diferentes protocolos ( por exemplo , FTP, SMB, SMTP, etc. ) e esquemas ( por exemplo file:// , phar://, gopher://, data://, dict://, etc.). O uso do protocolo / esquema é altamente dependente dos requisitos do aplicativo.

- Se o aplicativo for vulnerável à injeção de XML eXternal Entity (XXE), então ele pode ser explorado para realizar um ataque SSRF , dê uma olhada na folha de dicas do XXE para aprender como prevenir a exposição ao XXE.


### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)