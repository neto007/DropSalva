---
title: Políticas para dados sensíveis
---
## Descrição

Ao processar dados, você sempre deve impor políticas para a transferência de dados confidenciais, a fim de impor um nível mais alto de segurança, impondo limites estruturados para afastar os invasores.

## Solução

Primeiro, você deve criar uma lista que contenha locais onde todos os dados confidenciais sejam usados ​​e processados. Em seguida, você cria uma política que informa quem é permitido e até que ponto eles têm privilégios para analisar quais dados. Quando esses dados são movidos pela rede, eles sempre devem ser criptografados (TLS) e também armazenados em criptografia. Posteriormente, você deve estabelecer métodos de monitoramento e teste para verificar se tudo permanece criptografado e se suas políticas são aplicadas corretamente.

Além disso, determine sempre que o armazenamento de dados for necessário ou se tornar uma redundância. Sempre que os dados confidenciais não precisarem ser armazenados, não os armazene. Isso reduz a quantidade de dados que seu aplicativo pode ser comprometido.
Por fim, verifique se o acesso aos dados confidenciais está registrado, se os dados são coletados sob as diretivas relevantes de proteção de dados ou onde o registro de acessos é necessário. Dados sensíveis ou chaves primárias, como informações de identificação pessoal ou cartões de crédito, também devem ser anonimizados, mascarados ou truncados no servidor antes da transmissão ao cliente.