module.exports = {
    type: "category",
    label: "Code Sight",
    items: [
        "chapters/security/devsecops/synopsys/codesight/synopsys-polaris-visualcode",
        "chapters/security/devsecops/synopsys/codesight/synopsys-polaris-visualstudio",
    ],
};