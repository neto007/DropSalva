---
title: Injeção XXE
---
## Descrição

O processamento de uma Entidade Xml eXternal contendo dados corrompidos pode levar à divulgação de informações confidenciais e outros impactos no sistema. O padrão XML 1.0 define a estrutura de um documento XML. A norma define um conceito denominado entidade, que é uma unidade de armazenamento de algum tipo.

Existe um tipo específico de entidade, uma entidade externa geral analisada frequentemente encurtada a uma entidade externa, que pode acessar conteúdo local ou remoto por meio de um sistema declarado identificador e o processador XML podem divulgar informações confidenciais normalmente não acessível pelo aplicativo. Os ataques podem incluir a divulgação de arquivos locais, que podem contêm dados confidenciais, como senhas ou dados privados do usuário.

## Solução

Desative a possibilidade de buscar recursos de uma fonte externa.
Isso normalmente é feito na configuração do analisador XML usado.