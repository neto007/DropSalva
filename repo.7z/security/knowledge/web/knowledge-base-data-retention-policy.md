---
title: Política de retenção de dados
---
## Descrição

Para todos os dados coletados em um aplicativo, deve-se configurar uma política de retenção de dados para garantir que todos os dados sejam removidos do aplicativo quando não forem mais usados. Isso reduz o dano causado por invasores em potencial quando eles obtêm acesso aos dados do aplicativo devido a uma violação.

## Solução

Todas as informações confidenciais no aplicativo devem ser mapeadas junto com o
prazo é necessário armazenar esses dados no aplicativo. Para cada conjunto de dados,
deve-se determinar como efetivamente limpar essas informações do aplicativo.