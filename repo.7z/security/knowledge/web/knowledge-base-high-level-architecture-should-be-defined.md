---
title: Arquitetura de alto nível
---
## Descrição

Sempre que estiver desenvolvendo um aplicativo, você deseja mapear toda a arquitetura que ele contém. Sempre que há violações, atualizações ou outras escalações, fica fácil e transparente para forense, operadores e desenvolvedores realizarem seu trabalho o mais rápido possível.

## Solução

Verifique se uma arquitetura de alto nível para o aplicativo foi definida. Isso significa que algum tipo de assinatura técnica precisa ser composta dessa arquitetura e de todos os elementos que ela fornece. Isso fornece uma representação visual do seu aplicativo e facilita o trabalho.

Enquanto estiver mapeando sua arquitetura de aplicativo, você também deve adicionar todos os outros componentes que seu aplicativo contém em termos de funções de negócios e/ou funções de segurança que eles fornecem.

Quando você mapeia esses componentes, ele se torna mais transparente sobre os diferentes tipos de atenuação de segurança que podem ser esquecidos para algumas de suas funções de negócios. Porque, novamente, você agora possui uma representação visual dessa lógica. Seu aplicativo também se torna mais gerenciável em termos de atualizações e patches de segurança mais recentes e oferece uma visão melhor das configurações, funções e componentes obsoletos que podem ser removidos do sistema. Isso, é claro, também se aplica a todos os componentes externos dos quais seu aplicativo depende.