---
title:  Redirecionamentos de URL seguros
---

Quando queremos redirecionar um usuário automaticamente para outra página (sem uma ação do visitante, como clicar em um hiperlink), você pode implementar um código como o seguinte:

Java

`response.sendRedirect("http://www.mysite.com");`

PHP

```php
<?php
header("Location: http://www.mysite.com");
exit;
?>
```

ASP .NET

`Response.Redirect("~/folder/Login.aspx")`

Rails

`redirect_to login_path`
