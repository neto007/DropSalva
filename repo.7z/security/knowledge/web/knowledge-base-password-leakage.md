---
title: Vazamento de senha
---
## Descrição

Após concluir a funcionalidade de recuperação de senha, o usuário não deve receber uma senha em texto sem formatação no endereço de email. O aplicativo também não deve, em circunstância alguma, divulgar a senha antiga ou atual aos usuários.

## Solução

O aplicativo não deve, em circunstância alguma, divulgar aos usuários o texto atual, antigo e novo da senha. Esse comportamento torna o aplicativo suscetível a ataques de canal lateral e faz com que as senhas percam sua integridade, pois podem ser comprometidas por alguém olhando por cima do ombro de outros usuários para ver a senha.