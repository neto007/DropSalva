---
title: Log implementado no lado do servidor
---
## Descrição

O registro sempre deve ser implementado no lado do servidor, pois um invasor manipula a funcionalidade e apaga seus rastreamentos.

## Solução

Verifique se todos os controles de log estão implementados no lado do servidor.