---
title: Validação no lado do servidor
---
## Descrição

A validação da entrada fornecida pelo usuário deve sempre ser aplicada no lado do servidor.
Sempre que a validação da entrada está sendo realizada no lado do cliente,
as restrições podem ser facilmente contornadas sempre que um invasor usa um proxy de interceptação que ele pode usar para adulterar dados depois de serem validados e enviá-los ao servidor. Ou o invasor pode simplesmente alterar a restrição do lado do cliente em seu navegador para contornar as restrições.

## Solução

Toda validação de entrada deve ser tratada no lado do servidor. Sempre que a validação é tratada do lado do servidor, a lógica de validação está fora do escopo do invasor e ele não pode influenciar os resultados.

>Nota: A validação da entrada nunca deve ser feita com uma abordagem de lista negra, pois os invasores podem ser muito bacana em contornar esse tipo de restrições. Sempre execute verificações de validação de lista branca, de preferência em combinação na verificação de tipo. ou seja, se o aplicativo espera que o valor seja um inteiro, não faça o aplicativo aceitar o valor de uma string. Esta entrada deve ser registrada e rejeitada.