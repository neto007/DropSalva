---
title: Controle de acesso para GraphQL
---

Para garantir que uma API GraphQL tenha controle de acesso adequado, faça o seguinte:

* Sempre valide se o solicitante está autorizado a visualizar ou alterar/modificar os dados que está solicitando. Isso pode ser feito com RBAC ou outros mecanismos de controle de acesso.
* Imponha verificações de autorização nas bordas e nos nós.
* Use Interfaces e Unions para criar tipos de dados estruturados e hierárquicos que podem ser usados ​​para retornar mais ou menos propriedades do objeto, de acordo com as permissões do solicitante.
* Os resolvedores de consulta e mutação podem ser usados ​​para executar a validação de controle de acesso, possivelmente usando algum middleware RBAC.
* Desative as consultas de introspecção em todo o sistema em qualquer produção ou ambientes de acesso público.
* Desative GraphiQL e outras ferramentas de exploração de esquema semelhantes em ambientes de produção ou acessíveis ao público.