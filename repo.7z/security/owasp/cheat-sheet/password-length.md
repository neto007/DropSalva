---
title: Comprimento máximo da senha
---

Alguns algoritmos de hash, como Bcrypt, têm um comprimento máximo para a entrada, que é de 72 caracteres para a maioria das implementações (há alguns relatórios de que outras implementações têm comprimentos máximos mais baixos, mas nenhum foi identificado no momento da escrita). Onde Bcrypt é usado, um comprimento máximo de 64 caracteres deve ser aplicado na entrada, pois isso fornece um limite suficientemente alto, enquanto ainda permite problemas de terminação de string e não revela que o aplicativo usa Bcrypt.

Além disso, devido ao quão caro são computacionalmente as funções de hashing modernas, se um usuário pode fornecer senhas muito longas, então há uma vulnerabilidade de negação de serviço potencial, como a publicada no Django em 2013.

A fim de se proteger contra esses dois problemas, um comprimento máximo de senha deve ser aplicado. Deve ter 64 caracteres para Bcrypt (devido a limitações no algoritmo e nas implementações) e entre 64 e 128 caracteres para outros algoritmos.

Embora a implementação de um comprimento máximo de senha reduza o espaço de chave possível para senhas, um limite de 64 caracteres ainda deixa um espaço de chave de pelo menos `2^420`, o que é completamente inviável para um invasor quebrar. Como tal, não representa uma redução significativa na segurança.

## Senhas de pré-hash
Uma abordagem alternativa é fazer o pré-hash da senha fornecida pelo usuário com um algoritmo rápido como SHA-256 e, em seguida, fazer o hash do hash resultante com um algoritmo mais seguro como Bcrypt (isto é, `bcrypt(sha256($password))`). Embora essa abordagem resolve o problema de entradas de usuário de comprimento arbitrário para algoritmos de hash mais lentos, ela também apresenta algumas vulnerabilidades que podem permitir que invasores quebrem hashes mais facilmente.

Se um invasor conseguir obter hashes de senha de dois sites comprometidos diferentes, um dos quais está armazenando senhas com `bcrypt(sha256($password))` e o outro as está armazenando como simples `sha256($password)`, e o invasor pode usar hashes SHA-256 não quebradas do segundo site como senhas candidatas para tentar quebrar os hashes do primeiro site (mais seguro). Se as senhas forem reutilizadas entre os dois sites, isso pode permitir que o invasor remova a camada Bcrypt e concentre seus esforços em quebrar os hashes SHA-256, muito mais fáceis.

Ao usar o pré-hash, certifique-se de que a saída do primeiro algoritmo de hash seja codificada com segurança como hexadecimal ou base64, pois alguns algoritmos de hash como Bcrypt podem se comportar de maneiras indesejáveis ​​se a entrada contiver bytes nulos. Devido a esses problemas, a opção preferida geralmente deve ser limitar o comprimento máximo da senha. O pré-hash de senhas deve ser executado apenas onde houver um requisito específico para fazê-lo e as etapas apropriadas tiverem sido executadas para mitigar os problemas discutidos acima.