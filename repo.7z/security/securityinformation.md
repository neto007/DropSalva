---
slug: './'
id: informationSecurity
title: Desenvolvimento Seguro
sidebar_label: Introdução
---

## Descrição

Base de conhecimento sobre assuntos relacionados a segurança da informação.
Conteúdos que irão axiliar a todos com as melhores práticas de segurança da informação, dicas e consientização sobre alguns riscos que podemos correr caso essas práticas não sejam seguidas.

## Estrutura

Nossa estrutura na comunidade XP está definida da seguinte maneira:

* __Base de conhecimento__
    * Onde descrevemos algumas vulnerabilidades cohecidas e possíveis soluções.
* __Exemplos de códigos__
    * Aqui somos mais objetivos e demonstramos apenas exemplos de códigos que podem ser utilizados, como referência para auxiliar a implementação de algum mecanismo de segurança em algumas linguagens de programação específicas.
* __DevSecOps__
    * Nesta parte você poderá conhecer ainda melhor alguns de nossos procedimentos e como realizamos algumas análises específicas para que fique ainda mais transparente nossos processos. 
* __Labs__
    * Nessa aba adicionamos containers que possuem aplicações com vulnerabilidades. A ideia é que você adiquira conhecimento com exploração de vulnerabilidade. Pois uma vez entendendo o processo de exploração fica mais fácil a assimilação de como podemos nos proteger e evitar vulnerabilidades futuras.
    
## Objetivo

Nosso objetivo é desenvolver o pensamento crítico voltado a segurança da informação descrevendo os dois lados da moeda, como um atacante enxerga uma oportunidade de ataque e o que podemos fazer para nos previnir.

## Contato

Se interessou, quer trocar uma idéia, aprender mais sobre este mundo, dúvidas, sugestões, pode entrar em contato com **DevSecOps** (devsecops@xpi.com.br). Em breve teremos mais conteúdos! \o/
