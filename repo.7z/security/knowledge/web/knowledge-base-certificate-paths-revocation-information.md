---
title: Revogação de certificado
---

## Descrição

Sempre que sua autoridade de certificação não é mais confiável, você sempre deve poder revogar esses certificados o mais rápido possível para evitar ataques intermediários aos usuários de seus aplicativos.

## Solução

O laço de confiança para uma determinada zona é encontrada no arquivo "[nome da zona + valor da chave]". Este arquivo é criado automaticamente como parte do processo de assinatura. Uma lista de revogação de certificado (CRL) é uma lista criada e assinada por uma autoridade de certificação (CA), que contém o número de série dos certificados que foram emitidos por essa CA e atualmente são revogados. Além do número de série do
certificações revogadas, a CRL também contém o motivo da revogação de cada certificado
e a hora em que o certificado foi revogado. O número de série para cada certificado revogado é mantido no banco de dados das CAs e publicados na CRL até o vencimento do certificado.

Após a expiração do certificado revogado, a entrada de certificados na CRL é removida e
a CA pode remover o certificado do banco de dados. Normalmente, o certificado revogado
permanecerá na CRL por um período de publicação após a expiração do certificado. Por todas as vezes, você deve ter essas informações ao alcance para realizar ações rápidas.
