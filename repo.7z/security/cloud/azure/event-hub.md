---
title: Azure Event Hub
sidebar_label: Event Hub
---

**Proposta de melhores práticas de segurança para o uso do Event Hub na Azure:**
  
O Azure Event Hub é uma plataforma de streaming de Big Data e serviço de ingestão de eventos. Ele pode receber e processar milhões de eventos por segundo. Os dados enviados para um Event Hub podem ser transformados e armazenados usando qualquer provedor de análise em tempo real ou batching/storage adapters.

O objetivo desse documento é descrevermos as melhores práticas de configuração do Event Hub nas assinaturas da Azure.

## Recomendações

**Gerenciamento de identidade e acesso**
- É recomendado a utilização do *Azure Active Directory* para concessão de acessos. Autorizar usuários ou aplicativos usando um token OAuth 2.0 retornado pelo Azure AD oferece segurança e facilidade de uso superior ao SAS (Shared Access Signature);
- Seguindo o conceito de _menor privilégio_ é recomendado que o acesso ao Event Hub seja concedido apenas ao recurso e escopo necessário. Exemplo: Se uma aplicação necessita de acesso para envio de dados em um único Event Hub você não deve conceder o acesso a aplicação de Data Owner com permissão no Event Hub Namespace;
- Não recomendamos o uso do SAS para concessão de acesso devido aos seguintes motivos:
- Caso ocorra o vazamento de um SAS, ele pode ser usado por qualquer pessoa que o obtiver, o que pode comprometer os recursos do Event Hub;
- Se um SAS fornecido a um aplicativo cliente expirar e o aplicativo não for capaz de recuperar um novo SAS para seu serviço, a funcionalidade do aplicativo pode ser prejudicada;
- Caso não existam alternativas e a utilização do SAS seja necessária, temos as seguintes recomendações:
- Todos os clientes devem ter a capacidade de renovação do SAS automaticamente;
- Conceder acesso apenas a role específica no recurso específico que precisará ser acessado;
- Restringir a comunicação com o Event Hub para redes específicas;
- Sempre utilizar HTTPS. 

**Redes**
- Não permitir o uso do Event Hub do tipo **Basic**, pois esse tipo de recurso não tem a possibilidade de uso de firewall para controle de acesso;  
- Não permitir o acesso público ao Event Hub. Toda exceção deve ser aprovada previamente pela equipe de Segurança da Informação;  
- Limitar a exposição do Event Hub somente para redes que precisem deste acesso (utilizando Private Endpoint ou Service Endpoint);  
- Recomendado o uso de private endpoint para comunicação com Event Hub através de redes internas.        

**Monitoração**
- Habilitar o log do Azure Event Hub para garantir o registro das operações no Event Hub;
- Habilitar o Diagnostics Logs, isso permite recriar trilhas de atividades para fins de investigação quando ocorre um incidente de segurança ou quando a rede é comprometida.
        
**Proteção de dados**
- Recomendado a identificação dos Event Hub que tratam informações sensíveis com o uso de TAGs;
- Recomendado o isolamento dos Event Hubs que tratam informações sensíveis, por exemplo, com o uso de Service Endpoints;
- Recomendado a criptografia dos dados em repouso no Event Hub com uso de CMKs (Customer-Managed keys).    

**Configurações de segurança**
- Para máquinas virtuais ou Web Apps do Azure App Service e que são utilizados para acessar o Event Hub, recomendados o uso do Managed Identity Service em conjunto com o Azure Key Vault para simplificar e proteger o gerenciamento de SAS nas implantações de Event Hub.

## Políticas de prevenção e detecção
Abaixo alguns campos para correta configuração do Event Hub. Os itens destacados já estão aplicados com as polices de prevenção.

![Políticas de prevenção e detecção](/assets/security/cloud/azure-event-hub.png)

- [Azure security baseline for Event Hubs - Azure Event Hubs](https://docs.microsoft.com/en-us/azure/event-hubs/security-baseline)
- [Azure Policy Regulatory Compliance controls for Azure Event Hubs - Azure Event Hubs](https://docs.microsoft.com/en-us/azure/event-hubs/security-controls-policy)
- [Network security for Azure Event Hubs - Azure Event Hubs](https://docs.microsoft.com/en-us/azure/event-hubs/network-security)
- [Authorize access to Azure Event Hubs - Azure Event Hubs](https://docs.microsoft.com/en-us/azure/event-hubs/authorize-access-event-hubs)
- [Authentication a managed identity with Azure Active Directory - Azure Event Hubs](https://docs.microsoft.com/en-us/azure/event-hubs/authenticate-managed-identity?tabs=latest)
- [Authenticate access to Azure Event Hubs with shared access signatures - Azure Event Hubs](https://docs.microsoft.com/en-us/azure/event-hubs/authenticate-shared-access-signature)
- [Built-in policy definitions for Azure Event Hubs - Azure Event Hubs](https://docs.microsoft.com/en-us/azure/event-hubs/policy-reference)
- [Configure your own key for encrypting Azure Event Hubs data at rest - Azure Event Hubs](https://docs.microsoft.com/en-us/azure/event-hubs/configure-customer-managed-key)
