---
title: Politica estrita - Content-security Police (CSP)
---

A função de uma política rígida é proteger contra ataques clássicos armazenados, refletidos e alguns dos ataques XSS DOM e deve ser o objetivo ideal de qualquer equipe que esteja tentando implementar CSP. O Google foi em frente e criou um guia para adotar um CSP estrito baseado em nonces. Com base em uma apresentação no LocoMocoSec, as duas políticas a seguir podem ser usadas para aplicar uma política rígida:

Política restrita moderada:
```
script-src 'nonce-r4nd0m' 'strict-dynamic';
object-src 'none'; base-uri 'none';
```

Política restrita bloqueada:
```
script-src 'nonce-r4nd0m';
object-src 'none'; base-uri 'none';
```