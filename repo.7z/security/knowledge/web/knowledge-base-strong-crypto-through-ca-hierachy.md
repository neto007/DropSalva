---
title: Criptografia forte por meio de hierarquia de CA
---
## Descrição

Quando você tem uma configuração de PKI offline, você precisa ter camadas de criptografia sólidas e fortes. Um invasor irá procurar cadeias fracas na hierarquia e abusar delas quando encontrado. Isso pode levar a ataques Man-In-The-Middle (MITM) e impactar os 3 pilares de segurança C.I.A (Confidencialidade, Integridade e Disponibilidade).

## Solução

Verifique se apenas algoritmos, cifras e protocolos fortes são usados, em toda a hierarquia de certificados, incluindo certificados raiz e intermediários da autoridade de certificação selecionada.Porque isso está sempre em fluxo, nós recomendamos utilizar:

* Teste grátis SSLlabs https://www.ssllabs.com/ssltest/
* OWASP OSAFT: https://www.owasp.org/index.php/O-Saft

Essas recomendações de proteção TLS podem então ser aplicadas em todos os servidores.