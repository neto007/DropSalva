---
title: Componentes De Aplicativo Assinados
---
## Descrição

Quando um aplicativo não usa componentes assinados, um invasor pode facilmente modificar as partes da aplicação e injetar carga em backdoors. Além disso, o invasor pode
modificar a lógica de negócios no aplicativo sem aviso prévio. Aplicativo assinado
componentes podem ajudar a proteger seu aplicativo e torná-lo perceptível quando um invasor tenta modificar o código.

## Solução

Crie para os diferentes componentes nas assinaturas assinadas do aplicativo e verifique-as em
o aplicativo no início do aplicativo e no nível de tempo de execução.