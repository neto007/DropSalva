---
title: Scripts dinâmicos não analisados acessíveis
---
## Descrição

Os aplicativos geralmente incluem arquivos em outras páginas. Quando esses arquivos podem ser diretamente abordado por usuários normais, a operação do aplicativo pode ser rastreada porque o código fonte fica disponível. Isso aumenta a possibilidade do  atacante descobrir vulnerabilidades.


## Solução

Sempre adicione os diferentes tipos de extensões ao manipulador do servidor web para analisar. Dessa forma, a fonte do arquivo não pode ser visualizada.
Também é altamente recomendável que os arquivos antigos sejam removidos do servidor e não armazenados - ou feito backup como, por exemplo, "file.php.old".