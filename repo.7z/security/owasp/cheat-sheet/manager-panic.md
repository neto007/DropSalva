---
title: Modos de pânico
---

Modo de pânico é um modo ao qual os usuários ameaçados podem se referir quando estão sob ameaça direta para divulgar as credenciais da conta.

Oferecer aos usuários a capacidade de criar um modo de pânico pode ajudá-los a sobreviver a essas ameaças, especialmente em regiões tumultuadas ao redor do mundo. Infelizmente, muitos usuários em todo o mundo estão sujeitos a tipos de ameaças que a maioria dos desenvolvedores da Web não conhece ou leva em consideração.

Exemplos de modos de pânico são modos em que usuários angustiados podem excluir seus dados sob ameaça, entrar em caixas de entrada / contas / sistemas falsos ou invocar gatilhos para fazer backup / upload / ocultar dados confidenciais.

O modo de pânico apropriado para implementar difere dependendo do tipo de aplicativo. Um software de criptografia de disco, como o `VeraCrypt`, pode implementar um modo de pânico que inicia uma partição de sistema falsa se o usuário inserir sua senha incorreta.

Os provedores de e-mail podem implementar um modo de pânico que oculta e-mails ou contatos confidenciais predefinidos, permitindo a leitura apenas de mensagens de e-mail inocentes, geralmente conforme definido pelo usuário, enquanto evita que o modo de pânico tome conta da conta real.

Uma observação importante sobre os modos de pânico é que eles não devem ser facilmente descobertos, se é que são. Um adversário dentro do estado de pânico da vítima não deve ter nenhuma maneira, ou o mínimo de possibilidades possível, de descobrir a verdade. Isso significa que, uma vez dentro do modo de pânico, a maioria das operações normais não sensíveis deve continuar (como enviar ou receber e-mail), e que outros modos de pânico devem ser criados a partir do modo de pânico original (se o adversário tentou para criar um modo de pânico no modo de pânico da vítima e falhar, o adversário saberia que já estava em modo de pânico e poderia tentar ferir a vítima).

Outra solução seria evitar a geração de modos de pânico a partir da conta do usuário e, em vez disso, dificultar um pouco a falsificação por parte dos adversários. Por exemplo, ele só poderia ser criado fora da banda, e os adversários não devem ter como saber que um modo de pânico já existe para essa conta específica.

A implementação de um modo de pânico deve sempre ter como objetivo confundir os adversários e impedi-los de chegar às contas reais / dados confidenciais da vítima, bem como prevenir a descoberta de quaisquer modos de pânico existentes para uma conta em particular.

Para obter mais detalhes sobre o modo de sistema operacional oculto do `VeraCrypt`, consulte:

- [Sistema operacional VeraCrypt](https://www.veracrypt.fr/en/Hidden%20Operating%20System.html)


### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)

```

```