---
title: Desenho impróprio de Autenticadores 2Fa
---
## Descrição

No caso de aplicações web usando apenas autenticadores biométricos, ou usá-los em primeiro lugar, não é uma prática recomendada de segurança.
Solicitar e validar dados (como senhas) precisa ser a primeira camada da parte de autenticação e, em seguida, em segundo lugar os autenticadores biométricos podem ser empregados.

## Solução

Verifique se os autenticadores biométricos estão limitados ao uso apenas como fatores secundários em conjunto com algo que o usuário possui e algo que ele conhece.
