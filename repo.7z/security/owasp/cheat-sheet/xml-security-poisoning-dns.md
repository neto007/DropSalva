---
title: Evenenamento DNS
---

O envenenamento de esquema remoto também pode ser possível, mesmo ao usar protocolos criptografados como` Hypertext Transfer Protocol Secure (HTTPS)`. Quando o software executa a resolução reversa do Sistema de Nome de Domínio (DNS) em um endereço IP para obter o nome do host, ele pode não garantir adequadamente que o endereço IP esteja realmente associado ao nome do host. Nesse caso, o software permite que um invasor redirecione o conteúdo para seus próprios endereços de protocolo de Internet (IP).

O exemplo fez referência ao host `example.com ` usando um protocolo não criptografado.

Ao mudar para HTTPS, a localização do esquema remoto será semelhante a `https://example/note.dtd`. Em um cenário normal, o IP de `example.com` resolve para `1.1.1.1`:


```bash

$ host example.com
example.com has address 1.1.1.1

```
Se um invasor compromete o DNS que está sendo usado, o nome do host anterior agora pode apontar para um novo IP diferente controlado pelo invasor `2.2.2.2`:

```bash
$ host example.com
example.com has address 2.2.2.2
```

Ao acessar o arquivo remoto, a vítima pode, na verdade, estar recuperando o conteúdo de um local controlado por um invasor.

## Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/cheatsheets/XML_Security_Cheat_Sheet.html)