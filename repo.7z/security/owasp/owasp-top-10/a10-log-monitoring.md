---
title: A10 Insufficient log and monitoring
---

## A Aplicação é Vulnerável?
Insuficiência do registo, deteção, monitorização e resposta acontece sempre que:

* Eventos auditáveis como autenticação, autenticações falhadas e transações de valor relevante não são registados
* Alertas e erros não são registados, ou geram mensagens desadequadas ou insuficientes.
* Registos das aplicações e APIs não são monitorizados para deteção de atividade suspeita.
* Registos são armazenados localmente.
* Limites para geração de alertas e processos de elevação de resposta não estão definidos ou não são eficazes.
* Testes de intrusão e verificações por ferramentas DAST (e.g. OWASP ZAP) não geram alertas.
* A aplicação é incapaz de detetar, lidar com ou alertar em tempo real ou quase-real para ataques em curso. Está ainda vulnerável à fuga de informação se tornar os registos e alertas visíveis para os utilizadores ou atacantes (ver A3:2017-Exposição de Dados Sensíveis).

## Exemplos de Cenários de Ataque

#### Cenário #1: 
Um projeto de código aberto de um forum mantido por uma equipa pequena foi comprometido, abusando duma vulnerabilidade do próprio software. Os atacantes conseguiram ter acesso ao repositório interno onde estava o código da próxima versão assim com todos os conteúdos. Embora o código fonte possa ser recuperado, a falta de monitorização, registo e alarmística tornam o incidente mais grave. O projeto foi abandonado em consequência deste incidente.
#### Cenário #2: 
Um atacante usa uma ferramenta automática para testar o uso de uma palavra-passe comum por forma a ganhar controlo sobre as contas que usam essa password. Para as outras contas esta operação deixa apenas registo duma tentativa de autenticação falhada, podendo ser repetida dias depois com outra palavra-passe.

#### Cenário #3: 
Um dos principais retalhistas dos Estados Unidos tinha internamente um ferramenta para análise de anexos para identificação de malware. Esta ferramenta detetou uma ocorrência mas ninguém atuou mesmo quando sucessivos alertas continuaram a ser gerados. Mais tarde a falha viria a ser identificada em consequência de transações fraudulentas.

## Como Prevenir
Dependendo do risco inerente à informação armazenada ou processada pela aplicação:

* Assegurar que todas as autenticações, falhas no controlo de acessos e falhas na validação de dados de entrada no servidor são registados com detalhe suficiente do contexto do utilizador que permita identificar contas suspeitas ou maliciosas e mantidos por tempo suficiente que permita a análise forense.
* Assegurar que os registos usam um formato que possa ser facilmente consumido por uma solução de gestão de registos centralizada.
* Assegurar que as transações mais críticas têm registo pormenorizado para auditoria com controlos de integridade para prevenir adulteração ou remoção tais como tabelas de base de dados que permitam apenas adição de novos registos.
* Definir processos de monitorização e alerta capazes de detetar atividade suspeita e resposta atempada
* Definir e adotar uma metodologia de resposta a incidentes e plano de recuperação tal como NIST 800-61 rev 2. Existem frameworks comerciais e de código aberto para proteção de aplicações (e.g. OWASP App Sensor), Web Application Firewalls (WAF) (e.g. ModSecurity with the OWASP ModSecurity Core Rule Set ) assim como ferramentas de análise de registos e alarmística.