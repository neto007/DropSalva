---
title: Evitar pré-preenchimento de senha
---
## Descrição

As senhas nunca devem ser armazenadas em texto simples ou em um formato reversível no aplicativo. Sempre que um invasor invade o banco de dados SQL dos aplicativos, as senhas são diretamente comprometidas. No caso de formulários pré-preenchidos no aplicativo, um invasor também pode seqüestrar as credenciais por regras CORS mal configuradas ou ataques XSS.

## Solução

Verifique se os formulários que contêm credenciais não são preenchidos pelo aplicativo. O preenchimento prévio pelo aplicativo implica que as credenciais sejam armazenadas em texto sem formatação ou em um formato reversível, explicitamente proibido. As senhas devem ser armazenadas de preferência por funções PBKDF.

O PBKDF2 usa uma função pseudo-aleatória e um número configurável de iterações para derivar uma chave criptográfica de uma senha. Como esse processo é difícil de reverter (semelhante a uma função de hash criptográfico), mas também pode ser configurado para ser lento na computação, as funções de derivação de chave são ideais para casos de uso de hash de senha.

Exemplos de boas maneiras de armazenar senhas são: BCRYPT, Blowfish ou, em alguns casos, SCRYPT, que é um pouco mais difícil de implementar corretamente

>NOTA: O pré-preenchimento de senha também acontece ao usar o gerenciador de senhas do navegador. No entanto, esse processo é diferente do contexto descrito acima, pois a descrição acima implica em um aplicativo que preenche credenciais do banco de dados / armazenamento local / etc.