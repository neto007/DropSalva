const knowledge = require('./knowledge/sidebars')
const codeExample = require('./code-examples/sidebars')
const devsecops = require('./devsecops/sidebars')
const labs = require('./labs/sidebars')
const owasp = require('./owasp/sidebars')
const cloud = require('./cloud/sidebars')

module.exports = {
  type: "category",
  label: "Segurança da Informação",
  items: [
    "chapters/security/informationSecurity",
    knowledge,
    cloud,
    codeExample,
    labs,
    owasp,
    devsecops
  ],
};
