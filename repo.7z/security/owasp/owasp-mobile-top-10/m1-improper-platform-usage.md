---
title: Improper Platform Usage
---

## O aplicativo está vulnerável?

A característica definidora dos riscos nesta categoria é que a plataforma (iOS, Android, Windows Phone, etc.) fornece um recurso ou capacidade que é documentado e bem compreendido. O aplicativo não consegue usar esse recurso ou o usa incorretamente. Isso difere de outros dez principais riscos para dispositivos móveis porque o design e a implementação não são problemas estritamente do desenvolvedor do aplicativo.

Existem várias maneiras pelas quais os aplicativos móveis podem enfrentar esse risco.

#### Violação das diretrizes publicadas. 
Todas as plataformas possuem diretrizes de desenvolvimento para segurança (c.f., ((Android)), ((iOS)), ((Windows Phone))). Se um aplicativo contradizer as melhores práticas recomendadas pelo fabricante, ele estará exposto a esse risco. Por exemplo, existem diretrizes sobre como usar o iOS Keychain ou como proteger serviços exportados no Android. Aplicativos que não seguem essas diretrizes apresentam esse risco.

#### Violação de convenção ou prática comum. 
Nem todas as práticas recomendadas são codificadas nas orientações do fabricante. Em alguns casos, existem práticas recomendadas de fato que são comuns em aplicativos móveis.

#### Uso incorreto não intencional. 
Alguns aplicativos pretendem fazer a coisa certa, mas na verdade erram em alguma parte da implementação. Isso pode ser um bug simples, como definir o sinalizador errado em uma chamada de API, ou pode ser um mal-entendido de como as proteções funcionam.

Falhas nos modelos de permissão da plataforma se enquadram nesta categoria. Por exemplo, se o aplicativo solicitar muitas permissões ou as permissões erradas, é melhor categorizar aqui.

## Cenários de exemplo de ataques
Como existem várias plataformas, cada uma com centenas ou milhares de APIs, os exemplos nesta seção apenas arranham a superfície do que é possível.

Armazenamento local de aplicativo em vez de "keychain". O "keychain" é um recurso de armazenamento seguro para dados de aplicativo e sistema. No iOS, os aplicativos devem usá-lo para armazenar quaisquer pequenos dados que tenham significado de segurança (chaves de sessão, senhas, dados de registro do dispositivo, etc.). Um erro comum é armazenar esses itens no armazenamento local do aplicativo. Os dados armazenados no armazenamento local do aplicativo estão disponíveis em backups não criptografados do iTunes (por exemplo, no computador do usuário). Para alguns aplicativos, essa exposição é inadequada.

## Como prevenir
As práticas de codificação e configuração seguras devem ser usadas no lado do servidor do aplicativo móvel. Para obter informações específicas sobre vulnerabilidades, consulte os projetos OWASP Web Top Ten ou Cloud Top Ten.

