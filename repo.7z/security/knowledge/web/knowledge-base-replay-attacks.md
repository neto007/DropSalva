---
title: Ataques de repetição
---
## Descrição
Um ataque de reprodução (também conhecido como ataque de reprodução) é uma forma de ataque na qual uma transmissão de dados válida é repetida ou atrasada de maneira maliciosa ou fraudulenta. Isso é realizado pelo remetente ou por um adversário que intercepta os dados e os retransmite. Esta é uma das versões de nível mais baixo de um "ataque do homem do meio".

## Solução
Os ataques de reprodução podem ser evitados marcando cada componente criptografado com um ID de sessão e um número de componente. O uso dessa combinação de soluções não utiliza nada que seja interdependente entre si. Como não há interdependência, há menos vulnerabilidades. Isso funciona porque um único, o ID da sessão aleatória é criado para cada execução do programa, portanto, uma execução anterior se torna mais difícil de replicar. Nesse caso, um invasor não conseguiria executar a repetição porque, em uma nova execução, o ID da sessão teria mudado