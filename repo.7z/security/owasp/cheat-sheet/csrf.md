---
title: Cross-Site Request Forgery (CSRF)
---

**Cross-Site Request Forgery (CSRF)** é um tipo de ataque que ocorre quando um site, e-mail, blog, mensagem instantânea ou programa malicioso faz com que o navegador de um usuário execute uma ação indesejada em um site confiável quando o usuário é autenticado. Um ataque CSRF funciona porque as solicitações do navegador incluem automaticamente todos os cookies, incluindo cookies de sessão. Portanto, se o usuário for autenticado no site, o site não poderá distinguir entre solicitações legítimas e solicitações falsas.

O impacto de um ataque CSRF bem-sucedido é limitado aos recursos expostos pelo aplicativo vulnerável e aos privilégios do usuário. Por exemplo, esse ataque pode resultar em uma transferência de fundos, alteração de senha ou compra com as credenciais do usuário. Com efeito, os ataques CSRF são usados ​​por um invasor para fazer um sistema alvo executar uma função por meio do navegador da vítima, sem o conhecimento da vítima, pelo menos até que a transação não autorizada seja realizada.

Em suma, os seguintes princípios devem ser seguidos para se defender contra CSRF:

- Verifique se sua estrutura tem proteção CSRF integrada e use-a
- Se o framework não tiver proteção CSRF integrada, adicione tokens CSRF a todas as solicitações de mudança de estado (solicitações que causam ações no site) e valide-as no backend
- Sempre use o atributo de cookie SameSite para cookies de sessão
- Implementar pelo menos uma mitigação da seção Defesa em Mitigações de Profundidade
- Use cabeçalhos de solicitação personalizados
- Verifique a origem com cabeçalhos padrão
- Use cookies de envio duplo
- Considere a implementação de proteção baseada na interação do usuário para operações altamente confidenciais
- Lembre-se de que qualquer Cross-Site Scripting (XSS) pode ser usado para derrotar todas as técnicas de mitigação de CSRF!
- Não use solicitações GET para operações de mudança de estado.
- Se por algum motivo você fizer isso, você também deve proteger esses recursos contra CSRF

### Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/)