---
title: Gerenciamento de dependência vulnerável
---

O objetivo desta abordagem quanto ao tratamento de dependências de terceiros vulneráveis ​​quando são detectadas, e isso, dependendo da situação diferente.

A folha de dicas não é orientada a ferramentas, mas contém uma seção de ferramentas informando o leitor sobre soluções gratuitas e comerciais que podem ser usadas para detectar dependências vulneráveis, dependendo do nível de suporte nas tecnologias disponíveis

**Nota:**

As propostas mencionadas nesta folha de dicas não são balas de prata (receitas que funcionam em todas as situações), mas podem ser usadas como base e adaptadas ao seu contexto.

### Contexto

A maioria dos projetos usa dependências de terceiros para delegar a manipulação de diferentes tipos de operações, por exemplo , geração de documento em um formato específico, comunicações HTTP, análise de dados de um formato específico, etc.

É uma boa abordagem porque permite que a equipe de desenvolvimento se concentre no código do aplicativo real que oferece suporte ao recurso de negócios esperado. A dependência traz uma desvantagem esperada em que a postura de segurança do aplicativo real agora repousa sobre ele.

Este aspecto é referenciado nos seguintes projetos:

- OWASP TOP 10 2017 sob o ponto A9 - Usando componentes com vulnerabilidades conhecidas.

- Projeto padrão de verificação de segurança de aplicativos OWASP na seção V14.2 Dependência.

Com base neste contexto, é importante para um projeto garantir que todas as dependências de terceiros implementadas estejam isentas de qualquer problema de segurança e, se acontecer de conter qualquer problema de segurança, a equipe de desenvolvimento precisa estar ciente disso e aplicar o necessário medidas de mitigação para proteger a aplicação afetada.

É altamente recomendável realizar análises automatizadas das dependências desde o nascimento do projeto. Na verdade, se essa tarefa for adicionada no meio ou no final do projeto, pode implicar em uma enorme quantidade de trabalho para lidar com todos os problemas identificados e que, por sua vez, imporá uma enorme carga à equipe de desenvolvimento e poderá bloquear o avanço de o projeto em questão.

**Nota:**

No restante da folha de dicas, quando nos referimos à equipe de desenvolvimento , presumimos que a equipe contém um membro com as habilidades de segurança de aplicativo necessárias ou pode se referir a alguém na empresa com esse tipo de habilidade para analisar a vulnerabilidade que afeta a dependência.

### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/cheatsheets/Vulnerable_Dependency_Management_Cheat_Sheet.html)
