---
title: Segurança da camada de transporte
---

Para proteger a troca de ID de sessão de espionagem ativa e divulgação passiva no tráfego de rede, é essencial usar uma conexão HTTPS (TLS) criptografada para toda a sessão da web, não apenas para o processo de autenticação onde as credenciais do usuário são trocadas.

Além disso, o Secure atributo cookie deve ser usado para garantir que o ID da sessão seja trocado apenas por meio de um canal criptografado. O uso de um canal de comunicação criptografado também protege a sessão contra alguns ataques de fixação de sessão onde o invasor é capaz de interceptar e manipular o tráfego da web para injetar (ou corrigir) o ID da sessão no navegador da vítima (veja aqui e aqui ).

O seguinte conjunto de práticas recomendadas concentra-se em proteger a ID da sessão (especificamente quando cookies são usados) e ajudar na integração de HTTPS dentro do aplicativo da web:

Não mude uma determinada sessão de HTTP para HTTPS, ou vice-versa, pois isso revelará o ID da sessão de forma clara através da rede.
Ao redirecionar para HTTPS, certifique-se de que o cookie seja definido ou gerado novamente após o redirecionamento.
Não misture conteúdos criptografados e não criptografados (páginas HTML, imagens, CSS, arquivos JavaScript, etc.) na mesma página ou do mesmo domínio.
Sempre que possível, evite oferecer conteúdo público não criptografado e conteúdo privado criptografado do mesmo host. Onde for necessário conteúdo não seguro, considere hospedá-lo em um domínio não seguro separado.
Implemente HTTP Strict Transport Security (HSTS) para impor conexões HTTPS.
Consulte a Folha de Dicas de Proteção da Camada de Transporte OWASP para obter orientações mais gerais sobre como implementar TLS com segurança.

É importante enfatizar que o TLS não protege contra predição de ID de sessão, força bruta, violação ou fixação do lado do cliente; no entanto, ele fornece proteção eficaz contra um invasor que intercepta ou rouba IDs de sessão por meio de um ataque intermediário.



### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)