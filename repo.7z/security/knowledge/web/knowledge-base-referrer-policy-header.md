---
title: Cabeçalho da política de referência
---
## Descrição
Solicitações feitas a partir de um documento e para navegações fora desse documento
estão associados a um cabeçalho de referência. Embora o cabeçalho possa ser suprimido por
links com o tipo de link noreferrer, os autores podem querer controlar o Referer
cabeçalho mais diretamente por várias razões,

- Privacidade
Um site de rede social tem uma página de perfil para cada um de seus usuários,
e os usuários adicionam hiperlinks da página de perfil às bandas favoritas.
O site de rede social pode não querer vazar o URL do perfil do usuário
aos sites da banda quando outros usuários seguem esses hiperlinks
(porque os URLs do perfil podem revelar a identidade do proprietário do perfil).

Alguns sites de redes sociais, no entanto, podem querer informar os sites da banda que
os links originados no site de redes sociais, mas não revelam quais
o perfil do usuário continha os links.

- Segurança
Um aplicativo Web usa HTTPS e um identificador de sessão baseado em URL. O aplicativo da web pode deseja vincular a recursos HTTPS em outros sites sem vazar a sessão do usuário
identificador no URL.

Como alternativa, um aplicativo Web pode usar URLs que garantem alguma capacidade.
Controlar o referenciador pode ajudar a impedir que esses URLs de capacidade vazem por
cabeçalhos de referência.

Observe que existem outras maneiras de vazar URLs de capacidade e controlar
o referenciador não é suficiente para controlar todos esses possíveis vazamentos.

- Rastrear
Um blog hospedado em HTTPS pode desejar vincular a um blog hospedado em HTTP e
receber links de trackback.

## Solução

Para mais informações sobre a política e como ela deve ser implementada, favor
visite o seguinte link

https://www.w3.org/TR/referrer-policy/#referrer-policies