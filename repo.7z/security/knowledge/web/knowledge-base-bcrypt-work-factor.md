---
title: Fator de trabalho do Bcrypt
---

## Descrição
O interessante do bcrypt é que você pode ajustar seu fator de trabalho para combater o processamento computacional, para que seja muito lento a força bruta em comparação com um MD5/SHA/CRC que são extremamente rápidos para calcular. Quando o bcrypt foi introduzido, o fator de custo era 6 para usuários normais e 8 para superusuários. Provavelmente, você está apenas usando o fator de custo padrão de criptografia. 
O Bcrypt-ruby e a maioria das outras implementações definem isso para 10, o que significa 2^10 rodadas de expansão principais. Com os avanços na tecnologia de computação, é altamente recomendável ajustar o custo do fator de trabalho periodicamente para combater ataques de força bruta.