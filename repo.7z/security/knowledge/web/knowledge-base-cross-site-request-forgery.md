---
title: Cross-Site Request Forgery (CSRF)
---
## Descrição

Cross-Site Request Forgery (CSRF) é um tipo de ataque que ocorre quando um site mal-intencionado, email, blog, mensagem instantânea ou programa faz com que o navegador da Web de um usuário execute uma ação indesejada, ação em um site confiável para o qual o usuário está atualmente autenticado.

O impacto de um ataque bem-sucedido de CSRF entre sites é limitado ao recursos expostos pelo aplicativo vulnerável. Por exemplo, esse ataque pode resultar em em uma transferência de fundos, alterando uma senha ou comprando um item no contexto de usuários. De fato, os ataques de CSRF são usados ​​por um invasor para fazer com que um sistema de destino execute uma (transferência de fundos, envio de formulários etc.) através do navegador de destinos sem conhecimento do usuário de destino pelo menos até que a função não autorizada seja confirmada.

## Solução

Para proteger um aplicativo contra ataques e ferramentas automatizados, você precisa usar tokens exclusivos que estão incluídos nos formulários de um aplicativo, chamadas de API ou solicitações AJAX. Qualquer operação de alteração de estado requer um token aleatório seguro (por exemplo, token CSRF), contra ataques CSRF. As características de um token CSRF são um token grande e aleatório valor gerado por um gerador de números aleatórios criptograficamente seguro.

O token CSRF é então adicionado como um campo oculto para formulários e validado no lado do servidor sempre que necessário quando um usuário está enviando uma solicitação ao servidor.

Nota :

Sempre que o aplicativo for um serviço REST e estiver usando tokens, como tokens JWT, sempre que esses tokens estiverem sendo enviados nos cabeçalhos do aplicativo, em vez de armazenados nos cookies, o aplicativo não deve ser suspeito de ataques de CSRF, pois um ataque de CSRF bem-sucedido depende do pote de cookies do navegador.