---
title: Inclua um Cabeçalho de Segurança Estrito
---
## Descrição


A Segurança de Tranporte Estrito HTTP (Strict-Transport-Security - HSTS) aplica conexões seguras (HTTP sobre SSL / TLS) ao servidor. Isso reduz o impacto de bugs em aplicativos da Web que vazam dados da sessão através de cookies e links externos e defende de ataques do tipo "homem no meio" (man-in-the-middle). HSTS também desativa a capacidade do usuário ignorar avisos de negociação SSL.

## Solução

Esses cabeçalhos também são conhecidos como: Strict-Transport-Security: max-age = 16070400:
includeSubDomains e fornecem proteção contra ataques de faixa SSL quando implementados no
aplicativo ou servidor web.

Ao conectar-se a um host HSTS pela primeira vez, o navegador não saberá se deve ou não
usar uma conexão segura, porque nunca recebeu um cabeçalho HSTS desse host.
Conseqüentemente, um invasor de rede ativo pode impedir que o navegador se conecte
com segurança (e pior ainda, o usuário pode nunca perceber que algo está errado). Para mitigar este ataque, você pode adicionar seu aplicativo a uma lista de pré-carregamento que torna o HSTS imposto por padrão. Quando um usuário se conecta a um desses hosts pela primeira vez, o navegador saberá que ele deve usar uma conexão segura. Se um invasor de rede impedir conexões seguras com o servidor, o navegador não tentará se conectar através de um protocolo inseguro, mantendo a segurança do usuário.

Visita:
    https://hstspreload.appspot.com/
Aqui você encontra como adicionar seu aplicativo ao pré-carregamento do HSTS

