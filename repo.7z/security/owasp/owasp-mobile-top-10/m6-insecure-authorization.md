---
title: Insecure Authorization
---

## O aplicativo está vulnerável?
É importante reconhecer a diferença entre autenticação e autorização. A autenticação é o ato de identificar um indivíduo. Autorização é o ato de verificar se o indivíduo identificado possui as permissões necessárias para a prática do ato. Os dois estão intimamente relacionados, já que as verificações de autorização devem sempre seguir imediatamente a autenticação de uma solicitação de entrada de um dispositivo móvel.

Se uma organização falhar na autenticação e no indivíduo antes de executar um endpoint de API solicitado de um dispositivo móvel, o código também sofrerá automaticamente de autorização insegura. É essencialmente impossível que ocorram verificações de autorização em uma solicitação de entrada quando a identidade do chamador não é estabelecida.

Existem algumas regras fáceis a seguir ao tentar determinar se um endpoint móvel está sofrendo de autorização não segura:

Presença de vulnerabilidades de Insecure Direct Object Reference (IDOR) - Se você estiver vendo uma Vulnerabilidade de Insecure Direct Object Reference (IDOR), o código provavelmente não está executando uma verificação de autorização válida; e
Pontos de extremidade ocultos - normalmente, os desenvolvedores não realizam verificações de autorização na funcionalidade oculta do back-end, pois presumem que a funcionalidade oculta só será vista por alguém na função certa;
Transmissões de função ou permissão do usuário - se o aplicativo móvel estiver transmitindo as funções ou permissões do usuário para um sistema de back-end como parte de uma solicitação, ele está sofrendo de autorização insegura.

## Cenários de exemplo de ataques

#### Cenário #1 - Referência Insegura de Objeto Direto:
Um usuário faz uma solicitação de terminal de API para uma API REST de backend que inclui um ID de ator e um token de portador oAuth. O usuário inclui seu ID de ator como parte da URL de entrada e inclui o token de acesso como um cabeçalho padrão na solicitação. O back-end verifica a presença do token do portador, mas não consegue validar o ID do ator associado ao token do portador. Como resultado, o usuário pode ajustar o ID do ator e obter informações da conta de outros usuários como parte da solicitação da API REST.

#### Cenário #2 - Transmissão de funções LDAP:
Um usuário faz uma solicitação de terminal de API para uma API REST de backend que inclui um token de portador oAuth padrão junto com um cabeçalho que inclui uma lista de grupos LDAP aos quais o usuário pertence. A solicitação de back-end valida o token do portador e, em seguida, inspeciona os grupos LDAP de entrada para a associação de grupo correta antes de continuar com a funcionalidade confidencial. No entanto, o sistema de backend não executa uma validação independente da associação ao grupo LDAP e, em vez disso, depende das informações de entrada do LDAP vindas do usuário. O usuário pode ajustar o cabeçalho de entrada e relatar para ser um membro de qualquer grupo LDAP arbitrariamente e executar a funcionalidade administrativa.

## Como prevenir
Para evitar verificações de autorização inseguras, faça o seguinte:

Verifique as funções e permissões do usuário autenticado usando apenas as informações contidas nos sistemas backend. Evite confiar em quaisquer funções ou informações de permissão provenientes do próprio dispositivo móvel;
O código de back-end deve verificar de forma independente se quaisquer identificadores de entrada associados a uma solicitação (operandos de uma operação solicitada) que vêm junto com a identificação correspondem e pertencem à identidade de entrada;
