---
title: A funcionalidade de logout deve revogar a sessão completa
---
## Descrição

Quando a funcionalidade de logout não revoga a sessão completa, um invasor ainda pode
representar um usuário quando ele tiver acesso ao cookie da sessão, mesmo depois que o usuário fizer logoff do aplicativo.

## Solução

A funcionalidade de logout deve revogar a sessão completa sempre que um usuário
deseja encerrar sua sessão.

Cada framework tem seu próprio guia para conseguir essa revogação.
Também é recomendado que você faça casos de teste que você siga para garantir
revogação da sessão em sua aplicação.