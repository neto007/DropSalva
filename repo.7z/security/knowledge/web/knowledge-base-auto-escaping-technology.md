---
title: Tecnologia de escape automático
---
## Descrição

Algumas estruturas/modelos têm a opção de escapar automaticamente todas as entradas do usuário (dados codificados inofensivos) para evitar ataques. No entanto, essa funcionalidade de escape automático pode ser opcionalmente desativado. Sempre que essa função de escape automático for desativada, sua aplicação pode estar vulnerável a ataques como o XSS (https://owasp.org/www-community/attacks/xss/).

## Solução

Sempre que a funcionalidade de escape automático em seu aplicativo for desativada por qualquer motivo, você deve garantir que exista outra proteção, como a sanitização do HTML para impedir que os invasores injetem código malicioso na aplicação.