---
title: Gerenciar ID de sessão como qualquer outra entrada do usuário
---


Os IDs de sessão devem ser considerados não confiáveis, como qualquer outra entrada do usuário processada pelo aplicativo da web, e devem ser totalmente validados e verificados. Dependendo do mecanismo de gerenciamento de sessão utilizado, o ID da sessão será recebido em um parâmetro GET ou POST, na URL ou em um cabeçalho HTTP (por exemplo, cookies). Se os aplicativos da web não validarem e filtrarem os valores de ID de sessão inválidos antes de processá-los, eles podem ser potencialmente usados ​​para explorar outras vulnerabilidades da web, como injeção de SQL se os IDs de sessão forem armazenados em um banco de dados relacional ou XSS persistente se os IDs de sessão são armazenados e refletidos posteriormente pelo aplicativo da web.


### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)