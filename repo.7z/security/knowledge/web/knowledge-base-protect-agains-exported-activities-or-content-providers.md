---
title: Proteger contra exportação de conteúdo
---
## Descrição

Sempre que a entrada das intenções das atividades exportadas ou do conteúdo fornecido não for devidamente validada essa entrada pode potencialmente explorar vulnerabilidades no aplicativo móvel, dependendo da o contexto em que a entrada está sendo usada.

## Solução

A contribuição de atividades, intenções ou provedores de conteúdo exportados deve ser validada a operação pretendida do aplicativo, ou seja, se o aplicativo espera um campo com um valor inteiro, todos os outros dados recebidos que funcionam com esta operação pretendida devem ser registrados e rejeitados pelo aplicativo.