---
title: Autenticação
---

## O que é?

**A autenticação** é o processo de verificar se um indivíduo, entidade ou site é quem afirma ser. A autenticação no contexto de aplicativos da web é comumente realizada enviando um nome de usuário ou ID e um ou mais itens de informações privadas que apenas um determinado usuário deve saber.

**Gerenciamento de sessão** é um processo pelo qual um servidor mantém o estado de uma entidade interagindo com ele. Isso é necessário para que um servidor se lembre de como reagir às solicitações subsequentes durante uma transação. As sessões são mantidas no servidor por um identificador de sessão que pode ser transmitido entre o cliente e o servidor ao transmitir e receber solicitações. As sessões devem ser exclusivas por usuário e muito difíceis de prever do ponto de vista computacional. A página de [Gerenciamento de Sessão](manager-session-intro) contém mais orientações sobre as melhores práticas nesta área.