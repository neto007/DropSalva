---
title: Exposição de informações confidenciais em URL
---
## Descrição

Se a lógica do aplicativo transmitir IDs de sessão na URL, seus valores podem vazar através do cabeçalho Referer para sites de terceiros, registrados por servidores proxy, marcados no navegador, enviados acidentalmente por e-mail ou bate-papo.
Sempre que o ID da sessão é divulgado no URL, também pode haver a possibilidade de realizar outros ataques (como fixação de sessão) que levam ao sequestro de sessão.

## Solução

Os tokens de sessão nunca devem ser incluídos em locais diferentes do cabeçalho do Cookie do aplicativo ou de outros cabeçalhos personalizados definidos pelo aplicativo.