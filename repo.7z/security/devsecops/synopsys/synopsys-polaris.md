---
title: Synopsys – Ferramenta de SAST (Static Application Security Testing)
sidebar_label: Ferramenta Synopsys 
---

#### O que é SAST?

SAST em Português é um acrônimo para Teste Estático de Segurança de Aplicação (Código fonte).

#### Qual ferramenta de SAST a XP Possui?

Atualmente dentro do processo de build a XP utiliza a ferramenta Fortify, mas ela será descontinuada no mês de Maio e será substituída pelo Synopsys.

#### Qual a diferença entre Fortify e Synopsys?

A ferramenta da Synopsys apresenta melhores resultados em tempo de processamento (salvo exceções), redução de falsos-positivos e possui workflow de indicação de falso-positivo sem a necessidade de abertura de chamado no Taylor para a equipe de DevSecOps.
Diante disto, esclarecemos abaixo como utilizar e configurar o seu projeto. 

## Como acessar ?

Para acesso ao Synopsys utilize a seguinte URL com seu usuário e senha da Rede:

Link para acesso: [Home | Polaris Software Integrity Platform](https://xpinvestimentos.polaris.synopsys.com/home)

![Página inicial:](/assets/devsecops/synopsys/portal/03.png)

Na guia “Projects” você encontrará todos os projetos aos quais você tem acesso:

![Projects-Synopsys](/assets/devsecops/synopsys/portal/04.png)

Caso não esteja aparecendo nenhum projeto para você, entre em contato com Claudio Silva (claudio.silva@xpi.com.br) ou com o Salvador Dilio (salvador.dilio@xpi.com.br) para que possam verificar o seu acesso.

Não conseguiu acesso, solicite conforme abaixo.

## Solicitando acesso

Utilizar a oferta de [Solicitação acesso a sistema - Funcionário - Portal de Serviços do Grupo XP (service-now.com)](https://xpinvestimentos.service-now.com/sp?id=sc_cat_item&sys_id=def00a11dbc09810392a32ffaa9619c3) e preencher conforme exemplo a seguir:

![Service-now](/assets/devsecops/synopsys/portal/02.png)

## Avaliando as vulnerabilidades encontradas

Clicando no nome o seu projeto você irá verificar os detalhes, como o histórico do resultado dos scans realizados, quantidades de vulnerabilidades abertas:

![app-Synopsys](/assets/devsecops/synopsys/portal/05.png)

Na guia de Issues, irá encontrar a lista com o detalhe de todas as vulnerabilidades encontradas.

![issues-Synopsys](/assets/devsecops/synopsys/portal/06.png)

Caso seja necessário, realize a busca por filtros ou ordenação de grupo.

![filter-issue-Synopsys](/assets/devsecops/synopsys/portal/15.png)

Clicando na vulnerabilidade irá exibir os detalhes da issue:

![issues-Synopsys](/assets/devsecops/synopsys/portal/07.png)

Nesta tela será possível informar se a vulnerabilidade encontrada é um falso-positivo.

![Dismissed-Synopsys](/assets/devsecops/synopsys/portal/08.png)

É importante que se tenha uma descrição clara do porquê este item deve ser considerado como falso positivo, pois após clicar em Save, este item irá para aprovação da equipe de DevSecOps.

Para acompanhar o andamento da sua solicitação, realize o filtro conforme abaixo:

![Filter-Synopsys](/assets/devsecops/synopsys/portal/12.png)

Caso a requisição de falso positivo utilize o filtro a baixo:

![Filter2-Synopsys](/assets/devsecops/synopsys/portal/13.png)

## Migrando o seu projeto do Fortify para o Synopsys 

Criar o  arquivo  “polaris.yml” na raiz do seu projeto:

Exemplo do arquivo polaris.yml:

    Favor prencher corretamente as propriedades: "ALIANÇA - TRIBO - SQUAD - TECHLEAD" 

``` yml
version: "1"
project:
  name: ${scm.git.repo}
  branch: ${scm.git.branch}
  revision:
    name: ${scm.git.commit}
    date: ${scm.git.commit.date}
  properties:
    Alianca: '<nomeAlianca>'
    Tribo: '<nomeTribo>'
    Squad: '<nomeSquad>'
    TechLead: '<emailTL>'
capture:
  build:
    buildCommands:
    - shell: [msbuild, '', '/t:Build', '/p:platform=x64', '/p:configuration=release']
    coverity:
      cov-build: [--instrument]
  fileSystem:
    ears:
      extensions: [ear]
      files:
      - directory: ${project.projectDir}
    java:
      files:
      - directory: ${project.projectDir}
    javascript:
      files:
      - directory: ${project.projectDir}
      - excludeRegex: node_modules|bower_components|vendor
    php:
      files:
      - directory: ${project.projectDir}
    python:
      files:
      - directory: ${project.projectDir}
    ruby:
      files:
      - directory: ${project.projectDir}
    wars:
      extensions: [war]
      files:
      - directory: ${project.projectDir}
analyze:
  mode: central
install:
  coverity:
    version: default
serverUrl: https://xpinvestimentos.polaris.synopsys.com
```
    OBS. Caso o diretório da sua solution não esteja na raiz do projeto favor alterar:  
    - shell: [msbuild, 'DIRETORIO-DA-SOLUTION', '/t:Build', '/p:platform=x64', '/p:configuration=release']
  
Repositório: [Template dos arquivos de config](https://xpinvestimentos.visualstudio.com/Projetos/_git/TemplateSynopsysConfig)

Para a maioria das aplicações é necessário apenas ajustar os campos de “properties” para os detalhes da sua Squad. Em  projetos Javascript e outras linguagens, que não utilizam o msbuild. Caso seu projeto necessite de customização entre em contato com DevSecOps por meio da oferta -> “[Outros](https://xpinvestimentos.service-now.com/sp?id=sc_cat_item&sys_id=943f4e501b2a1c903772419fe54bcb14)”:

![Dismissed-Synopsys](/assets/devsecops/synopsys/portal/14.png)

## Configurando a pipeline (azure-pipelines.yml)

Usualmente devem ser utilizados os 2 parâmetros abaixo:

 - **runFortify : false** _Para desativar o scan do Fortify_
- **runSynopsys : true** _Para ativar o scan do Synopsys_  
- **runNugetRestore : false** _Para aplicações que não utilizem os pacotes do Nuget_
 
Exemplo abaixo:

![Dismissed-Synopsys](/assets/devsecops/synopsys/portal/09.png)

## Configurando a pipeline (Modo clássico)
Para as pipelines mais antigas também já está disponível o plugin do Synopsys, basta **substituir** o _Task Group do Fortify_ pelo _Task Group do Synopsys_:

![Dismissed-Synopsys](/assets/devsecops/synopsys/portal/10.png)

Caso sua aplicação utilize pacotes do Nuget será necessário adicionar a tarefa do Nuget Restore.

![Dismissed-Synopsys](/assets/devsecops/synopsys/portal/11.png)

## Classificação no Scan das ferramentas de SAST

Toda vez que um “Commit” ocorrer no código-fonte, é preciso iniciar um processo de “Build” automatizado na ferramenta AzureDevOPS .  Todos os “Builds” irão obrigatoriamente passar por um scan do Fortify, Synopsys ou ferrramenta similar. Caso seja identificadas vulnerabilidades de níveis superiores em suas classificações e quantidades maiores do que no último scan a ferramenta irá bloquear e invalidar o Build.

Classificação de níveis por ferramenta:

  - Fortify: Críticas e Altas

  - Synopsys: Altas e Médias


## Referência

- https://sig-docs.synopsys.com/polaris/
- https://sig-docs.synopsys.com/polaris/topics/r_compatible-tools.html