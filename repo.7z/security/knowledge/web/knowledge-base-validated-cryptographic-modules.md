---
title: Módulos criptografados validados
---
## Descrição

O Instituto Nacional de Padrões e Tecnologia (NIST) emitiu a publicação de série FIPS 140
para coordenar os requisitos e padrões para módulos de criptografia que incluem
componentes de hardware e software. Proteção de um módulo criptográfico dentro de um
sistema de segurança é necessário para manter a confidencialidade e integridade do
informações protegidas pelo módulo.

## Solução

Verifique se os módulos criptográficos usados ​​pelo aplicativo foram validados contra
FIPS 140-2 ou um padrão equivalente.

