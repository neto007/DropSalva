---
title: Controle de acesso em .NET
---

## Gerenciamento fraco de contas
Certifique-se de que os cookies sejam enviados via httpOnly:

```c#
CookieHttpOnly = true,
```

Reduza o período de tempo em que uma sessão pode ser roubada reduzindo o tempo limite da sessão e removendo a expiração móvel:

```c#
ExpireTimeSpan = TimeSpan.FromMinutes(60),
SlidingExpiration = false
```

Certifique-se de que o cookie seja enviado por HTTPS no ambiente de produção. Isso deve ser aplicado nas configurações:

```c#
<httpCookies requireSSL="true" xdt:Transform="SetAttributes(requireSSL)"/>
<authentication>
    <forms requireSSL="true" xdt:Transform="SetAttributes(requireSSL)"/>
</authentication>
```

Proteja os métodos de LogOn, Registro e redefinição de senha contra ataques de força bruta por meio de solicitações de limitação (consulte o código abaixo), considere também o uso de ReCaptcha.

```c#
[HttpPost]
[AllowAnonymous]
[ValidateAntiForgeryToken]
[AllowXRequestsEveryXSecondsAttribute(Name = "LogOn",
Message = "You have performed this action more than {x} times in the last {n} seconds.",
Requests = 3, Seconds = 60)]
public async Task<ActionResult> LogOn(LogOnViewModel model, string returnUrl)
``` 

* Não utilize sua própria autenticação ou gerenciamento de sessão, use o fornecido por .Net
* Não Diga a alguém se a conta existe no LogOn, Registro ou redefinição de senha. Diga algo como 'O nome de usuário ou a senha estavam incorretos' ou 'Se esta conta existir, um token de redefinição será enviado para o endereço de e-mail registrado'. Isso protege contra a enumeração de contas.
* O feedback para o usuário deve ser idêntico, quer a conta exista ou não, tanto em termos de conteúdo quanto de comportamento: por exemplo, se a resposta demorar 50% mais quando a conta for real, as informações de associação podem ser adivinhadas e testadas.


## Controle de acesso de nível de função ausente¶
Autorizar usuários em todos os terminais externos. O .NET framework tem muitas maneiras de autorizar um usuário, use-as no nível do método:

```c#
[Authorize(Roles = "Admin")]
[HttpGet]
public ActionResult Index(int page = 1)
```
Ou melhor ainda, no nível do controlador:

```c#
[Authorize]
public class UserController
```

Você também pode verificar funções no código usando recursos de identidade em .net: `System.Web.Security.Roles.IsUserInRole(userName, roleName)`

## Referências inseguras de objetos diretos
Quando você tem um recurso (objeto) que pode ser acessado por uma referência (no exemplo abaixo este é o id), você precisa garantir que o usuário é dono deste objeto.

```c#
// Insecure
public ActionResult Edit(int id)
{
  var user = _context.Users.FirstOrDefault(e => e.Id == id);
  return View("Details", new UserViewModel(user);
}

// Secure
public ActionResult Edit(int id)
{
  var user = _context.Users.FirstOrDefault(e => e.Id == id);
  // Establish user has right to edit the details
  if (user.Id != _userIdentity.GetUserId())
  {
        HandleErrorInfo error = new HandleErrorInfo(
            new Exception("INFO: You do not have permission to edit these details"));
        return View("Error", error);
  }
  return View("Edit", new UserViewModel(user);
}
```

## Referência externa
[.Net security](https://cheatsheetseries.owasp.org/cheatsheets/DotNet_Security_Cheat_Sheet.html)