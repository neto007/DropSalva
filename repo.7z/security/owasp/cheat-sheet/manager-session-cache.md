---
title: Cache de conteúdo da web
---

Mesmo após o encerramento da sessão, pode ser possível acessar os dados privados ou confidenciais trocados na sessão por meio do cache do navegador da web. Portanto, os aplicativos da web devem usar diretivas de cache restritivas para todo o tráfego da web trocado por meio de HTTP e HTTPS, como cabeçalhos Cache-Controle PragmaHTTP e / ou tags META equivalentes em todas ou (pelo menos) páginas da web confidenciais.

Independentemente da política de cache definida pelo aplicativo da web, se o conteúdo do aplicativo da web em cache for permitido, os IDs de sessão nunca devem ser armazenados em cache, por isso é altamente recomendável usar a Cache-Control: no-cache="Set-Cookie, Set-Cookie2"diretiva, para permitir que os clientes da web armazenem em cache tudo, exceto o ID da sessão (consulte aqui ).


### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)