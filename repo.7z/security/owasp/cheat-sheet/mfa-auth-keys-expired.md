---
title: As credenciais de autorização devem ser válidas apenas por um período limitado de tempo
---

Em alguns cenários de ataques de malware, as credenciais de autorização inseridas pelo usuário são passadas para o servidor de controle e comando do malware (C&C) e, em seguida, usadas em uma máquina controlada pelo invasor. Esse processo geralmente é executado manualmente por um invasor. Para dificultar tais ataques, o servidor deve permitir a autorização da transação apenas em uma janela de tempo limitada entre a geração do desafio ou OTP e a autorização da transação. Além disso, essa proteção também ajudará na prevenção de ataques de exaustão de recursos. A janela de tempo deve ser cuidadosamente selecionada para não interromper o comportamento normal dos usuários.

### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)