---
title: Codificação de transporte
---

Os estilos de codificação SOAP têm como objetivo mover dados entre objetos de software para o formato XML e vice-versa.

**Regra:** aplique o mesmo estilo de codificação entre o cliente e o servidor.

## Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/)