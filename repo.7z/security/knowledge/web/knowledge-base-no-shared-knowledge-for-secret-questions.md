---
title: Nenhum conhecimento compartilhado para perguntas secretas
---
## Descrição

Sempre que um aplicativo faz uma pergunta secreta ao usuário, ou seja, uma senha esqueceu a funcionalidade, essas perguntas não devem ser um conhecimento compartilhado que um invasor pode obter da Web para impedir que ele comprometa a conta por essa função.

## Solução

Perguntas secretas nunca devem incluir conhecimento compartilhado, valores previsíveis ou fáceis de adivinhar. Caso contrário, as respostas para essas perguntas secretas podem ser facilmente pesquisadas na Internet por meio de contas de mídia social e similares.