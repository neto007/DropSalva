---
title: Biding automático de parâmetros
---
## Descrição

Se o framework da aplicação permitir a atribuição automática de parâmetros em massa
(também chamada de associação automática de variáveis) a partir da solicitação de entrada para um modelo, verifique se os campos sensíveis à segurança, como 'accountBalance', 'role' ou 'password' estão protegidos contra 'binding' automático malicioso. Sempre que seu aplicativo usa parâmetros na instrução HTTPs GET e as passa como variáveis para codificar dentro da aplicação pode se tornar um risco à segurança, pois a aplicação processa essas variáveis em suas operações.

## Solução

Ao trabalhar com 'binding' automático de variáveis, você deve criar listas de permissões que são esperados e permitem que somente esses parâmetros sejam passados para a operação da aplicação.