---
title: Distinguir Log
---
## Descrição

Sempre que os campos de log se distinguem por meio de logs de confiáveis ​​e
nos campos de registro não confiáveis ​​em suas entradas, seus registros se tornam mais claros e transparentes.

## Solução

Verifique se os campos de log de fontes confiáveis ​​e não confiáveis ​​são distinguíveis em entradas de log. Se possível, é altamente recomendável que você separe esses arquivos inteiramente um do outro, para que os logs com entrada não confiável do usuário não possam corromper o logs gerados pelo sistema.