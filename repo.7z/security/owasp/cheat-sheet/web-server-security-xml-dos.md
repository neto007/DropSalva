---
title: Proteção contra negação de serviço XML
---

O `XML Denial of Service` é provavelmente o ataque mais sério contra os serviços da web. Portanto, o serviço da web deve fornecer a seguinte validação:

**Regra:** validação contra cargas úteis recursivas.

**Regra:** validação contra cargas úteis superdimensionadas.

**Regra:** Proteção contra expansão de entidade XML .

**Regra:** Validando em relação a nomes de elementos muito longos. Se você estiver trabalhando com Web Services baseados em SOAP , os nomes dos elementos são essas Ações SOAP .

Essa proteção deve ser fornecida por seu analisador XML / validador de esquema. Para verificar, crie casos de teste para garantir que seu analisador seja resistente a esses tipos de ataques.

## Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/)
