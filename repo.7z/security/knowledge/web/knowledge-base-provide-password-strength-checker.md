---
title: Fornecer verificador de força da senha
---
## Descrição

Os usuários podem tender a escolher senhas fáceis de adivinhar. Portanto, sugere-se implementar uma funcionalidade que os incentive a definir uma senha de maior complexidade.

## Solução

Os aplicativos devem fornecer aos usuários um medidor de segurança de senha em caso de registro de conta e alteração de senha.