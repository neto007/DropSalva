---
title:  Injeção de script em .Net
---

## Cross-Site Scripting (XSS)
NÃO: confie em nenhum dado que o usuário enviar a você, prefira listas de permitidos á listas de bloqueio.

Utilize a codificação de todo o conteúdo HTML com MVC3, para codificar adequadamente todo o conteúdo, seja HTML, javascript, CSS, LDAP etc., use a biblioteca "Microsoft AntiXSS"

Em seguida, defina na configuração:

```c#
<system.web>
    <httpRuntime targetFramework="4.5"
        enableVersionHeader="false"
        encoderType="Microsoft.Security.Application.AntiXssEncoder, AntiXssLibrary"
        maxRequestLength="4096" />
```

Não use o atributo `[AllowHTML]` ou a classe auxiliar, para garantir que o conteúdo que está sendo escrito para o navegador é seguro e foi escapado corretamente.

Ative uma Política de Segurança de Conteúdo , isso impedirá que suas páginas acessem ativos que não deveriam ser acessados ​​(por exemplo, um script malicioso):

```c#
<system.webServer>
    <httpProtocol>
        <customHeaders>
            <add name="Content-Security-Policy"
                value="default-src 'none'; style-src 'self'; img-src 'self';
                font-src 'self'; script-src 'self'" />
```
Mais informações podem ser encontradas aqui para [Cross-Site Scripting](cross-site-scripting).