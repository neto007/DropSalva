---
title: Expiração manual da sessão
---

Os aplicativos da web devem fornecer mecanismos que permitam aos usuários conscientes da segurança fechar ativamente sua sessão assim que terminarem de usar o aplicativo da web.

**Botão Logout**

Os aplicativos da web devem fornecer um botão de logout visível e facilmente acessível (logoff, sair ou fechar a sessão) que está disponível no cabeçalho ou menu do aplicativo da web e acessível a partir de todos os recursos e páginas do aplicativo da web, para que o usuário possa fechar manualmente a sessão em a qualquer momento. Conforme descrito na seção Session_Expiration , o aplicativo da web deve invalidar a sessão pelo menos no lado do servidor.

**NOTA**: Infelizmente, nem todos os aplicativos da web facilitam o fechamento da sessão atual. Assim, os aprimoramentos do lado do cliente permitem que usuários conscienciosos protejam suas sessões, ajudando a fechá-las diligentemente.

### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)