---
title: Injeção de Cabeçalho HTTP
---
## Descrição

Injeção de cabeçalho HTTP (Http Header Injection) é uma classe geral de vulnerabilidade de segurança de aplicação web a qual ocorre quando  cabeçalhos de Protocolo de Transferênica de Hypertexto (HTTP) são gerados dinamicamente baseados em input de usuário. 

Injeção de cabeçalho (header injection) em respostas HTTP podem permitir a divisão (splitting - também conhecida como CRLF, Carriage Return Line Feed), fixação de sessão do cabeçalho via Set-Cookie, execução de script via site cruzado (cross-site scripting - XSS) e ataques de redirecionamento malicioso via localização do cabeçalho. 

A Injeção de Cabeçalho HTTP é uma área relativamente nova para ataques baseados na web e tem principalmento sido explorada por Amit Klein em seu trabalho em requisição/resposta (request/response)  e presunção/divisão (smuggling/splitting). Vulnerabilidades devido a injeção de cabeçalho HTTP tais como CRLF não tem sido mais realizáveis devido ao fato que requisições de cabeçalho múltiplas não são mais possíveis.

## Solução

Quando o input do usuário for usado em cabeaçalhos HTTP então novas linhas devem ser puladas de um modo correto. A recomendação seria criar uma whitelist de input esperado ou usar um método de validação o qual por exemplo apenas aceite valores alfanuméricos. Cada detecção de input que estiver fora da operação desejada deve ser rejeitada.