---
title: Segurança da camada de transporte (TLS)
---
## Descrição

Transport Layer Security (TLS) e seu predecessor agora obsoleto, Secure Sockets Layer (SSL),
são protocolos criptografados projetados para fornecer segurança de comunicação em uma rede de computadores. Diversas versões de protocolos são amplamente utilizadas em aplicações de navegação na web, e-mail, mensagens instantâneas e voz sobre IP (VoIP). Os sites podem usar TLS para proteger todas as comunicações entre seus servidores e navegadores da web.

O protocolo TLS visa principalmente fornecer privacidade e integridade de dados entre a comunicação de dois ou mais aplicativos de computador. [2]:3 Quando protegidos por TLS, as conexões entre um cliente (por exemplo, um navegador da web) e um servidor (por exemplo, wikipedia.org) deve ter uma ou mais das seguintes propriedades:

A conexão é privada (ou segura) porque a criptografia simétrica é usada para criptografar os dados transmitidos. As chaves para esta criptografia simétrica são geradas exclusivamente para cada conexão e são baseadas em um segredo compartilhado que foi negociado no início da sessão. O servidor e o cliente negociam os detalhes de qual algoritmo de criptografia e chaves criptográficas usar antes do primeiro byte de dados a ser transmitido.
A negociação de um segredo compartilhado é segura (o segredo negociado não está disponível para 'curiosos' e não pode ser obtido, mesmo por um invasor que se coloca no meio da conexão) e confiável (nenhum invasor pode modificar as comunicações durante a negociação sem serem detectados).

A identidade das partes em comunicação pode ser autenticada usando criptografia de chave pública. Essa autenticação pode ser opcional, mas geralmente é exigida por pelo menos uma das partes (normalmente o servidor). A conexão é confiável porque cada mensagem transmitida inclui uma verificação de integridade da mensagem usando um código de autenticação de mensagem para evitar perda não detectada ou alteração dos dados durante a transmissão.

Além das propriedades acima, a configuração cuidadosa da camada de transporte TLS pode fornecer propriedades adicionais relacionadas a privacidade, como sigilo de encaminhamento, garantindo que qualquer divulgação futura de chaves de criptografia não possa ser usada para descriptografar qualquer comunicação TLS registrada anteriormente.

## Solução 

Sempre use TLS em tudo e aplique as melhores configurações de segurança.