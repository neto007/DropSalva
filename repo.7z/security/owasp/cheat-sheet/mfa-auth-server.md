---
title: A Aplicar autorização no lado do servidor
---


Como para todos os outros controles de segurança , a autorização da transação deve ser aplicada no lado do servidor. De forma alguma deve ser possível influenciar o resultado da autorização alterando os dados que fluem de um cliente para um servidor, por exemplo:

- Adulteração de parâmetros que contêm dados de transação,

- Adicionar / remover parâmetros que desabilitarão a verificação de autorização,

- Causando um erro.

Para conseguir isso, as melhores práticas de programação de segurança devem ser aplicadas, como:

- Negação padrão.

- Evitando a funcionalidade de depuração no código de produção.

Para evitar adulteração, proteções adicionais devem ser consideradas. Por exemplo, protegendo criptograficamente os dados para confidencialidade e integridade e enquanto descriptografa e verifica o lado do servidor de dados.

### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)