---
title: Execução de código arbitrário em sistemas cliente
---

Esse risco surge do fato de que o código JavaScript de terceiros raramente é revisado pela parte que os invocou antes de sua integração em um site / aplicativo. Quando o cliente chega ao site / aplicativo de hospedagem, esse código de terceiros é executado, concedendo ao terceiro exatamente os mesmos privilégios que foram concedidos ao usuário (semelhante a ataques XSS ).

Qualquer teste realizado antes de entrar em produção perde parte de sua validade, incluindo AST testing( IAST , RAST , SAST , DAST , etc.).

Embora seja amplamente aceito que a probabilidade de ter códigos invasores injetados intencionalmente por terceiros seja baixa, ainda existem casos de injeções maliciosas em códigos de terceiros depois que os servidores da organização foram comprometidos (ex: Yahoo, janeiro de 2014).

Este risco deve, portanto, ainda ser avaliado, em particular quando o terceiro não mostra qualquer documentação de que está aplicando melhores medidas de segurança do que a própria organização que fez a solicitação, ou pelo menos equivalente. Outro exemplo é que o domínio que hospeda o código JavaScript de terceiros expira porque a empresa que o mantém está falida ou os desenvolvedores abandonaram o projeto. Um ator malicioso pode registrar novamente o domínio e publicar o código malicioso.

As defesas típicas incluem, mas não estão restritas a:

- Espelhamento de script interno (para evitar alterações por terceiros),

- Integridade de sub-recursos (para permitir a interceptação no nível do navegador),

- Transmissão segura do código de terceiros (para evitar modificações durante o transporte) e vários tipos de sandbox. Veja abaixo para mais detalhes.


### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)