---
title: As configurações de TLS estão de acordo com as principais práticas atuais
---
## Descrição

As configurações de TLS devem sempre estar de acordo com a prática atual. Sempre que as configurações de TLS e cifras ficarem desatualizadas, a conexão TLS pode ser degradada/interrompida e usada por invasores para espionar o tráfego de dados dos usuários na aplicação.

## Solução

Deve haver varreduras estruturais que são feitas regularmente em relação às configurações TLS das aplicações e configurações para verificar se as configurações de TLS estão de acordo com a prática atual. Isso poderia ser alcançado usando a API SSLLabs ou o projeto OWASP O-Saft.

- O-Saft é uma ferramenta fácil de usar para mostrar informações sobre o certificado SSL e testar a conexão SSL de acordo com uma determinada lista de criptografias e configurações SSL. Foi projetado para ser usado por testadores de penetração, auditores de segurança ou administradores de servidor.

A ideia é mostrar as informações importantes com uma simples chamada da ferramenta.
No entanto, o mesmo oferece uma ampla gama de opções para que possa ser usado por pessoas experientes.

Ao fazer esses testes, leve em consideração a seguinte configuração no lado do servidor:

Verifique se as versões antigas de protocolos, algoritmos, criptografias e configurações SSL e TLS são desativados, como SSLv2, SSLv3 ou TLS 1.0 e TLS 1.1. A versão mais recente do TLS deve ser o conjunto de criptografia preferido.