---
title: Gerenciamento de Tags de Javascript 
---

Tags, também conhecidas como tags de marketing, tags analíticas, etc., são pequenos pedaços de JavaScript em uma página da web. Eles também podem ser elementos de imagem HTML quando o JavaScript está desativado. O motivo para eles é coletar dados sobre as ações do usuário da web e contexto de navegação para uso pelo proprietário da página da web em marketing.

As tags JavaScript de terceiros (doravante, tags) podem ser divididas em dois tipos:

- Tags da interface do usuário.

- Tags analíticas.

A invocação de código JS de terceiros em um aplicativo da web requer consideração para 3 riscos em particular:

- [A perda de controle sobre as mudanças no aplicativo cliente](manager-js-risk1)

- [A execução de código arbitrário em sistemas cliente](manager-js-risk2)

- [A divulgação ou vazamento de informações confidenciais para terceiros](manager-js-risk3)

Outros aspectos para implantação:

- [Arquitetura de implantação de JavaScript de terceiros](manager-js-architecture)

- [Considerações de defesa de segurança](manager-js-cloud-defense)

### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)