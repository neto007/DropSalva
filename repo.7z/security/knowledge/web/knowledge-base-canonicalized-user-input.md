---
title: Validação do input do usuário
---
## Descrição

Sempre que a entrada do usuário é parcialmente validada, há uma alta probabilidade de que o aplicativo não valide uma entrada maliciosa que pode executar um ataque bem-sucedido ao seu aplicativo.

## Solução

Toda entrada do usuário deve ser validada sempre que a sequência de entrada do usuário estiver completa e estiver sendo processado pelo seu aplicativo.
