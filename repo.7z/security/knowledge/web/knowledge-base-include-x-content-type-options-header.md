---
title: Inclua cabeçalhos X-Content-Type-Options 
---
## Descrição

Configurar seu servidor para retornar o cabeçalho de resposta HTTP X-Content-Type-Options definido como nosniff instruirá os navegadores que suportam a detecção de MIME a usar o Content-Type fornecido pelo servidor e não interpretar o conteúdo como um tipo de conteúdo diferente. O valor único definido, nosniff, impede o Internet Explorer e o Google Chrome de
MIME-sniffing uma resposta para o tipo de conteúdo declarado. Isso também se aplica ao Google Chrome, ao baixar extensões. 

Isso reduz a exposição a ataques de direcionados por download e sites que servem
conteúdo carregado por usuário que, por nomeação inteligente, poderia ser tratado pelo MSIE como um executável ou arquivos HTML dinâmicos.

## Solução
Esses cabeçalhos também são conhecidos como: `X-Content-Type-Options: nosniff`;
e fornecem proteção contra ataques do tipo Mime quando implementados no aplicativo ou servidor da web.