---
title: Content-security Police (CSP)
---

Este artigo apresenta uma maneira de integrar o conceito de defesa em profundidade ao lado do cliente dos aplicativos da web. Ao injetar os cabeçalhos Content-Security-Policy (CSP) do servidor, o navegador está ciente e é capaz de proteger o usuário de chamadas dinâmicas que carregam conteúdo na página que está sendo visitada.

## Descrição

O aumento nas vulnerabilidades de XSS e clickjacking exige uma abordagem de segurança mais defensiva em profundidade. O CSP vem em vigor para forçar o carregamento de recursos (scripts, imagens, etc.) de locais restritos que são confiáveis ​​pelo servidor, bem como forçar o uso de HTTPS de forma transparente. Além disso, o desenvolvedor terá mais visibilidade sobre os ataques que ocorrem no aplicativo usando a [diretiva de relatório CSP](content-security-police-directives).

## Defesa em profundidade

Um CSP forte fornece uma segunda camada eficaz de proteção contra vários tipos de vulnerabilidades, incluindo XSS. Embora não seja possível mitigar totalmente esses problemas, um CSP pode tornar significativamente mais difícil para um invasor explorá-los de fato.

Mesmo em um site totalmente estático, que não aceita nenhuma entrada do usuário, um CSP pode ser usado para impor o uso de Sub resource Integrity (SRI). Isso pode ajudar a evitar que códigos maliciosos sejam carregados no site se um dos sites de terceiros que hospedam arquivos JavaScript (como scripts de análise) estiver comprometido.

No entanto, CSP não deve ser considerado o único mecanismo defensivo em um site. Ainda é vital que outros controles de proteção sejam implementados, como aqueles discutidos na página de [prevenção de scripts entre sites](cross-site-scripting).