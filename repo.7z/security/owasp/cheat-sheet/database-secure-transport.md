---
title: Segurança em banco de dados (Transporte)
---

## Proteção da Camada de Transporte

A maioria dos bancos de dados permite conexões de rede não criptografadas em suas configurações padrão. Embora alguns criptografem a autenticação inicial (como o Microsoft SQL Server), o restante do tráfego não será criptografado, o que significa que todos os tipos de informações confidenciais serão enviados pela rede em texto não criptografado. As seguintes etapas devem ser executadas para evitar o tráfego não criptografado:

* Configure o banco de dados para permitir apenas conexões criptografadas.
* Instale um certificado digital confiável no servidor.
* Configure o aplicativo cliente para se conectar usando TLSv1.2 com cifras modernas (por exemplo, AES-GCM ou ChaCha20).
* Configure o aplicativo cliente para verificar se o certificado digital está correto.

## Referência externa
[OWASP - segurança em baco de dados](https://cheatsheetseries.owasp.org/cheatsheets/Database_Security_Cheat_Sheet.html)