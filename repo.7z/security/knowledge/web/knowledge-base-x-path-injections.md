---
title: X-Path injections
---
## Descrição

Os aplicativos da Web usam intensamente bancos de dados para armazenar e acessar os dados de que precisam para seus operações. Historicamente, os bancos de dados relacionais têm sido de longe os mais comuns tecnologia para armazenamento de dados, mas nos últimos anos, estamos testemunhando um aumento popularidade para bancos de dados que organizam dados usando a linguagem XML. Assim como bancos de dados relacionais são acessados ​​via linguagem SQL, bancos de dados XML usam X-Path como sua linguagem de consulta padrão.

## Solução

Assim como as técnicas para evitar injeção de SQL, você precisa usar um X-Path parametrizado
interface, se houver uma disponível, ou escape da entrada do usuário para torná-la segura para inclusão em um consulta construída dinamicamente. Se você estiver usando aspas para encerrar a entrada não confiável em um consulta X-Path construída dinamicamente, então você precisa escapar dessa citação no não confiável entrada para garantir que os dados não confiáveis ​​não podem tentar quebrar fora desse contexto citado.
