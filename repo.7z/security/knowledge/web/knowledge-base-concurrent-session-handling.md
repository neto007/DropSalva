---
title: Manipulação de sessão simultânea
---
## Descrição

Você deve acompanhar todas as diferentes sessões simultâneas ativas.
Sempre que o aplicativo descobrir sessões simultâneas, ele deve sempre notificar o usuário sobre isso e deve dar a ele a oportunidade de terminar as outras sessões.

Com essa defesa, fica mais difícil para os invasores sequestrar uma sessão de usuários, pois eles serão notificados sobre sessões simultâneas.

## Solução

O aplicativo deve acompanhar e limitar todas as sessões concedidas.
Ele deve armazenar o endereço IP, o ID da sessão e o ID do usuário. Depois de armazenar essas credenciais deve fazer verificações regulares para verificar se há:

1. Várias sessões ativas vinculadas ao mesmo ID de usuário
2. Várias sessões ativas de diferentes locais
3. Várias sessões ativas de diferentes dispositivos
4. Limite e destrua as sessões quando elas excederem um limite aceito.

Quanto mais crítico o aplicativo se torna, menor o limite aceito para
sessões simultâneas devem ser.

