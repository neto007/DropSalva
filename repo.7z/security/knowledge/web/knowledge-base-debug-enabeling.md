---
title: Ativação de depuração
---
## Descrição

Às vezes, é possível através de um "parâmetro de habilitação de depuração" exibir informações técnicas informações/segredos dentro do aplicativo. Como resultado, o atacante aprende mais sobre o operação do aplicativo, aumentando sua superfície de ataque. Às vezes, ter um sinalizador de depuração ativado pode até levar a ataques de execução de código (versões mais antigas do werkzeug)

## Solução

Desative a possibilidade de habilitar informações de depuração em um ambiente ativo.