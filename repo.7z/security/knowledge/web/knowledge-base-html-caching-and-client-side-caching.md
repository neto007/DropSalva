---
title: Cache em HTML
---
## Descrição

Os desenvolvedores que criam aplicações HTML5 podem criar aplicações totalmente compatíveis com offline usando a interface ApplicationCache HTML5. O cache de aplicações usa um arquivo de manifesto de cache para especificar quais arquivos em uma aplicação HTML5 podem ser usados offline e quais arquivos requerem uma conexão de rede.

## Solução

Nunca armazene informações confidenciais em um cache do lado do cliente, podendo ser facilmente comprometida pelo invasor/atacante. O mesmo princípio também se aplica às funções de preenchimento automático.

Item da base de conhecimento recomendado:

- Cabeçalhos de cache (caching headers)
- Armazenamento do lado do cliente
