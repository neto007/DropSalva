---
title: A alteração do token de autorização deve ser autorizada usando o token de autorização atual
---

Quando um usuário tem permissão para alterar o token de autorização usando a interface do aplicativo, a operação deve ser autorizada usando suas credenciais de autorização atuais (como é o caso com o procedimento de alteração de senha ). Por exemplo: quando um usuário altera um número de telefone para códigos SMS, um código SMS de autorização deve ser enviado para o número de telefone atual.

### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)