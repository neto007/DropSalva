---
title: Robots
---
## Descrição

Cada site usa um arquivo robots.txt que permite que os mecanismos de pesquisa forneçam informações. O robots.txt determina quais páginas podem ou não ser indexadas pelo Google ou Yahoo, etc. No entanto, um erro comum cometido pelos programadores é aplicar um método de lista negra, causando o aplicativo que exibe informações confidenciais para os invasores.

## Solução

Em vez do método da lista negra:

User-agent: *
Disallow: /squirrelmail/
Disallow: /admin/
Disallow: /modules/

Você deve usar um método de lista de permissões:

User-agent: *
Disallow: *
Allow: /index.html
Allow: /home.html
