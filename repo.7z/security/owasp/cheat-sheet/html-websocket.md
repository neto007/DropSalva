---
title: Websocket HTML
---

* Abandone a compatibilidade com versões anteriores em clientes/servidores implementados e use apenas versões de protocolo acima de hybi-00. A versão popular do Hixie-76 (hiby-00) e anteriores são desatualizadas e inseguras.
* A versão recomendada com suporte nas versões mais recentes de todos os navegadores atuais é RFC 6455 (compatível com Firefox 11+, Chrome 16+, Safari 6, Opera 12.50 e IE10).
* Embora seja relativamente fácil encapsular serviços TCP por meio de WebSockets (por exemplo, VNC, FTP), isso permite o acesso a esses serviços encapsulados para o invasor no navegador no caso de um ataque de Cross Site Scripting. Esses serviços também podem ser chamados diretamente de uma página ou programa malicioso.
* O protocolo não trata de autorização e/ou autenticação. Os protocolos de nível de aplicativo devem lidar com isso separadamente, caso os dados que diferenciam maiúsculas de minúsculas estejam sendo transferidos.
* Processar as mensagens recebidas pelo websocket como dados. Não tente atribuí-lo diretamente ao DOM nem avalie como código. Se a resposta for JSON, nunca use a `eval()` função insegura; use a opção segura `JSON.parse()` em vez disso.
* Os endpoints expostos através do `ws://protocolo` são facilmente reversíveis para texto simples. Apenas **wss://(WebSockets sobre SSL/TLS)** deve ser usado para proteção contra ataques Man-In-The-Middle.
* É possível falsificar o cliente fora de um navegador, portanto, o servidor WebSockets deve ser capaz de lidar com entradas incorretas/maliciosas. Sempre valide a entrada vinda do site remoto, pois ela pode ter sido alterada.
* Ao implementar servidores, verifique o cabeçalho no handshake do Websockets. Embora possa ser falsificado fora de um navegador, os navegadores sempre adicionam a Origem da página que iniciou a conexão Websockets.
* Como um cliente WebSockets em um navegador pode ser acessado por meio de chamadas JavaScript, toda a comunicação do Websockets pode ser falsificada ou sequestrada por meio de Cross Site Scripting . Sempre valide os dados provenientes de uma conexão WebSockets.