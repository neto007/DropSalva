---
title: Proteção contra o vírus
---

SOAP fornece a capacidade de anexar arquivos e documentos a mensagens SOAP . Isso dá aos hackers a oportunidade de anexar vírus e `malware` a essas mensagens SOAP .

**Regra:** Certifique-se de que a tecnologia `Virus Scanning` esteja instalada e, de preferência, inline, para que os arquivos e anexos possam ser verificados antes de serem salvos no disco.

**Regra:** Certifique-se de que a tecnologia de verificação de vírus seja regularmente atualizada com as definições / regras de vírus mais recentes.

## Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/)