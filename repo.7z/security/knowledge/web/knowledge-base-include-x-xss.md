---
title:  Inclua X XSS
---
## Descrição

Esse cabeçalho permite que o filtro XSS (Cross-site scripting) embutido nas mais recentes
navegadores da web. De qualquer maneira, ele geralmente é ativado por padrão, portanto, a função desse cabeçalho é reativar o filtro para esse site específico, se ele foi desativado pelo usuário. Este cabeçalho é suportado no IE 8 e no Chrome 4.

## Solução

Esses cabeçalhos também são conhecidos como: X-XSS-Protection: 1; mode=block e fornecem proteção contra ataques XSS quando implementados no aplicativo ou servidor web.

>Nota: Este cabeçalho protege apenas contra alguns ataques XSS refletidos. Ele não é substituto para o escape normal, a filtragem de entrada e a higienização.