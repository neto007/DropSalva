---
title: Os dados de verificação da transação devem ser gerados no lado do servidor
---

Quando dados de transação significativos são transmitidos programaticamente para um componente de autorização, cuidado extra deve ser colocado em negar modificações do cliente nos dados de transação na autorização. Dados de transação significativos que devem ser verificados pelo usuário, devem ser gerados e armazenados em um servidor, depois passados ​​para um componente de autorização sem qualquer possibilidade de violação pelo cliente.

Não é comum coletar dados de transação significativos do lado do cliente e passá-los para o servidor. Nesses casos, o malware pode manipular esses dados e, como resultado, mostrar dados de transação falsos em um componente de autorização.

### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)