---
title: Gerenciamento de regras do lado do cliente
---
## Descrição

Um aplicativo pode implementar todos os tipos de regras lógicas por meio de JavaScript e HTML. No entanto, essas são restrições do lado do cliente que um hacker pode facilmente desativar ou modificar.

## Solução

As restrições do usuário sempre devem ser impostas por técnicas do lado do servidor
de restrições do lado do cliente.