---
title: Valide a integridade de todas as configurações de segurança relevantes
---
## Descrição

Apenas os administradores autorizados devem ter acesso para alterar as configurações relevantes para a segurança.

Esses administradores também devem verificar regularmente essas configurações para serem adequadas e que eles não são alterados por más intenções. Isso pode manter os sistemas vulneráveis ​​a ataques devido a desativação de sistemas importantes de segurança.


## Solução

Verifique se os administradores autorizados têm a capacidade de verificar a
integridade de todas as configurações relevantes para a segurança para garantir que não foram violadas. Uma maneira de conseguir isso seria aplicar regras (HIDS).

Este é um sistema que monitora arquivos importantes do sistema operacional e pode verificar se esses arquivos foram editados. Sempre que esses arquivos são editados, um princípio dos quatro olhos deve ser aplicado para verificar a integridade dessas mudanças.