---
title: Módulos criptográficos e políticas de segurança
---
## Descrição

Sempre que os módulos criptográficos não operam no modo aprovado, de acordo com suas
políticas de segurança publicadas, esses métodos podem se tornar fracos e inadequados para garantir cifras fortes.

## Solução

Sempre verifique se os módulos criptográficos operam no modo aprovado, de acordo com
suas políticas de segurança publicadas antes de implementá-las em seu aplicativo.