---
title: Reverse Engineering
---

## O aplicativo está vulnerável?
Geralmente, a maioria dos aplicativos é suscetível à engenharia reversa devido à natureza inerente do código. A maioria das linguagens usadas para escrever aplicativos hoje é rica em metadados que auxiliam muito o programador na depuração do aplicativo. Esse mesmo recurso também ajuda muito um invasor a entender como o aplicativo funciona. Diz-se que um aplicativo é suscetível à engenharia reversa se um invasor puder fazer qualquer uma das seguintes coisas:

Compreender claramente o conteúdo da tabela de strings de um binário
Realize análises multifuncionais com precisão
Derive uma recriação razoavelmente precisa do código-fonte do binário. Embora a maioria dos aplicativos seja suscetível à engenharia reversa, é importante examinar o impacto potencial da engenharia reversa nos negócios ao considerar se deve ou não mitigar esse risco. Veja os exemplos abaixo para uma pequena amostra do que pode ser feito com engenharia reversa por conta própria.

## Cenários de exemplo de ataques
#### Cenário #1 - Análise da Tabela de String:

O invasor executa 'strings' no aplicativo não criptografado. Como resultado da análise da tabela de strings, o invasor descobre uma string de conectividade codificada que contém credenciais de autenticação para um banco de dados de back-end. O invasor usa essas credenciais para obter acesso ao banco de dados. O invasor rouba uma vasta gama de dados PII sobre os usuários do aplicativo.

#### Cenário #2 - Análise multifuncional:

O invasor usa o IDA Pro contra um aplicativo não criptografado. Como resultado da análise da tabela de strings combinada com a referência cruzada funcional, o invasor descobre o código de detecção de Jailbreak. O invasor usa esse conhecimento em um ataque subequente de modificação de código para desabilitar a detecção de jailbreak no aplicativo móvel. O invasor então implanta uma versão do aplicativo que explora o método swizzling para roubar informações do cliente.

#### Cenário #3 - Análise do código-fonte:

Considere um aplicativo bancário para Android. O arquivo APK pode ser facilmente extraído usando 7zip/Winrar/WinZip/Gunzip. Uma vez extraído, o invasor tem o arquivo de manifesto, ativos, recursos e, mais importante, o arquivo classes.dex.

Então, usando o conversor Dex para Jar, um invasor pode facilmente convertê-lo em um arquivo jar. Na próxima etapa, o Java Decompiler (como JDgui) fornecerá o código.

## Como prevenir
Para evitar a engenharia reversa eficaz, você deve usar uma ferramenta de ofuscação. Existem muitos obfuscators gratuitos e comerciais no mercado. Por outro lado, existem muitos desofuscadores diferentes no mercado. Para medir a eficácia de qualquer ferramenta de ofuscação que você escolher, tente desofuscar o código usando ferramentas como IDA Pro e Hopper.

Um bom ofuscador terá as seguintes habilidades:

Limite quais métodos/segmentos de código ofuscar;
Ajuste o grau de ofuscação para equilibrar o impacto no desempenho;
Suporta a desofuscação de ferramentas como IDA Pro e Hopper;
Ofuscam tabelas de string, bem como métodos
