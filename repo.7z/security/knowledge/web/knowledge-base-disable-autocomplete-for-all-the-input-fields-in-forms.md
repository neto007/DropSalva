---
title: Desabilitar o preenchimento automático
---
## Descrição

Os gerenciadores de preenchimento automático e senha do navegador podem ser usados pelos invasores para roubar informações confidenciais em formação. Sempre que um aplicativo é suscetível a ataques XSS (Cross site scripting), o invasor pode injetar formulários no aplicativo que são preenchidos automaticamente pelo navegador.
O invasor pode então utilizar o JavaScript para ler os campos de entrada e roubar credenciais ououtras informações confidenciais.

## Solução

O navegador deve ser informado explicitamente de todos os campos de entrada que a função de preenchimento automático deve estar desligado. O atributo HTML "autocomplete = off" deve ser adicionado a todas as entradas e campos de entrada ocultos no formulário do qual você deseja desativar o preenchimento automático.