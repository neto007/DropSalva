---
title: Alterar e validar senha atual
---
## Descrição

O usuário deve ser o único que sabe sua senha. Portanto, se um administrador fornecer a senha inicial, o usuário deve poder alterar sua senha. Além disso, quando um usuário acredita que a senha atual foi (ou pode ter sido) comprometido ou como medida de precaução, o usuário deve poder alterar sua senha. Quando um usuário altera sua senha, sua senha atual deve ser validada. Isso evita que um invasor possa assumir o controle de uma sessão válida e altere facilmente a senha da vítima.

## Solução

Verifique se os usuários podem alterar sua senha e a alteração valida o segredo atual.