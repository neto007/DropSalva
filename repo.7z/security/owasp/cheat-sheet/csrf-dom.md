---
title: Cross-Site Request Forgery (CSRF)
---

### Orientação de JavaScript para inclusão automática de tokens CSRF como um cabeçalho de solicitação AJAX

A orientação a seguir considera os métodos GET, HEAD e OPTIONS são operações seguras. Portanto, as chamadas AJAX dos métodos GET, HEAD e OPTIONS não precisam ser anexadas a um cabeçalho de token CSRF. No entanto, se os verbos forem usados ​​para realizar operações de mudança de estado, eles também exigirão um cabeçalho de token CSRF (embora isso seja uma prática ruim e deva ser evitado).

Os métodos POST, PUT, PATCH e DELETE , sendo verbos de alteração de estado, devem ter um token CSRF anexado à solicitação. A orientação a seguir demonstrará como criar substituições em bibliotecas JavaScript para ter tokens CSRF incluídos automaticamente com cada solicitação AJAX para os métodos de alteração de estado mencionados acima.

Armazenando o valor do token CSRF no DOM¶
Um token CSRF pode ser incluído na `<meta>`tag conforme mostrado abaixo. Todas as chamadas subsequentes na página podem extrair o token CSRF desta `<meta>`tag. Ele também pode ser armazenado em uma variável JavaScript ou em qualquer lugar do DOM. No entanto, não é recomendado armazená-lo em cookies ou armazenamento local do navegador.

O seguinte snippet de código pode ser usado para incluir um token CSRF como uma `<meta>`tag:

```
<meta name="csrf-token" content="{{ csrf_token() }}">
```

A sintaxe exata para preencher o atributo content dependeria da linguagem de programação de back-end do seu aplicativo da web.

### Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/)