---
title: Identificar Dependências Externas 
---
## Descrição

Às vezes, seu aplicativo possui determinadas dependências externas que podem
influenciar a operação do seu aplicativo. Essas dependências externas
podem se tornar um alvo de invasores, pois comprometer esse serviço pode levar a
DoS do seu sistema ou influenciar o sistema de maneira a deixar espaço para outros
ataques.

## Solução

Primeiro, você deve identificar em quais dependências externas seu aplicativo se baseia
para o seu funcionamento. Segundo, deve ser implementado um sistema à prova de falhas, caso essa dependência venha a falhar ao fornecer seus serviços para o seu aplicativo.
