---
title: Enumeração de nome de usuário
---
## Descrição

Sempre que uma aplicação gera um erro como:
"Esse nome de usuário já existe"

Um invasor pode enumerar esses nomes de usuário, aumentando sua chance de sucesso
em um ataque de força bruta. O mesmo vale para as funções "Esquecer a senha".
Sempre que um usuário esquecer sua senha, faça com que ele preencha seu endereço de e-mail
em vez de um nome de usuário.

## Solução

Todas as mensagens de erro devem ser genéricas para evitar a enumeração do nome de usuário.
Além disso, às vezes você não pode evitar o vazamento de informações em funcionalidades como uma página de registro. Aqui você precisa usar métodos tar-pitting para evitar um
ataque por um invasor.