---
title: Desserialização insegura de objetos
---
## Descrição


Serialização é o processo de transformar algum objeto em um formato de dados que pode ser restaurado posteriormente. As pessoas geralmente serializam objetos para salvá-los no banco de dados ou enviar como parte das comunicações.

A desserialização é o inverso desse processo, pegando dados estruturados de algum formato e reconstruindo-os em um objeto. Hoje, o formato de dados mais popular para serializar dados é o JSON. Antes disso, era XML.

No entanto, muitas linguagens de programação oferecem um recurso nativo para serializar objetos. Esses formatos nativos geralmente oferecem mais recursos que JSON ou XML, incluindo a personalização do processo de serialização.

Infelizmente, os recursos desses mecanismos nativos de desserialização podem ser reaproveitados para efeitos mailiciosos quando operando com dados não confiáveis. Ataques contra desserializadores tem sido encontrados para permitir negação de serviço,
controle de acesso e ataques de execução remota de código (RCE).


## Solução


Verifique se os objetos serializados usam verificações de integridade ou estão criptografados para impedir a criação de objetos hostis ou a violação de dados.

Uma grande redução de risco é alcançada evitando os formatos nativos de (des) serialização. Ao mudar para um formato de dados puro, como JSON ou XML, você diminui a chance de a lógica de desserialização personalizada ser redirecionada para fins maliciosos.

Muitos aplicativos contam com um padrão de objeto de transferência de dados que envolve a criação de um domínio separado de objetos para a transferência de dados de finalidade explícita. Claro, ainda é possível que o aplicativo cometa erros de segurança após a análise de um objeto de dados puro. Se o aplicativo souber antes da desserialização quais mensagens precisarão ser processadas, ele poderia assiná-los como parte do processo de serialização. O aplicativo poderia então escolher não desserializar nenhuma mensagem que não tenha uma assinatura autenticada.

