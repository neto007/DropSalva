---
title: Os possíveis riscos para a aplicação devem ser documentados
---
## Descrição

As informações que são armazenadas da aplicação e/ou atividades do usuário
precisam ser documentadas, o que o tornará transparente onde essas informações
sensíveis são armazenadas e por quê.

## Solução

Crie uma seção na documentação do projeto que defina as informações
que serão armazenadas. Isso torna mais fácil fazer estimativas sobre partes críticas
de sua aplicação e que merecem atenção extra.