---
title: Componentes de Terceiros
---
## Descrição

Todos os componentes de terceiros dos quais a aplicação depende para operar devem ser mapeados em termos das funções e/ou funções de segurança, sendo fornecidos por várias razões.

1. Sempre que uma dessas dependências está inativa, o aplicativo precisa lidar com a falta 
   dessa dependência e não quebrar resultando em um DoS.

2. Todas as funções de segurança que forem fornecidas devem ser mapeadas e apoiadas por um WAF 
   ou ModSecurity, no caso da dependência for desativada pelo serviço.

## Solução

Verifique todos os componentes que não fazem parte da aplicação e também as que a aplicação
confia para operar, se estão definidas em termos das funções e/ou funções de segurança que são fornecidas pelos terceiros.