---
title: MASVS
---
## Descrição


O Projeto de Segurança e Verificação de Aplicativos Móveis OWASP (MASVS) fornece uma base para testar os controles técnicos de segurança de aplicativos móveis e também fornece aos desenvolvedores uma lista de requisitos para o desenvolvimento seguro. Ele pode ser usado por arquitetos e desenvolvedores de software móvel que buscam desenvolver aplicativos móveis seguros, bem como testadores de segurança para garantir a integridade e consistência dos resultados do teste.

Os requisitos foram desenvolvidos com os seguintes objetivos em mente:

Usar como métrica - forneça aos desenvolvedores e proprietários de aplicativos um critério para avaliar o grau de confiança que pode ser depositado em seus aplicativos móveis;
Use como orientação - forneça orientações aos desenvolvedores de controle de segurança sobre o que criar nos controles de segurança para atender aos requisitos de segurança do aplicativo; Usar durante a compra - forneça uma base para especificar os requisitos de verificação de segurança do aplicativo nos contratos.

## Solução

Confira a lista de verificação OWASP-MASVS no aplicativo OWASP-SKF ou faça o download da versão em PDF do MASVS aqui:

https://github.com/OWASP/owasp-masvs/releases/download/1.0/OWASP_Mobile_AppSec_Verification_Standard_v1.0.pdf
