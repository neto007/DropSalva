---
title: Limpe rapidamente os dados confidenciais da memória
---
## Descrição

Sempre que dados sensíveis são removidos rapidamente da memória dos sistemas, isso diminui a possibilidade de o invasor comprometer esses dados por meio de ataques de dumping de memória.

## Solução

Verifique se os dados confidenciais são limpos rapidamente da memória assim que não são mais necessários e manipulados de acordo com as funções e técnicas suportadas pela estrutura/biblioteca/sistema operacional.
