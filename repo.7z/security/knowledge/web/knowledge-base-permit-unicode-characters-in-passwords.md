---
title: Permitir caracteres Unicode em senhas
---
## Descrição

Lembramos as informações visuais com mais rapidez e melhor comparação com o texto, para que uma senha mais complexa possa ser facilmente lembrada.
No momento, os crackers de senha não consideram os caracteres de Emoji e kanji em suas ferramentas, mas mesmo se considerassem (e farão no futuro próximo), o uso de um único Emoji, além de caracteres ou números, aumenta a variedade de senhas possíveis, o que significa que é mais difícil invadir.

## Solução
	
Verifique se caracteres Unicode são permitidos em senhas.
Um único ponto de código Unicode é considerado um caractere, portanto, 8 caracteres emoji ou 64 kanji devem ser válidos e permitidos.
