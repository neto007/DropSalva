---
title: Gerenciamento de Sessão
---

**Autenticação da Web, gerenciamento de sessão e controle de acesso**

Uma sessão da web é uma sequência de transações de solicitação e resposta HTTP de rede associadas ao mesmo usuário. Os aplicativos da web modernos e complexos requerem a retenção de informações ou status sobre cada usuário durante várias solicitações. Portanto, as sessões fornecem a capacidade de estabelecer variáveis ​​- como direitos de acesso e configurações de localização - que se aplicam a toda e qualquer interação que um usuário tenha com o aplicativo da web durante a sessão.

Os aplicativos da Web podem criar sessões para rastrear usuários anônimos após a primeira solicitação do usuário. Um exemplo seria manter a preferência de idioma do usuário. Além disso, os aplicativos da web farão uso de sessões depois que o usuário for autenticado. Isso garante a capacidade de identificar o usuário em quaisquer solicitações subsequentes, bem como a capacidade de aplicar controles de acesso de segurança, acesso autorizado aos dados privados do usuário e aumentar a usabilidade do aplicativo. Portanto, os aplicativos da web atuais podem fornecer recursos de sessão pré e pós-autenticação.

Depois que uma sessão autenticada foi estabelecida, o ID da sessão (ou token) é temporariamente equivalente ao método de autenticação mais forte usado pelo aplicativo, como nome de usuário e senha, frases-senha, senhas de uso único (OTP), certificados digitais baseados em cliente, smartcards ou biometria (como impressão digital ou retina do olho). Consulte a folha de referências da autenticação OWASP .

[Propriedades de ID de sessão](manager-session-prop-id)

[Impressão digital do nome do ID da sessão](manager-session-id-fingerprint)

[Comprimento do ID da sessão](manager-session-length)

[Entropia de ID de sessão](manager-session-entropy)

[Conteúdo de ID de sessão](manager-session-value)

[Implementação de gerenciamento de sessão](manager-session-imp-session)

[Implementações de gerenciamento de sessão integrado](manager-session-integration)

[Mecanismos de troca de ID de sessão usados ​​vs. aceitos](manager-session-change-id)

[Segurança da camada de transporte](manager-session-tls)


### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)