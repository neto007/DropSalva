---
title: Re Autenticação
---
## Descrição

Sempre que um usuário estiver alterando credenciais, como sua senha, ele deve sempre ser
desafiado pelo aplicativo a se autenticar novamente. Isso é para impedir um invasor de alterar credenciais, se algum invasor puder seqüestrar outra sessão de usuários.

## Solução

Verifique se a funcionalidade de alteração de senha inclui a senha antiga,
a nova senha e uma confirmação de senha, bem como uma indicação de força da senha
para incentivar a adoção de frases de senha fortes. Esse mesmo princípio se aplica a outras operações que são considerados críticos, como alterar um endereço de email ou número de telefone.