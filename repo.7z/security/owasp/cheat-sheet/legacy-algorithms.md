---
title: Atualizando Hashes Legados
---

Para aplicativos mais antigos que foram construídos usando algoritmos de hash menos seguros, como MD5 ou SHA-1, esses hashes devem ser atualizados para outros mais modernos e seguros. Na próxima vez que o usuário inserir sua senha (geralmente por meio da autenticação no aplicativo), deverá ser feito um novo hash usando o novo algoritmo. Também seria uma boa prática expirar a senha atual dos usuários e exigir que eles digitem uma nova, para que os hashes mais antigos (menos seguros) de sua senha não sejam mais úteis para um invasor.

No entanto, essa abordagem significa que os hashes de senha antigos (menos seguros) serão armazenados no banco de dados até o próximo login do usuário e podem ser armazenados indefinidamente. Existem duas abordagens principais que podem ser adotadas para resolver isso.

Um método é expirar e excluir os hashes de senha de usuários que permaneceram inativos por um longo período e exigir que eles redefinam suas senhas para fazer o login novamente. Embora segura, essa abordagem não é particularmente amigável e expirar as senhas de um grande número de usuários pode causar problemas para a equipe de suporte ou pode ser interpretada pelos usuários como uma indicação de violação. No entanto, se houver um atraso razoável entre a implementação do código de atualização de hash de senha no login e a remoção de hashes de senha antigos, a maioria dos usuários ativos já deve ter alterado suas senhas.

Uma abordagem alternativa é usar os hashes de senha existentes como entradas para um algoritmo mais seguro. Por exemplo, se o aplicativo originalmente armazenava senhas como `md5($password)`, isso poderia ser facilmente atualizado para `bcrypt(md5($password))`. Colocar os hashes em camadas dessa maneira evita a necessidade de saber a senha original, no entanto, pode tornar os hashes mais fáceis de quebrar, conforme discutido na seção [Senhas pré-hash](password-length). Como tal, esses hashes devem ser substituídos por hashes diretos das senhas dos usuários na próxima vez que eles fizerem login.

## Algoritmos Customizados
Escrever código criptográfico personalizado, como um algoritmo de hash, é realmente difícil e nunca deve ser feito fora de um exercício acadêmico. Qualquer benefício potencial que você possa ter com o uso de um algoritmo desconhecido ou personalizado será amplamente ofuscado pelas fraquezas que existem nele.

>**Não faça isso.**

## Referência externa
[OWASP - Algoritmo legado](https://cheatsheetseries.owasp.org/cheatsheets/Password_Storage_Cheat_Sheet.html#upgrading-legacy-hashes)