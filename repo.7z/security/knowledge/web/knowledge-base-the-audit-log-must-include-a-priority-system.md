---
title: O log de auditoria deve incluir um sistema prioritário
---
## Descrição

Se o registro (log) de auditoria não tiver um sistema claro de prioridade, será difícil
priorizar diferentes tipos de falhas de processo.

## Solução

Sempre que o aplicativo da web estiver gravando mensagens de erro no log de erros, eles precisam ter um rótulo de prioridade correto. Os rótulos (ou labels) que podem ser usados são LOW, MEDIUM e HIGH. Esse tipo de rótulo pode ser usados posteriormente para uma análise de recursos de forma fácil e rápida dos arquivos de log.

Você também deve verificar os controles de registro de segurança, fornecer a capacidade de registrar eventos de sucesso e particularmente eventos de falhas que são relevantes para a segurança.