---
title: Implementação de gerenciamento de sessão
---


A implementação do gerenciamento de sessão define o mecanismo de troca que será usado entre o usuário e o aplicativo da web para compartilhar e trocar continuamente o ID da sessão. Existem vários mecanismos disponíveis em HTTP para manter o estado da sessão em aplicativos da web, como cookies (cabeçalho HTTP padrão), parâmetros de URL (reescrita de URL - RFC2396 ), argumentos de URL em solicitações GET, argumentos de corpo em solicitações POST, como campos de formulário ocultos (Formulários HTML) ou cabeçalhos HTTP proprietários.

O mecanismo de troca de ID de sessão preferencial deve permitir a definição de propriedades avançadas de token, como a data e hora de expiração do token ou restrições de uso granular. Esta é uma das razões pelas quais os cookies (RFCs 2109 e 2965 e 6265 ) são um dos mecanismos de troca de ID de sessão mais amplamente usados, oferecendo recursos avançados não disponíveis em outros métodos.

O uso de mecanismos de troca de ID de sessão específicos, como aqueles em que o ID está incluído no URL, pode divulgar o ID da sessão (em links e logs da web, histórico e favoritos do navegador, cabeçalho Referer ou mecanismos de pesquisa), bem como facilitar outros ataques, como a manipulação do ID ou ataques de fixação de sessão .


### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)