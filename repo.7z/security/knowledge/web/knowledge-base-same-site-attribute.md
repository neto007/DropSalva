---
title: Atributo do mesmo site
---
## Descrição
SameSite impede que o navegador envie esse cookie junto com solicitações entre sites.
O objetivo principal é reduzir o risco de vazamento de informações de origem cruzada. Também fornece alguns proteção contra ataques de falsificação de solicitação entre sites.


## Solução
O valor estrito impedirá que o cookie seja enviado pelo navegador para o site de destino em todos os contexto de navegação entre sites, mesmo quando segue um link regular. Por exemplo, para um site semelhante ao GitHub, isso significa que se um usuário conectado seguir um link para um projeto privado do GitHub publicado em um fórum de discussão corporativo ou e-mail, o GitHub não receberá o cookie da sessão e o usuário não poderá para acessar o projeto.

Um site do banco, no entanto, provavelmente não deseja permitir que nenhuma página transacional seja vinculada de sites externos, portanto, a sinalização estrita seria mais apropriada aqui.

O valor lax padrão fornece um equilíbrio razoável entre segurança e usabilidade para sites que desejam manter a sessão de logon do usuário após a chegada de um link externo. No cenário acima do GitHub, o cookie da sessão seria permitido ao seguir um link regular de um site externo e bloqueá-lo nos métodos de solicitação propensos a CSRF (por exemplo, POST).

Desde novembro de 2017, o atributo SameSite é implementado no Chrome, Firefox e Opera.
Desde a versão 12.1, o Safari também suporta isso. O Windows 7 com IE 11 não possui suporte a partir de dezembro de 2018, veja caniuse.com abaixo.