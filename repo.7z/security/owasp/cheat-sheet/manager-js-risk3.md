---
title: Divulgação de informações confidenciais a terceiros
---

Quando um script de terceiros é invocado em um site / aplicativo, o navegador entra em contato diretamente com os servidores de terceiros. Por padrão, a solicitação inclui todos os cabeçalhos HTTP regulares. Além do endereço IP de origem do navegador, o terceiro também obtém outros dados, como o referenciador (em solicitações não https) e quaisquer cookies previamente definidos pelo terceiro, por exemplo, ao visitar o site de outra organização que também invoca o script de terceiros.

Em muitos casos, isso concede ao terceiro acesso primário às informações sobre os usuários / clientes / clientes da organização. Além disso, se o terceiro estiver compartilhando o script com outras entidades, ele também coleta dados secundários de todas as outras entidades, sabendo assim quem são os visitantes da organização, mas também com que outras organizações eles interagem.

Um caso típico é a situação atual com grandes sites de notícias / imprensa que invocam código de terceiros (normalmente para motores de anúncios, estatísticas e APIs JavaScript): qualquer usuário que visita qualquer um desses sites também informa os terceiros sobre a visita. Em muitos casos, o terceiro também consegue saber em quais artigos de notícias cada usuário individual está clicando especificamente (o vazamento ocorre por meio do campo referenciador HTTP) e, assim, pode estabelecer perfis de personalidade mais profundos.

As defesas típicas incluem, mas não estão restritas a: espelhamento de script interno (para evitar vazamento de solicitações HTTP para terceiros). Os usuários podem reduzir seu perfil clicando em links aleatórios em sites / aplicativos que vazam (como sites de imprensa / notícias) para reduzir o perfil. Veja abaixo para mais detalhes.

### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)