---
title: Charset incorreto ou faltante 
---
## Descrição

Quando o navegador precisa adivinhar o conjunto de caracteres de acordo com o conteúdo apresentado pelo aplicativo, 
isso pode levar a injeções de XSS quando o palpite estiver errado.

## Solução

Defina o conjunto de caracteres para todas as suas páginas para impedir que o navegador adivinhe os tipos de conteúdo. Isso pode ser feito adicionando um meta-cabeçalho no cabeçalho do seu HTML, como:

Para HTML4:
```html
<meta http-equiv="Content-Type" content="text/html;charset=ISO-8859-1">
```
Para HTML5:
```html
<meta charset="UTF-8">
```
Ou simplesmente definindo cabeçalhos de tipo de conteúdo pelo idioma do servidor,
Exemplo de C # de um cabeçalho de tipo de conteúdo:
