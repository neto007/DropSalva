---
title: Uso de pinagem de chave pública
---

A pinagem de chave pública pode ser usada para fornecer garantia de que o certificado do servidor não é apenas válido e confiável, mas também que corresponde ao certificado esperado para o servidor. Isso fornece proteção contra um invasor capaz de obter um certificado válido, seja explorando uma falha no processo de validação, comprometendo uma autoridade de certificação confiável ou tendo acesso administrativo ao cliente.

A pinagem de chave pública foi adicionada aos navegadores no padrão `HTTP Public Key Pinning (HPKP)`. No entanto, devido a uma série de problemas, ele foi descontinuado posteriormente e não é mais recomendado ou suportado por [navegadores modernos](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Public-Key-Pins).

No entanto, a pinagem de chave pública ainda pode fornecer benefícios de segurança para aplicativos móveis, clientes pesados ​​e comunicação de servidor para servidor. Isso é discutido em mais detalhes na Folha de Dicas de Fixação .


### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)