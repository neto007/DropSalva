---
title: Assinatura de código
---
## Descrição
A assinatura de código é o processo de assinatura digital de executáveis ​​e scripts para confirmar o software autor e garantir que o código não tenha sido alterado ou corrompido desde que foi assinado. O processo emprega o uso de um hash criptográfico para validar a autenticidade e a integridade.

Este processo pode fornecer vários recursos valiosos. O uso mais comum da assinatura de código é fornecer segurança ao implantar; em algumas linguagens de programação, também pode ser usado para ajudar a evitar conflitos de espaço e nome. Quase toda implementação de assinatura de código fornecerá algum tipo de mecanismo de assinatura para verificar a identidade do autor ou sistema de criação e uma soma de verificação para verificar que o objeto não foi modificado. Também pode ser usado para fornecer informações de versão sobre um objeto ou para armazenar outros metadados sobre um objeto.

## Solução
Assine seu código e valide as assinaturas (somas de verificação) do seu código e de terceiros componentes para confirmar a integridade dos componentes implantados.