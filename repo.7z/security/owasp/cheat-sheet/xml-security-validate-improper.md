---
title: Validação imprópria 
---

Quando os esquemas são definidos de forma insegura e não fornecem regras rígidas, eles podem expor o aplicativo a diversas situações. O resultado disso pode ser a divulgação de erros internos ou documentos que atingem a funcionalidade do aplicativo com valores inesperados.

### Tipos de dados de string

Precisa usar um valor hexadecimal, não há sentido em definir esse valor como uma string que mais tarde será restrita aos 16 caracteres hexadecimais específicos. Para exemplificar esse cenário, ao usar a criptografia XML, alguns valores devem ser codificados usando base64. Esta é a definição do esquema de como esses valores devem ser:

```xml

<element name="CipherData" type="xenc:CipherDataType"/>
 <complexType name="CipherDataType">
  <choice>
   <element name="CipherValue" type="base64Binary"/>
   <element ref="xenc:CipherReference"/>
  </choice>
 </complexType>

```

## Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/cheatsheets/XML_Security_Cheat_Sheet.html)