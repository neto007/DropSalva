---
title: Cofre de Chaves
---
## Descrição

As chaves devem permanecer em um cofre de chaves protegido o tempo todo.
Em particular, garanta que haja uma lacuna entre os vetores de ameaças
que têm acesso direto aos dados e aos vetores de ameaças que têm acesso direto às chaves.
Isso implica que as chaves não devem ser armazenadas no aplicativo ou no servidor web
(supondo que os invasores de aplicativos façam parte do modelo de ameaça relevante).

Um cofre de chaves ajuda a proteger, armazenar e controlar rigidamente o acesso a tokens, senhas, certificados e
chaves de criptografia para proteger segredos e outros dados confidenciais.

Imagine o uso de um keyvault no seguinte cenário

* Executando um contêiner de docker e provisionando-o com segredos pela CLI
* Verificando as chaves da API em seus repositórios de origem
* Criptografando dados confidenciais em repouso

O Cofre fornece criptografia como um serviço com gerenciamento centralizado de chaves para simplificar a criptografia de dados
em trânsito e em repouso através de nuvens e datacenters.

Um cofre pode ser usado para criptografar/descriptografar dados armazenados em outro local. O principal uso disso é permitir que os aplicativos criptografem seus dados enquanto ainda os armazenam no repositório de dados primário.

A vantagem disso é que os desenvolvedores não precisam se preocupar com a criptografia correta dos dados. A responsabilidade da criptografia é do Vault e da equipe de segurança, e os desenvolvedores apenas criptografam/descriptografam os dados conforme necessário.

## Solução

Mantenha todas as chaves secretas, senhas e qualquer outra informação confidencial no vaul.


