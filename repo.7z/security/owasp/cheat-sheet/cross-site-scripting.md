---
title: Cross-site scripting (XSS)
---

Os dados entram em um aplicativo da Web por meio de uma fonte não confiável, geralmente uma solicitação da Web.
Os dados são incluídos no conteúdo dinâmico que é enviado a um usuário da web sem ser validado para conteúdo malicioso.
O conteúdo malicioso enviado ao navegador da web geralmente assume a forma de um segmento de JavaScript, mas também pode incluir HTML, Flash ou qualquer outro tipo de código que o navegador possa executar. A variedade de ataques baseados em XSS é quase ilimitada, mas eles geralmente incluem a transmissão de dados privados, como cookies ou outras informações de sessão, para o invasor, redirecionando a vítima para conteúdo da web controlado pelo invasor ou executando outras operações maliciosas na máquina do usuário sob o disfarce de site vulnerável.

### Ataques XSS armazenados e refletidos

Os ataques XSS geralmente podem ser categorizados em duas categorias: armazenados e refletidos. Há um terceiro tipo de ataque XSS, muito menos conhecido, chamado XSS baseado em DOM, que é discutido separadamente aqui .

### Ataques XSS armazenados

Ataques armazenados são aqueles em que o script injetado é armazenado permanentemente nos servidores de destino, como em um banco de dados, em um fórum de mensagens, registro de visitantes, campo de comentários, etc. A vítima então recupera o script malicioso do servidor quando solicita o armazenamento em formação. O XSS armazenado às vezes também é conhecido como XSS persistente ou Tipo I.

### Ataques XSS refletidos

Ataques refletidos são aqueles em que o script injetado é refletido no servidor da Web, como em uma mensagem de erro, resultado de pesquisa ou qualquer outra resposta que inclua parte ou todas as entradas enviadas ao servidor como parte da solicitação. Os ataques refletidos são entregues às vítimas por outra rota, como em uma mensagem de e-mail ou em algum outro site. Quando um usuário é induzido a clicar em um link malicioso, enviar um formulário especialmente criado ou mesmo apenas navegar em um site malicioso, o código injetado viaja para o site vulnerável, o que reflete o ataque de volta ao navegador do usuário. O navegador então executa o código porque ele veio de um servidor “confiável”. O XSS refletido às vezes também é referido como XSS não persistente ou tipo II.

### Outros tipos de vulnerabilidades de XSS

Além do XSS armazenado e refletido, outro tipo de XSS, o XSS baseado em DOM , foi identificado por Amit Klein em 2005 . OWASP recomenda a categorização XSS conforme descrito no Artigo OWASP: Tipos de Cross-Site Scripting , que cobre todos esses termos XSS, organizando-os em uma matriz de XSS Armazenado vs. Refletido e XSS Servidor vs. Cliente, onde XSS baseado em DOM é um subconjunto de cliente XSS.

### Consequências do Ataque XSS

A consequência de um ataque XSS é a mesma, independentemente de ser armazenado ou refletido ( ou baseado em DOM) A diferença está em como a carga chega ao servidor. Não se iluda pensando que um site “somente leitura” ou “brochura” não é vulnerável a sérios ataques XSS refletidos. O XSS pode causar uma variedade de problemas para o usuário final, que variam em gravidade, desde um incômodo até o comprometimento total da conta. Os ataques XSS mais graves envolvem a divulgação do cookie de sessão do usuário, permitindo que um invasor sequestre a sessão do usuário e assuma o controle da conta. Outros ataques prejudiciais incluem a divulgação de arquivos do usuário final, instalação de programas cavalo de Tróia, redirecionamento do usuário para outra página ou site ou modificação da apresentação do conteúdo. Uma vulnerabilidade XSS que permite a um invasor modificar um comunicado à imprensa ou um item de notícias pode afetar o preço das ações de uma empresa ou diminuir a confiança do consumidor. Uma vulnerabilidade XSS em um site farmacêutico pode permitir que um invasor modifique as informações de dosagem, resultando em uma overdose. Para obter mais informações sobre esses tipos de ataques, consulte Content_Spoofing .

### Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/)