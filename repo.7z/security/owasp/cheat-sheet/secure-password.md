---
title: Senha segura
---

## Implementar controles adequados de força de senha

Uma preocupação importante ao usar senhas para autenticação é a força da senha. Uma política de senha "forte" torna difícil ou mesmo improvável adivinhar a senha por meios manuais ou automatizados. As seguintes características definem uma senha forte:

## Comprimento da senha

* O comprimento mínimo das senhas deve ser imposto pelo aplicativo. As senhas com menos de 8 caracteres são consideradas fracas (NIST SP800-63B). 
* O comprimento máximo da senha não deve ser definido como muito baixo, pois isso evitará que os usuários criem frases-senha. Um comprimento máximo comum é de 64 caracteres devido às limitações em certos algoritmos de hash. É importante definir um comprimento máximo de senha para evitar ataques de negação de serviço de senha longas.
* Não trunque as senhas silenciosamente quando receber senhas maiores que o comprimento máximo.
* Permitir o uso de todos os caracteres, incluindo Unicode e espaços em branco. Não deve haver regras de composição de senha que limitem o tipo de caracteres permitidos.
* Garanta a rotação de credenciais quando houver vazamento de senha ou no momento de identificação de comprometimento.
* Incluir medidor de força de senha para ajudar os usuários a criar uma senha mais complexa e bloquear senhas comuns e anteriormente violadas.

## Referência externa
[OWASP - Senha segura](https://cheatsheetseries.owasp.org/cheatsheets/Authentication_Cheat_Sheet.html#implement-proper-password-strength-controls)