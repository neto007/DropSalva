---
title: Princípio da mediação completa
---
## Descrição

Durante o desenvolvimento do aplicativo, deve haver verificações permanentes para verificar se todas as páginas e recursos, por padrão, exigem autenticação, exceto aqueles especificamente destinados a serem públicos.
Às vezes, os desenvolvedores simplesmente esquecem de implementar essas verificações ou removem-nas temporariamente para fins de teste.

## Solução

Verifique se todos os controles de acesso foram implementados corretamente para impedir que um usuário acesse dados/funções que ele não pretendia usar.