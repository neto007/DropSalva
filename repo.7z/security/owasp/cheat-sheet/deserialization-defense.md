---
title: Deserialização segura
---

## Usando formatos de dados alternativos
Uma grande redução de risco é obtida evitando formatos de (des)serialização nativos. Ao mudar para um formato de dados puro como JSON ou XML, você diminui a chance de a lógica de desserialização personalizada ser reaproveitada para fins maliciosos.

Muitos aplicativos contam com um padrão de objeto de transferência de dados que envolve a criação de um domínio separado de objetos para a transferência de dados de propósito explícito. Obviamente, ainda é possível que o aplicativo cometa erros de segurança depois que um objeto de dados puro for analisado.

## Apenas desserializar dados assinados

Se o aplicativo souber antes da desserialização quais mensagens precisarão ser processadas, ele poderá assiná-las como parte do processo de serialização. O aplicativo poderia então escolher não desserializar qualquer mensagem que não tivesse uma assinatura autenticada.

### Ferramentas/Bibliotecas de mitigação

* [Biblioteca de desserialização segura Java](https://github.com/ikkisoft/SerialKiller)
* [SWAT](https://github.com/cschneider4711/SWAT)
* [NotSoSerial](https://github.com/kantega/notsoserial)

### Ferramentas de detecção

* [Página de dicas de desserialização de Java destinada a pentesters](https://github.com/GrrrDog/Java-Deserialization-Cheat-Sheet)
* [Uma ferramenta de prova de conceito](https://github.com/frohoff/ysoserial)
* [Kits de ferramentas de desserialização de Java](https://github.com/brianwrf/hackUtils)
* [Gerador de carga útil .Net](https://github.com/pwntester/ysoserial.net)
* [Desserialização segura em Java](https://github.com/ikkisoft/SerialKiller)
* [Extensão Serianalyzer](https://github.com/mbechler/serianalyzer)
* [Gerador de carga últil](https://github.com/mbechler/marshalsec)
* [Desserialização em Android](https://github.com/modzero/modjoda)
* __Extensão Burp Suite__
    * JavaSerialKiller](https://github.com/NetSPI/JavaSerialKiller)
    * Scanner de desserialização Java(https://github.com/federicodotta/Java-Deserialization-Scanner)
    * Burp-ysoserial(https://github.com/summitt/burp-ysoserial)
    * SuperSerial(https://github.com/DirectDefense/SuperSerial)
    * SuperSerial-Active(https://github.com/DirectDefense/SuperSerial-Active)

## Referência externa
[OWASP - Desserialização segura](https://cheatsheetseries.owasp.org/cheatsheets/Deserialization_Cheat_Sheet.html)