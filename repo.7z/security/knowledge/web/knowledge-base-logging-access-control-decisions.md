---
title: Registrar ações de controle de acesso
---
## Descrição

As decisões de controle de acesso devem ser registradas para análise forense no caso de ataques de força bruta.
Os logs dos controles de acesso também podem ajudar a controlar possíveis sequestros de sessões ataques. Uma vez que pode ser medido de onde os usuários efetuaram login e quantas sessões simultâneas estão ativas.

## Solução

Verifique se todas as decisões de controle de acesso podem ser registradas e todas as decisões com falha.