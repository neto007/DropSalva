---
title: Cookies De Sessão Sem O Atributo Seguro
---
## Descrição

O sinalizador seguro é uma opção que pode ser definida ao criar um cookie.
Este sinalizador garante que o cookie não será enviado por meio de um não criptografado
conexão pelo navegador, o que garante que o cookie de sessão não possa ser enviado por um link não criptografado.

## Solução

Ao criar um cookie de sessão que é enviado por uma conexão criptografada
você deve definir o sinalizador seguro. O sinalizador Secure deve ser definido durante cada set-cookie.
Isso instruirá o navegador a nunca enviar o cookie por HTTP.
O objetivo deste sinalizador é evitar a exposição acidental de um valor de cookie se um usuário
segue um link HTTP.