---
title: Transação deve ser autorizada usando credenciais de autorização exclusivas
---

Alguns aplicativos estão pedindo credenciais de autorização de transação apenas uma vez, por exemplo, senha estática, código enviado por SMS, resposta de token. Posteriormente, um usuário pode autorizar qualquer transação durante toda a sessão do usuário ou, pelo menos, ele deve reutilizar as mesmas credenciais cada vez que precisar autorizar uma transação. Esse comportamento não é suficiente para evitar ataques de malware, pois o malware detecta essas credenciais e as usa para autorizar qualquer transação sem o conhecimento do usuário.

### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)