---
title: Substituindo padrões para definir cabeçalho personalizado
---

Várias bibliotecas JavaScript permitem substituir as configurações padrão para ter um cabeçalho adicionado automaticamente a todas as solicitações AJAX.

### XMLHttpRequest (JavaScript nativo)

O método `open()` de `XMLHttpRequest` pode ser sobrescrito para definir o `anti-csrf-token` cabeçalho sempre que o `open()` método for chamado em seguida. A função `csrfSafeMethod()` definida abaixo filtrará os métodos HTTP seguros e apenas adicionará o cabeçalho aos métodos HTTP não seguros.

Isso pode ser feito conforme demonstrado no seguinte snippet de código:

```js 

<script type="text/javascript">
    var csrf_token = document.querySelector("meta[name='csrf-token']").getAttribute("content");
    function csrfSafeMethod(method) {
        // these HTTP methods do not require CSRF protection
        return (/^(GET|HEAD|OPTIONS)$/.test(method));
    }
    var o = XMLHttpRequest.prototype.open;
    XMLHttpRequest.prototype.open = function(){
        var res = o.apply(this, arguments);
        var err = new Error();
        if (!csrfSafeMethod(arguments[0])) {
            this.setRequestHeader('anti-csrf-token', csrf_token);
        }
        return res;
    };
 </script>

```

### AngularJS

AngularJS permite definir cabeçalhos padrão para operações HTTP. Documentação adicional pode ser encontrada na documentação do AngularJS para `$httpProvider`.

```js

<script>
    var csrf_token = document.querySelector("meta[name='csrf-token']").getAttribute("content");

    var app = angular.module("app", []);

    app.config(['$httpProvider', function ($httpProvider) {
        $httpProvider.defaults.headers.post["anti-csrf-token"] = csrf_token;
        $httpProvider.defaults.headers.put["anti-csrf-token"] = csrf_token;
        $httpProvider.defaults.headers.patch["anti-csrf-token"] = csrf_token;
        // AngularJS does not create an object for DELETE and TRACE methods by default, and has to be manually created.
        $httpProvider.defaults.headers.delete = {
            "Content-Type" : "application/json;charset=utf-8",
            "anti-csrf-token" : csrf_token
        };
        $httpProvider.defaults.headers.trace = {
            "Content-Type" : "application/json;charset=utf-8",
            "anti-csrf-token" : csrf_token
        };
      }]);
 </script>

 ```

*Este trecho de código foi testado com AngularJS versão 1.7.7.*

### Axios

O Axios nos permite definir cabeçalhos padrão para as ações POST, PUT, DELETE e PATCH.

```js

<script type="text/javascript">
    var csrf_token = document.querySelector("meta[name='csrf-token']").getAttribute("content");

    axios.defaults.headers.post['anti-csrf-token'] = csrf_token;
    axios.defaults.headers.put['anti-csrf-token'] = csrf_token;
    axios.defaults.headers.delete['anti-csrf-token'] = csrf_token;
    axios.defaults.headers.patch['anti-csrf-token'] = csrf_token;

    // Axios does not create an object for TRACE method by default, and has to be created manually.
    axios.defaults.headers.trace = {}
    axios.defaults.headers.trace['anti-csrf-token'] = csrf_token
</script>
```

*Este trecho de código foi testado com Axios versão 0.18.0.*

### JQuery

JQuery expõe uma API chamada `$.ajaxSetup()` que pode ser usada para adicionar o `anti-csrf-token` cabeçalho à solicitação AJAX. A documentação da API para `$.ajaxSetup()` pode ser encontrada aqui. A função `csrfSafeMethod()` definida abaixo filtrará os métodos HTTP seguros e apenas adicionará o cabeçalho aos métodos HTTP não seguros.

Você pode configurar o jQuery para adicionar automaticamente o token a todos os cabeçalhos de solicitação, adotando o seguinte trecho de código. Isso fornece uma proteção CSRF simples e conveniente para seus aplicativos baseados em AJAX:

```js

<script type="text/javascript">
    var csrf_token = $('meta[name="csrf-token"]').attr('content');

    function csrfSafeMethod(method) {
        // these HTTP methods do not require CSRF protection
        return (/^(GET|HEAD|OPTIONS)$/.test(method));
    }

    $.ajaxSetup({
        beforeSend: function(xhr, settings) {
            if (!csrfSafeMethod(settings.type) && !this.crossDomain) {
                xhr.setRequestHeader("anti-csrf-token", csrf_token);
            }
        }
    });
</script>
```

*Este trecho de código foi testado com jQuery versão 3.3.1.*

### Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/)