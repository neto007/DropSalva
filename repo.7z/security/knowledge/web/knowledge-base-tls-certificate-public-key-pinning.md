---
title: Pinning de chave pública de certificado TLS
---
## Descrição

Pinning é o processo de associar um host ao certificado X509 esperado ou
chave pública. Depois que um certificado ou chave pública é conhecido ou visto por um host, o certificado ou a chave pública está associada ou 'fixada' ao host. 
Se houver mais de um certificado ou chave pública aceitável, então o programa contém um conjunto de pinos (retirado da palestra de Jon Larimer e Kenny Root Google I/O). Neste caso, o anunciado a identidade deve corresponder a um dos elementos do conjunto de pinos.

## Solução

A ideia é reutilizar os protocolos e infraestrutura existentes, mas usá-los de uma 
maneira firme/rígida. Para reutilização, um programa continuaria fazendo as coisas que costumava fazer quando estabelecido uma conexão segura.

Para fortalecer o canal, o programa tiraria vantagem do retorno de chamada OnConnect oferecido por uma biblioteca, estrutura ou plataforma. No retorno da chamada, o programa verificaria a identidade do host remoto validando seu certificado ou chave pública. Enquanto a fixação não tem ocorrido em um retorno de chamada OnConnect, muitas vezes é mais conveniente, isso porque as informações de conexão subjacentes estão prontamente disponíveis.

Para maiores informações relacionadas a outros tipos de implementação, acesse o link:
https://www.owasp.org/index.php/Certificate_and_Public_Key_Pinning
