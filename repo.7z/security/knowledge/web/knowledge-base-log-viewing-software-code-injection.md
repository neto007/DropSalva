---
title: Injeção de código para visualização de log
---
## Descrição

Sempre que a entrada fornecida pelo usuário estiver sendo manipulada no software de visualização de logs, este software poderá ser manipulado por possíveis invasores sempre que essa entrada não for adequadamente higienizada antes da saída no software. Dependendo do contexto de onde a entrada fornecida está sendo usada, isso pode levar a um subconjunto inteiro de ataques.

## Solução

Você deve considerar estes três controles ao fornecer informações ao software de visualização de logs:

* Design: Se possível, evite registrar dados provenientes de entradas externas.

* Implementação: Verifique se todas as entradas de log são criadas estaticamente ou se devem registrar dados externos para que a entrada seja vigorosamente verificada na lista branca.

* Run time: Evite exibir logs com ferramentas que possam interpretar caracteres de controle no arquivo, como shells da linha de comando.

Verifique também se todos os símbolos não imprimíveis e separadores de campo estão codificados corretamente nas entradas de log, para evitar a injeção de log.