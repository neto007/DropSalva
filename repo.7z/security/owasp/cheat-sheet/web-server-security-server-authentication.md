---
title: Autenticação de Servidor
---

**Regra**: TLS deve ser usado para autenticar o provedor de serviços para o consumidor do serviço. O consumidor do serviço deve verificar se o certificado do servidor foi emitido por um provedor confiável, não expirou, não foi revogado, corresponde ao nome de domínio do serviço e se o servidor provou que possui a chave privada associada ao certificado de chave pública ( assinando algo apropriadamente ou descriptografando com sucesso algo criptografado com a chave pública associada).

## Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/)
