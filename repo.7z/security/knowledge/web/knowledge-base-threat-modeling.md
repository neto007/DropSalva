---
title: Modelagem de Ameaças
---
## Descrição

A modelagem de ameaças é um procedimento para otimizar a segurança de rede/aplicação/Internet  com objetivo de identificar vulnerabilidades e, em seguida, definir contra-medidas para prevenir, ou mitigar os efeitos de ameaças ao sistema. Uma ameaça é um potencial ou real
evento indesejável que pode ser malicioso (como ataque DoS) ou acidental 
(falha de um dispositivo de armazenamento). A modelagem de ameaças é uma atividade planejada para identificar e avaliar ameaças e vulnerabilidades de aplicações.

## Solução

A modelagem de ameaças é melhor aplicada continuamente ao longo de um projeto de desenvolvimento de software. O processo é essencialmente o mesmo em diferentes níveis de abstração, embora as informações fiquem cada vez mais granulares ao longo do ciclo de vida. Um alto nível de modelagem de ameaça deve ser definido na fase de conceito ou planejamento e, em seguida, refinado ao longo do ciclo de vida. A medida que mais detalhes são adicionados ao sistema, novos vetores de ataque são criados e expostos. 
O processo contínuo de modelagem de ameaças deve examinar, diagnosticar e endereçar essas ameaças.

Observe que é uma parte natural do refinamento de um sistema para que novas ameaças sejam expostas. Por exemplo, quando você seleciona uma tecnologia específica - como Java, por 

exemplo:
você assume a responsabilidade de identificar as novas ameaças criadas por essa escolha.
Mesmo as opções de implementação, como o uso de expressões regulares para validação, apresentam novas ameaças potenciais com as quais lidar.

Maiores informações sobre modelagem de ameaças podem ser encontradas em:
https://www.owasp.org/index.php/Application_Threat_Modeling
