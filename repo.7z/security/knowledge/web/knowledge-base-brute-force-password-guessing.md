---
title: Senha por força bruta
---
## Descrição

As funções de login não devem ser usadas de maneira automatizada para que um invasor possa criar um script que contém uma lista de nomes de usuário e senhas e que ele, assim, poderia usar em sua função de login obtendo acesso não autorizado às contas de usuário.

## Solução

Implemente um método que limite a quantidade de tentativas com ferramentas automatizadas. Alguns exemplos estão usando um método CAPTCHA ou TARPIT (limitador de frequência).

Esteja ciente de que uma simples limitação no número de tentativas pode ser usada como um método para executar ataques de negação de serviço e, portanto, impedir que certos usuários, como o administrador do sistema, efetuem login. Um mecanismo combina tentativas de limite com teste de challenge-response (tentativa-resposta) para evitar esse risco e, ao mesmo tempo, proporcionar comodidade para o login real do usuário. Por exemplo, comece a pedir ao usuário que complete uma pergunta CAPTCHA ou TARPIT durante o logon após um certo número de tentativas.
