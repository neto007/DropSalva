---
title: Sincronismo de horário
---
## Descrição

Todas as fontes de horário devem ser sincronizadas. Por exemplo, diferentes servidores de API ou microsserviços - para impedir que os logs sejam contaminados e se tornem inutilizáveis ​​para forense.

## Solução

As fontes de tempo devem ser sincronizadas para garantir que os logs tenham a hora correta. Se estas fontes de tempo não são sincronizadas, os logs perdem a integridade e podem se tornar não confiáveis pelos investigadores.