---
title: Pinagem de Certificado - IOS
---

[TrustKit](https://github.com/datatheorem/TrustKit), uma biblioteca de fixação SSL de código aberto para iOS e macOS está disponível. Ele fornece uma API fácil de usar para implementar a fixação e foi implantado em muitos aplicativos.

Caso contrário, mais detalhes sobre como a validação de SSL pode ser personalizada no iOS (para implementar a fixação) estão disponíveis na nota técnica de [Avaliação de confiança do servidor HTTPS](https://developer.apple.com/library/archive/technotes/tn2232/_index.html). No entanto, a implementação da validação de pinning do zero deve ser evitada, pois os erros de implementação são extremamente prováveis ​​e geralmente levam a vulnerabilidades graves.

Por fim, se você deseja validar se a fixação foi bem-sucedida, siga as instruções do Guia de teste de segurança móvel para [testar a comunicação de rede](https://github.com/OWASP/owasp-mstg/blob/master/Document/0x04f-Testing-Network-Communication.md#testing-network-communication) e o [teste de rede específico](https://github.com/OWASP/owasp-mstg/blob/master/Document/0x06g-Testing-Network-Communication.md) do [iOS](https://github.com/OWASP/owasp-mstg/blob/master/Document/0x06g-Testing-Network-Communication.md).


