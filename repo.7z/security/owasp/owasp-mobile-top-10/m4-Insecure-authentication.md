---
title: Insecure Authentication
---

## O aplicativo está vulnerável?
Existem muitas maneiras diferentes pelas quais um aplicativo móvel pode sofrer de autenticação insegura:

* Se o aplicativo móvel for capaz de executar anonimamente uma solicitação de serviço de API de back-end sem fornecer um token de acesso, esse aplicativo sofre de autenticação insegura;
* Se o aplicativo móvel armazenar quaisquer senhas ou segredos compartilhados localmente no dispositivo, muito provavelmente sofrerá de autenticação insegura;
* Se o aplicativo móvel usa uma política de senha fraca para simplificar a digitação de uma senha, ele sofre de autenticação insegura; ou
* Se o aplicativo móvel usa um recurso como TouchID, ele sofre de autenticação insegura.

## Cenários de exemplo de ataques
Os cenários a seguir apresentam controles fracos de autenticação ou autorização em aplicativos móveis:

#### Cenário #1 - Solicitações de serviço ocultas: 
Os desenvolvedores presumem que apenas usuários autenticados serão capazes de gerar uma solicitação de serviço que o aplicativo móvel envia ao seu back-end para processamento. Durante o processamento da solicitação, o código do servidor não verifica se a solicitação recebida está associada a um usuário conhecido. Consequentemente, os adversários enviam solicitações de serviço ao serviço de back-end e executam anonimamente a funcionalidade que afeta os usuários legítimos da solução.

#### Cenário #2 - Confiabilidade da interface: 
Os desenvolvedores presumem que apenas usuários autorizados poderão ver a existência de uma função específica em seu aplicativo móvel. Portanto, eles esperam que apenas usuários legitimamente autorizados sejam capazes de emitir a solicitação de serviço de seu dispositivo móvel. O código de back-end que processa a solicitação não se preocupa em verificar se a identidade associada à solicitação está autorizada a executar o serviço. Consequentemente, os adversários são capazes de executar funções administrativas remotas usando contas de usuário com privilégios relativamente baixos.

#### Cenário #3 - Requisitos de usabilidade: 
Devido aos requisitos de usabilidade, os aplicativos móveis permitem senhas com 4 dígitos. O código do servidor armazena corretamente uma versão com hash da senha. No entanto, devido ao comprimento extremamente curto da senha, um adversário será capaz de deduzir rapidamente as senhas originais usando tabelas de hash. Se o arquivo de senha (ou armazenamento de dados) no servidor for comprometido, um adversário será capaz de deduzir rapidamente as senhas dos usuários.

## Como prevenir
Evite os seguintes padrões de design de autenticação de aplicativo móvel inseguro:

#### Padrões fracos
* Se você estiver transferindo um aplicativo da web para seu equivalente móvel, os requisitos de autenticação dos aplicativos móveis devem corresponder aos do componente do aplicativo da web. Portanto, não deve ser possível autenticar com menos fatores de autenticação do que o navegador da web;
* Autenticar um usuário localmente pode levar a vulnerabilidades de desvio do lado do cliente. Se o aplicativo armazena dados localmente, a rotina de autenticação pode ser contornada em dispositivos desbloqueados por meio de manipulação em tempo de execução ou modificação do binário. Se houver um requisito comercial atraente para autenticação offline, consulte M10 para obter orientações adicionais sobre a prevenção de ataques binários contra o aplicativo móvel;
* Sempre que possível, certifique-se de que todas as solicitações de autenticação sejam realizadas no lado do servidor. Após a autenticação bem-sucedida, os dados do aplicativo serão carregados no dispositivo móvel. Isso garantirá que os dados do aplicativo só estarão disponíveis após a autenticação bem-sucedida;
* Se o armazenamento de dados do lado do cliente for necessário, os dados deverão ser criptografados usando uma chave de criptografia que é derivada com segurança das credenciais de login do usuário. Isso garantirá que os dados armazenados do aplicativo só serão acessíveis após a inserção bem-sucedida das credenciais corretas. Existem riscos adicionais de que os dados sejam descriptografados por meio de ataques binários. Consulte M9 para obter orientações adicionais sobre a prevenção de ataques binários que levam ao roubo de dados locais;
* A funcionalidade de autenticação persistente (Lembre-se de mim) implementada em aplicativos móveis nunca deve armazenar a senha de um usuário no dispositivo;
Idealmente, os aplicativos móveis devem utilizar um token de autenticação específico do dispositivo que pode ser revogado no aplicativo móvel pelo usuário. Isso garantirá que o aplicativo possa mitigar o acesso não autorizado de um dispositivo roubado / perdido;
* Não use nenhum valor falsificável para autenticar um usuário. Isso inclui identificadores de dispositivo ou geolocalização;
* A autenticação persistente em aplicativos móveis deve ser implementada como opt-in e não estar habilitada por padrão;
* Se possível, não permita que os usuários forneçam números PIN de 4 dígitos para senhas de autenticação.

#### Reforçar a autenticação

* Os desenvolvedores devem assumir que todos os controles de autorização e autenticação do lado do cliente podem ser contornados por usuários mal-intencionados. Os controles de autorização e autenticação devem ser reforçados no lado do servidor sempre que possível.
* Devido aos requisitos de uso offline, os aplicativos móveis podem ser solicitados a executar a autenticação local ou verificações de autorização dentro do código do aplicativo móvel. Se for esse o caso, os desenvolvedores devem instrumentar verificações de integridade local em seu código para detectar quaisquer alterações de código não autorizadas. Consulte M9 para obter mais informações sobre como detectar e reagir a ataques binários.
