---
title: Renovar a ID da sessão após qualquer alteração do nível de privilégio
---


O ID da sessão deve ser renovado ou regenerado pelo aplicativo da web após qualquer alteração do nível de privilégio na sessão de usuário associada. O cenário mais comum em que a regeneração do ID da sessão é obrigatória é durante o processo de autenticação, pois o nível de privilégio do usuário muda do estado não autenticado (ou anônimo) para o estado autenticado. Outros cenários comuns também devem ser considerados, como alterações de senha, alterações de permissão ou mudança de uma função de usuário regular para uma função de administrador no aplicativo da web. Para todas essas páginas críticas de aplicativos da web, os IDs de sessão anteriores devem ser ignorados, um novo ID de sessão deve ser atribuído a cada nova solicitação recebida para o recurso crítico e o ID de sessão anterior ou antigo deve ser destruído.

As estruturas de desenvolvimento da Web mais comuns fornecem funções e métodos de sessão para renovar o ID da sessão, como request.getSession(true)& HttpSession.invalidate()(J2EE), Session.Abandon()& Response.Cookies.Add(new...)(ASP .NET) ou session_start()& session_regenerate_id(true)(PHP).

A regeneração do ID da sessão é obrigatória para evitar ataques de fixação de sessão , onde um invasor define o ID da sessão no navegador do usuário da vítima em vez de coletar o ID da sessão da vítima, como na maioria dos outros ataques baseados em sessão, e independentemente do uso de HTTP ou HTTPS. Essa proteção atenua o impacto de outras vulnerabilidades baseadas na web que também podem ser usadas para lançar ataques de fixação de sessão, como divisão de resposta HTTP ou XSS (veja aqui e aqui ).

Uma recomendação complementar é usar um ID de sessão diferente ou nome de token (ou conjunto de IDs de sessão) pré e pós-autenticação, de modo que o aplicativo da web possa rastrear usuários anônimos e usuários autenticados sem o risco de expor ou vincular a sessão do usuário entre ambos os estados.

### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)