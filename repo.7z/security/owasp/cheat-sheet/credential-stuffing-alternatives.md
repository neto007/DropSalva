---
title: Alternativas para preenchimento de credenciais
---

### Defesas Alternativas

Onde não é possível implementar o MFA, existem muitas defesas alternativas que podem ser usadas para proteger contra o preenchimento de credenciais e a difusão de senhas. Isoladamente, nenhum deles é tão eficaz quanto o MFA; no entanto, se várias defesas forem implementadas em uma abordagem em camadas, elas podem fornecer um grau razoável de proteção. Em muitos casos, esses mecanismos também protegerão contra ataques de força bruta ou espalhamento de senha.

Quando um aplicativo possui várias funções de usuário, pode ser apropriado implementar diferentes defesas para diferentes funções. Por exemplo, pode não ser viável aplicar o MFA a todos os usuários, mas deve ser possível exigir que todos os administradores o usem.

### Senhas secundárias, PINs e perguntas de segurança

Além de exigir que um usuário digite a senha ao autenticar, ele também pode ser solicitado a fornecer informações de segurança adicionais, como:

### Um PIN

Caracteres específicos de uma senha secundária ou palavra memorável
Respostas a perguntas de segurança
Deve ser enfatizado que isso não constitui autenticação multifator (já que os dois fatores são iguais - algo que você sabe). No entanto, ele ainda pode fornecer uma camada útil de proteção contra o preenchimento de credenciais e a difusão de senhas onde o MFA adequado não pode ser implementado.

### CAPTCHA

Exigir que um usuário resolva um CAPTCHA para cada tentativa de login pode ajudar a evitar tentativas de login automatizadas, o que tornaria significativamente mais lento um ataque de preenchimento de credenciais ou de senha. No entanto, os CAPTCHAs não são perfeitos e, em muitos casos, existem ferramentas que podem ser usadas para quebrá-los com uma taxa de sucesso razoavelmente alta.

Para melhorar a usabilidade, pode ser desejável exigir que o usuário resolva um CAPTCHA apenas quando a solicitação de login for considerada suspeita, usando os mesmos critérios discutidos acima.

### Lista negra de IP

Ataques menos sofisticados geralmente usam um número relativamente pequeno de endereços IP, que podem ser colocados na lista negra após várias tentativas de login malsucedidas. Essas falhas devem ser rastreadas separadamente para as falhas por usuário, que se destinam a proteger contra ataques de força bruta. A lista negra deve ser temporária, a fim de reduzir a probabilidade de bloqueio permanente de usuários legítimos.

Além disso, existem listas negras publicamente disponíveis de endereços IP inválidos conhecidos, coletados por sites como o AbuseIPDB com base em relatórios de abuso de usuários.

Considere armazenar o último endereço IP que se conectou com sucesso a cada conta e, se esse endereço IP for adicionado a uma lista negra, tome as medidas adequadas, como bloquear a conta e notificar o usuário, pois é provável que sua conta tenha sido comprometida.

### Impressão digital do dispositivo

Além do endereço IP, há vários fatores diferentes que podem ser usados ​​para tentar fazer a impressão digital de um dispositivo. Alguns deles podem ser obtidos passivamente pelo servidor a partir dos cabeçalhos HTTP (particularmente o cabeçalho "User-Agent"), incluindo:

- Sistema operacional
- Navegador
- Língua

Usando JavaScript, é possível acessar muito mais informações, como:

- Resolução da tela
- Fontes instaladas
- Plugins de navegador instalados

Usando esses vários atributos, é possível criar uma impressão digital do dispositivo. Essa impressão digital pode então ser comparada com qualquer navegador que tenta fazer login na conta e, se não corresponder, o usuário pode ser solicitado a fornecer autenticação adicional. Muitos usuários terão vários dispositivos ou navegadores para usar, portanto, não é prático bloquear tentativas que não correspondem às impressões digitais existentes.

A biblioteca JavaScript `fingerprintjs2` pode ser usada para realizar impressões digitais do lado do cliente.

Deve-se observar que, como todas essas informações são fornecidas pelo cliente, elas podem ser falsificadas por um invasor. Em alguns casos, falsificar esses atributos é trivial (como o cabeçalho "User-Agent"), mas em outros casos pode ser mais difícil modificar esses atributos.

### Requer nomes de usuário imprevisíveis

Ataques de recheio de credenciais dependem não apenas da reutilização de senhas entre vários sites, mas também da reutilização de nomes de usuário. Um número significativo de sites usa o endereço de e-mail como nome de usuário e, como a maioria dos usuários terá um único endereço de e-mail para todas as suas contas, isso torna a combinação de endereço de e-mail e senha muito eficaz para ataques de preenchimento de credenciais.

Exigir que os usuários criem seu próprio nome de usuário ao se registrar no site torna mais difícil para um invasor obter pares válidos de nome de usuário e senha para enchimento de credenciais, já que muitas das listas de credenciais disponíveis incluem apenas endereços de e-mail. Fornecer ao usuário um nome de usuário gerado pode fornecer um maior grau de proteção (já que os usuários provavelmente escolherão o mesmo nome de usuário na maioria dos sites), mas é amigável. Além disso, é necessário ter cuidado para garantir que o nome de usuário gerado não seja previsível (como ser baseado no nome completo do usuário ou IDs numéricos sequenciais), pois isso pode facilitar a enumeração de nomes de usuário válidos para um ataque de difusão de senha.

### Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/)