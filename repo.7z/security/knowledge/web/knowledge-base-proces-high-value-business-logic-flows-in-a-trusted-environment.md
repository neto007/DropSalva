---
title: Processo de fluxo lógico de alto valor para o negócio em um ambiente confiável
---
## Descrição

Sempre que os fluxos lógicos de negócios de alto valor são processados em um ambiente monitorado confiável, reduz a mobilidade de um invasor e as chances de êxito em executar ataques bem-sucedidos. Se um invasor violar seu aplicativo, suas ações podem ser seguidas rapidamente e medidas preventivas podem ser tomadas.

## Solução

Verifique os processos do aplicativo ou todos os fluxos lógicos de negócios de alto valor em um ambiente confiável, como em um servidor protegido e monitorado.
