---
title: Bloquear senha comum e senhas fracas
---
## Descrição

Os aplicativos devem incentivar o uso de senhas e frases secretas fortes. Preferencialmente a política de senhas não deve colocar limitações ou restrições na escolha de senhas. No entanto, sempre que a aplicação suportar senhas fortes e uso de gerenciadores de senhas, a possibilidade de um atacante realizar um ataque de força bruta bem-sucedido cairá significativamente. Isso também aumenta a possibilidade da aplicação poder usar os gerenciadores de senhas dos usuários.

## Solução

Os campos "verificar entrada de senha" permitem ou incentivam o uso de senhas e não impedem gerenciadores de senhas, senhas longas ou senhas altamente complexas ser inseridas.