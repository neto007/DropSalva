---
title: Expiração da Sessão
---

Para minimizar o período de tempo que um invasor pode lançar ataques em sessões ativas e sequestrá-los, é obrigatório definir tempos limite de expiração para cada sessão, estabelecendo por quanto tempo uma sessão permanecerá ativa. A expiração de sessão insuficiente pelo aplicativo da web aumenta a exposição de outros ataques baseados em sessão, pois para o invasor ser capaz de reutilizar uma ID de sessão válida e sequestrar a sessão associada, ela ainda deve estar ativa.

Quanto mais curto for o intervalo da sessão, menor será o tempo que o invasor terá para usar a ID de sessão válida. Os valores de tempo limite de expiração da sessão devem ser configurados de acordo com a finalidade e a natureza do aplicativo da web e equilibrar segurança e usabilidade, para que o usuário possa completar confortavelmente as operações dentro do aplicativo da web sem que sua sessão expire frequentemente.

Os valores de tempo limite inativo e absoluto são altamente dependentes de quão críticos são o aplicativo da web e seus dados. Os intervalos de tempo limite ocioso comuns são de 2 a 5 minutos para aplicativos de alto valor e 15 a 30 minutos para aplicativos de baixo risco. Os tempos limite absolutos dependem de quanto tempo um usuário geralmente usa o aplicativo. Se o aplicativo for para ser usado por um funcionário de escritório por um dia inteiro, um intervalo de tempo limite absoluto apropriado pode ser entre 4 e 8 horas.

Quando uma sessão expira, o aplicativo da web deve executar ações ativas para invalidar a sessão em ambos os lados, cliente e servidor. Este último é o mais relevante e obrigatório do ponto de vista da segurança.

Para a maioria dos mecanismos de troca de sessão, as ações do lado do cliente para invalidar o ID da sessão são baseadas na limpeza do valor do token. Por exemplo, para invalidar um cookie, é recomendável fornecer um valor vazio (ou inválido) para o ID da sessão e definir o atributo Expires(ou Max-Age) para uma data do passado (no caso de um cookie persistente estar sendo usado):Set-Cookie: id=; Expires=Friday, 17-May-03 18:45:00 GMT

Para fechar e invalidar a sessão no lado do servidor, é obrigatório que o aplicativo da web execute ações ativas quando a sessão expira, ou o usuário se desconecta ativamente, usando as funções e métodos oferecidos pelos mecanismos de gerenciamento de sessão, tais como HttpSession.invalidate()(J2EE), Session.Abandon()(ASP .NET) ou session_destroy()/unset()(PHP).


### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)