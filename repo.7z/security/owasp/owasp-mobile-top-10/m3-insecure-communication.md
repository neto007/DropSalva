---
title: Insecure Communication
---

## O aplicativo está vulnerável?
Esse risco cobre todos os aspectos da obtenção de dados do ponto A ao ponto B, mas de forma insegura. Abrange comunicações móveis-para-móveis, comunicações de aplicativos para servidores ou comunicações móveis-para-alguma-outra-coisa. Este risco inclui todas as tecnologias de comunicação que um dispositivo móvel pode usar: TCP/IP, WiFi, Bluetooth/Bluetooth-LE, NFC, áudio, infravermelho, GSM, 3G, SMS, etc.

>Todos os problemas de comunicação TLS vão aqui. Todos os problemas de NFC, Bluetooth e WiFi vão aqui.

As características proeminentes incluem empacotar algum tipo de dados confidenciais e transmiti-los para dentro ou para fora do dispositivo. Alguns exemplos de dados confidenciais incluem chaves de criptografia, senhas, informações privadas do usuário, detalhes da conta, tokens de sessão, documentos, metadados e binários. Os dados confidenciais podem estar vindo de um servidor para o dispositivo, podem vir de um aplicativo para um servidor ou podem estar indo entre o dispositivo e outro local (por exemplo, um terminal NFC ou cartão NFC). A característica definidora desse risco é a existência de dois dispositivos e alguns dados passando entre eles.

Se os dados estiverem sendo armazenados localmente no próprio dispositivo, isso é **Insecure Data Storage**. Se os detalhes da sessão são comunicados com segurança (por exemplo, por meio de uma conexão TLS forte), mas o identificador da sessão em si é ruim (talvez seja previsível, baixa entropia, etc.), então isso é um problema de **Insecure Authentication**, não um problema de comunicação.

Os riscos usuais de comunicação insegura estão em torno da integridade dos dados, confidencialidade dos dados e integridade da origem. Se os dados podem ser alterados durante o trânsito, sem que a alteração seja detectável (por exemplo, por meio de um ataque man-in-the-middle), então esse é um bom exemplo desse risco. Se os dados confidenciais podem ser expostos, aprendidos ou derivados observando as comunicações enquanto elas acontecem (ou seja, espionagem) ou gravando a conversa enquanto ela acontece e atacando-a mais tarde (ataque offline), isso também é um problema de comunicação inseguro. Deixar de configurar e validar adequadamente uma conexão TLS (por exemplo, verificação de certificado, cifras fracas, outros problemas de configuração de TLS) são tudo isso em uma comunicação insegura.

## Cenários de exemplo de ataques
Existem alguns cenários comuns que os _pentesters_ frequentemente descobrem ao inspecionar a segurança de comunicação de um aplicativo móvel:

#### Falta de inspeção de certificado
O aplicativo móvel e um endpoint se conectam com sucesso e realizam um handshake TLS para estabelecer um canal seguro. No entanto, o aplicativo móvel falha ao inspecionar o certificado oferecido pelo servidor e o aplicativo móvel aceita incondicionalmente qualquer certificado oferecido a ele pelo servidor. Isso destrói qualquer capacidade de autenticação mútua entre o aplicativo móvel e o terminal. O aplicativo móvel é suscetível a ataques man-in-the-middle por meio de um proxy TLS.

#### Negociação de handshake fraca
O aplicativo móvel e um endpoint conectam-se e negociam com êxito um pacote de criptografia como parte do handshake de conexão. O cliente negocia com sucesso com o servidor para usar um pacote de criptografia fraco que resulta em criptografia fraca que pode ser facilmente descriptografada pelo adversário. Isso compromete a confidencialidade do canal entre o aplicativo móvel e o terminal.

#### Vazamento de informações de privacidade
O aplicativo móvel transmite informações de identificação pessoal para um endpoint por meio de canais não seguros em vez de SSL. Isso compromete a confidencialidade de quaisquer dados relacionados à privacidade entre o aplicativo móvel e o terminal.

## Como prevenir

* Suponha que a camada de rede não seja segura e seja suscetível a espionagem.
* Aplique SSL/TLS para transportar canais que o aplicativo móvel usará para transmitir informações confidenciais, tokens de sessão ou outros dados confidenciais para uma API de back-end ou serviço da web.
* Conta também para entidades externas, como empresas de análise de terceiros, redes sociais, etc., usando suas versões SSL quando um aplicativo executa uma rotina por meio do navegador/webkit. Evite sessões SSL mistas, pois elas podem expor o ID de sessão do usuário.
* Use conjuntos de criptografia robustos e padrão da indústria com comprimentos de chave apropriados.
* Use certificados assinados por um provedor de CA confiável. Nunca permita certificados autoassinados e considere a fixação de certificados para aplicativos preocupados com a segurança.
* Sempre exija verificação de cadeia SSL.
* Somente estabeleça uma conexão segura após verificar a identidade do servidor de endpoint usando certificados confiáveis ​​na cadeia de chaves.
* Alerte os usuários por meio da IU se o aplicativo móvel detectar um certificado inválido.
* Não envie dados confidenciais por canais alternativos (por exemplo, SMS, MMS ou notificações).
* Se possível, aplique uma camada separada de criptografia a todos os dados confidenciais antes de serem fornecidos ao canal SSL. No caso de futuras vulnerabilidades serem descobertas na implementação SSL, os dados criptografados fornecerão uma defesa secundária contra violação de confidencialidade.
* Ameaças mais recentes permitem que um adversário escute o tráfego confidencial interceptando o tráfego dentro do dispositivo móvel antes que a biblioteca SSL do dispositivo móvel criptografe e transmita o tráfego de rede ao servidor de destino. Consulte M10 para obter mais informações sobre a natureza desse risco.

#### Práticas recomendadas específicas para iOS
As classes padrão na versão mais recente do iOS lidam muito bem com a negociação de força de cifra SSL. O problema surge quando os desenvolvedores adicionam código temporariamente para contornar esses padrões para acomodar os obstáculos de desenvolvimento. Além das práticas gerais acima:

* Certifique-se de que os certificados são válidos e não fecham.
* Ao usar CFNetwork, considere usar a API de transporte seguro para designar certificados de cliente confiáveis. * Em quase todas as situações, NSStreamSocketSecurityLevelTLSv1 deve ser usado para maior força de codificação padrão.
* Após o desenvolvimento, certifique-se de que todas as chamadas NSURL (ou wrappers de NSURL) não permitem certificados autoassinados ou inválidos, como o método da classe NSURL setAllowsAnyHTTPSCertificate.
Considere usar a fixação de certificado fazendo o seguinte: exporte seu certificado, inclua-o em seu pacote de aplicativos e ancore-o em seu objeto de confiança. Usando o método de conexão NSURL: willSendRequestForAuthenticationChallenge: agora aceitará seu certificado. 

#### Práticas recomendadas específicas para Android
Remova todo o código após o ciclo de desenvolvimento que pode permitir que o aplicativo aceite todos os certificados, como org.apache.http.conn.ssl.AllowAllHostnameVerifier ou SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER. Isso é equivalente a confiar em todos os certificados.
Se estiver usando uma classe que estende SSLSocketFactory, certifique-se de que o método checkServerTrusted esteja implementado corretamente para que o certificado do servidor seja verificado corretamente.

