---
title: Preenchimento de credenciais (stuffing)
---

Esta página cobre as defesas contra dois tipos comuns de ataques relacionados à autenticação: preenchimento de credenciais e difusão de senha. Embora esses ataques sejam separados e distintos, em muitos casos as defesas que seriam implementadas para protegê-los são as mesmas e também seriam eficazes na proteção contra ataques de força bruta. Um resumo desses diferentes ataques está listado abaixo:

| Tipo de Ataque         	| Descrição                                                                    	|
|------------------------	|------------------------------------------------------------------------------	|
| Força bruta            	| Testar várias senhas de dicionário ou outra fonte em uma única conta.        	|
| Recheio de credenciais 	| Testando pares de nome de usuário / senha obtidos da violação de outro site. 	|
| Pulverização de senha  	| Testando uma única senha fraca em um grande número de contas diferentes      	|


### Autenticação multifator

A autenticação multifator (MFA) é de longe a melhor defesa contra a maioria dos ataques relacionados a senhas, incluindo preenchimento de credenciais e difusão de senhas, com análises da Microsoft sugerindo que teria interrompido 99,9% dos comprometimentos de contas . Como tal, deve ser implementado sempre que possível; no entanto, dependendo do público-alvo da aplicação, pode não ser prático ou viável impor o uso do MFA.

A fim de equilibrar segurança e usabilidade, a autenticação multifator pode ser combinada com outras técnicas para exigir o segundo fator apenas em circunstâncias específicas em que haja razão para suspeitar que a tentativa de login pode não ser legítima, como um login de:

- Um novo navegador / dispositivo ou endereço IP.
- Um país ou local incomum.
- Países específicos que são considerados não confiáveis.
- Um endereço IP que aparece em listas negras conhecidas.
- Um endereço IP que tentou fazer login em várias contas.
- Uma tentativa de login que parece ser baseada em script em vez de manual.
- Além disso, para aplicativos corporativos, intervalos de IP confiáveis ​​conhecidos podem ser adicionados a uma lista de permissões para que o MFA não seja necessário quando os usuários se conectam a partir desses intervalos.

### Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/)