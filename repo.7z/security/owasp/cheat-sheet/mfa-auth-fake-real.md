---
title: Distinguir o processo legitimo do fraudulento
---

O malware pode enganar os usuários ao autorizar operações fraudulentas, quando um aplicativo exige que um usuário execute as mesmas ações para autenticação e autorização de transação. Considere o seguinte exemplo:

- Um aplicativo está usando o mesmo método para autenticação de usuário (geralmente como um segundo fator para o login / senha tradicional) e para autorização de transação. 
Por exemplo, usando um token OTP, códigos de resposta de desafio, assinatura de operação usando smartcard externo,

- Um malware pode apresentar ao usuário uma mensagem de erro falsa após a primeira etapa (autenticação para o aplicativo) e induzir o usuário a repetir o procedimento de autenticação. O primeiro código de autenticação será usado pelo malware para autenticação, enquanto o segundo código será usado para autorizar uma transação fraudulenta. Mesmo os esquemas de desafio-resposta podem ser abusados ​​usando esse cenário, pois o malware pode apresentar um desafio retirado de uma transação fraudulenta e enganar o usuário para fornecer uma resposta. Esse cenário de ataque é amplamente usado em ataques de malware contra banco eletrônico .

No cenário acima mencionado, o mesmo método foi utilizado para autenticar o usuário e autorizar a transação. Malware pode abusar desse comportamento para extrair credenciais de autorização de transação sem o conhecimento do usuário. Métodos de engenharia social podem ser usados ​​apesar dos métodos de autenticação e autorização de operação utilizados, mas o aplicativo não deve simplificar esses cenários de ataque.

As proteções devem permitir ao usuário distinguir facilmente a autenticação da autorização da transação. Isso pode ser alcançado por:

- Usando métodos diferentes para autenticar e autorizar,

- Ou usando diferentes ações em um componente de segurança externo (por exemplo, modo diferente de operação no leitor CAP),

- Ou apresentar ao usuário uma mensagem clara sobre o que ele está "assinando" (princípio do que você vê é o que você assina).

### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)