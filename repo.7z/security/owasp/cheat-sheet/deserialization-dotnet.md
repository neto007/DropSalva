---
title: Desserialização segura em .Net
---

## Análise WhiteBox
Pesquise o código-fonte para os seguintes termos:

* TypeNameHandling
* JavaScriptTypeResolver

Procure qualquer serializador em que o tipo seja definido por uma variável controlada pelo usuário.

## Avaliação do BlackBox
Pesquise o seguinte conteúdo codificado em base64 que começa com:

`AAEAAAD/////`

Pesquise conteúdo com o seguinte texto:

* TypeObject
* $type:

## Precauções gerais
Não permita que o fluxo de dados defina o tipo de objeto para o qual o fluxo será desserializado. Você pode evitar isso, por exemplo, usando o `DataContractSerializerou` ou `XmlSerializer` se possível.

Onde JSON.Net está sendo usado, certifique-se de que "TypeNameHandling" está definido apenas como None.

`TypeNameHandling = TypeNameHandling.None`

Se "JavaScriptSerializer" for para ser usado, não o use com um "JavaScriptTypeResolver".

Se você precisar desserializar os fluxos de dados que definem seu próprio tipo, restrinja os tipos que podem ser desserializados. Deve-se estar ciente de que isso ainda é arriscado, pois muitos tipos .Net nativos são potencialmente perigosos por si próprio. por exemplo:

`System.IO.FileInfo`

`FileInfo` objetos que fazem referência a arquivos realmente no servidor podem, quando desserializados, alterar as propriedades desses arquivos, por exemplo, para somente leitura, criando um potencial ataque de negação de serviço.

Mesmo que você tenha limitado os tipos que podem ser desserializados, lembre-se de que alguns tipos têm propriedades arriscadas. `System.ComponentModel`.`DataAnnotations.ValidationException`, por exemplo, tem uma propriedade do tipo "Object". se esse tipo for o tipo permitido para desserialização, um invasor poderá definir a propriedade para qualquer tipo de objeto que escolher.

Os atacantes devem ser impedidos de direcionar o tipo que será instanciado. Se isso for possível, mesmo `DataContractSerializer ` ou `XmlSerializer`pode ser subvertido, por exemplo:

```csharp
// Action below is dangerous if the attacker can change the data in the database
var typename = GetTransactionTypeFromDatabase();
var serializer = new DataContractJsonSerializer(Type.GetType(typename));
var obj = serializer.ReadObject(ms);
```
A execução pode ocorrer dentro de certos tipos .Net durante a desserialização. Criar um controle como o mostrado abaixo é ineficaz.

```c#
var suspectObject = myBinaryFormatter.Deserialize(untrustedData);

//Check below is too late! Execution may have already occurred.
if (suspectObject is SomeDangerousObjectType)
{
    //generate warnings and dispose of suspectObject
}
```

Para o "BinaryFormatter" e "JSON.Net" é possível criar uma forma mais segura de controle de lista de permissões usando um personalizado `SerializationBinder`.

Tente se manter atualizado sobre os gadgets de desserialização não seguros .Net conhecidos e preste atenção especial onde esses tipos podem ser criados por seus processos de desserialização. Um desserializador só pode instanciar tipos que ele conhece.

Tente manter qualquer código que possa criar gadgets em potencial separado de qualquer código que tenha conectividade com a Internet. Como exemplo `System.Windows.Data.ObjectDataProvider` usado em aplicativos WPF é um dispositivo conhecido que permite a invocação de método arbitrário. Seria arriscado ter essa referência a esse assembly em um projeto de serviço REST que desserializa dados não confiáveis.

## Gadgets .NET RCE conhecidos
* `System.Configuration.Install.AssemblyInstaller`
* `System.Activities.Presentation.WorkflowDesigner`
* `System.Windows.ResourceDictionary`
* `System.Windows.Data.ObjectDataProvider`
* `System.Windows.Forms.BindingSource`
* `Microsoft.Exchange.Management.SystemManager.WinForms.ExchangeSettingsProvider`
* `System.Data.DataViewManager, System.Xml.XmlDocument/XmlDataDocument`
* `System.Management.Automation.PSObject`

## Referência externa
[OWASP - Desserialização segura](https://cheatsheetseries.owasp.org/cheatsheets/Deserialization_Cheat_Sheet.html)
