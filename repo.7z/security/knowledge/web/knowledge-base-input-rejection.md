---
title: Rejeição de Input
---
## Descrição

Sempre que o aplicativo detectar entrada maliciosa ou inesperada do usuário, verifique se
o aplicativo atual rejeita a entrada do usuário enviada em vez de processá-la diretamente.

## Solução

Verifique se o aplicativo realmente rejeita as solicitações do usuário sempre que uma entrada maliciosa é detectado pelo seu aplicativo. A base deste processo estará verificando a aplicação pela entrada esperada de usuário, por exemplo: Sempre que o usuário estiver preenchendo um formulário que contém uma caixa de seleção, existem valores fixos que seu aplicativo pode esperar o usuário retornar. Sempre que esse valor difere do que o aplicativo serviu ao usuário como respostas possíveis, você pode assumir que a solicitação foi corrompida e rejeitar a solicitação.

Você também deve acompanhar os movimentos dos usuários adicionando uma trilha de auditoria e uma contador para rastrear o número de violações dele (enviando entrada incorreta) em sua entrada classe de validação. Você deve aplicar um bloqueio sempre que um número razoável de
violações sejam detectadas pelo seu aplicativo para protegê-lo contra invasores.