---
title: Perfil de segurança de endpoint
---

Regra : Os serviços da Web devem ser compatíveis com o Perfil Básico de Interoperabilidade de Serviços da Web (WS-I), no mínimo.

## Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/)
