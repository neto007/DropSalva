---
title: Redirecionamento Url perigosos
---

Os exemplos a seguir demonstram redirecionar e encaminhar códigos inseguros.

O seguinte código Java recebe o URL do parâmetro denominado url( GET ou POST ) e redireciona para esse URL:

`response.sendRedirect(request.getParameter("url"));`

O código `PHP` a seguir obtém um `URL` da string de consulta (por meio do parâmetro denominado url) e redireciona o usuário para esse `URL`. Além disso, o código `PHP` após esta `header()` função continuará a ser executado, portanto, se o usuário configurar seu navegador para ignorar o redirecionamento, ele poderá acessar o restante da página.

```php

$redirect_url = $_GET['url'];
header("Location: " . $redirect_url);
```

Um exemplo semelhante de código vulnerável C # .NET:

```csharp

string url = request.QueryString["url"];
Response.Redirect(url);

```
E no Rails:

`redirect_to params[:url]`
