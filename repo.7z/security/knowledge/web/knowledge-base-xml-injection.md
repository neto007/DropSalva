---
title: Injeção XML
---
## Descrição

XML Injection é uma técnica de ataque usada para manipular ou comprometer a lógica de um XML
aplicativo ou serviço. A injeção de conteúdo e / ou estruturas XML não intencionais em uma mensagem XML pode alterar a lógica pretendida do aplicativo. Além disso, injeção de XML
pode causar a inserção de conteúdo malicioso na mensagem / documento resultante.

## Solução

Além da validação de entrada existente, defina uma abordagem positiva que escapa / codifica caracteres que podem ser interpretados como XML. No mínimo, isso inclui o seguinte: ` <> / "'`