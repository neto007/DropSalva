---
title: Manipulação de exceção
---
## Descrição
O tratamento de exceções é o processo de responder à ocorrência, durante o cálculo,
de exceções - condições anômalas ou excepcionais que requerem processamento especial
interrompendo frequentemente o fluxo normal da execução do programa. É fornecido por especialistas construções de linguagem de programação, mecanismos de hardware de computador, como interrupções ou operação instalações IPC do sistema, como sinais.

Em geral, uma exceção interrompe o fluxo normal de execução e executa um pré-registro
manipulador de exceção. Os detalhes de como isso é feito dependem se é um hardware ou
exceção de software e como a exceção de software é implementada. Algumas exceções,
especialmente os de hardware, podem ser manuseados tão graciosamente que a execução pode continuar onde foi interrompida.

Abordagens alternativas para o tratamento de exceções no software são a verificação de erros, que mantém o fluxo normal do programa com verificações explícitas posteriores para contingências relatado usando valores de retorno especiais ou alguma variável global auxiliar como sinalizadores de status de errno ou ponto flutuante de C; ou validação de entrada para preventivamente filtrar casos excepcionais.

## Solução

Ao capturar todos os diferentes erros e exceções, seu programa nunca será redirecionado em um fluxo de execução que causa comportamento inesperado. Esse comportamento pode incluir ignorar a autorização lógica ou outras verificações de sanidade que poderiam ser usadas para atacar o sistema de destino.