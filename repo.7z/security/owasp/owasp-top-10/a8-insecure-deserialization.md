---
title: A8 Insecure deserialization
---

## A Aplicação é Vulnerável?
Aplicações e APIs são vulneráveis se desserializarem dados não confiáveis ou objetos adulterados fornecidos pelo atacante. Isto resulta em dois tipos principais de ataques:

* Ataques relacionados com objetos e estruturas de dados em que o atacante consegue modificar lógica aplicacional ou executar remotamente código arbitrário se existirem classes cujo comportamento possa ser alterado durante ou depois da desserialização.
* Ataques de adulteração de dados, tais como os relacionados com o controlo de acessos, onde são utilizadas estruturas de dados existentes mas cujo conteúdo foi alterado. A serialização pode ser usada numa aplicação para:
* Comunicação remota e inter-processos (RPC/IPC)
* Wire protocols, web services, message brokers
* Caching/Persistência
* Base de Dados, servidores de cache, sistemas de ficheiros
* HTTP cookies, parâmetros de formulários HTML, tokens de autenticação em APIs

## Exemplos de Cenários de Ataque
#### Cenário #1: 
Uma aplicação de React invoca um conjunto de micro-serviços Spring Boot. Tratando-se de programadores funcionais, tentaram assegurar que o seu código fosse imutável. A solução que arranjaram foi serializar o estado do utilizador e passar o mesmo de um lado para o outro em cada um dos pedidos. Um atacante apercebe-se da existência do objecto Java "R00", e usa a ferramenta Java Serial Killer para ganhar a possibilidade de executar código remoto no servidor aplicacional.
#### Cenário #2: 
Um fórum de PHP usa a serialização de objetos PHP para gravar um "super" cookie que contém o identificador (ID) do utilizador, o seu papel, o resumo (hash) da sua password e outros estados:

```php
 a:4:{i:0;i:132;i:1;s:7:"Mallory";i:2;s:4:"user";  i:3;s:32:"b6a8b3bea87fe0e05022f8f3c88bc960";}
#Um atacante pode mudar o objeto serializado para lhe dar privilégios de administrador:
 a:4:{i:0;i:1;i:1;s:5:"Alice";i:2;s:5:"admin"; i:3;s:32:"b6a8b3bea87fe0e05022f8f3c88bc960";}
```
## Como Prevenir
A única forma segura de utilizar serialização pressupõe que não são aceites objetos serializados de fontes não confiáveis e que só são permitidos tipos de dados primitivos. Se isto não for possível, considere uma ou mais das seguintes recomendações:

* Implementar verificações de integridade como assinatura digital nos objetos serializados como forma de prevenir a criação de dados hostis ou adulteração de dados
* Aplicar uma política rigorosa de tipos de dados durante a desserialização, antes da criação do objeto uma vez que a
lógica tipicamente espera um conjunto de classes bem definido. Uma vez que existem formas demonstradas de
contornar esta técnica, ela não deve ser usada individualmente.
* Isolar e correr a lógica de desserialização, sempre que possível, num ambiente com privilégios mínimos.
* Registar exceções e falhas na desserialização tais como tipos de dados não expectáveis.
* Restringir e monitorizar o tráfego de entrada e saída dos containers e servidores que realizam desserialização.
* Monitorizar a desserialização, gerando alertas quando esta operação é realizada com frequência anómala.
