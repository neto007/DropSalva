---
title: Atenuar ataques de dumping de memória
---
## Descrição

Sempre que informações confidenciais são armazenadas na memória dos dispositivos, essas informações podem ser despejadas por várias ferramentas, como "android debugger (ADB)", em dispositivos Android. Essas informações podem fornecer informações críticas sobre o aplicativo e ajudar os invasores em seus ataques.

## Solução

As informações confidenciais mantidas na memória devem ser substituídas por zeros assim que não forem mais ativamente usadas, para reduzir os ataques de despejo de memória.

>Nota: Sempre que a linguagem de programação possuir um coletor de lixo, verifique sempre que os valores são zerados, o GC também é esvaziado.