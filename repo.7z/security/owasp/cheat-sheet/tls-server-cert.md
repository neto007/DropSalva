---
title: Certificados
---

A chave privada usada para gerar a chave de cifra deve ser suficientemente forte para o tempo de vida previsto da chave privada e do certificado correspondente. A prática recomendada atual é selecionar um tamanho de chave de pelo menos 2.048 bits. Informações adicionais sobre a vida útil e as forças comparáveis ​​principais podem ser encontradas aqui e no NIST SP 800-57 .

A chave privada também deve ser protegida contra acesso não autorizado usando permissões do sistema de arquivos e outros controles técnicos e administrativos.

### Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/)
