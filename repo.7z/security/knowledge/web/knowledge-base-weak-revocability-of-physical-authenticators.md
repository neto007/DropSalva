---
title: Revogabilidade Fraca De Autenticadores Físicos
---

## Descrição

Os autenticadores físicos são muito poderosos e possuem algumas vantagens, porém devem ser considerados comprometidos, caso tenham sido roubados ou desaparecidos. Nesse caso, o usuário (proprietário do token físico) precisa revogar esses tokens. Se o processo de revogação não for eficaz, o invasor poderá usá-lo em nome do proprietário e obter acesso aos seus recursos.

## Solução

Certifique-se de que a revogação seja imediatamente efetiva em todos os Provedores de Identidade e Partes Confiantes.
