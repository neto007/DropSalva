---
title: Credenciais do usuário em registros de auditoria
---
## Descrição

Sempre que houver credenciais de usuário fornecidas em um registro de auditoria,
isso pode se tornar um risco sempre que um invasor conseguir acessar um desses arquivos de log.

## Solução

Em vez de armazenar as credenciais do usuário, você pode usar IDs de usuário para
identificar o usuário nos arquivos de log.