---
title: Afirmações
---

Os componentes de asserção restringem a existência e os valores de elementos e atributos relacionados em esquemas `XML`. Um elemento ou atributo será considerado válido em relação a uma asserção apenas se o teste for avaliado como verdadeiro sem gerar nenhum erro. A variável `$value` pode ser usada para fazer referência ao conteúdo do valor que está sendo analisado. As consequências potenciais do uso de tipos de dados contendo o valor zero para denominadores, propondo um tipo de dados contendo apenas valores positivos. Um exemplo oposto consideraria válido todo o intervalo de números, exceto zero. Para evitar a divulgação de erros potenciais, os valores podem ser verificados usando um `assertion` não permitido o número zero:


```xml

<xs:element name="denominator">
 <xs:simpleType>
  <xs:restriction base="xs:integer">
   <xs:assertion test="$value != 0"/>
  </xs:restriction>
 </xs:simpleType>
</xs:element>

```

A declaração garante que `denominator` não conterá o valor zero como um número válido e também permite que números negativos sejam um denominador válido.

## Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/cheatsheets/XML_Security_Cheat_Sheet.html)
