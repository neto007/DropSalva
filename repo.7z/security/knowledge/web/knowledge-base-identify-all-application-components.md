---
title: Identificar todos os componentes da aplicação
---
## Descrição

Ao criar um aplicativo, primeiro você deseja mapear onde está colocando
arquivos de origem, bibliotecas e executáveis.

Com esses componentes identificados e mapeados, isto torna transparente onde possíveis
armadilhas podem estar em sua aplicação e aumenta a capacidade de manutenção do
sistema. Além disso, você tem um indicador onde possíveis reforços devem ser
implementados para evitar ataques (por exemplo, locais em que seu aplicativo contém executáveis)

## Solução

Verifique se todos os componentes do aplicativo (individuais ou grupos de arquivos de origem,
bibliotecas e / ou executáveis) que estão presentes no aplicativo são identificados. 
Quando você identificou esses componentes você pode querer mapeá-los e documentá-los de modo 
a ter uma referência rápida a essa infraestrutura, quando necessário.
