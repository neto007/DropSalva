---
title: Defesa profunda de enchimento de credenciais
---

### Defesa em profundidade

Os mecanismos a seguir não são suficientes para evitar o preenchimento de credenciais ou ataques de difusão de senha; no entanto, eles podem ser usados ​​para tornar os ataques mais demorados ou tecnicamente difíceis de implementar. Isso pode ser útil para se defender de invasores oportunistas, que usam ferramentas prontas para uso e provavelmente serão desencorajados por quaisquer barreiras técnicas, mas não será suficiente contra um ataque mais direcionado.

### Processos de login de várias etapas

A maioria das ferramentas disponíveis no mercado é projetada para um processo de login de etapa única, em que as credenciais são postadas no servidor e a resposta indica se a tentativa de login foi bem-sucedida ou não. Ao adicionar etapas adicionais a este processo, como exigir que o nome de usuário e a senha sejam inseridos sequencialmente ou exigir que o usuário obtenha primeiro um token CSRF aleatório antes de poder fazer o login, isso torna o ataque um pouco mais difícil de executar e dobra o número de solicitações que o invasor deve fazer.

### Exigir JavaScript e bloquear navegadores sem cabeçalho

A maioria das ferramentas usadas para esses tipos de ataques farão solicitações POST diretas ao servidor e lerão as respostas, mas não farão o download ou executarão o JavaScript contido nelas. Ao exigir que o invasor avalie o JavaScript na resposta (por exemplo, para gerar um token válido que deve ser enviado com a solicitação), isso força o invasor a usar um navegador real com uma estrutura de automação como Selenium ou Headless Chrome, ou implementar Análise de JavaScript com outra ferramenta como o PhantomJS. Além disso, existem várias técnicas que podem ser usadas para identificar Headless Chrome ou PhantomJS .

Observe que bloquear visitantes com JavaScript desativado reduzirá a acessibilidade do site, especialmente para visitantes que usam leitores de tela. Em certas jurisdições, isso pode ser uma violação da legislação de igualdade.

### Identificação de senha vazada

Quando um usuário define uma nova senha no aplicativo, além de compará-la com uma lista de senhas fracas conhecidas, também pode ser verificada com as senhas que foram violadas anteriormente. O serviço público mais conhecido para isso é a senha Pwned . Você mesmo pode hospedar uma cópia do aplicativo ou usar a API .

A fim de proteger o valor da senha de origem que está sendo pesquisada, Pwned Passwords implementa um modelo k-Anonimato que permite que uma senha seja pesquisada por hash parcial. Isso permite que os primeiros 5 caracteres de um hash de senha SHA-1 sejam passados ​​para a API.

### Notificar usuários sobre eventos de segurança incomuns

Quando uma atividade suspeita ou incomum é detectada, pode ser apropriado notificar ou avisar o usuário. No entanto, deve-se ter cuidado para que o usuário não fique sobrecarregado com um grande número de notificações que não são importantes para ele, ou simplesmente comece a ignorá-las ou excluí-las.

Por exemplo, geralmente não seria apropriado notificar um usuário de que houve uma tentativa de login em sua conta com uma senha incorreta. No entanto, se houve um login com a senha correta, mas que falhou na verificação de MFA subsequente, o usuário deve ser notificado para que possa alterar sua senha.

Os detalhes relacionados aos logins atuais ou recentes também devem ficar visíveis para o usuário. Por exemplo, quando eles fazem login no aplicativo, a data, a hora e o local da tentativa anterior de login podem ser exibidos para eles. Além disso, se o aplicativo oferecer suporte a sessões simultâneas, o usuário deverá ser capaz de visualizar uma lista de todas as sessões ativas e encerrar quaisquer outras sessões que não sejam legítimas.

### Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/)