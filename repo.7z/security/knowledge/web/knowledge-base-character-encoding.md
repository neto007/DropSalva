---
title: Codificação de caracteres
---
## Descrição

Codificação de caracteres é o processo de mapear caracteres, números e outros símbolos para um Formato padrão. Normalmente, isso é feito para criar uma mensagem pronta para transmissão entre remetente e destinatário. É, em termos simples, a conversão de caracteres (pertencente a diferentes idiomas, como inglês, chinês, grego ou qualquer outro idioma conhecido) em bytes.
 
 Um exemplo de um esquema de codificação de caracteres amplamente utilizado é o Código Padrão para Intercâmbio de Informações (ASCII) que inicialmente usava códigos de 7 bits. Exemplos mais recentes de esquemas de codificação seriam os Unicode UTF-8 e UTF-16 padrões industriais. No ambiente de segurança de aplicações e devido à infinidade de esquemas de codificações disponíveis, a codificação de caracteres tem um uso popular indevido.
 
 As codificações vem sendo utilizadas para codificar sequências de injeção maliciosas de uma maneira que as ofusque. Isso pode levar à ignorar os filtros de validação de entrada ou tirar proveito de maneiras específicas pelas quais os navegadores renderizar texto codificado.

## Solução

Ao tentar descobrir a codificação de caracteres de um recurso, os atacantes tentarão, validar alguns campos, sendo eles:

- O cabeçalho HTTP Content-Type enviado pelo servidor
- A declaração XML (apenas para documentos XHTML)
- Meta elemento HTML / XHTML.

Verifique se essas informações são fornecidas pelo seu aplicativo para o servidor para
impedi-lo de adivinhar o padrão de codificação errado, deixando espaço para injeção.

## Nota

Estas três maneiras de fornecer a codificação de caracteres de um documento não são
equivalentes.
