---
title: Perfil Básico De SOAP
---
## Descrição

Simple Soap Binding Profile é uma especificação do consórcio da indústria de interoperabilidade de serviços da Web. isto destina-se a ser um perfil de suporte para o Perfil Básico WS-I. Este perfil define a forma como WSDL os documentos são para ligar operações a um protocolo de transporte específico SOAP.

## Solução

Verifique se os serviços da web baseados em SOAP estão usando o perfil WS-I Basic. Para estar em conformidade com este padrão, isso significa essencialmente que a infraestrutura do aplicativo deve ser protegida por TLS.

Fonte: http://www.ws-i.org/Profiles/SimpleSoapBindingProfile-1.0.html