---
title: Controles de acesso
---
## Descrição

A manipulação segura de erros é um aspecto essencial da codificação segura.
Existem dois tipos de erros que merecem atenção especial. O primeiro são exceções
que ocorrem no processamento de um controle de segurança em si. É importante que essas 
exceções não permitam comportamentos que a contramedida normalmente não permitiria.
Como desenvolvedor, você deve considerar que geralmente existem três resultados possíveis de um mecanismo de segurança:

1. Permitir a operação
2. Rejeitar a operação
3. Exceção

Em geral, você deve projetar seu mecanismo de segurança para que uma falha siga o mesmo caminho de execução como desativando a operação

## Solução

Certifique-se de que todos os sistemas de controle de acesso sejam minuciosamente testados quanto a falhas de segurança antes de usaá-lo no seu aplicativo. É comum que testes unitários completos sejam criados especialmente para esse fim.