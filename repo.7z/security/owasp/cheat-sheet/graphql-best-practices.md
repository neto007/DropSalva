---
title: GraphQL melhores práticas
---

## Validação de entrada

Adicionar validação de entrada estrita pode ajudar a prevenir contra injeção e DoS. O design principal do GraphQL é que o usuário fornece um ou mais identificadores e o back-end tem vários buscadores de dados que fazem outras chamadas usando os identificadores fornecidos. Isso significa que a entrada do usuário será incluída em solicitações HTTP, consultas de banco de dados ou outras solicitações/chamadas que fornecem oportunidade para injeção que pode levar a vários ataques de injeção ou DoS.

## Práticas Gerais
Valide todos os dados de entrada para permitir apenas valores válidos (ou seja, lista de permissões).

* Use tipos de dados GraphQL específicos. Escreva validadores GraphQL personalizados para validações mais complexas.
* Defina esquemas para entrada de mutações.
* Caracteres permitidos na lista de permissões - não use uma lista de bloqueio.
* Quanto mais restrita a lista de permissões, melhor. Muitas vezes, um bom ponto de partida é permitir apenas caracteres alfanuméricos, não Unicode, porque isso não permitirá muitos ataques.
* Para lidar adequadamente com a entrada Unicode, use uma única codificação interna de caracteres.
* Rejeite entradas inválidas com elegância, tomando cuidado para não revelar informações excessivas sobre como a API e sua validação funcionam.