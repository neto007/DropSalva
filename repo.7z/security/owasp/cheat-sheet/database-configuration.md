---
title: Configuração segura em banco de dados
---

O sistema operacional subjacente para o servidor de banco de dados deve ser reforçado da mesma forma que qualquer outro servidor, com base em uma linha de base segura, como os Benchmarks do CIS ou os Baselines de segurança da Microsoft. O aplicativo de banco de dados também deve ser configurado e protegido adequadamente. Os seguintes princípios devem ser aplicados a qualquer aplicativo e plataforma de banco de dados:

* Instale todas as atualizações e patches de segurança necessários.
* Configure os serviços de banco de dados para serem executados em uma conta de usuário com poucos privilégios.
* Remova todas as contas e bancos de dados padrão.
* Armazene os logs de transações em um disco separado para os arquivos do banco de dados principal.
* Configure um backup regular do banco de dados.
* Certifique-se de que os backups estão protegidos com as permissões apropriadas e, de preferência, criptografados.

## Referência externa
[OWASP - segurança em baco de dados](https://cheatsheetseries.owasp.org/cheatsheets/Database_Security_Cheat_Sheet.html)