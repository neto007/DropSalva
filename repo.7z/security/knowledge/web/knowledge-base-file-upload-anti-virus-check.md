---
title: Verificação antivírus no upload de arquivos
---
## Descrição

sempre que arquivos de serviços não confiáveis ​​são carregados no servidor, deve haver verificações adicionais para verificar se esses arquivos contêm vírus (malware, trojans, ransomware).

## Solução

Após o upload do arquivo, ele deve ser colocado em quarentena e o antivírus deve
inspecione o arquivo em busca de vírus maliciosos. O software antivírus que possui uma interface de linha de comando é requisito para realizar essas digitalizações. Também existem APIs disponíveis para outros serviços, como "VirusTotal.com".

Este site fornece um serviço gratuito no qual seu arquivo é fornecido como entrada para
inúmeros produtos antivírus e você recebe de volta um relatório detalhado com as evidências resultantes.