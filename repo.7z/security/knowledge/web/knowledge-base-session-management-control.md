---
title: Controle De Gerenciamento De Sessão
---
## Descrição

A capacidade de restringir e manter as ações do usuário em sessões únicas é crítica para
segurança na web. A maioria dos usuários deste guia usará uma estrutura de aplicativo com
em recursos de gerenciamento de sessão. Outros usarão linguagens como Perl CGI que não o fazem. Aqueles sem um sistema de gerenciamento de sessão integrado e aqueles que substituem o existente os sistemas de gerenciamento de sessão estão em desvantagem imediata. Implementações construídas a partir de idéias são frequentemente fracos e quebráveis. Os desenvolvedores são fortemente desencorajados de implementar seu próprio Gerenciamento de Sessão.

## Solução

Sempre use a implementação de controle de gerenciamento de sessão padrão do frameworks em seu aplicativo. Se não for possível, você deve encontrar guias experientes sobre como fazer isso de maneira segura.