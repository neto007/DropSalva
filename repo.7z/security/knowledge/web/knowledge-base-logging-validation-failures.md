---
title: Falhas na validação de log
---
## Descrição

Ao registrar todas as falhas de validação de entrada em seu aplicativo, você pode descobrir desde o início que seu aplicativo está sob ataque e tomar medidas rápidas contra os invasores.

## Solução

Verifique se todas as falhas de validação de entrada estão registradas para combater possíveis ataques em um estágio inicial. Além disso, você deseja verificar se a lógica de manipulação de erros nos controles de segurança nega o acesso por padrão.
