---
title: Build e deploy de forma segura
---

## Descrição

O uso de plataformas de builds no local ou como serviço é um dos componentes principais de um SDLC. Às vezes, esses servidores de compilação e implantação não são perfeitos para executar compilações ou implantações seguras. Isso ocorre porque a falta de proteção do sistema operacional para melhorias de segurança em que o aplicativo também pode se beneficiar desse endurecimento. Além disso, o acesso a serviços de terceiros pode levar a comprometimento dos segredos ou integridade do código do aplicativo.

## Solução

A criação do seu aplicativo sempre deve ser feita em um servidor confiável, você está no controle e tem os mais recentes patches de segurança e proteção configurados. Para realizar o deploy da aplicação e aplicar as mesmas regras, pense também em que tipo de serviços de terceiros podem acessar ou modificar o código. Criar scripts para monitorar o mau comportamento de um serviço de terceiros pode ser uma opção extra para verificação de controle de qualidade.