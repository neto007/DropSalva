---
title: Criptografar informações confidenciais
---
## Descrição

O aplicativo móvel não deve armazenar dados confidenciais de maneira não criptografada, mesmo em os chaveiros do aplicativo, pois eles podem ser acessados ​​facilmente quando o telefone é desbloqueado ou explorado o chaveiro pode ser facilmente lido.

## Solução

Determine o contexto de onde as informações confidenciais estão sendo armazenadas. 
É uma pequena conjunto de dados ou são os dados armazenados em um banco de dados SQLite. Para cada contexto, determine as configurações de opções nativas recomendadas pela plataforma de aplicativos e siga estas recomendações em conformidade.