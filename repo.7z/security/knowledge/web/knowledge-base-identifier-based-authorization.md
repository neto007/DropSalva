---
title: Autorizção baseada no identificador
---
## Descrição

Um aplicativo usa parâmetros para processar dados.
Esses parâmetros também podem ser usados ​​para atribuir determinadas funções e recuperar
Conteúdo correspondente a esses parâmetros.
Por exemplo:

`www.target.com/index.php?loggedin=user`

Nessa situação, o aplicativo obterá conteúdo e assinará funções de usuário correspondentes ao parâmetro do usuário.

`www.target.com/index.php?loggedin=admin`

Nessa situação, o aplicativo obterá conteúdo e assinará funções de usuário correspondentes ao parâmetro admin. (Nota: os dois links acima não estão mais disponíveis.)


## Solução

Sempre que você estiver verificando se um usuário está restrito a revisar determinados dados, as restrições de acesso devem ser processadas no lado do servidor.
O ID do usuário deve ser armazenado dentro de uma variável de sessão no login e deve ser usado para recuperar dados do usuário do banco de dados como: SELECT dados de personaldata em que `userID =: id` <- session var. Agora, um possível invasor não pode violar e alterar a operação do aplicativo, pois o identificador para recuperar os dados é tratado no lado do servidor.