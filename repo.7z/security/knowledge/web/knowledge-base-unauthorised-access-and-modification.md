---
title: Acesso ou modificação não autorizada
---
## Descrição

Ao longo do desenvolvimento da aplicação, deve haver verificações perpétuas para verificar
se todas as páginas e recursos, por padrão, exigirem autenticação, exceto aqueles especificamente destinados a ser público.
Às vezes, os desenvolvedores simplesmente se esquecem de implementar essas verificações ou as removem temporariamente para fins de teste.


## Solução

Verifique se todos os controles de acesso estão implementados corretamente, a fim de evitar que um usuário acesse dados/funções que ele não se destinava a usar.