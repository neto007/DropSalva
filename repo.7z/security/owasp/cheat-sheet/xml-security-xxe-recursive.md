---
title: Referência de entidade recursiva
---

Quando a definição de um elemento A é outro elemento B, e esse elemento Bé definido como elemento A, esse esquema descreve uma referência circular entre os elementos:

```xml

<!DOCTYPE A [
 <!ELEMENT A ANY>
 <!ENTITY A "<A>&B;</A>">
 <!ENTITY B "&A;">
]>
<A>&A;</A>


```

## Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/cheatsheets/XML_Security_Cheat_Sheet.html)