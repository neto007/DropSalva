---
title: Uso de cookie seguro
---

Todos os cookies devem ser marcados com o atributo `Secure`, que instrui o navegador a enviá-los apenas por conexões HTTPS criptografadas, a fim de evitar que sejam detectados por uma conexão HTTP não criptografada. Isso é importante mesmo que o site não escute em HTTP (porta 80), pois um invasor executando um ataque man in the middle pode apresentar um servidor da web falsificado na porta 80 para o usuário roubar seu cookie.

### Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/)