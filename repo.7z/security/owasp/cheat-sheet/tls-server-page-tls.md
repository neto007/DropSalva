---
title: Use TLS para todas as páginas
---

O TLS deve ser usado para todas as páginas, não apenas para aquelas consideradas confidenciais, como a página de login. Se houver páginas que não imponham o uso de TLS, elas podem dar a um invasor a oportunidade de farejar informações confidenciais, como tokens de sessão, ou injetar JavaScript malicioso nas respostas para realizar outros ataques contra o usuário.

Para aplicativos voltados ao público, pode ser apropriado ter o servidor da web ouvindo conexões HTTP não criptografadas na porta 80 e, em seguida, redirecionando-as imediatamente com um redirecionamento permanente (HTTP 301), a fim de fornecer uma melhor experiência aos usuários que digitam manualmente no nome do domínio. Isso deve ser compatível com o cabeçalho HTTP Strict Transport Security (HSTS) para evitar que acessem o site via HTTP no futuro.

## Não misture conteúdo TLS e não-TLS

Uma página que está disponível em TLS não deve incluir quaisquer arquivos de recursos (como JavaScript ou CSS) carregados em HTTP não criptografado. Esses recursos não criptografados podem permitir que um invasor detecte cookies de sessão ou injete código malicioso na página. Os navegadores modernos também bloqueiam as tentativas de carregar conteúdo ativo por meio de HTTP não criptografado em páginas seguras.


### Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/)