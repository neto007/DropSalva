---
title: Divulgação de vulnerabilidade
---

Um pesquisador descobre uma vulnerabilidade em um componente e, após colaboração com o provedor do componente, ele emite um [CVE](https://en.wikipedia.org/wiki/Common_Vulnerabilities_and_Exposures) (às vezes, um identificador de vulnerabilidade específico para o provedor é criado, mas geralmente um identificador CVE é o preferido) associado ao problema, permitindo a referência pública do problema, bem como a fixação / mitigação disponível.

Caso o provedor não coopere adequadamente com o pesquisador, os seguintes resultados são esperados:

- O CVE é aceito pelo fornecedor, mas o provedor se recusa a corrigir o problema .

- Na maioria das vezes, se o pesquisador não receber uma resposta em 30 dias, ele vai em frente e faz uma divulgação completa da vulnerabilidade.
Aqui, a vulnerabilidade é sempre referenciada na base de dados global CVE utilizada, geralmente, pelas ferramentas de detecção como uma das várias fontes de entrada utilizadas.


### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)

```

```