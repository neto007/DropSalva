---
title: Informações confidenciais criptografadas
---
## Descrição

O aplicativo móvel não deve armazenar dados confidenciais em arquivos compartilhados não criptografados. Esses recursos podem ser acessíveis por outros aplicativos ou
acessível fisicamente sempre que um dispositivo for perdido ou roubado.

## Solução

Informações confidenciais sempre devem ser armazenadas criptografadas e de preferência no lado do servidor e recuperado usando uma referência de objeto com mecanismos de autorização adequados em vigor.

Não implemente um algoritmo criptográfico por conta própria, não importa quão fácil
parece. Em vez disso, use algoritmos amplamente aceitos e implementações amplamente aceitas.

A regra principal dos aplicativos móveis é não armazenar dados, a menos que seja absolutamente necessário. Como desenvolvedor, você deve assumir que os dados são perdidos assim que tocam o telefone. Você também deve considerar as implicações da perda de dados dos usuários móveis para um jailbreak ou exploração de raiz.