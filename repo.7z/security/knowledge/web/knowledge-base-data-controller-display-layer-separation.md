---
title: Separador de camada de exibição do controlador de dados
---
## Descrição

O aplicativo deve separar as camadas de dados, controlador e exibição para tornar seu
aplicação mais clara e compreensível em termos de abstração devido à separação.
Sempre que seu aplicativo é mais organizado e abstrato, é muito mais fácil implementar
controles de segurança menos defeituosos.

## Solução

Verifique se os diferentes tipos de camadas de dados estão separados no seu aplicativo.
A separação dessas diferentes camadas também é conhecida como um padrão de design que vai pelo nome MVC (modelo, visualização, controlador).