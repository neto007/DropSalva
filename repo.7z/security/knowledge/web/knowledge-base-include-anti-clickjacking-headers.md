---
title: Inclua cabeçalhos anti-clickjacking 
---
## Descrição

O Clickjacking, também conhecido como "ataque de redirecionamento da UI", ocorre quando um invasor usa vária camadas transparentes ou opacas para induzir um usuário a clicar em um botão ou link em outra página quando eles pretendiam clicar na página de nível superior. Assim, o atacante está "sequestrando" cliques destinados à página deles e direcionando-os para outra página, provavelmente de propriedade de outro aplicativo, domínio ou ambos.
Usando uma técnica semelhante, as teclas também podem ser seqüestradas. Com uma cuidadosa
combinação de tags html, iframes e caixas de texto, um usuário pode ser levado a acreditar que está digitando a senha do e-mail ou da conta bancária, mas digitando em um
quadro invisível controlado pelo atacante.

## Solução

Para evitar que sua aplicação seja "Clickjacked" você pode adiconar o cabeçalho X-frame-Options para a sua aplicação.
Estes cabeçalhos podem ser configurados como:

`X-frame-Options: deny`

A página não pode ser exibida em um quadro, independentemente do site que está tentando fazê-lo.

`X-Frame-Options: sameorign`


A página só pode ser exibida em um quadro na mesma origem que a própria página.

`X-Frame-Options: ALLOW-FROM uri`


A página pode ser exibida apenas em um quadro na origem especificada.

Você também pode considerar incluir a defesa "Framebreaking/Framebusting" para 
navegadores legados que não suportam cabeçalhos X-Frame-Option.

Fonte:
https://www.codemagi.com/blog/post/194
