---
title: Os segredos devem ser gerador aleatório seguro
---
## Descrição

Chaves secretas, tokens de API ou senhas devem ser gerados dinamicamente. Sempre que esses tokens não são gerados dinamicamente, eles podem se tornar previsíveis e usados ​​por invasores para comprometer
contas de usuário.

## Solução

Quando se trata de tokens de API e chaves secretas, esses valores devem ser gerados dinamicamente e válidos apenas uma vez. O token secreto deve ser criptograficamente 'aleatório seguro', com pelo menos 120 bits de entropia efetiva, salgado com um valor único e aleatório de 32 bits e hash com uma função de hash (unidirecional) aprovada.

As senhas, por outro lado, devem ser criadas pelo próprio usuário, ao invés de atribuir
um usuário uma senha gerada dinamicamente. O usuário deve receber um link único com um
token criptograficamente aleatório por meio de um e-mail ou SMS que é usado para ativar seu
conta e forneça uma senha própria
