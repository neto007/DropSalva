---
title: Geração De Token De Sessão Após Login
---
## Descrição

O aplicativo deve sempre gerar um novo ID de sessão somente depois que o usuário enviar um conjunto de credenciais válidas na autenticação. Isso evita que um invasor execute ataques de Fixação de Sessão contra outros usuários.

## Solução

Verifique se os tokens de sessão são gerados após uma autenticação bem-sucedida, não antes. Observe também que esses IDs devem ser únicos e gerados aleatoriamente.