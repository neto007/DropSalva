---
title: Proteger atividades sensíveis
---
## Descrição

O aplicativo nunca deve exportar atividades confidenciais, intenções ou provedores de conteúdo. Essas atividades podem potencialmente ser exploradas por aplicativos de terceiros instalados no mesmo dispositivo.

## Solução

Identifique em todo o aplicativo se existem atividades, intenções ou
provedores de conteúdo que estão sendo exportados.