---
title: Cabeçalhos de tipo de conteúdo
---
## Descrição

Definir os cabeçalhos de conteúdo (Content-Type) certos é importante para reforçar a segurança de seus aplicativos, isso reduz a exposição de diversos ataques e podem levar a vulnerabilidades de segurança.

## Solução

Um exemplo de cabeçalho de tipo de conteúdo seria:

Tipo de conteúdo: text/html; charset = UTF-8
ou:
Tipo de Conteúdo: application/json;
    
    
Verifique se as solicitações que contêm tipos de conteúdo ausentes ou inesperados são rejeitadas com cabeçalhos apropriados (status de resposta HTTP 406 Not Acceptable ou 415 Unsupported Media Type).