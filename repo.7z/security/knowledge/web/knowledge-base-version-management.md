---
title: Gerenciamento de versão
---
## Descrição

Sempre que um programador decide usar um software de terceiros,
ele deve ficar de olho na implementação de uma metodologia de gerenciamento de versão adequada para este software. Quando os hackers descobrem vulnerabilidades, eles geralmente publicam essas explorações online para para empurrar os desenvolvedores deste software para corrigir seus problemas. Como um resultado, quando seu software não é atualizado para a versão mais recente disponível, script kiddies podem facilmente comprometer seu aplicativo, seguindo o explorar tutoriais online, comprometendo assim a sua aplicação.

## Solução

Uma opção é não usar componentes que você não escreveu.
Mas isso não é muito realista. A maioria dos projetos de componentes não cria patches de vulnerabilidade para versões antigas. Em vez disso, basta corrigir o problema na próxima versão. Então, atualizando para estes novos versões é crítica. Os projetos de software devem ter um processo em vigor para:

- Identifique todos os componentes e as versões que você está usando, incluindo todas as dependências. (por exemplo, o plug-in de versões).

- Monitore a segurança desses componentes em bancos de dados públicos,
listas de discussão de projetos e listas de discussão de segurança e mantê-las atualizadas.

- Estabeleça políticas de segurança que regem o uso de componentes, como exigir determinado software, práticas de desenvolvimento, passando em testes de segurança e licenças aceitáveis.

- Quando apropriado, considere adicionar invólucros de segurança em torno dos componentes para desativar funcionalidade e/ou proteger aspectos fracos ou vulneráveis ​​do componente.

Isso também se aplica a todos os outros componentes que devem estar atualizados com a segurança adequada configuração (ões) e versão (ões), como sistema operacional de servidor, etc.

Isso deve incluir a remoção de configurações e pastas desnecessárias, como amostra
aplicativos, documentação da plataforma e usuários padrão ou de exemplo.
