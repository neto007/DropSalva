---
title: Cabeçalhos HTTP adicionados por um frontend
---
## Descrição


Há alguns tipos de cabeçalhos que usam tokens tais como Bearer ou JWT que são assinalados ou calculados usando uma chave, pelo servidor que o cria.

## Solução

Verifique a integrida e autenticidade do cabeçalho HTTP adicionado por um proxy confiável ou um dispositivo SSO ao checar a assinatura digital ou ao recalcular o hash ou o método de integridade usando uma chave privada uma frase passe.
