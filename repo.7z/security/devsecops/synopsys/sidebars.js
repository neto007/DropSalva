const codesight = require('./codesight/sidebars')
module.exports = {
    type: "category",
    label: "Processos Synopsys",
    items: [
        "chapters/security/devsecops/synopsys/synopsys-polaris",
        "chapters/security/devsecops/synopsys/synopsys-polaris-treinamento",
        codesight
    ],
};