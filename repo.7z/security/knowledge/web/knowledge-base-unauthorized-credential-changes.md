---
title: Alterações de credenciais não autorizadas
---
## Descrição

Uma aplicação que oferece a funcionalidade de login do usuário, geralmente tem uma página de administração onde os dados do usuário podem ser modificados. Quando o usuário deseja alterar esses dados, ele deve especificar sua senha atual.

## Solução

Ao alterar as credenciais do usuário ou endereço de e-mail, o usuário deve sempre inserir um password válido para implementar as alterações. Isso também é chamado de reautenticação ou
autenticação avançada/adaptativa. Sempre que um usuário "reautentica" a si mesmo, o
o valor do ID da sessão também deve ser atualizado para evitar os chamados "sequestradores de sessão" (no inglês, "session hijackers").
