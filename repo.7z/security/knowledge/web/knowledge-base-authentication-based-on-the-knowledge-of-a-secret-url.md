---
title: Autenticação baseada no conhecimento de uma URL secreta
---
## Descrição

Esta é uma forma de segurança pela obscuridade. Sempre que um atacante consegue realizar um (1) fuzz ou (2) spider dssa URL, a aplicação poderá comprometer o que está por trás dessa URL.

(1) O teste de fuzz (fuzzing) é uma técnica de garantia de qualidade usada para detectar erros de codificação e brechas de segurança em software, sistemas operacionais ou redes. Isso envolve a introdução de grandes quantidades de dados aleatórios teste (conhecido como fuzz) na tentativa de obter uma falha na aplicação.
(2) O spider (mecanismo de busca), também conhecido como rastreador, é um bot da Internet que rastreia sites e armazena informações para indexação do mecanismo de busca.

## Solução

Sempre implemente mecanismos de autenticação adequados que não estejam usando uma URL de autenticação estática.