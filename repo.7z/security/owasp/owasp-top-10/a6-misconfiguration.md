---
title: A6 Security misconfiguration
---

## A Aplicação é Vulnerável?
A aplicação pode ser vulnerável se:

* Estão em falta medidas apropriadas de segurança em alguma parte da camada aplicacional.
* Funcionalidades desnecessárias estão ativas ou instaladas (e.g. portos de comunicação desnecessários, serviços, páginas, contas ou privilégios).
* Existem contas padrão e as suas palavras-passe ainda estão ativas e inalteradas.
* A rotina de tratamento de erros revela informação de execução (stack trace) ou outras mensagens que incluam detalhe excessivo para os utilizadores.
* Em sistemas atualizados, as últimas funcionalidades de segurança encontram-se desativadas ou configuradas de forma insegura.
* As definições de segurança nos servidores aplicacionais, frameworks (e.g. Struts, Spring, ASP.NET), bibliotecas de código, base de dados, etc., não usam valores seguros. 
* O servidor não inclui cabeçalhos ou diretivas de segurança nas respostas ou estas não usam valores seguros.
* O software está desatualizado ou vulnerável (ver A9:2017 Utilização de Componentes Vulneráveis). Sem manutenção corretiva e um processo de aplicação de definições de segurança reprodutível os sistemas apresentam um risco mais elevado.

## Exemplos de Cenários de Ataque

#### Cenário #1: 
O servidor aplicacional inclui aplicações de demonstração que não são removidas do servidor de produção. Para além de falhas de segurança conhecidas que os atacantes usam para comprometer o servidor, se uma destas aplicações for a consola de administração e as contas padrão não tiverem sido alteradas, o atacante consegue autenticar-se usando a palavra-passe padrão, ganhando assim o controlo do servidor.

#### Cenário #2: 
A listagem de diretorias não está desativada no servidor. O atacante encontra e descarrega a sua classe Java compilada, revertendo-a para ver o código e assim identificar outras falhas graves no controlo de acessos da aplicação.

#### Cenário #3: 
A configuração do servidor aplicacional gera mensagens de erro detalhadas incluindo, por exemplo, informação de execução (stack trace). Isto expõe potencialmente informação sensível ou falhas subjacentes em versões de componentes reconhecidamente vulneráveis.

#### Cenário #4: 
As permissões de partilha dum fornecedor de serviços Cloud permitem, por omissão, o acesso a outros utilizadores do serviço via Internet. Isto permite o acesso a dados sensíveis armazenados nesse serviço Cloud.

## Como Prevenir
Processos de instalação seguros devem ser implementados,
incluindo:

* Um processo automatizado e reprodutível de robustecimento do sistema, que torne fácil e rápido criar um novo ambiente devidamente seguro. Ambientes de desenvolvimento, qualidade e produção devem ser configurados de forma semelhante com credenciais específicas por ambiente.
* A plataforma mínima necessária, sem funcionalidades desnecessárias, componentes, documentação ou exemplos. Remover ou não instalar funcionalidades que não são usadas bem como frameworks.
* Uma tarefa para rever e atualizar as configurações de forma adequada e de acordo com as notas de segurança, atualizações e correções como parte do processo de gestão de correções (ver A9:2017 Utilização de Componentes com Vulnerabilidades Conhecidas).
* Uma arquitetura aplicacional segmentada que garanta uma separação efetiva e segura entre os componentes ou módulos, com segmentação, utilização de containers ou grupos de segurança cloud (Access Control List (ACL)).
* Envio de diretivas de segurança para o agente dos clientes e.g. Security Headers.
* Um processo automatizado para verificação da eficácia das configurações e definições em todos os ambientes.