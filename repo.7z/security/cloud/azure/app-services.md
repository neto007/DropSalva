---
title: Azure App Services
sidebar_label: App Services
---

**Proposta de melhores práticas de segurança para o uso do App Services na Azure:**

O Azure App Service é um serviço HTTP-based para hospedagem de aplicativos Web, REST APIs e mobile back ends, onde atualmente são disponibilizados pela Azure os serviços de Web App, Functions e API App. Os aplicativos são executados e escalonados em ambientes baseados em Windows e Linux e utilizando a sua linguagem, seja .NET, .NET Core, Java, Ruby, Node.js, PHP ou Python.

O objetivo desse documento é descrevermos as melhores práticas de segurança para a configuração do App Services nas assinaturas da Azure.

#### Pontos importantes sobre a estrutura proposta:

**Gerenciamento de identidade e acesso**

- Seguindo com a regra do menor privilégio, recomendamos que a opção “Anonymous acccess” esteja desabilitada;

- Recomendamos o uso de **Managed Identity** para proteção na autenticação com os recursos back-end;

- Garantir o uso de autenticação com métodos seguros em seu App Service;

- Para o processo de Autenticação/Autorização em Functions, recomendamos o uso do APIM para controle de acesso ou o uso do App Service Authentication;

- Recomendamos que o uso de chaves nas Functions, sigam a regra de menor privilégio:

    - **Function** - Essas chaves se aplicam apenas às funções específicas sob as quais são definidas. Quando usado como uma API key, ela só permite o acesso a essa Function;

    - **Host** - A chave com um escopo de Host, pode ser usadas para acessar todas as Functions dentro do Function App. Quando usado como uma API key, ela permite o acesso a qualquer Function dentro do Function App;

    - **Master-key** - Devido às permissões elevadas no Function App concedidas pela master key, essa chave não deve compartilhada ou distribuída;

- Recomendado o máximo de restrição no uso de CORS em seu App Service;

**Redes**

- Recomendamos como primeira opção de restrição de acesso interno o uso do **Private Endpoint**;
    
- Quando não for possível o uso do Private Endpoint, utilize o **Service Endpoint** como segunda opção nas configurações de rede do seu App Services;
    
- Garantir o uso do **Access Restrictions** no App Services limitando somente as redes autorizadas da XP. Por padrão o App Services é configurado para aceitar conexões de todos IPs da internet;
    
- Garantir que quando necessário a publicação do App Services externamente o time de Segurança da Informação será acionado;
    
- Garantir que o App Service exposto na internet, esteja protegido pelo **Web Application Firewall** recomendado pela equipe de Segurança da Informação.  
        
**Monitoração**
    
- Garantir que os logs de auditoria em seu App Service estejam habilitados para registro das operações e também para permitir recriar trilhas de atividades para fins de investigação quando, por exemplo, ocorrer um incidente de segurança ou quando a rede for comprometida.

**Proteção de dados**

- Garantir o uso a opção de **Redirect HTTP to HTTPS**, dessa forma utilizamos o protocolo SSL / TLS para fornecer uma conexão segura, criptografada e autenticada;
    
- Garantir a criptografia da comunicação com os demais recursos da Azure;
    
- Garantir o uso da última versão do protocolo TLS;
    
- Desabilitar o uso do recurso FTP do App Services. Se necessário o uso, o time de Segurança da informação deverá ser acionado;
    
- Garantir que credenciais de banco de dados, API tokens ou chave privada não estejam armazenados no código da aplicação ou em arquivos de configuração. Recomendamos o uso do Azure Key Vault para armazenamento dessas informações;
    
- Utilize as versões atualizadas e suportadas de suas linguagens de programação, protocolos, plataformas e frameworks;
    
- Garantir o uso da última versão do HTTP;
    
- Garantir que o Remote Debugging esteja desabilitado;
    
- Ao configurar um domínio personalizado (Custom Domain), você deve protegê-lo com um certificado TLS / SSL;
    
- Recomendamos a utilização de quotas de uso nas Functions, pois isso ajuda a mitigar o risco contra ataques de códigos maliciosos;
    
- Recomendado o uso de TAGS para identificação do App Service que tratar informações sensíveis;

**Recuperação de dados**

- Garantir backups regulares e automatizados do Azure App Service;

- Validar periodicamente os dados de backup do Azure App Service;

**Configurações de segurança**

- Recomendado o uso de Managed Identity Service em conjunto com o Azure Key Vault, para simplificar e proteger o gerenciamento de segredos de seu Azure App Service.

Abaixo alguns campos para correta configuração do Azure App Service:

![Configurações Azure App Service](/assets/security/cloud/azure-app-services.png)
