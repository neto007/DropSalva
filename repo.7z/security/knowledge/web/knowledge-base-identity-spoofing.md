---
title: Falsificação de identitade (Spoofing)
---
## Descrição

É importante identificar exclusivamente os usuários de um aplicativo por rastreabilidade. Portanto, não deve ser possível usar contas compartilhadas,
nem deve ser possível vincular novamente identidades a uma identidade diferente (falsificação (spoofing)).

## Solução

Verique que identidades não podem ser re-vinculadas a uma identidade diferente e as contas compartilhadas não estão presentes ("raiz", "admin" ou "sa").
Contas administrativas como root, admin, sa, ... não devem ser compartilhadas, devem ser renomeadas e não devem ser expostas ao front-end do aplicativo.
