---
title: Sem limitação de tipo de caractere
---
## Descrição

O aplicativo deve permitir e não limitar ou impor o tipo de caracteres permitido. Além disso, o aplicativo deve permitir que o usuário crie frases secretas que contenham qualquer caractere utilizável e, portanto, reforce a segurança.

## Solução
	
Verifique se não há regras de composição de senha que limitem o tipo de caracteres permitido. Não deve haver exigência de letras maiúsculas ou minúsculas ou números ou caracteres especiais.