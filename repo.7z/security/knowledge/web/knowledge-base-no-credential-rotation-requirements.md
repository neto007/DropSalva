---
title: Não estabelecer requisitos de rotação de credenciais
---
## Descrição

Não exija que segredos memorizados sejam alterados arbitrariamente (por exemplo, periodicamente), a menos que haja uma solicitação do usuário ou evidência de comprometimento do autenticador.

As políticas de expiração de senha fazem mais mal do que bem, porque essas políticas levam os usuários a senhas muito previsíveis, compostas por palavras e números seqüenciais intimamente relacionados entre si (ou seja, a próxima senha pode ser prevista com base na senha anterior). A alteração de senha não oferece benefícios de contenção Os criminosos cibernéticos quase sempre usam credenciais assim que os comprometem.
As alterações de senha obrigatória são uma prática de segurança de longa data, mas a pesquisa atual indica fortemente que a expiração da senha tem um efeito negativo.

## Solução
	
Verifique se não há requisitos de rotação de credenciais arbitrários ou periódicos.