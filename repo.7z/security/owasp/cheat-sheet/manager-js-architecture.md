---
title: Arquitetura de implantação de JavaScript de terceiros
---

Existem três mecanismos básicos de implantação para tags . Esses mecanismos podem ser combinados entre si.

### JavaScript do fornecedor na página

É aqui que o fornecedor fornece ao host o JavaScript e o host o coloca na página do host. Para estar seguro, a empresa host deve revisar o código em busca de quaisquer vulnerabilidades, como ataques XSS ou ações maliciosas, como o envio de dados confidenciais do DOM para um site malicioso. Isso geralmente é difícil porque o JavaScript geralmente é ofuscado.

```html
<!-- Some host, e.g. foobar.com, HTML code here -->
<html>
<head></head>
    <body>
        ...
        <script type="text/javascript">/* 3rd party vendor javascript here */</script>
    </body>
</html>
```

### Solicitação de JavaScript ao fornecedor

É aqui que uma ou algumas linhas de código na página do host solicitam um arquivo JavaScript ou URL diretamente do site do fornecedor. Quando a página do host está sendo criada, o desenvolvedor inclui as linhas de código fornecidas pelo fornecedor que solicitarão o JavaScript do fornecedor. Cada vez que a página é acessada, as solicitações são feitas ao site do fornecedor para o javascript, que é executado no navegador do usuário.

```html
<html>
    <head></head>
    <body>
        ...
        <!-- 3rd party vendor javascript -->
        <script src="https://analytics.vendor.com/v1.1/script.js"></script>
        <!-- /3rd party vendor javascript -->
    </body>
</html>
```

### Solicitação indireta ao fornecedor por meio do Gerenciador de tags

É onde uma ou algumas linhas de código na página do host solicitam um arquivo JavaScript ou URL de um agregador de tags ou site gerenciador de tags ; não do site do fornecedor de JavaScript. O site agregador de tags ou gerenciador de tags retorna quaisquer arquivos JavaScript de terceiros que a empresa host configurou para serem retornados. Cada arquivo ou solicitação de URL para o site do gerenciador de tags pode retornar muitos outros arquivos JavaScript de vários fornecedores.

O conteúdo real que é retornado do agregador ou gerenciador (ou seja, os arquivos JavaScript específicos, bem como exatamente o que eles fazem) pode ser alterado dinamicamente pelos funcionários do site de host usando uma interface gráfica de usuário para desenvolvimento, hospedada no site do gerenciador de tags que os usuários técnicos podem trabalhar, como a parte de marketing do negócio.

As mudanças podem ser:

- Obtenha um arquivo JavaScript diferente do fornecedor terceirizado para a mesma solicitação.

- Altere quais dados do objeto DOM são lidos, e quando, para enviar ao fornecedor.

A interface de usuário do desenvolvedor do gerenciador de tags irá gerar um código que faz o que a funcionalidade de marketing exige, basicamente determinando quais dados obter do DOM do navegador e quando obtê-los. O gerenciador de tags sempre retorna um arquivo JavaScript contêiner para o navegador, que é basicamente um conjunto de funções JavaScript que são usadas pelo código gerado pela interface do usuário para implementar a funcionalidade necessária.

Semelhante a estruturas Java que fornecem funções e dados globais para o desenvolvedor, o contêiner JavaScript é executado no navegador e permite que o usuário empresarial use a interface de usuário do desenvolvedor do gerenciador de tags para especificar a funcionalidade de alto nível sem a necessidade de conhecer JavaScript.


```html
<!-- algu host host, e.g. foobar.com,  -->
 <html>
   <head></head>
     <body>
       ...
       <!-- Tag -->
       <script>(function(w, d, s, l, i){
         w[l] = w[l] || [];
         w[l].push({'tm.start':new Date().getTime(), event:'tm.js'});
         var f = d.getElementsByTagName(s)[0],
         j = d.createElement(s),
         dl = l != 'dataLayer' ? '&l=' + l : '';
         j.async=true;
         j.src='https://tagmanager.com/tm.js?id=' + i + dl;
         f.parentNode.insertBefore(j, f);
       })(window, document, 'script', 'dataLayer', 'TM-FOOBARID');</script>
       <!-- /Tag -->
   </body>
</html>
```

### Problemas de segurança com a solicitação de tags

Os mecanismos descritos anteriormente são difíceis de tornar seguros porque você só pode ver o código se fizer proxy das solicitações ou se tiver acesso à GUI e ver o que está configurado. O JavaScript geralmente é ofuscado, portanto, mesmo vendo-o, geralmente não é útil. Também pode ser implantado instantaneamente porque cada nova solicitação de página de um navegador executa as solicitações para o agregador que obtém o JavaScript do fornecedor terceirizado. Assim, assim que qualquer arquivo JavaScript for alterado no fornecedor ou modificado no agregador, a próxima chamada para eles de qualquer navegador obterá o JavaScript alterado. Uma maneira de gerenciar esse risco é com o padrão de integridade de sub-recursos descrito abaixo.

### Camada de dados direta do servidor

A interface de usuário do desenvolvedor do gerenciador de tags pode ser usada para criar JavaScript que pode obter dados de qualquer lugar no DOM do navegador e armazená-los em qualquer lugar da página. Isso pode permitir vulnerabilidades porque a interface pode ser usada para gerar código para obter dados não validados do DOM (por exemplo, parâmetros de URL) e armazená-los em algum local da página que executaria JavaScript.

A melhor maneira de tornar o código gerado seguro é limitá-lo a obter dados DOM de uma camada de dados definida pelo host.

A camada de dados é:

1. Objeto DIV com valores de atributo que contêm os dados de marketing ou de comportamento do usuário que o terceiro deseja

2. Um conjunto de objetos JSON com os mesmos dados. Cada variável ou atributo contém o valor de algum elemento DOM ou a descrição de uma ação do usuário. A camada de dados é o conjunto completo de valores de que todos os fornecedores precisam para aquela página. A camada de dados é criada pelos desenvolvedores do host.

Quando eventos específicos acontecem e que a empresa definiu, um manipulador JavaScript para esse evento envia valores da camada de dados diretamente para o servidor do gerenciador de tags. O servidor do gerenciador de tags então envia os dados para terceiros ou terceiros que devem obtê-los. O código do manipulador de eventos é criado pelos desenvolvedores de host usando a interface de usuário do desenvolvedor do gerenciador de tags. O código do manipulador de eventos é carregado dos servidores do gerenciador de tags em cada carregamento de página.

**Esta é uma técnica segura** porque apenas o seu JavaScript é executado no navegador do usuário, e apenas os dados que você decidir são enviados ao fornecedor.

Isso requer cooperação entre o host, o agregador ou gerenciador de tags e os fornecedores.

Os desenvolvedores de host precisam trabalhar com o fornecedor para saber que tipo de dados o fornecedor precisa para fazer sua análise. Em seguida, o programador host determina qual elemento DOM terá esses dados.

Os desenvolvedores de host têm que trabalhar com o gerenciador de tags ou agregador para concordar com o protocolo para enviar os dados ao agregador: qual URL, parâmetros, formato etc.

O gerenciador de tags ou agregador deve trabalhar com o fornecedor para concordar com o protocolo para enviar os dados ao fornecedor: qual URL, parâmetros, formato etc. O fornecedor tem uma API?


### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)