---
title: Carga Útil De Mensagem Assinada Ws Security
---
## Descrição

A fim de estabelecer confiança entre duas partes que se comunicam, como servidores e clientes
a carga útil da mensagem deve ser assinada por meio do método de chave pública / privada. Isso gera confiança e torna mais difícil para os invasores se passarem por usuários diferentes.

Segurança de serviços da Web (WS-Security, WSS) é uma extensão do SOAP para aplicar segurança e Serviços web. É membro das especificações de serviço da Web e foi publicado pela OASIS.

O protocolo especifica como a integridade e a confidencialidade podem ser aplicadas às mensagens e permite a comunicação de vários formatos de token de segurança, como Security Assertion Markup Language (SAML), Kerberos e X.509. Seu foco principal é o uso de assinatura XML e criptografia XML para fornecer segurança ponta a ponta.

## Solução

WS-Security descreve três mecanismos principais:

Como assinar mensagens SOAP para garantir a integridade. As mensagens assinadas também fornecem não repúdio. Como criptografar mensagens SOAP para garantir a confidencialidade.
Como anexar tokens de segurança para verificar a identidade do remetente.
A especificação permite uma variedade de formatos de assinatura, algoritmos de criptografia e vários domínios de confiança, e está aberta a vários modelos de token de segurança, como:

Certificados X.509,
Tíquetes Kerberos,
Credenciais de ID de usuário / senha,
Asserções SAML e
tokens personalizados.
Os formatos de token e semântica são definidos nos documentos de perfil associados.

WS-Security incorpora recursos de segurança no cabeçalho de uma mensagem SOAP, trabalhando na camada do aplicativo.

Esses mecanismos por si só não fornecem uma solução de segurança completa para serviços da web. Em vez disso, esta especificação é um bloco de construção que pode ser usado em conjunto com outras extensões de serviço da Web e protocolos específicos de aplicativo de nível superior para acomodar uma ampla variedade de modelos de segurança e tecnologias de segurança. Em geral, o WSS por si só não oferece nenhuma garantia de segurança. Ao implementar e usar a estrutura e a sintaxe, é responsabilidade do implementador garantir que o resultado não seja vulnerável.

Gerenciamento de chaves, bootstrapping de confiança, federação e acordo sobre os detalhes técnicos (cifras, formatos, algoritmos) estão fora do escopo da WS-Security.

### Casos de uso

Segurança ponta a ponta
Se um intermediário SOAP for necessário e o intermediário não for mais ou menos confiável, as mensagens deverão ser assinadas e opcionalmente criptografadas. Esse pode ser o caso de um proxy de nível de aplicativo em um perímetro de rede que encerrará as conexões TCP (protocolo de controle de transmissão).

Não-repúdio
Um método de não repúdio é gravar transações em uma trilha de auditoria que está sujeita a salvaguardas de segurança específicas. As assinaturas digitais, que o WS-Security suporta, fornecem uma prova de não repúdio mais direta e verificável.

Ligações de transporte alternativas
Embora quase todos os serviços SOAP implementem ligações HTTP, em teoria, outras ligações, como JMS ou SMTP, poderiam ser usadas; neste caso, a segurança de ponta a ponta seria necessária.

Proxy reverso/token de segurança comum
Mesmo que o serviço da web dependa da segurança da camada de transporte, pode ser necessário que o serviço saiba sobre o usuário final, se o serviço for retransmitido por um proxy reverso (HTTP-). Um cabeçalho WSS pode ser usado para transmitir o token do usuário final, garantido pelo proxy reverso.