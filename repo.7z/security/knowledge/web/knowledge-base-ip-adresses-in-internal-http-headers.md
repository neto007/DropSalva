---
title: Endereços IP em Cabeçalhos HTTP Internos
---
## Descrição

Sempre que endereços IP são usados ​​em cabeçalhos HTTP nas estruturas internas da sua organização, um invasor pode usá-los para ampliar seu vetor de ataque e reconstruir suas
infra-estruturas internas.

## Solução

Nunca use endereços IP em cabeçalhos HTTP internos.
