---
title: Cross-Site Request Forgery (CSRF)
---

### Padrão de token baseado em criptografia

O padrão de token criptografado alavanca uma criptografia, em vez de método de comparação de validação de token. É mais adequado para aplicativos que não desejam manter nenhum estado no lado do servidor.

O servidor gera um token composto pelo ID da sessão do usuário e um carimbo de data / hora (para evitar ataques de repetição) usando uma chave exclusiva disponível apenas no servidor (AES256-com modo GCM / GCM-SIV é recomendado. O uso do modo ECB não é estritamente recomendado . Se desejar usar qualquer outro modo de operação de codificação em bloco, consulte aqui e aqui para obter mais informações). Este token é devolvido ao cliente e incorporado em um campo oculto para formulários, no cabeçalho / parâmetro de solicitação para solicitações AJAX. Ao receber essa solicitação, o servidor lê e descriptografa o valor do token com a mesma chave usada para criar o token.

Se o valor não puder ser descriptografado, isso sugere uma tentativa de intrusão (que deve ser bloqueada e registrada para fins de depuração ou resposta a incidentes). Depois de descriptografado, o ID da sessão do usuário e o carimbo de data / hora contidos no token são validados. O ID da sessão é comparado ao usuário conectado no momento e o carimbo de data / hora é comparado ao horário atual para verificar se não está além do tempo de expiração do token definido. Se o ID da sessão corresponder e o carimbo de data / hora estiver abaixo do tempo de expiração do token definido, a solicitação é permitida.

A folha de dicas de gerenciamento de chaves contém as melhores práticas sobre o gerenciamento de chaves de criptografia.

### Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/)