---
title: Autenticação no lado do cliente
---
## Descrição

Um aplicativo pode implementar funcionalidades de autenticação por meio de JavaScript e HTML. No entanto, essas são restrições impostas pelo cliente, o que significa que um hacker pode desativar ou modificar facilmente essas restrições.

## Solução

Nunca implemente restrições de autenticação do lado do cliente, pois elas são facilmente ignoradas. Ao implementar métodos de autenticação, use sempre soluções do lado do servidor.