---
title: O método de autorização deve ser aplicado no lado do servidor
---

Quando vários métodos de autorização de transação estão disponíveis para o usuário. O servidor deve impor o uso do método de autorização atual escolhido pelo usuário nas configurações do aplicativo ou reforçado pelas políticas do aplicativo. Deve ser impossível alterar um método de autorização manipulando os parâmetros fornecidos pelo cliente. Caso contrário, o malware pode fazer o downgrade de um método de autorização para um método de autorização menos ou mesmo o menos seguro.

Isso é especialmente importante quando um aplicativo é desenvolvido para adicionar um método de autorização novo e mais seguro. Não é muito raro que um novo método de autorização seja construído sobre uma base de código antiga. Dessa forma, quando um cliente está enviando parâmetros pelo método antigo, a transação pode ser autorizada, mesmo que o usuário já tenha mudado para um novo método.


### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)