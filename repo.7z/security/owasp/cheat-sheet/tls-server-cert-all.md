---
title: Forneça todos os certificados necessários
---

Para validar a autenticidade de um certificado, o navegador do usuário deve examinar o certificado que foi usado para assiná-lo e compará-lo com a lista de CAs confiáveis ​​por seu sistema. Em muitos casos, o certificado não é assinado diretamente por uma CA raiz, mas sim por uma CA intermediária, que por sua vez é assinada pela CA raiz.

Se o usuário não conhecer ou não confiar nessa CA intermediária, a validação do certificado falhará, mesmo se o usuário confiar na CA raiz final, pois não pode estabelecer uma cadeia de confiança entre o certificado e a raiz. Para evitar isso, todos os certificados intermediários devem ser fornecidos junto com o certificado principal.

### Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/)