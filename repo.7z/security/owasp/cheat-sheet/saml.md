---
title: Segurança SAML
---

O SAML (**S**egurança Um **A**ssertion **M**arkup **L**anguage),  é um padrão aberto para a troca de informação de autorização e autenticação. O perfil `SAML/SSO` do navegador da Web com vínculos `Redirect/POST` é uma das implementações de SSO mais comuns. Esta página de referências se concentrará principalmente nesse perfil.

- [Validar a confidencialidade e integridade da mensagem](saml-valid-msg-integrity.md)

- [Validar o uso do protocolo](saml-valid-protocol.md)

- [Validar assinaturas](saml-subscript-valid.md)

- [Validar regras de processamento de protocolo](saml-valid-rule-protocolo.md)

- [Validar a implementação de vinculação](saml-valid-implement-vinc.md)

- [Validar as contramedidas de segurança](saml-conter-measures.md)

- [Considerações sobre o provedor de identidade e o provedor de serviços](saml-service-provider)

### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)