---
title: Gerenciamento de chaves e Ciclo de Vida de Chaves pelo NIST
---
## Descrição

Este item da base de conhecimento refere-se ao padrão NIST para gerenciamento de chaves e
ciclo de vida da chave.
Esta recomendação fornece orientação de gerenciamento de chaves criptográficas. Ela consiste de três partes. A Parte 1 fornece orientação geral e melhores práticas para o gerenciamento de material de codificação criptográfica. A parte 2 fornece orientação sobre planejamento de políticas e requisitos de segurança para agências governamentais dos EUA. Por fim, a Parte 3 fornece orientação ao usar os recursos criptográficos dos sistemas atuais.

## Solução

Consulte a seguinte documentação para obter mais informações:

https://nvlpubs.nist.gov/nistpubs/SpecialPublications/NIST.SP.800-57pt1r4.pdf