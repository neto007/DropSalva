---
title: Permitir espaços nas senhas
---
## Descrição

Ao permitir espaços nas senhas, uma senha pode se tornar uma frase secreta quase impossível de ser quebrada, desde que não seja uma citação comum ou popular.
A adição de espaços em uma senha aumenta a entropia da sua senha.

## Solução
	
Verifique se as senhas podem conter espaços e se o truncamento não é executado. Espaços múltiplos consecutivos PODEM opcionalmente ser fundidos.