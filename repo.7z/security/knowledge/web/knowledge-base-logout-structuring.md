---
title: Estruturação de logout
---
## Descrição

A colocação de um link de logout em todas as páginas que requerem autenticação ajuda o usuário a encerrar a sessão quando terminar o site. Encerrar a sessão ajuda a impedir o seqüestro.

## Solução

Identifique todas as páginas que usam autenticação. Faça uma lista de todas as páginas em seu site que usam autenticação e verifique a presença de links de logout. Examine cada página que usa autenticação para garantir que tenha um link de logout em um local que possa ser encontrado intuitivamente.