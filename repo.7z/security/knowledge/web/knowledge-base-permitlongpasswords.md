---
title: Permitir senhas longas
---
## Descrição

Senhas com pelo menos 64 caracteres devem ser permitidas. O uso de gerenciadores de senhas deve ser incentivado e suportado, garantindo que os usuários colem nos campos de entrada de dados de senha, permitindo assim o uso automatizado de gerenciadores de senhas.

## Solução

Verifique se são permitidas senhas de 64 caracteres ou mais.
