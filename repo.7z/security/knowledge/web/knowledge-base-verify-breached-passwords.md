---
title: Verificar senhas violadas
---
## Descrição

Vários bancos de dados de credenciais vazados foram liberados durante as violações ao longo dos anos. Se os usuários escolherem senhas já vazadas, eles estarão vulneráveis ​​a ataques de dicionário.

## Solução

Verifique se as senhas enviadas durante o registro da conta, login e alteração de senha são comparadas a um conjunto de senhas violadas. Caso a senha escolhida já tenha sido violada, o aplicativo deve exigir que o usuário insira novamente uma senha não violada.