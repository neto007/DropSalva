---
title: HSTS
---
## Descrição

O HTTP Strict Transport Security (HSTS) é um aprimoramento de segurança opcional especificado por um aplicação web através do uso de um cabeçalho de resposta especial. Depois que um navegador suportado recebe este cabeçalho o navegador impedirá que qualquer comunicação seja enviada por HTTP para o especificado domínio e enviará todas as comunicações por HTTPS. Também impede que os cliques HTTPS sejam solicitados nos navegadores.

No entanto, ainda existe uma janela em que um usuário com uma nova instalação ou que apaga seu estado local, é vulnerável. Isso se deve ao fato de o navegador ainda não estar ciente se o aplicativo está tentando se conectar ao HSTS. Sempre que você for adicionado à lista de pré-carregamento, sua preferência na aplicação é codificada no navegador e todas as primeiras conexões iniciais serão sempre realizadas por HTTPS.

## Solução

Para solicitar a pré-carga do HSTS, existem alguns requisitos que a aplicação precisa
ser compatível. O envio para o pré-carregamento do HSTS pode ser realizado no seguinte URL:

https://hstspreload.org/

Requisitos de envio:

Se um site envia a diretiva pré-carregamento em um cabeçalho HSTS, é considerado uma inclusão de solicitação na lista de pré-carregamento e pode ser enviado através do formulário neste site.

Para ser aceito na lista de pré-carregamento do HSTS, o site deve atender ao seguinte conjunto de requisitos:

1. Servir um certificado válido.
2. Redirecionar de HTTP para HTTPS no mesmo host, se você estiver ouvindo na porta 80.
3. Servir todos os subdomínios por HTTPS.
   - Em particular, você deve oferecer suporte a HTTPS para o subdomínio 'www' se existir um registro DNS para esse subdomínio.
5. Servir um cabeçalho HSTS no domínio base para solicitações HTTPS:
   - A idade máxima deve ser de pelo menos dezoito semanas (10886400 segundos).
   - A diretiva includeSubDomains deve ser especificada.
   - A diretiva pré-carregamento deve ser especificada.
   - Se você estiver servindo um redirecionamento adicional do site HTTPS, esse redirecionamento ainda deverá ter o cabeçalho HSTS (em vez da página para a qual ele redireciona).

Agora, o seguinte parâmetro pode ser adicionado ao cabeçalho HSTS e mantido pelo Chrome (e usado pelo Firefox e Safari), bastando usar:

`Strict-Transport-Security: max-age=31536000; includeSubDomains; preload`

A flag 'preload' indica que o proprietário do site terá seu domínio pré-carregado. O proprietário do site ainda precisa ir e enviar o domínio para a lista.

## CUIDADO

Certifique-se de ter um gerenciamento de certificação. Sempre que não houver certificado válido, o aplicativo não pode ser rebaixado temporariamente por HTTP. A falha do certificado TLS levará a um DOS, pois o HSTS não permite que o aplicativo seja visitado por HTTP.