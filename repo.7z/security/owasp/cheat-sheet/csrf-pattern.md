---
title: Padrão de Token de Sincronização
---

Os tokens CSRF devem ser gerados no lado do servidor. Eles podem ser gerados uma vez por sessão de usuário ou para cada solicitação. Os tokens por solicitação são mais seguros do que os tokens por sessão, pois o intervalo de tempo para um invasor explorar os tokens roubados é mínimo. No entanto, isso pode resultar em problemas de usabilidade. Por exemplo, o recurso do navegador do botão "Voltar" costuma ser prejudicado, pois a página anterior pode conter um token que não é mais válido. A interação com a página anterior resultará em um evento de segurança CSRF falso positivo no servidor. Na implementação do token por sessão após a geração inicial do token, o valor é armazenado na sessão e usado para cada solicitação subsequente até que a sessão expire.

Quando uma solicitação é emitida pelo cliente, o componente do lado do servidor deve verificar a existência e validade do token na solicitação em comparação com o token encontrado na sessão do usuário. Se o token não foi encontrado na solicitação ou o valor fornecido não corresponde ao valor na sessão do usuário, a solicitação deve ser abortada, a sessão do usuário encerrada e o evento registrado como um possível ataque CSRF em andamento.

Os tokens CSRF devem ser:

- Único por sessão de usuário

- Segredo

- Imprevisível (grande valor aleatório gerado por um método seguro ).

- Os tokens CSRF impedem o CSRF porque, sem o token, o invasor não pode criar solicitações válidas para o servidor backend.

- Os tokens CSRF não devem ser transmitidos por meio de cookies.

O token CSRF pode ser adicionado por meio de campos ocultos, cabeçalhos e pode ser usado com formulários e chamadas AJAX. Certifique-se de que o token não vazou nos logs do servidor ou na URL. Os tokens CSRF em solicitações GET são potencialmente vazados em vários locais, como o histórico do navegador, arquivos de log, dispositivos de rede que registram a primeira linha de uma solicitação HTTP e cabeçalhos Referer se o site protegido for vinculado a um site externo.

Por exemplo:

```js

<form action="/transfer.do" method="post">
<input type="hidden" name="CSRFToken" value="OWY4NmQwODE4ODRjN2Q2NTlhMmZlYWEwYzU1YWQwMTVhM2JmNGYxYjJiMGI4MjJjZDE1ZDZMGYwMGEwOA==">
[...]
</form>

```

Inserir o token CSRF no cabeçalho de solicitação HTTP customizado via JavaScript é considerado mais seguro do que adicionar o token no parâmetro de formulário de campo oculto porque usa cabeçalhos de solicitação customizados.

### Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/)