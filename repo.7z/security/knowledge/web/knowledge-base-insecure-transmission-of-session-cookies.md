---
title: Transmissão insegura de cookies de sessão
---
## Descrição


Se os cookies da sessão forem enviados por uma conexão não criptografada,
eles devem ser retirados imediatamente. Esses cookies não são mais confiáveis, pois um hacker pode ter capturado seus valores.

## Solução

Os cookies de sessão usados ​​para autenticar o usuário sempre devem ser definidos em uma
conexão segura. Para conseguir isso, você deve definir o sinalizador "seguro" no cookie de sessão para garantir que seu aplicativo, em qualquer circunstância, não envie esse cookie por conexões não HTTPS.