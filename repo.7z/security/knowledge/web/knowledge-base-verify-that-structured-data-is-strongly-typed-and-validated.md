---
title: Dados estruturados tipados e validados
---
## Descrição

Sempre que os dados estruturados são fortemente tipados e validados em relação a um esquema definido, o aplicativo pode ser desenvolvido como uma aplicação pró-ativa defensável. O aplicativo agora pode medir tudo que está fora de sua operação pretendida por meio do esquema definido e deve ser usado para rejeitar a entrada se as verificações de esquema retornarem falso.


## Solução

Verifique se os dados estruturados são fortemente tipados e validados em relação a um esquema definido incluindo caracteres permitidos, comprimento e padrão (por exemplo, números de cartão de crédito ou telefone, ou validar que dois campos relacionados são razoáveis, como validar subúrbios e zip ou correspondência de códigos postais.