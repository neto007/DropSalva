---
title: Alterar senha e expiração da sessão
---
## Descrição

Caso a sessão do usuário não seja encerrada após uma modificação importante no perfil do usuário, como uma modificação de alteração de senha, a sessão e o perfil do usuário não estarão no estado mais atualizado. Se a senha do usuário for comprometida, um invasor poderá operar o aplicativo em nome do usuário enquanto a sessão permanecer válida, mesmo após a alteração da senha.


## Solução

Após um processo bem-sucedido de alteração de senha, encerre todas as outras sessões ativas, e isso é eficaz no aplicativo, no logon federado (se presente) e em terceiros confiáveis.