module.exports = {
    type: "category",
    label: "Top 10",
    items: [    
        "chapters/security/owasp/owasp-top-10/a1-injection",
        "chapters/security/owasp/owasp-top-10/a2-broken-authentication",
        "chapters/security/owasp/owasp-top-10/a3-sensitive-data",
        "chapters/security/owasp/owasp-top-10/a4-external-entities",
        "chapters/security/owasp/owasp-top-10/a5-broken-access-control",
        "chapters/security/owasp/owasp-top-10/a6-misconfiguration",
        "chapters/security/owasp/owasp-top-10/a7-cross-site-scripting",
        "chapters/security/owasp/owasp-top-10/a8-insecure-deserialization",
        "chapters/security/owasp/owasp-top-10/a9-known-vulnerabilities",
        "chapters/security/owasp/owasp-top-10/a10-log-monitoring",
    ],
};