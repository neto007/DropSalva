---
title: Informações Confidenciais Armazenadas Em Cookies
---
## Descrição

Os dados sensíveis não devem ser armazenados em um cookie, pois o cookie também é usado no lado do cliente e é adaptável, tornando assim seu conteúdo legível. 
Um hacker pode obter acesso a um cookie por meio de scripts entre sites ataques e obter as informações confidenciais armazenadas no cookie de destino.

## Solução

Não armazene informações confidenciais em cookies.