---
title: Segurança em banco de dados (Autenticação)
---

## Proteção na camada de autenticação
O banco de dados deve ser configurado para sempre exigir autenticação, incluindo conexões do servidor local. As contas de banco de dados devem ser:

* Protegido com senhas fortes e exclusivas.
* Usado por um único aplicativo ou serviço.
* Configurado com as permissões mínimas exigidas conforme discutido na seção de permissões abaixo.

Como acontece com qualquer sistema que possui suas próprias contas de usuário, os processos usuais de gerenciamento de contas devem ser seguidos, incluindo:

* Revisões regulares das contas para garantir que ainda são necessárias.
* Revisões regulares de permissões.
* Remover contas de usuário quando um aplicativo é encerrado.
* Alterar as senhas quando a equipe sai ou há motivos para acreditar que elas podem ter sido comprometidas.

Para o Microsoft SQL Server, considere o uso do Windows ou da Autenticação Integrada  que usa contas existentes do Windows em vez de contas do SQL Server. Isso também remove a necessidade de armazenar credenciais no aplicativo, pois ele se conectará usando as credenciais do usuário do Windows sob o qual está sendo executado. Os plug-ins de autenticação nativa do Windows fornecem funcionalidade semelhante para MySQL.

## Referência externa
[OWASP - segurança em baco de dados](https://cheatsheetseries.owasp.org/cheatsheets/Database_Security_Cheat_Sheet.html)