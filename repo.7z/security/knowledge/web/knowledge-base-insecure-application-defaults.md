---
title: Padrões de aplicação inseguros
---
## Descrição

Quando sua aplicação utiliza usuários, senhas ou qualquer outra configuração que venha por padrão na hora da instalação e por algum motivo essas configurações não forem removidas.
Você estará aumentando significativamente a superfície de ataque do atacante.

## Solução

Verifique se todos os recursos desnecessários, documentação, amostras, configurações estão removidas, como aplicativos de demonstração, documentação da plataforma e usuários padrão ou de exemplo.
