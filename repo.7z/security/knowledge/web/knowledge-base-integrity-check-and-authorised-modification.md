---
title: Verificação de Integridade e Modificação Autorizada
---
## Descrição

O estado atual dos dados ou programa deve ser comparado ao registrado anteriormente, a fim de detectar alterações. Durante o desenvolvimento do aplicativo, deve haver verificações perpétuas para verificar se todas páginas e recursos, por padrão, exigem autenticação, exceto aqueles especificamente destinados a serem públicos. Às vezes, os desenvolvedores simplesmente esquecem de implementar essas verificações ou removem-nas temporariamente
para fins de teste.

## Solução

Verifique se todos os controles de acesso foram implementados corretamente para impedir que um usuário acesse dados/funções que ele não estava destinado a usar.