---
title: Solicitações GET POST
---
## Descrição

Os autores de serviços que usam o protocolo HTTP NÃO DEVEM usar formulários baseados em GET para o envio de dados confidenciais, porque isso fará com que esses dados sejam
codificado no Request-URI. Muitos servidores, proxies e os navegadores registrarão o URL da solicitação em algum lugar onde possa estar visível para terceiros. Os servidores podem usar o envio de formulários com base no POST. Também é mais provável que os parâmetros GET sejam vulneráveis ao XSS. Por favor, consulte o Manual XSS na base de conhecimento para obter mais informações.

## Solução

Sempre que transmitir dados confidenciais, faça-o sempre por meio da solicitação POST ou por cabeçalho. Além disso, certifique-se de desativar todos os outros métodos de solicitação HTTP desnecessários para sua operação de aplicativos como; REST, PUT, TRACE, DELETE, OPTIONS etc., permitindo que esses métodos de solicitação possa levar a vulnerabilidades e injeções.

>Nota: Evite a entrada do usuário no cabeçalho do aplicativo, isso pode levar a vulnerabilidades