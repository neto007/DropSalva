---
title: Controlar os estados da transação
---

A autorização da transação geralmente é realizada em várias etapas, por exemplo:

- O usuário insere os dados da transação.

- O usuário solicita autorização.

- O aplicativo inicializa um mecanismo de autorização.

- O usuário verifica / confirma os dados da transação.

- O usuário responde com as credenciais de autorização.

- O aplicativo valida a autorização e executa uma transação.

 Um aplicativo deve processar esse fluxo de lógica de negócios em ordem de etapas sequenciais e evitar que um usuário execute essas etapas fora de ordem ou até mesmo pule qualquer uma dessas etapas (consulte o requisito [15.1 OWASP ASVS](https://owasp.org/www-project-application-security-verification-standard/)).

Isso deve proteger contra técnicas de ataque, como:

- Substituir os dados da transação antes que o usuário insira as credenciais de autorização,

- Ignorando autorização de transação.



### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)