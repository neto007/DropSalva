---
title: Proteção contra exfiltração
---
## Descrição

O aplicativo móvel não deve vazar informações confidenciais.
Esta informação pode vazar, por exemplo, sempre que:

- As capturas de tela são salvas no aplicativo atual enquanto o aplicativo principal está em segundo plano
- As informações confidenciais são gravadas no console do dispositivo móvel
- O gerenciador de atividades deve mostrar o nome do aplicativo e uma página em branco e não mostrar informações

## Solução

- Proibir capturas de tela do aplicativo sempre que o aplicativo estiver em segundo plano
- Não escreva informações confidenciais no console do aplicativo, essas informações podem ser acessadas por invasores.
- Crie uma janela personalizada para sempre que o aplicativo for mostrado no gerenciador de atividades, para que não seja revelada nenhuma informação.
