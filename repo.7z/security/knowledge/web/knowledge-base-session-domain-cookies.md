---
title: Cookies De Domínio De Sessão
---
## Descrição

A opção Domínio permite que você especifique se deseja ou não enviar o cookie aos subdomínios.

## Solução

Definir www.example.com significará apenas o domínio exato www.example.com
ser correspondido, enquanto .example.com (curinga) também corresponderá novamente a qualquer
subdomínio (forums.example.com, blog.example.com). O uso de um caractere curinga não é recomendado e deve ser evitado.

Existem várias mitigações diferentes para fortalecer o gerenciamento de sua sessão.
Essas atenuações são, entre outras, a configuração dos sinalizadores "HttpOnly e seguro" em
suas sessões. Siga a lista "Padrão de sessões" para certificar-se de que seu gerenciamento de sessão está seguro. Itens recomendados da base de conhecimento:

- Ataques de cookies entre subdomínios