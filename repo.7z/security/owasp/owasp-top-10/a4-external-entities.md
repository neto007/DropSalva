---
title: A4 XML external entities (XXE)
---

## A Aplicação é Vulnerável?
As aplicações e em particular serviços web baseados em XML ou integrações posteriores podem ser vulneráveis a ataques se:

* A aplicação aceita XML diretamente ou carregamentos de XML, em particular de fontes pouco confiáveis, ou se insere dados não-confiáveis em documentos XML, que são depois consumidos pelo processador.
* Qualquer um dos processadores de XML em uso na aplicação ou em serviços web baseados em SOAP permite Definição de Tipo de Documento (DTD). A desativação do processamento de DTD varia entre processadores de XML, é recomendável que consulte uma referência como o Cheat Sheet da OWASP sobre Prevenção do XXE.
* Se a aplicação usa Security Assertion Markup Language (SAML) para processamento de identidade no contexto de segurança federada ou Single Sign-on (SSO): SAML usa XML para validação da identidade e pode por isso ser vulnerável.
* Se a aplicação usa SOAP anterior à versão 1.2, é provável que seja suscetível a ataques de XXE se as entidades XML estiverem a ser passadas à framework SOAP.
* Ser vulnerável a ataques de XXE muito provavelmente significa também que a aplicação é igualmente vulnerável a ataques de negação de serviço, incluindo o ataque billion laughs

## Exemplos de Cenários de Ataque
Numerosos problemas públicos com XXE têm vindo a ser descobertos, incluindo ataques a dispositivos embutidos. XXE ocorre em muitos locais não expectáveis, incluindo em dependências muito profundas. A forma mais simples de abuso passa por carregar um ficheiro XML, que, quando aceite:

#### Cenário #1: 
O atacante tenta extrair dados do servidor:
```xml
 <?xml version="1.0" encoding="ISO-8859-1"?>
 <!DOCTYPE foo [
  <!ELEMENT foo ANY >
  <!ENTITY xxe SYSTEM "file:///etc/passwd" >]>
 <foo>&xxe;</foo>
 ```
 
#### Cenário #2: 
Um atacante analisa a rede privada do servidor alterando a seguinte linha da ENTITY para:
`<!ENTITY xxe SYSTEM "https://192.168.1.1/private" >]>`

#### Cenário #3: 
Um atacante tenta efetuar um ataque de negação de serviço incluindo um potencial ficheiro sem fim:
`<!ENTITY xxe SYSTEM "file:///dev/random" >]>`

## Como Prevenir
O treino dos programadores é essencial para identificar e mitigar completamente o XXE. Para além disso:
* Optar por um formato de dados mais simples, tal como JSON.
* Corrigir ou atualizar todos os processadores e bibliotecas de XML usados pela aplicação, dependências ou sistema operativo. Atualizar SOAP para a versão 1.2 ou superior.
* Desativar o processamento de entidades externas de XML e de DTD em todos os processadores de XML em uso pela aplicação, tal como definido no Cheat Sheet da OWASP sobre Prevenção do XXE.
* Implementar validação, filtragem ou sanitização dos dados de entrada para valores permitidos (whitelisting) prevenindo dados hostis nos documentos de XML, cabeçalhos ou nós.
* Verificar que a funcionalidade de carregamento de ficheiros XML ou XSL valida o XML usando para o efeito XSD ou similar.
* As ferramentas SAST podem ajudar a detetar XXE no código fonte, ainda assim a revisão do código é a melhor alternativa em aplicações de grande dimensão e complexidade com várias integrações. Se estes controlos não forem possíveis considere a utilização de correções virtuais, gateways de segurança de APIs, ou WAFs para detetar, monitorizar e bloquear ataques de XXE