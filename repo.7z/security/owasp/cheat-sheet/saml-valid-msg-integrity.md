---
title: Validar a confidencialidade e integridade da mensagem
---

O TLS 1.2 é a solução mais comum para garantir a confidencialidade e integridade da mensagem na camada de transporte. Esta etapa ajudará a combater os seguintes ataques:

- Eavesdropping 7.1.1.1

- Roubo de informações de autenticação do usuário 7.1.1.2

- Roubo do token do portador 7.1.1.3

- Exclusão de mensagem 7.1.1.6

- Modificação de Mensagem 7.1.1.7

- Man-in-the-middle 7.1.1.8

Uma mensagem assinada digitalmente com uma chave certificada é a solução mais comum para garantir a integridade e autenticação da mensagem. Esta etapa ajudará a combater os seguintes ataques:

- Man-in-the-middle 6.4.2

- Asserção Forjada 6.4.3

- Modificação de Mensagem 7.1.1.7

As afirmações podem ser criptografadas via `XMLEnc` para evitar a divulgação de atributos confidenciais após o transporte. Esta etapa ajudará a combater os seguintes ataques:

- Roubo de informações de autenticação do usuário 7.1.1.2


### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)