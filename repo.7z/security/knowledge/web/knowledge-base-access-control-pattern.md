---
title: Padrões de Controle de Acesso
---
## Descrição

Para uma funcionalidade bem-sucedida de controle de acesso/login, há muitas coisas a serem consideradas antes de começar a desenvolver esse tipo de funcionalidade.

A utilização de alguns padrões de controle de acesso evita problemas conhecidos como acesso não autorizado de informações sensíveis e/ou de outros clientes e torna a aplicação mais segura, evitando um possível vazamentos de dados.

## Solução

É altamente recomendável estudar todos os itens listados e implementar esses princípios 
no sistema de controle de acesso/login para impor um nível mais alto de segurança.

1. Logs de auditoria
2. Princípio do menor privilégio (sistema de autenticação baseado em privilégios)
3. As senhas devem ser criptografadas
4. Cross-Site Request Forgery (CSRF para formulários autenticados)
5. Padrão de sessão
6. Fixação da sessão (OWASP - https://owasp.org/www-community/attacks/Session_fixation)
7. Seqüestro de sessão (OWASP - https://owasp.org/www-community/attacks/Session_hijacking_attack)
8. Função "Esqueci a senha" (OWASP - https://cheatsheetseries.owasp.org/cheatsheets/Forgot_Password_Cheat_Sheet.html)
9. Autenticação no lado do cliente
10. Gerenciamento de estado do lado do cliente
11. Ataque de cookie entre subdomínios