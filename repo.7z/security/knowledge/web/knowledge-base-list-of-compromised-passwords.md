---
title: Lista de Senhas Comprometidas
---
## Descrição

O aplicativo deve comparar a nova senha proposta com uma lista que contém valores conhecidos por serem comumente usados, esperados ou comprometidos.

## Solução
	
Verifique se as senhas novas ou alteradas são validadas com relação a uma lista de segredos comprometidos, e se for comprometido, o usuário será solicitado a escolher outro segredo.
Você pode incluir a lista de senhas como as encontradas aqui https://wiki.skullsecurity.org/Passwords e/ou use uma API que forneça uma lista de segredos comprometidos, como pode ser encontrado aqui https://haveibeenpwned.com/API/v2
