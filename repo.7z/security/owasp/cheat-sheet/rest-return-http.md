---
title: Código de retorno HTTP
---

HTTP define o código de status. Ao projetar a API REST, não use apenas `200` para obter sucesso ou `404` erro. Sempre use o código de status semanticamente apropriado para a resposta.

Aqui está uma seleção não exaustiva de códigos de status da API REST relacionados à segurança . Use-o para garantir que você retornou o código correto.

| Código 	| Mensagem                    	| Descrição                                                                                                                                                                                                                              	|
|--------	|-----------------------------	|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------	|
| 200    	| Está bem                    	| Resposta a uma ação API REST bem-sucedida. O método HTTP pode ser GET, POST, PUT, PATCH ou DELETE.                                                                                                                                     	|
| 201    	| Criada                      	| A solicitação foi atendida e o recurso criado. Um URI para o recurso criado é retornado no cabeçalho Location.                                                                                                                         	|
| 202    	| Aceitaram                   	| A solicitação foi aceita para processamento, mas o processamento ainda não foi concluído.                                                                                                                                              	|
| 301    	| Movido Permanentemente      	| Redirecionamento permanente.                                                                                                                                                                                                           	|
| 304    	| Não modificado              	| Resposta relacionada ao armazenamento em cache que é retornada quando o cliente tem a mesma cópia do recurso que o servidor.                                                                                                           	|
| 307    	| Redirecionamento temporário 	| Redirecionamento temporário de recurso.                                                                                                                                                                                                	|
| 400    	| Pedido ruim                 	| A solicitação está malformada, como erro de formato do corpo da mensagem.                                                                                                                                                              	|
| 401    	| Não autorizado              	| ID / senha de autenticação errada ou não fornecida.                                                                                                                                                                                    	|
| 403    	| Proibido                    	| É usado quando a autenticação foi bem-sucedida, mas o usuário autenticado não tem permissão para o recurso de solicitação.                                                                                                             	|
| 404    	| Não encontrado              	| Quando um recurso inexistente é solicitado.                                                                                                                                                                                            	|
| 405    	| Método não aceitável        	| O erro de um método HTTP inesperado. Por exemplo, a API REST espera HTTP GET, mas HTTP PUT é usado.                                                                                                                                    	|
| 406    	| Inaceitável                 	| O cliente apresentou um tipo de conteúdo no cabeçalho Aceitar que não é compatível com a API do servidor.                                                                                                                              	|
| 413    	| Carga útil muito grande     	| Use-o para sinalizar que o tamanho da solicitação excedeu o limite fornecido, por exemplo, em relação ao upload de arquivos.                                                                                                           	|
| 415    	| Tipo de mídia não suportado 	| O tipo de conteúdo solicitado não é compatível com o serviço REST.                                                                                                                                                                     	|
| 429    	| Muitos pedidos              	| O erro é usado quando pode haver um ataque DOS detectado ou a solicitação é rejeitada devido à limitação de taxa.                                                                                                                      	|
| 500    	| Erro do Servidor Interno    	| Uma condição inesperada impediu o servidor de atender à solicitação. Esteja ciente de que a resposta não deve revelar informações internas que ajudem um invasor, por exemplo, mensagens de erro detalhadas ou rastreamentos de pilha. 	|
| 501    	| Não implementado            	| O serviço REST ainda não implementa a operação solicitada.                                                                                                                                                                             	|
| 503    	| Serviço indisponível        	| O serviço REST está temporariamente impossibilitado de processar a solicitação. Usado para informar ao cliente que ele deve tentar novamente mais tarde.                                                                               	|

### Referência Externa

- [HTTP Status Code](https://www.restapitutorial.com/httpstatuscodes.html)

- [OWASP](https://cheatsheetseries.owasp.org/)