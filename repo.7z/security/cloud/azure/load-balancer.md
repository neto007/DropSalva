---
title: Azure Load Balancer 
sidebar_label: Load Balancer
---

**Proposta de melhores práticas de segurança para o uso do Load Balancer na Azure:**

O Azure Load Balancer é um balanceador de carga que distribui fluxos de conexões para instancias backend que opera na camada 4 do modelo OSI e é utilizado como único ponto de contato dos clientes. Esses fluxos de comunicação funcionam mediante as regras de balanceamento configuradas.

O objetivo desse documento é descrevermos as melhores práticas de segurança para a configuração do Load Balancer nas assinaturas da Azure.

## Pontos importantes sobre a estrutura proposta:

**Redes**
- Garantir o uso apenas do Load Balancer do tipo interno, permitindo apenas o trafego de redes virtuais conhecidas sem a exposição do mesmo para a internet;
- Em caso de necessidade de uso do Load Balancer externo, a solicitação deverá ser avaliada pelo time de Segurança da Informação;
- Recomendamos o uso de Load Balancer do tipo Standard para ambientes de produção, garantindo o uso de recursos como o Health Probe com HTTPS, HA ports e proteção para tráfegos internos com regras do NSG;
- Garantir que os recursos que receberão as conexões do Load Balancer estão protegidos com NSG (Network Security Gateway), garantindo dessa forma o balanceamento somente para portas e IPs específicos no backend. No caso da não existência do NSG o trafego não será balanceado para o recurso;

**Gerenciamento de identidade e acesso**
- Utilize o RBAC para gerenciamento dos recursos de Load Balancer;

**Monitoração**
- Garantir que os logs de auditoria em seu Lod Balancer estejam habilitados para registro das operações e também para permitir recriar trilhas de atividades para fins de investigação quando, por exemplo, ocorrer um incidente de segurança ou quando a rede for comprometida.

#### Abaixo alguns campos para correta configuração do Azure Load Balancer:

![Azure Load Balancer](/assets/security/cloud/azure-load-balancer.png)
