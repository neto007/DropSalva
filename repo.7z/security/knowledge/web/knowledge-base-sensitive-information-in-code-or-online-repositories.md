---
title: Informações confidenciais em código ou repositórios online
---
## Descrição

Sempre que segredos, chaves de API e senhas são armazenados no código-fonte dos aplicativos, um invasor pode potencialmente recuperar essas informações confidenciais, por exemplo:

1. Encontrar arquivos zip antigos com versões anteriores
2. Recupere e leia arquivos por meio de ataques de travessia de caminho

Também tome cuidado para não armazenar essas informações confidenciais em repositórios online.
Sempre que este repositório se torna público por acidente ou compromete todas essas informações confidenciais pode cair nas mãos de atacantes.

## Solução

Verifique se os segredos, chaves de API e senhas não estão incluídos no código-fonte ou no código-fonte online repositórios. Isso pode ser alcançado por revisões manuais de código e ferramentas potencialmente pequenas que verificam o código
para essas chaves e segredos por meio de correspondência de padrões.