---
title: Cross-Site Request Forgery (CSRF)
---

### Padrão de token baseado em HMAC

A mitigação de padrão de token baseado em HMAC também é alcançada sem manter nenhum estado no servidor. A proteção CSRF baseada em HMAC funciona de maneira semelhante à proteção CSRF baseada em criptografia, com algumas pequenas diferenças

- Ele usa uma função HMAC forte (SHA-256 ou maior) em vez de uma função de criptografia para gerar o token.
- O token consiste em um HMAC e um carimbo de data / hora.

Abaixo estão as etapas para a implementação adequada da proteção CSRF baseada em HMAC:

**Gere o token**
Usando a chave K, gere HMAC(session ID + timestamp) e anexe o mesmo valor de carimbo de data / hora a ela, o que resulta em seu token CSRF.
Inclui o token ( ou seja HMAC+timestamp )
Incluir token em um campo oculto para formulários e no campo do cabeçalho da solicitação / parâmetro do corpo da solicitação para solicitações AJAX.

**Validando o token**
Quando a solicitação é recebida no servidor, gere novamente o token com a mesma chave K (os parâmetros são o ID da sessão da solicitação e o carimbo de data / hora no token recebido). Se o HMAC no token recebido e o gerado nesta etapa corresponderem, verifique se o carimbo de data / hora recebido é menor que o tempo de expiração do token definido. Se ambos forem bem-sucedidos, a solicitação será tratada como legítima e poderá ser permitida. Caso contrário, bloqueie a solicitação e registre o ataque para fins de resposta a incidentes.

A folha de dicas de gerenciamento de chaves contém as melhores práticas sobre como gerenciar a chave HMAC.

### Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/)