---
title: Dados de sessão no navegador do cliente
---
## Descrição

Todos os dados autenticados devem ser removidos do armazenamento do navegador assim que
a sessão é encerrada. Isso reduz a possibilidade de um invasor em potencial obter
informações autenticadas confidenciais sempre que o aplicativo for atacado.

Essa abordagem também é necessária para desativar usuários não autenticados que tentam acessar as informações caso o usuário tiver efetuado login inicialmente em um computador público.

## Solução

Sempre que o usuário encerra sua sessão, todas as informações autenticadas confidenciais devem ser excluídas/limpas do navegador/armazenamento do cliente, tais como:

* Armazenamento local
* Armazenamento de sessão
* Web SQL
* Armazenamento em cache
* Cache da aplicação
* Entre outros