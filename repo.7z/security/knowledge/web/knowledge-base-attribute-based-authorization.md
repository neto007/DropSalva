---
title: Autorização Baseada em Atributos
---
## Descrição

Controle de acesso (ou autorização) é o processo de concessão ou negação de solicitações específicas de um usuário, programa ou processo. O controle de acesso também envolve o ato de conceder e revogar esses privilégios.

Importante ressaltar que a autorização (verificação do acesso a recursos ou recursos específicos) não é equivalente para autenticação (verificação de identidade).

## Solução

O controle de acesso baseado em atributos (ABAC) concederá ou negará solicitações de usuários com base em atributos do usuário e atributos arbitrários do objeto e condições do ambiente que podem ser reconhecidos globalmente e mais relevantes para as políticas em questão.

Depois de escolher um padrão de design de controle de acesso específico, geralmente é difícil e demorado para reconstruir o controle de acesso em seu aplicativo com um novo padrão. Controle de acesso é uma das principais áreas do design de segurança de aplicativos que deve ser completamente projetada com antecedência, especialmente ao atender requisitos como multilocação e controle de acesso horizontal (dependente de dados).


A melhor forma é alterando de:
```plain
if (user.hasRole("ADMIN")) || (user.hasRole("MANAGER")) {
   deleteAccount();
}
```

Para:

```plain
if (user.hasAccess("DELETE_ACCOUNT")) {
   deleteAccount();
}
```

Isso porque o último é mais gerenciável ao longo do tempo.

Para mais informações, consulte os 10 principais controles proativos da OWASP.

OWASP Pro Active Controls - Capítulo 7 - "Enforce Access Controls" ("Aplicar controles de acesso")
Link: https://www.owasp.org/index.php/OWASP_Proactive_Controls 