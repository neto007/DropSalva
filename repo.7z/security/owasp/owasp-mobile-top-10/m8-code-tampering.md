---
title: Code Tampering
---

## O aplicativo está vulnerável?
Tecnicamente, todo código móvel é vulnerável a adulteração de código. O código móvel é executado em um ambiente que não está sob o controle da organização que o produz. Ao mesmo tempo, existem muitas maneiras diferentes de alterar o ambiente em que o código é executado. Essas mudanças permitem que um adversário mexa no código e modifique-o à vontade.

Embora o código móvel seja inerentemente vulnerável, é importante perguntar a si mesmo se vale a pena detectar e tentar evitar a modificação não autorizada do código. Aplicativos escritos para determinados setores de negócios (jogos, por exemplo) são muito mais vulneráveis ​​aos impactos da modificação de código do que outros (hospitalidade, por exemplo). Como tal, é fundamental considerar o impacto nos negócios antes de decidir se deve ou não tratar desse risco.

## Cenários de exemplo de ataques
Existem vários aplicativos falsificados disponíveis nas lojas de aplicativos. Alguns deles contêm cargas de malware. Muitos dos aplicativos modificados contêm formas modificadas do binário principal original e recursos associados. O invasor os reempacota como um novo aplicativo e os libera em lojas de terceiros.

#### Cenário #1:

Os jogos são um alvo particularmente popular para atacar usando esse método. O invasor atrairá pessoas que não estão interessadas em pagar por nenhum recurso freemium do jogo. Dentro do código, o invasor dá um curto-circuito em saltos condicionais que detectam se uma compra no aplicativo foi bem-sucedida. Este desvio permite que a vítima obtenha artefatos de jogo ou novas habilidades sem pagar por eles. O invasor também inseriu um spyware que roubará a identidade do usuário.

#### Cenário #2:

Os aplicativos bancários são outro alvo popular de ataque. Esses aplicativos normalmente processam informações confidenciais que serão úteis para um invasor. Um invasor pode criar uma versão falsificada do aplicativo que transmite as informações de identificação pessoal (PII) do usuário junto com o nome de usuário / senha para um site de terceiros. Isso é uma reminiscência do equivalente de desktop do malware Zeus. Isso normalmente resulta em fraude contra o banco.

## Como prevenir
O aplicativo móvel deve ser capaz de detectar em tempo de execução que o código foi adicionado ou alterado do que ele sabe sobre sua integridade em tempo de compilação. O aplicativo deve ser capaz de reagir adequadamente em tempo de execução a uma violação de integridade do código.

As estratégias de remediação para este tipo de risco são descritas com mais detalhes técnicos no Projeto de Engenharia Reversa e Prevenção de Modificação de Código OWASP.

Detecção de raiz do Android Normalmente, um aplicativo que foi modificado será executado em um ambiente desbloqueado ou com acesso root. Como tal, é razoável tentar detectar esses tipos de ambientes comprometidos em tempo de execução e reagir de acordo (reportar ao servidor ou desligar). Existem algumas maneiras comuns de detectar um dispositivo Android com acesso root: Verifique se há chaves de teste

Verifique se build.prop inclui a linha ro.build.tags = test-keys indicando uma construção de desenvolvedor ou ROM não oficial

* Verifique se há certificados OTA
* Verifique se o arquivo /etc/security/otacerts.zip existe
* Verifique se há vários APKs com root conhecidos
* com.noshufou.android.su
* com.thirdparty.superuser
* eu.chainfire.supersu
* com.koushikdutta.superuser
* Verifique os binários do SU
* /system/bin/su
* /system/xbin/su
* /sbin/su
* /system/su
* /system/bin/.ext/.su
* Tentar o comando SU diretamente

Tente executar o comando su e verifique o id do usuário atual, se retornar 0 então o comando su foi bem sucedido
Detecção de Jailbreak iOS
