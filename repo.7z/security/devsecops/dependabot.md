`DependaBot` é um serviço que realiza a verificação de dependências diretamente no repositório do projeto, auxiliando os desenvolvedores a manter as mesmas atualizadas.

O fluxo é bem simples:

**Passo 1:**
Dependabot verifica se há atualizações
Dependabot puxa seus arquivos de dependência e procura por quaisquer requisitos desatualizados ou inseguros.

**Passo 2:**
Dependabot abre solicitações pull
Se alguma de suas dependências estiver desatualizada, o Dependabot abre solicitações pull individuais para atualizar cada uma.

**Passo 3:**
O desenvolvedor revisa e mescla
O desenvolvedor verifica se os testes foram bem-sucedidos, o changelog incluído e as notas de versão e, em seguida, clica em mesclar com confiança.

### Executando no Docker

Para criar a imagem Dependabot é bem simples:

Realize o clone deste [repositório](https://dev.azure.com/xpinvestimentos/SEC-INFO/_git/XPInc.DependaBot) para a máquina local. Com o docker em execução, entre na pasta Docker e execute o comando abaixo e aguarde o processo de construção da imagem:

```bash
docker build -t xpdependabot:lastest .
```

após concluído  a construção  da imagem do dependabot, crie e execute um contêiner a partir da imagem:

```bash
docker run --rm -t \
           -e GITHUB_ACCESS_TOKEN={token_Acess} \
           -e AZURE_HOSTNAME=<your-hostname> \
           -e AZURE_ACCESS_TOKEN=<your-devops-token-here> \
           -e AZURE_ORGANIZATION=<your-organization-here> \
           -e AZURE_PROJECT=<your-project-here> \
           -e AZURE_REPOSITORY=<your-repository-here> \
           -e DEPENDABOT_PACKAGE_MANAGER=<your-package-manager-here> \
           -e DEPENDABOT_DIRECTORY=/ \
           -e DEPENDABOT_TARGET_BRANCH=<your-target-branch> \
           -e DEPENDABOT_VERSIONING_STRATEGY=<your-versioning-strategy> \
           -e DEPENDABOT_OPEN_PULL_REQUESTS_LIMIT=10 \
           -e DEPENDABOT_EXTRA_CREDENTIALS=<your-extra-credentials> \
           -e DEPENDABOT_ALLOW=<your-allowed-packages> \
           -e DEPENDABOT_IGNORE=<your-ignore-packages> \
           xpdependabot
```

```bash
docker run  --rm -t \
            -e GITHUB_ACCESS_TOKEN=CHAVEGITHUB \
            -e AZURE_HOSTNAME=dev.azure.com \
            -e AZURE_ACCESS_TOKEN=CHAVE_AZUREDEVOPS \
            -e AZURE_ORGANIZATION=xpinvestimentos \
            -e AZURE_PROJECT=SEC-INFO \
            -e AZURE_REPOSITORY=XPInc.DevSecOps.Azure.DevOps..... \
            -e DEPENDABOT_PACKAGE_MANAGER=docker \
            -e DEPENDABOT_DIRECTORY=/ \
            -e DEPENDABOT_TARGET_BRANCH=main \
            -e DEPENDABOT_VERSIONING_STRATEGY=auto \
            -e DEPENDABOT_OPEN_PULL_REQUESTS_LIMIT=10 \
            xpdependabot
```

## Environment Variables

Para executar o script, algumas variáveis de ambiente são necessárias.

|Variable Name|Descrição|
|--|--|
|GITHUB_ACCESS_TOKEN|**_Opcional_**. O token GitHub para autenticação de solicitações em repositórios públicos do GitHub. Isso é útil para evitar erros de limitação de taxa para consultas acima de 10 dependência. O token deve incluir permissões para ler repositórios públicos. Veja a [documentação](https://docs.github.com/en/free-pro-team@latest/github/authenticating-to-github/creating-a-personal-access-token) para mais informações sobre tokens de acesso pessoal.|
|AZURE_HOSTNAME|**_Optional_**. O nome do host de onde a organização está hospedada.Padrões para `dev.azure.com` |
|AZURE_ACCESS_TOKEN|**_Required_**. Use Personal Access Token no Azure DevOps para acessar o repositório e criar solicitações de **PullRequest**.<br/> As permissões necessárias são: <br/>-&nbsp; Code (Full)<br/>-&nbsp; Pull Request Threads(Read & Write).<br/>Veja a [Documentação](https://docs.microsoft.com/en-us/azure/devops/organizations/accounts/use-personal-access-tokens-to-authenticate?view=azure-devops&tabs=preview-page#create-a-pat) para saber mais sobre como criar um Personal Access Token|
|AZURE_ORGANIZATION|**_Required_**.O nome da Organização do Azure DevOps, isso pode ser extraído do URL da página inicial. https://dev.azure.com/{organization}/|
|AZURE_PROJECT|**_Required_**. O nome do Azure DevOps Project na organização acima. Isso pode ser extraído do URL também. https://dev.azure.com/{organization}/{project}/|
|AZURE_REPOSITORY|**_Required_**. O nome do Azure DevOps Repository dentro do projeto acima para executar o Dependabot. Isso pode ser extraído da URL do repositório. https://dev.azure.com/{organization}/{project}/_git/{repository}/|
|DEPENDABOT_PACKAGE_MANAGER|**_Required_**. O tipo de pacote para verificar se há atualizações de dependência. Exemplos: `nuget`, `maven`, `gradle`, `npm_and_yarn`, etc. Veja a lista abaixo .|
|DEPENDABOT_DIRECTORY|**_Optional_**. O diretório no qual as dependências devem ser verificadas. Quando não especificado, a raiz do repositório (padrão '/') é usado.|
|DEPENDABOT_TARGET_BRANCH|**_Optional_**. O branch a ser direcionado ao criar uma solicitação pull.Quando não especificado, o Dependabot resolverá a ramificação padrão do repositório.|
|DEPENDABOT_VERSIONING_STRATEGY|**_Optional_**. A estratégia de controle de versão a ser usada. por padrão utiliza-se (auto), veja [official docs](https://docs.github.com/en/free-pro-team@latest/github/administering-a-repository/configuration-options-for-dependency-updates#versioning-strategy) para os valores permitidos|
|DEPENDABOT_OPEN_PULL_REQUESTS_LIMIT|**_Optional_**. O número máximo de solicitações de pull abertas a qualquer momento.O padrão é 5.|
|DEPENDABOT_EXTRA_CREDENTIALS|**_Optional_**. As credenciais extras no formato JSON.Credenciais extras podem ser usadas para acessar feeds NuGet privados, registros docker, repositórios maven, etc. Por exemplo, uma autenticação de registro privado (For example FontAwesome Pro: `[{"type":"npm_registry","token":"<redacted>","registry":"npm.fontawesome.com"}]`)|
|DEPENDABOT_ALLOW|**_Optional_**. As dependências cujas atualizações são permitidas, no formato JSON.Isso pode ser usado para controlar quais pacotes podem ser atualizados.Por exemplo: `[{\"name\":"django*",\"type\":\"direct\"}]`. Veja [official docs](https://docs.github.com/en/free-pro-team@latest/github/administering-a-repository/configuration-options-for-dependency-updates#allow) para mais. |
|DEPENDABOT_IGNORE|**_Optional_**. As dependências a serem ignoradas, no formato JSON.Isso pode ser usado para controlar quais pacotes podem ser atualizados.Por exemplo: `[{\"name\":\"express\",\"versions\":[\"4.x\",\"5.x\"]}]`. Vejo [official docs](https://docs.github.com/en/free-pro-team@latest/github/administering-a-repository/configuration-options-for-dependency-updates#ignore) para mais.|


Nome do gerenciador de pacotes para o qual você gostaria de fazer a atualização. As opções são:
 - bundler
 - pip (includes pipenv)
 - npm_and_yarn
 - maven
 - gradle
 - cargo
 - hex
 - composer
 - nuget
 - dep
 - go_modules
 - elm
 - submodules
 - docker
 - terraform