---
title: Bloqueio de conta
---
## Descrição

Devido a ataques de força bruta.
Todas as aplicações devem ter a possibilidade de bloquear contas sempre que
detectar ataques por/sobre usuários. Além disso, você deve incluir opções para mecanismos de bloqueio suave e rígido.

## Solução

Bloqueio suave:
Essa pode ser uma boa opção para proteger seus usuários contra ataques de força bruta.
Por exemplo, sempre que o usuário digita uma senha errada três vezes, o aplicativo pode
bloquear a conta por um minuto, a fim de retardar o processo de bruto forçando sua
senha tornando menos lucrativo para o invasor prosseguir. Se você fosse implementar
contramedidas de bloqueio rígido para este exemplo, você obteria um "DoS" permanentemente para bloqueio de contas.

Bloqueio rígido:
Esse tipo de bloqueio deve ser aplicado sempre que você detectar um usuário atacando sua
aplicação e barrá-lo por meio de bloqueio permanente de sua conta até que uma 
equipe de resposta tenha tempo para fazer uma perícia. Após esse processo, você pode decidir devolver ao usuário a própria conta ou tomar outras ações legais contra ele.
Esse tipo de abordagem evita que o invasor penetre ainda mais no seu aplicativo e infraestrutura.

Nota:
Tenha cuidado para que uma contramedida de bloqueio suave não substitua um status de bloqueio rígido.