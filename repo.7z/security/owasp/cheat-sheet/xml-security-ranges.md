---
title: Ranges
---

Os aplicativos de software, bancos de dados e linguagens de programação normalmente armazenam informações em intervalos específicos. Sempre que usar um elemento ou atributo em locais onde certos tamanhos específicos importam (para evitar `overflows` ou `underflows`), seria lógico verificar se o comprimento dos dados é considerado válido. O esquema a seguir pode restringir um nome usando um comprimento mínimo e máximo para evitar cenários incomuns:

```xml 

<xs:element name="name">
 <xs:simpleType>
  <xs:restriction base="xs:string">
   <xs:minLength value="3"/>
   <xs:maxLength value="256"/>
  </xs:restriction>
 </xs:simpleType>
</xs:element>
```

Nos casos em que os valores possíveis são restritos a um determinado comprimento específico (digamos 8), esse valor pode ser especificado da seguinte forma para ser válido:

```xml

<xs:element name="name">
 <xs:simpleType>
  <xs:restriction base="xs:string">
   <xs:length value="8"/>
  </xs:restriction>
 </xs:simpleType>
</xs:element>

```

## Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/cheatsheets/XML_Security_Cheat_Sheet.html)
