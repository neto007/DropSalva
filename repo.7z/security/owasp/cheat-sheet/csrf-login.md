---
title: Login CSRF (Cross-Site Request Forgery)
---

A maioria dos desenvolvedores tende a ignorar a vulnerabilidade de CSRF em formulários de login, pois presumem que CSRF não seria aplicável em formulários de login porque o usuário não é autenticado nesse estágio; no entanto, essa suposição nem sempre é verdadeira. Vulnerabilidades de CSRF ainda podem ocorrer em formulários de login em que o usuário não está autenticado, mas o impacto e o risco são diferentes.

Por exemplo, se um invasor usa CSRF para autenticar uma vítima em um site de compras usando a conta do invasor, e a vítima então insere as informações do cartão de crédito, um invasor pode comprar itens usando os detalhes armazenados do cartão da vítima. Para obter mais informações sobre o login CSRF e outros riscos.

O CSRF de login pode ser atenuado criando pré-sessões (sessões antes de um usuário ser autenticado) e incluindo tokens no formulário de login. Você pode usar qualquer uma das técnicas mencionadas acima para gerar tokens. Lembre-se de que as pré-sessões não podem ser transferidas para sessões reais depois que o usuário é autenticado - a sessão deve ser destruída e uma nova deve ser feita para evitar ataques de fixação de sessão . Esta técnica é descrita em Defesas robustas para falsificação de solicitação entre sites.

Se os subdomínios em seu domínio mestre não forem confiáveis ​​em seu modelo de ameaça, será difícil mitigar o CSRF de login. Um subdomínio estrito e validação de cabeçalho de referenciador de nível de caminho podem ser usados ​​nesses casos para atenuar CSRF em formulários de login até certo ponto.

### Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/)