---
title: Informações Confidenciais
---
## Descrição

A exposição de informações por meio de strings de consulta no URL ocorre quando dados confidenciais são passados ​​para parâmetros no URL. Isso permite que os invasores obtenham dados confidenciais, como nomes de usuário, senhas, tokens (authX), detalhes do banco de dados e quaisquer outros dados potencialmente confidenciais. Simplesmente usar HTTPS não resolve esta vulnerabilidade.

Independentemente de usar criptografia, o seguinte URL irá expor informações nos locais detalhados abaixo:
`https://vulnerablehost.com/authuser?user=bob&authz_token=1234&expire=1500000000`

Os valores dos parâmetros para 'usuário', 'authz_token' e 'expirar' serão expostos nos seguintes locais
ao usar HTTP ou HTTPS:

- Cabeçalho de referência
- Logs web
- Sistemas Compartilhados
- Histórico do navegador
- Cache do navegador
- Espiar sobre os ombros
- Homem no meio



## Solução

Informações confidenciais nunca devem ser incluídas no URL.