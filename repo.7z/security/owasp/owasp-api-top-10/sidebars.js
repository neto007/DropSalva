module.exports = {
    type: "category",
    label: "API Top 10",
    items: [    
        "chapters/security/owasp/owasp-api-top-10/api1-broken-object-level-authorization",
        "chapters/security/owasp/owasp-api-top-10/api2-broken-user-authentication",
        "chapters/security/owasp/owasp-api-top-10/api3-excessive-data-exposure",
        "chapters/security/owasp/owasp-api-top-10/api4-lack-of-resources-rate-limiting",
        "chapters/security/owasp/owasp-api-top-10/api5-broken-function-level-authorization",
        "chapters/security/owasp/owasp-api-top-10/api6-mass-assignment",
        "chapters/security/owasp/owasp-api-top-10/api7-security-misconfiguration",
        "chapters/security/owasp/owasp-api-top-10/api8-Injection",
        "chapters/security/owasp/owasp-api-top-10/api9-improper-assets-management",
        "chapters/security/owasp/owasp-api-top-10/api10-insufficient-logging-monitoring",
    ],
};