---
title: Proteções WAF de gerenciamento de sessão
---

Existem situações em que o código-fonte do aplicativo da web não está disponível ou não pode ser modificado, ou quando as alterações necessárias para implementar as várias recomendações de segurança e melhores práticas detalhadas acima implicam em um redesenho completo da arquitetura do aplicativo da web e, portanto, não podem ser facilmente implementadas A curto prazo.

Nestes cenários, ou para complementar as defesas do aplicativo web, e com o objetivo de manter o aplicativo web o mais seguro possível, é recomendado o uso de proteções externas, como Firewalls de Aplicativos Web (WAFs) que podem mitigar as ameaças de gerenciamento de sessão já descritas .

Os firewalls de aplicativos da Web oferecem recursos de detecção e proteção contra ataques baseados em sessão. Por um lado, é trivial para WAFs impor o uso de atributos de segurança em cookies, como os sinalizadores Securee HttpOnly, aplicando regras básicas de reescrita no Set-Cookiecabeçalho para todas as respostas de aplicativos da web que definem um novo cookie.

Por outro lado, recursos mais avançados podem ser implementados para permitir que o WAF controle as sessões e os IDs de sessão correspondentes e aplique todos os tipos de proteção contra a fixação de sessão (renovando o ID de sessão no lado do cliente quando o privilégio mudar são detectados), impondo sessões persistentes (verificando a relação entre o ID da sessão e outras propriedades do cliente, como o endereço IP ou User-Agent) ou gerenciando a expiração da sessão (forçando o cliente e o aplicativo da web a finalizar a sessão) .

O ModSecurity WAF de código aberto, mais o OWASP Core Rule Set , fornecem recursos para detectar e aplicar atributos de cookies de segurança, contra-medidas contra ataques de fixação de sessão e recursos de rastreamento de sessão para reforçar as sessões persistentes.


### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)