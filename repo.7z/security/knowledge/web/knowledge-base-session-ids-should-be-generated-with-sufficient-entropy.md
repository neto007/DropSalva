---
title: Os Ids De Sessão Devem Ser Gerados Com Entropia Suficiente
---
## Descrição

Sempre que os IDs de sessão não são gerados com uma entropia suficiente, isso pode levar a um
colisão de sessão ou sequestro de sessão. Se um invasor pode adivinhar um usuário autenticado
identificador de sessão, ele pode assumir a sessão do usuário.

## Solução

O descritor de implantação do WebLogic deve especificar um comprimento de identificador de sessão de pelo menos 128 bits. Um identificador de sessão mais curto deixa o aplicativo aberto para ataques de adivinhação de sessão de força bruta.