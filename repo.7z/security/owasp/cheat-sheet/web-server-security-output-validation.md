---
title: Codificação de saída
---

Os serviços da Web precisam garantir que a saída enviada aos clientes seja codificada para ser consumida como dados e não como scripts. Isso se torna muito importante quando os clientes de serviço da web usam a saída para renderizar páginas HTML direta ou indiretamente usando objetos AJAX.

**Regra:** Todas as regras de codificação de saída se aplicam de acordo com a Folha de Dicas de Prevenção de Scripts Cross Site .

## Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/)
