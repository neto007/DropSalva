---
title: Cabeçalhos de segurança de respostas da API
---
## Descrição

Existem alguns cabeçalhos de segurança que devem ser configurados corretamente para proteger alguns retornos de chamada da API contra o download de arquivos refletivos e outros tipos de injeções.

Verifique também se a resposta da API é dinâmica, se a entrada do usuário é refletida na resposta. Nesse caso, você deve validar e codificar a entrada para impedir ataques de execução do método XSS e "same origin".

## Solução

Sanitizar a entrada da sua API (neste caso, eles devem permitir apenas alfanuméricos); escapar não é suficiente.

Verifique se todas as respostas da API contêm 'X-Content-Type-Options: nosniff', para impedir que o navegador interprete os arquivos como algo que não seja declarado pelo tipo de conteúdo (isso ajuda a impedir o XSS se a página for interpretada como HTML ou JS).

Adicione 'Content-Disposition: anexo; filename = "filename.extension" 'com a extensão correspondente à extensão do arquivo e ao tipo de conteúdo, nas APIs que não serão renderizadas.