---
title: Desserialização segura em python
---

## Avaliação do BlackBox
Se os dados de tráfego contiverem o ponto do símbolo "." no final, é muito provável que os dados tenham sido enviados em serialização.

## Análise WhiteBox
A seguinte API em Python estará vulnerável a ataques de deserialização.

O uso de `pickle/c_pickle/_pickle with load/loads`:

```python
import pickle
data = """ cos.system(S'dir')tR. """
pickle.loads(data)
```

O Uso de PyYAML com load:

```python
import yaml
document = "!!python/object/apply:os.system ['ipconfig']"
print(yaml.load(document))
Usos de jsonpicklecom encodeou storemétodos.
```

## Referência externa

[OWASP - Desserialização python](https://cheatsheetseries.owasp.org/cheatsheets/Deserialization_Cheat_Sheet.html#python)