---
title: Todas as conexões devem ser TLS
---
## Descrição

Sempre que um aplicativo fornece TLS, todas as conexões devem ser TLS, caso contrário, a
criptografia será perdida.

## Solução

Verifique se o TLS é usado para todas as conexões (incluindo conexões internas de back-end) que estão usando tokens de autenticação ou que envolvam dados ou funções confidenciais. Isso também deve ser aplicado no próprio aplicativo, sempre que possível.

Por exemplo: Sinalizadores (flags) seguros em cookies, HSTS, fixação de certificado e etc.