---
title: Controle de acesso - RBAC
---

Na metodologia Role-Based Access Control (RBAC), as decisões de acesso são baseadas nas funções e responsabilidades de um indivíduo dentro da organização ou base de usuários.

O processo de definição de funções geralmente é baseado na análise dos objetivos fundamentais e da estrutura de uma organização e geralmente está vinculado à política de segurança. Por exemplo, em uma organização médica, as diferentes funções dos usuários podem incluir aquelas como médico, enfermeira, atendente, pacientes, etc. Esses membros exigem diferentes níveis de acesso para desempenhar suas funções, mas também os tipos de transações na web e seu contexto permitido varia muito, dependendo da política de segurança e quaisquer regulamentos relevantes (HIPAA, Gramm-Leach-Bliley, etc.).

Uma estrutura de controle de acesso RBAC deve fornecer aos administradores de segurança de aplicativos da web a capacidade de determinar quem pode executar quais ações, quando, de onde, em que ordem e, em alguns casos, sob quais circunstâncias relacionais.

### As vantagens de usar esta metodologia

* As funções são atribuídas com base na estrutura organizacional, com ênfase na política de segurança organizacional
* Fácil de usar
* Fácil de administrar
* Integrado na maioria das estruturas
* Alinha-se com os princípios de segurança, como segregação de funções e privilégios mínimos

### Problemas que podem ser encontrados ao usar esta metodologia

* A documentação das funções e acessos deve ser mantida rigorosamente.
* A multilocação não pode ser implementada de forma eficaz, a menos que haja uma maneira de associar as funções aos requisitos de capacidade de multilocação, por exemplo, OU no Active Directory
* Há uma tendência de aumento do escopo, por exemplo, mais acessos e privilégios podem ser dados do que o pretendido. Ou um usuário pode ser incluído em duas funções se as revisões de acesso adequadas e a revogação subsequente não forem realizadas.
* Não suporta controle de acesso baseado em dados
* As áreas de cautela ao usar o RBAC são:

As funções só devem ser transferidas ou delegadas usando procedimentos e aprovações estritas.
Quando um usuário muda sua função para outra, o administrador deve certificar-se de que o acesso anterior seja revogado de forma que, em qualquer ponto do tempo, um usuário seja atribuído apenas a essas funções com base na necessidade de saber. A garantia para RBAC deve ser realizada usando análises de controle de acesso rígidas.

## Referência externa
[OWASP - Controle de acesso RBAC](https://cheatsheetseries.owasp.org/cheatsheets/Access_Control_Cheat_Sheet.html#role-based-access-control-rbac)