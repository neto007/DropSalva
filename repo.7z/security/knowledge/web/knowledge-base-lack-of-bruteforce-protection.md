---
title: Falta de Proteção contra Força Bruta
---
## Descrição

Toda senha é hackável. Até as mais fortes também. O nome da técnica é Força Bruta (bruteforce). Caso o invasor possa fazer milhares de tentativas de login para descobrir a senha correta, basta uma questão de tempo e ele/ela terá êxito.

## Solução

É recomendado empregar-se diferentes níveis de controles como: limite de tentativas, CAPTCHA, aumentar delays, restrições de IP, bloqueio de contas, restrições baseadas em riscos. Verifique que não mais do 5-7 tentativas falhas sejam possíveis em uma única conta.
