---
title: Segurança GraphQL
---
## Descrição

O GraphQL é uma linguagem de manipulação e consulta de dados de código aberto para APIs,
e um tempo de execução para atender a consultas com dados existentes. GraphQL foi
desenvolvido internamente pelo Facebook em 2012 antes de ser lançado publicamente 
em 2015. Em 7 de novembro de 2018, o projeto GraphQL foi movido do Facebook
à recém-criada fundação GraphQL, hospedada pela Linux Foundation, sem fins lucrativos.

## Solução

Verifique se o GraphQL ou outra lógica de autorização da camada de dados está
implementado na camada de lógica de negócios em vez da camada GraphQL.