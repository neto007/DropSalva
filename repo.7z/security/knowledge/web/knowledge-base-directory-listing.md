---
title: Listagem de diretório
---
## Descrição

Sempre que a listagem de diretórios estiver ativada, um invasor poderá obter informações confidenciais sobre estrutura hierárquica do sistema e obter conhecimento sobre diretórios ou arquivos que devem possivelmente não seja acessível ao público. Um invasor pode usar essas informações para aumentar seu vetor de ataque. Em alguns casos, isso pode levar o invasor a adquirir conhecimento sobre credenciais ou funções antigas de demonstração do sistema vulnerável que podem levar à execução remota de código.

## Solução

Diferentes tipos de servidores requerem um tipo diferente de abordagem para desativar
listagem de diretório. Por exemplo: o Apache usa um .htacces para desativar a listagem de diretórios. Quanto ao iis7, a listagem de diretórios é desativada por padrão.