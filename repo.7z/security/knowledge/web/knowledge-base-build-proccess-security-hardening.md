---
title: Reforço de segurança no processo de build
---
## Descrição

A criação de um aplicativo sempre deve ser feita em um servidor em que você confia, você está no controle e tem os mais recentes patches de segurança e proteção configurados. Em alguns aplicativos, você pode usar segurança técnicas e módulos que podem proteger seu aplicativo contra problemas de segurança conhecidos. Sempre use estes técnicas quando disponíveis.

## Solução

Certifique-se de que os processos de construção para linguagens no nível do sistema tenham todos os sinalizadores de segurança ativados, como ASLR, DEP e outras verificações de segurança específicas para a sua aplicação.