---
title: Configurações de segurança em frameworks
---
## Descrição

Sempre que certas configurações de segurança em suas estruturas de aplicativos
(por exemplo, Struts, Spring, ASP.NET) e as bibliotecas não estão definidas para proteger os valores, isso pode levar a vulnerabilidades em seu aplicativo que um invasor pode explorar.

## Solução

Certifique-se de que todas as configurações de segurança em sua estrutura de desenvolvimento estejam definidas para valores seguros. Isso pode ser verificado usando guias de endurecimento.