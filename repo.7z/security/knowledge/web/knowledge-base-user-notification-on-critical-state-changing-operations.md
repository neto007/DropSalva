---
title: Notificação do usuário sobre mudanças
---
## Descrição
Quando um usuário é informado de operações críticas, ele pode determinar
se a notificação é enviada por suas próprias ações, ou se a notificação indica
potencial comprometimento de sua conta de usuário.

## Solução

Verifique se as notificações seguras são enviadas aos usuários após as atualizações
para detalhes de autenticação, como redefinições de credenciais, e-mail ou alterações de endereço, logando de locais desconhecidos ou arriscados. Os usuários também devem ser notificados quando há alterações nas políticas de senha ou quaisquer outras atualizações importantes que requeiram ação do usuário para aumentar a segurança de sua conta.

O uso de notificações push - em vez de SMS ou e-mail - é preferido, mas na
ausência de notificações push, SMS ou e-mail é aceitável, desde que nenhuma informação sensível seja divulgada na notificação.