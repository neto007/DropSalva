---
title: Prevenção de injeção de SQL
---

Ataques de injeção de SQL são infelizmente muito comuns, e isso se deve a dois fatores:

- a prevalência significativa de vulnerabilidades de injeção de SQL e
- a atratividade do destino (ou seja, o banco de dados normalmente contém todos os dados interessantes / críticos para sua aplicação).

As falhas de injeção de SQL são introduzidas quando os desenvolvedores de software criam consultas dinâmicas de banco de dados que incluem entradas fornecidas pelo usuário. Para evitar falhas de injeção de SQL é simples. Os desenvolvedores precisam: 

- Parar de escrever consultas dinâmicas.

- Evitar que a entrada fornecida pelo usuário que contém SQL malicioso afete a lógica da consulta executada.

Essas técnicas podem ser usadas com praticamente qualquer tipo de linguagem de programação com qualquer tipo de banco de dados. Existem outros tipos de bancos de dados, como bancos de dados XML, que podem ter problemas semelhantes (por exemplo, injeção XPath e XQuery) e essas técnicas podem ser usadas para protegê-los também.


As falhas de injeção de SQL normalmente são assim:

O seguinte exemplo (`Java`) é INSEGURO e permitiria que um invasor injetasse código na consulta que seria executada pelo banco de dados. O parâmetro não validado "customerName" que é simplesmente anexado à consulta permite que um invasor injete qualquer código SQL que desejar. Infelizmente, esse método para acessar bancos de dados é muito comum.

```java

String query = "SELECT account_balance FROM user_data WHERE user_name = "
             + request.getParameter("customerName");
try {
    Statement statement = connection.createStatement( ... );
    ResultSet results = statement.executeQuery( query );
}

```


### Defesas:

- [Uso de instruções preparadas (com consultas parametrizadas)](prevent-sql-inject-defense-query-parameter.md)

- [Uso de procedimentos armazenados](prevent-sql-inject-defense-stored-procedure.md)

- [Validação de entrada da lista de permissões](prevent-sql-inject-valid-input.md)

- [Escapar de todas as entradas fornecidas pelo usuário](prevent-t-sql-inject-escape.md)


### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)