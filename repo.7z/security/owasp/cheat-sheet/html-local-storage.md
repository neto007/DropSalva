---
title: Armazenamento seguro em HTML
---

## Armazenamento Local

Também conhecido como armazenamento offline, armazenamento na web. O mecanismo de armazenamento subjacente pode variar de um agente de usuário para outro. Em outras palavras, qualquer autenticação que seu aplicativo requer pode ser ignorada por um usuário com privilégios locais para a máquina na qual os dados estão armazenados. Portanto, é recomendado não armazenar nenhuma informação sensível no armazenamento local.

Use o objeto sessionStorage em vez de localStorage se o armazenamento persistente não for necessário. O objeto sessionStorage está disponível apenas para aquela janela/guia até que a janela seja fechada. Um único Cross Site Scripting pode ser usado para roubar todos os dados nesses objetos, portanto, novamente, é recomendado não armazenar informações confidenciais no armazenamento local.

Um único Cross Site Scripting também pode ser usado para carregar dados maliciosos nesses objetos, portanto, não considere os objetos neles como confiáveis.
Preste atenção extra às chamadas "localStorage.getItem" e "setItem" implementadas na página HTML5. Ajuda a detectar quando os desenvolvedores criam soluções que colocam informações confidenciais no armazenamento local, o que é uma prática ruim.

Não armazene identificadores de sessão no armazenamento local, pois os dados estão sempre acessíveis por JavaScript. Os cookies podem mitigar esse risco usando o httpOnly. Não há como restringir a visibilidade de um objeto a um caminho específico como no caminho de atributo de Cookies HTTP, todo objeto é compartilhado dentro de uma origem e protegido com a Política de Mesma Origem. Evite hospedar vários aplicativos na mesma origem, todos eles compartilhariam o mesmo objeto localStorage e, em vez disso, use diferentes subdomínios.