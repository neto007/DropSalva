---
title: Envenenamento de Esquema de remoto
---

Os esquemas definidos por organizações externas são normalmente referenciados remotamente. Se for capaz de desviar ou acessar o tráfego da rede, um invasor pode fazer com que a vítima busque um tipo distinto de conteúdo, em vez do originalmente pretendido.

### ATAQUE MAN-IN-THE-MIDDLE (MITM)

Quando os documentos fazem referência a esquemas remotos usando o protocolo `HTTP` (Hypertext Transfer Protocol) não criptografado, a comunicação é realizada em texto simples e um invasor pode facilmente adulterar o tráfego. Quando os documentos XML fazem referência a esquemas remotos usando uma conexão `HTTP`, a conexão pode ser detectada e modificada antes de chegar ao usuário final:


```xml

<!DOCTYPE note SYSTEM "http://example.com/note.dtd">
<note>
 <to>Tove</to>
 <from>Jani</from>
 <heading>Reminder</heading>
 <body>Don't forget me this weekend</body>
</note>

```

O arquivo remoto `note.dtd` pode ser suscetível a adulteração quando transmitido usando o protocolo HTTP não criptografado. Uma ferramenta disponível para facilitar esse tipo de ataque é o `mitm proxy`.

## Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/cheatsheets/XML_Security_Cheat_Sheet.html)