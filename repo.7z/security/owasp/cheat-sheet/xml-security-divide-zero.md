---
title: Divisão por zero
---

Sempre que usar valores controlados pelo usuário como denominadores em uma divisão, os desenvolvedores devem evitar permitir o número zero. Nos casos em que o valor zero é usado para divisão em `XSLT`, o erro `FOAR0001` ocorrerá. Outros aplicativos podem lançar outras exceções e o programa pode falhar. Existem tipos de dados específicos para esquemas `XML` que evitam especificamente usar o valor zero. Por exemplo, nos casos em que valores negativos e zero não são considerados válidos, o esquema pode especificar o tipo de dados `positiveInteger` para o elemento.

```xml

<xs:element name="denominator">
 <xs:simpleType>
  <xs:restriction base="xs:positiveInteger"/>
 </xs:simpleType>
</xs:element>

```

O elemento `denominator` agora está restrito a inteiros positivos. Isso significa que apenas valores maiores que zero serão considerados válidos. Se você vir qualquer outro tipo de restrição sendo usado, poderá disparar um erro se o denominador for zero.

## Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/cheatsheets/XML_Security_Cheat_Sheet.html)