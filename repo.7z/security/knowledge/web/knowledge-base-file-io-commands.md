---
title: Comandos de E/S de arquivo
---
## Descrição

Os comandos de E/S (Entrada e Saída) permitem que você possua, use, leia, escreva para, feche dispositivos e direcione E/S operações para um dispositivo. Sempre que o usuário forneceu entrada, ou seja, nomes de arquivos e/ou dados de arquivos usado diretamente nesses comandos, isso pode levar ao percurso, caminho local inclui, arquivo tipo mime e vulnerabilidades de injeção de comando do SO.

## Solução

Os nomes e o conteúdo do arquivo devem ser limpos antes de serem utilizados nos comandos de E/S.