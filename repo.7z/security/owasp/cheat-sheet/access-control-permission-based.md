---
title: Controle de acesso - Baseado em permissão
---

O conceito-chave no Controle de acesso baseado em permissão é a abstração das ações do aplicativo em um conjunto de permissões . Uma permissão pode ser representada simplesmente como um nome baseado em string, por exemplo, "READ". As decisões de acesso são feitas verificando se o usuário atual tem a permissão associada à ação do aplicativo solicitada.

O relacionamento entre o utilizador e autorização pode ser satisfeito através da criação de uma relação direta entre o utilizador e autorização (chamado uma concessão ), ou um indireto. No modelo indireto, a concessão de permissão é para uma entidade intermediária, como um grupo de usuários. Um usuário é considerado membro de um grupo de usuários se e somente se o usuário herdar permissões do grupo de usuários. O modelo indireto torna mais fácil gerenciar as permissões para um grande número de usuários, pois a alteração das permissões atribuídas ao grupo de usuários afeta todos os membros do grupo.

Em alguns sistemas de Controle de Acesso Baseado em Permissão que fornecem controle de acesso de nível de objeto de domínio refinado, as permissões podem ser agrupadas em classes. Neste modelo, assume-se que cada objeto de domínio no sistema pode ser associado a uma classe que determina as permissões aplicáveis ​​ao respectivo objeto de domínio. Em tal sistema, uma classe "DOCUMENTO" pode ser definida com as permissões "LER", "ESCREVER" e "EXCLUIR"; uma classe "SERVIDOR" pode ​​ser definida com as permissões "INICIAR","PARAR" e "REINICIALIZAR".

## Referência externa
[OWASP - Controle de acesso baseado em permissão](https://cheatsheetseries.owasp.org/cheatsheets/Access_Control_Cheat_Sheet.html#permission-based-access-control)