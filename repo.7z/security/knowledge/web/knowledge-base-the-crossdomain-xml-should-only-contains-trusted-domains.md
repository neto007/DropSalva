---
title: O crossdomain.xml deve conter apenas domínios confiáveis
---
## Descrição

O uso de um arquivo crossdomain.xml é necessário quando a aplicação web usa Flash.
Este arquivo é usado para definir restrições para quaisquer outros servidores da web usando a
aplicação Flash. Se não estiverem definidos corretamente, um invasor pode explorar isso para
executar ataques direcionados contra os usuários da aplicação.

## Solução

Sempre certifique-se de que crossdomain.xml contenha apenas domínios confiáveis.
