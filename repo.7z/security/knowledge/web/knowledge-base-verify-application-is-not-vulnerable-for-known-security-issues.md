---
title: Verifique se o aplicativo não é vulnerável a problemas de segurança conhecidos
---
## Descrição

Sempre que pesquisadores de segurança encontrarem uma vulnerabilidade em uma biblioteca, módulos, frameworks, plataformas ou sistema operacional, essas vulnerabilidades são relatadas e salvas na lista CVE.

CVE é uma lista de vulnerabilidades e exposições de segurança da informação que visa fornecer
nomes comuns para problemas de segurança cibernética publicamente conhecidos. O objetivo do CVE é tornar mais fácil o compartilhamento de dados entre recursos de vulnerabilidade separados (ferramentas, repositórios e serviços) com esta "enumeração comum".

Os invasores podem usar essas listas para encontrar exploits publicamente conhecidos que podem existir no aplicativo de destino.
Muitos exploits CVE populares também têm exploits disponíveis no Metasploit
ou o banco de dados Exploit. Isso permite que os script kiddies explorem facilmente os aplicativos de destino, serviços, bibliotecas e sistemas operacionais.

## Solução

Verifique se todos os componentes do aplicativo, bibliotecas, módulos,
frameworks, plataforma e sistemas operacionais estão livres de vulnerabilidades conhecidas.

Isso poderia ser alcançado, por exemplo, com o gerenciamento estrito de patches e verificação periódica de ambiente para novos CVEs emitidos.

Também é altamente recomendável executar as bibliotecas e módulos de aplicativos no SDLC
por meio de ferramentas como verificação de dependência OWASP. Esta ferramenta verifica os módulos e bibliotecas importados para CVEs conhecidos.

Link: https://www.owasp.org/index.php/OWASP_Dependency_Check