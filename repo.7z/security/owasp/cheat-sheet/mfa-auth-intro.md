---
title: Autorização de transação (2MFA)
---

Os cenários de uso não se limitam apenas aos sistemas financeiros. Por exemplo: um e-mail com um código secreto ou um link com algum tipo de token para desbloquear uma conta de usuário também é um caso especial de autorização de transação. Um usuário autoriza a operação de desbloqueio de conta usando um segundo fator (um código único enviado para seu endereço de e-mail). A autorização de transação pode ser implementada usando vários métodos, por exemplo:

- Cartões com números de autorização de transação (TAN),

- Tokens OTP baseados em tempo, como OATH TOTP (senha única baseada em tempo) ,

- OTP enviado por SMS ou fornecido por telefone

- Assinatura digital usando, por exemplo, um cartão inteligente ou um telefone inteligente,

- Tokens de resposta de desafio, incluindo leitores de cartão não conectados ou soluções que fazem a varredura dos dados da transação na tela do computador do usuário.

- Alguns deles podem ser implementados em um dispositivo físico ou em um aplicativo móvel.

A autorização de transação é implementada a fim de proteger contra transferências eletrônicas não autorizadas como resultado de ataques usando `malware`, `phishing`, senha ou sequestro de sessão, `CSRF`, `XSS`, etc. Infelizmente, como acontece com qualquer pedaço de código, esta proteção pode ser implementada incorretamente e como resultado, pode ser possível contornar essa proteção.


### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)