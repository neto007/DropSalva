---
title: Truncamento De Coluna - SQL Injection
---
## Descrição

Sempre que a lógica estrutural de um aplicativo não combina com a lógica estrutural do banco de dados, um invasor ganha a oportunidade de truncar seu envio para a coluna do banco de dados, enviando um valor maior do que o limite permitido no banco de dados. Imagine que você tem um sistema onde os usuários podem se cadastrar.

O invasor pode abusar desse comportamento do banco de dados para estourar o limite de comprimento e truncar seu envio e se registrar como administrador, obtendo assim seus privilégios.

## Solução

Em locais críticos onde valores únicos são impostos e esperados,
como nomes de usuário para autorizar ou distribuir certos privilégios. Os usuários enviam
deve ser verificado no lado do servidor, a fim de verificar se não excede o limite
definido em seu banco de dados.