---
title: Validação da sessão
---
## Descrição

Um provedor de serviços credenciais (ou provedor de identidades) é uma entidade de gerenciamento de acesso a identidades que libera tokens de segurança para usuários de serviços específicos (chamados terceiros ou prestadores de serviços). Um provedor de identidade torna possível autenticar o usuário nos serviços registrados, sem exigir que eles efetuem login novamente para cada aplicativo.

Ao implantar um provedor de serviços de credenciais, é necessário verificar se o provedor de serviços de credenciais e as partes confiáveis ​​confiam nos mecanismos de gerenciamento de sessões de maneira segura.

## Solução

Para garantir uma conexão adequadamente implementada entre o Provedor de Identidade e as Partes Confiantes, é necessário validar o gerenciamento de sessões em ambos os lados. Em particular, as Partes Confiantes precisam especificar para o IdP o prazo máximo de autenticação para sessões inativas. Após esse período, o IdP precisa autenticar novamente o assinante (ou seja, o usuário) novamente.
Por outro lado, cabe ao IdP informar as Terceiras Confiantes do último evento de autenticação de um usuário. Com essas informações, as Partes Confiantes podem determinar se precisam forçar o usuário a se autenticar novamente.