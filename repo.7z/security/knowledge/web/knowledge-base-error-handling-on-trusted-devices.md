---
title: Tratamento de erros
---
## Descrição

Sempre que a manipulação de erros não é aplicada através de dispositivos confiáveis, os erros que ela fornece podem não ser confiável, pois eles podem ser adulterados.

## Solução

Verifique se todo o tratamento de erros é realizado em dispositivos confiáveis.