---
title: Validação de Input
---
## Descrição

Para garantir que o aplicativo seja robusto contra todas as formas de dados de entrada, esses dados devem ser higienizados e/ou codificados no lado do servidor, pois um invasor poderia facilmente ignorar essas verificações com um proxy interceptador.


## Solução

Todas as rotinas de validação e codificação de entrada devem ser implementadas no lado do servidor fora do alcance de um atacante. Assim como na rejeição de entrada, você deve se certificar de que depois de validar a entrada do usuário, sempre que a entrada é ruim, ela realmente rejeita, higieniza ou formata a entrada do usuário em dados não maliciosos.

O método recomendado para validar a entrada do usuário seria o método de validação positiva.
Validação de entrada em uma withelist (lista de permissões) significa permitir apenas entradas definidas explicitamente como válidas,
em oposição à validação de entrada da lista negra, que filtra as entradas inválidas conhecidas.

Você também deve acompanhar os movimentos dos usuários adicionando uma trilha de auditoria e uma contador para rastrear o número de violações dele (enviando entradas incorretas) em sua 
classe de validação de entrada. Você deve aplicar um bloqueio sempre que um número razoável de violações são detectadas pelo seu aplicativo para protegê-lo contra invasores.


