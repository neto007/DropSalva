module.exports = {
    type: "category",
    label: "Mobile Top 10",
    items: [    
        "chapters/security/owasp/owasp-mobile-top-10/m1-improper-platform-usage",
        "chapters/security/owasp/owasp-mobile-top-10/m2-insecure-data-storage",
        "chapters/security/owasp/owasp-mobile-top-10/m3-insecure-communication",
        "chapters/security/owasp/owasp-mobile-top-10/m4-Insecure-authentication",
        "chapters/security/owasp/owasp-mobile-top-10/m5-insufficient-cryptography",
        "chapters/security/owasp/owasp-mobile-top-10/m6-insecure-authorization",
        "chapters/security/owasp/owasp-mobile-top-10/m7-client-code-quality",
        "chapters/security/owasp/owasp-mobile-top-10/m8-code-tampering",
        "chapters/security/owasp/owasp-mobile-top-10/m9-reverse-engineering",
        "chapters/security/owasp/owasp-mobile-top-10/m10-extraneous-functionality",
    ],
};