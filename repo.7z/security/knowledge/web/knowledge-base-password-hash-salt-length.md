---
title: Comprimento do salt do hash da senha
---

## Descrição

Para armazenamento seguro de senhas, é recomendável fazer o hash das senhas com um sal exclusivo. Um salt é um valor único e não secreto no banco de dados, que é anexado (dependendo do algoritmo usado) à senha antes de ser hash. Um sal é usado para impedir pesquisas na Tabela Arco-Íris (um ataque no qual você calcula uma tabela de hashes para senhas). O comprimento de um sal é crítico para garantir a verdadeira aleatoriedade e entropia entre a senha com hash e evitar conluio.

## Solução

Certifique-se de que o comprimento do sal seja de pelo menos 32 bits, DEVE ser gerado por um gerador de bits aleatórios aprovado e escolhido arbitrariamente para minimizar as colisões de valor de sal entre os hashes armazenados.