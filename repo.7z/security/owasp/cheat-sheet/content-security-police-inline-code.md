---
title: Refatorando código - Content-security Police (CSP)
---

Por padrão, o CSP desativa qualquer código JavaScript não assinado colocado in-line no código-fonte HTML, como este:

```html 
<script>
var foo = "314"
<script>
```

O código inline pode ser ativado especificando seu hash SHA256 no cabeçalho CSP:

`Content-Security-Policy: script-src 'sha256-gPMJwWBMWDx0Cm7ZygJKZIU2vZpiYvzUQjl5Rh37hKs=';`

O hash deste script específico pode ser calculado usando o seguinte comando:

`echo -n 'var foo = "314"' | openssl sha256 -binary | openssl base64`

Alguns navegadores (por exemplo, Chrome) também exibirão o hash do script no aviso do console JavaScript ao bloquear um script não assinado. O código embutido também pode ser simplesmente movido para um arquivo JavaScript separado e o código na página se torna:

```html
<script> 
    src="app.js">
</script>
```
Com app.js contendo o cóodigo `var foo = "314"`. A restrição do código inline também se aplica a inline event handlers, de modo que a seguinte construção seja bloqueada no CSP:

```html
<button id="button1" onclick="doSomething()">
```

Isso deve ser substituído por **addEventListener**:

```html
document.getElementById("button1").addEventListener('click', doSomething);
```