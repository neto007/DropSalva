const web = require('./web/sidebars')

module.exports = {
    type: "category",
    label: "Base de Conhecimento",
    items: [
      web
    ],
  };