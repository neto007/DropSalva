---
title: Suporte apenas protocolos forte
---

Os protocolos SSL têm um grande número de pontos fracos e não devem ser usados ​​em nenhuma circunstância. Os aplicativos da web de uso geral devem oferecer suporte apenas a `TLS 1.2 `e `TLS 1.3`, com todos os outros protocolos desativados. Quando se sabe que um servidor da web deve oferecer suporte a clientes legados com navegadores inseguros não suportados (como o Internet Explorer 10), pode ser necessário habilitar o TLS 1.0 para fornecer suporte.

Onde os protocolos legados são necessários, a [extensão "TLS_FALLBACK_SCSV"](https://tools.ietf.org/html/rfc7507) deve ser habilitada para evitar ataques de downgrade contra clientes.

Observe que o PCI DSS [proíbe o uso de protocolos legados, como o TLS 1.0](https://www.pcisecuritystandards.org/document_library?category=educational_resources&subcategory=educational_resources_ssltls#results) .

### Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/)