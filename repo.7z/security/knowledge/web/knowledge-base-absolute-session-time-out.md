---
title: Tempo limite absoluto da sessão
---
## Descrição

Todas as sessões devem implementar um tempo limite absoluto, independentemente da atividade da sessão.
Esse tempo limite define a quantidade máxima de tempo que uma sessão pode estar ativa,
encerrando e invalidando a sessão no período absoluto definido desde o momento em que a sessão foi criada inicialmente pelo aplicativo web. Após invalidar a sessão,
o usuário é forçado a (re)autenticar novamente no aplicativo web estabelecendo
uma nova sessão. A sessão absoluta limita a quantidade de tempo que um invasor pode usar uma sessão seqüestrada e personificar a vítima.

## Solução

Sempre verifique se o tempo limite absoluto das sessões está no lado do servidor, a fim de diminuir o vetor de ataque do hacker.
