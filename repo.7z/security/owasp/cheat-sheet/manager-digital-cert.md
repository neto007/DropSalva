---
title: Certificado Digital
---

A pinagem de certificado é a prática de codificar ou armazenar um conjunto predefinido de informações (geralmente hashes) para certificados digitais / chaves públicas no agente do usuário (seja navegador da web, aplicativo móvel ou plugin do navegador) de modo que apenas os certificados / chaves públicas predefinidos sejam usado para comunicação segura e todos os outros falharão, mesmo se o usuário confiar (implícita ou explicitamente) nos outros certificados / chaves públicas.

Algumas vantagens são:

- No caso de um comprometimento da CA, em que uma CA comprometida em que um usuário confia pode emitir certificados para qualquer domínio, permitindo que perpetradores malvados espiem os usuários.

- Em ambientes onde os usuários são forçados a aceitar uma CA raiz potencialmente mal-intencionada, como ambientes corporativos ou esquemas de PKI nacionais.

- Em aplicativos em que o grupo demográfico de destino pode não entender os avisos de certificado e provavelmente permitirá apenas qualquer certificado inválido.

Para obter detalhes sobre a fixação de certificado, consulte o seguinte:

- [Pinagem de certificado](manager-pinning.md)

- [Extensão de fixação de chave pública para HTTP RFC](https://tools.ietf.org/html/rfc7469).

- [Protegendo o canal SSL contra ataques man-in-the-middle: HTTP Strict Transport Security e e Pinning of Certs, de Tobias Gondrom](https://owasp.org/www-pdf-archive/OWASP_defending-MITMA_APAC2012.pdf).


### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)
