---
title: Defesa contra SQL inject - Consulta Parametrizadas
---

O uso de instruções preparadas com associação de variáveis ​​(também conhecidas como consultas parametrizadas) é como todos os desenvolvedores devem primeiro ser ensinados a escrever consultas de banco de dados. Eles são simples de escrever e mais fáceis de entender do que consultas dinâmicas. As consultas parametrizadas forçam o desenvolvedor a definir primeiro todo o código SQL e, em seguida, passar cada parâmetro para a consulta. Este estilo de codificação permite que o banco de dados distinga entre código e dados, independentemente da entrada do usuário fornecida.

As instruções preparadas garantem que um invasor não seja capaz de alterar a intenção de uma consulta, mesmo se comandos SQL forem inseridos por um invasor. No exemplo seguro abaixo, se um invasor inserir o ID do usuário de tom `' or '1'='1`, a consulta parametrizada não ficará vulnerável e, em vez disso, procurará um nome de usuário que corresponda literalmente a toda a string tom `' or '1'='1`.

Recomendações específicas de idioma:

- Java EE - usar PreparedStatement()com variáveis ​​de ligação

- .NET - use consultas parametrizadas como SqlCommand()ou OleDbCommand()com variáveis ​​de ligação

- PHP - use PDO com consultas parametrizadas fortemente tipadas (usando bindParam ())

- Hibernate - use createQuery()com variáveis ​​de ligação (chamadas de parâmetros nomeados no Hibernate)

- SQLite - use sqlite3_prepare()para criar um objeto de instrução

Em raras circunstâncias, as declarações preparadas podem prejudicar o desempenho. Quando confrontado com esta situação, é melhor a) validar fortemente todos os dados ou b) escapar de todas as entradas fornecidas pelo usuário usando uma rotina de escape específica para seu fornecedor de banco de dados conforme descrito abaixo, em vez de usar uma instrução preparada.

**Exemplo de instrução preparada por Java seguro:**

O exemplo de código a seguir usa uma implementação `PreparedStatement` de Java de uma consulta parametrizada para executar a mesma consulta de banco de dados.

```java

// This should REALLY be validated too
String custname = request.getParameter("customerName");
// Perform input validation to detect attacks
String query = "SELECT account_balance FROM user_data WHERE user_name = ? ";
PreparedStatement pstmt = connection.prepareStatement( query );
pstmt.setString( 1, custname);
ResultSet results = pstmt.executeQuery( );

```

**Exemplo de instrução preparada em C # .NET seguro :**

Com o .NET, é ainda mais simples. A criação e execução da consulta não muda. Tudo o que você precisa fazer é simplesmente passar os parâmetros para a consulta usando a Parameters.Add()chamada conforme mostrado aqui.

```csharp

String query = "SELECT account_balance FROM user_data WHERE user_name = ?";
try {
  OleDbCommand command = new OleDbCommand(query, connection);
  command.Parameters.Add(new OleDbParameter("customerName", CustomerName Name.Text));
  OleDbDataReader reader = command.ExecuteReader();
  // …
} catch (OleDbException se) {
  // error handling
}
```

Mostramos exemplos em Java e .NET, mas praticamente todas as outras linguagens, oferecem suporte a interfaces de consulta parametrizadas. Mesmo as camadas de abstração SQL, como a Hibernate Query Language (HQL), têm o mesmo tipo de problemas de injeção (que chamamos de injeção HQL). O HQL também oferece suporte a consultas parametrizadas, portanto, podemos evitar este problema:

Instrução preparada da linguagem de consulta do Hibernate (HQL) (parâmetros nomeados) Exemplos :

```java

//First is an unsafe HQL Statement
Query unsafeHQLQuery = session.createQuery("from Inventory where productID='"+userSuppliedParameter+"'");

//Here is a safe version of the same query using named parameters
Query safeHQLQuery = session.createQuery("from Inventory where productID=:productid");
safeHQLQuery.setParameter("productid", userSuppliedParameter);

```

Para obter exemplos de consultas parametrizadas em outras linguagens, incluindo Ruby, PHP, Cold Fusion e Perl, consulte a folha de dicas de parametrização de consulta ou este site .

Os desenvolvedores tendem a gostar da abordagem da instrução preparada porque todo o código SQL permanece dentro do aplicativo. Isso torna seu aplicativo relativamente independente do banco de dados.

### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)