---
title: Autenticação detalhada
---
## Descrição

As mensagens de erro que são exibidas quando um usuário não consegue fazer login em uma aplicação deve ser selecionada com cautela. Quando esta mensagem de erro fornece muitas informações, estas informações podem ser exploradas por um hacker.

## Solução

O aplicativo nunca deve publicar nomes de usuário disponíveis. Quando um invasor ganha essas
informações, ele aumenta seu vetor de ataque e reduz o tempo necessário para identificar contas.

Ou seja:

Imagine uma função 'esqueci a senha', onde o usuário insere seu nome de usuário para que a
aplicação envie uma nova senha para seu endereço de e-mail, o usuário digita um nome de usuário correto e a aplicação responde com:

“Email enviado com sucesso para o seu endereço de email.”
Quando o usuário insere um nome de usuário incorreto, ele diz: “Erro: o usuário não existe”.
Esta função seria vulnerável à enumeração de nome de usuário