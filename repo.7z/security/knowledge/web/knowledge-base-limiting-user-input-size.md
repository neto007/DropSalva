---
title: Limitando o Tamanho do Input de Usuário
---
## Descrição

Sempre que há input de usuário dentro de sua aplicação você também quer limitar 
o tamanho do input de usuário para um comprimento máximo apropriado.

## Solução

Verifique se todos os inputs de usuário tem sido limitados e que a aplicação apenas aceita 
comprimentos de input esperados.
