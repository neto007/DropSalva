---
title: O log é realizado antes de executar a transação
---
## Descrição

Sempre que o log é realizado antes de executar uma transação, você pode garantir que as transações sejam registradas. Isso aumenta a integridade dos seus arquivos de log. Se o log for realizado após a execução de uma transação e um invasor realizar um ataque bem-sucedido, a parte do log poderá não ser alcançada e nenhum rastreamento será registrado para o ataque.

## Solução

Verifique se o log é realizado antes de executar a transação. Se o registro não tiver êxito (por exemplo, disco cheio, permissões insuficientes), o aplicativo falhará em segurança. Isso ocorre quando a integridade e o não repúdio são obrigatórios.