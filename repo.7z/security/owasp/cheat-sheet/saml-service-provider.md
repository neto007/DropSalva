---
title: SAML provedor de identidade e o provedor de serviços
---

O protocolo SAML raramente é o vetor de escolha, embora seja importante ter cheatsheets para garantir que seja robusto. Os vários terminais são mais direcionados, portanto, como o token SAML é gerado e como é consumido são importantes na prática.

- Considerações sobre o provedor de identidade (IdP)

- Validar certificado X.509 para compatibilidade de algoritmo, força de criptografia, restrições de exportação

- Validar opções de autenticação forte para gerar o token SAML

- Validação de IDP (que IDP cria o token)

- Use / confie em CAs raiz sempre que possível

- Sincronizar com uma fonte de tempo comum da Internet

- Definir níveis de garantia para verificação de identidade

- Prefira identificadores assimétricos para afirmações de identidade em vez de informações de identificação pessoal (por exemplo, SSNs, etc)

- Assine cada afirmação individual ou todo o elemento de resposta

- Considerações do provedor de serviços (SP)

- Validando o estado da sessão para o usuário

- Nível de granularidade na configuração do contexto authZ ao consumir token SAML (você usa grupos, funções, atributos)

- Certifique-se de que cada Assertion ou todo o elemento Response seja assinado

- Validar assinaturas

- Valide se for assinado por IDP autorizado

- Validar certificados IDP para expiração e revogação contra CRL / OCSP

- Validar NotBefore e NotOnorAfter

- Validar atributo de destinatário

- Definir critérios para logout SAML

- Troque asserções apenas em transportes seguros

- Definir critérios para gerenciamento de sessão

- Verifique as identidades de usuário obtidas de asserções de tíquete SAML sempre que possível.

**Validação de entrada**

Só porque o SAML é um protocolo de segurança não significa que a validação de entrada vai embora.

Certifique-se de que todos os provedores / consumidores SAML façam a validação de entrada adequada .

**Criptografia**

As soluções baseadas em algoritmos criptográficos precisam seguir os desenvolvimentos mais recentes em criptoanálise.

- Certifique-se de que todos os elementos SAML na cadeia usam criptografia forte

- Considere descontinuar o suporte para algoritmos XMLEnc inseguros



### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)