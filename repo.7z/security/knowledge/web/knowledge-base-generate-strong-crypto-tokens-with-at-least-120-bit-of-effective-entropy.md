---
title: Tokens criptográficos fortes
---
## Descrição

Os valores de ID armazenados no dispositivo, como IMEI e UDID, não devem ser usados como tokens de autenticação. Esses tokens são recuperáveis por outros aplicativos e, portanto, não garantem integridade.
 
O uso de valores de ID do dispositivo móvel também implica o uso de tokens de API estáticos, que são considerados inseguros. Esses tokens não podem, por exemplo, expirar ou ser invalidados pelo aplicativo.
 
Sempre que o aplicativo usa tokens estáticos, como os valores de ID e essas informações,
vazado por um ataque MiTM ou vazado de outra maneira, esse atacante agora pode comprometer totalmente o usuário sem poder rejeitar a validade ou invalidar o token estático EMEI ou UDID, por exemplo.

## Solução

Os tokens de autenticação sempre devem ser genéricos e devem ter criptografia graficamente aleatória com pelo menos 120 bits de entropia efetiva. A melhor maneira de implementar esses tokens é seguindo os métodos comprovados que são testados no nível efetivo de entropia.

Por exemplo, o JSON Web Token (JWT) é um padrão aberto (RFC 7519) que define um compacto e
maneira independente de transmitir informações com segurança entre as partes como um objeto JSON. Essas informações podem ser verificadas e confiáveis porque são assinadas digitalmente. JWTs podem ser assinado usando um segredo (com o algoritmo HMAC) ou um par de chaves pública/privada usando RSA.