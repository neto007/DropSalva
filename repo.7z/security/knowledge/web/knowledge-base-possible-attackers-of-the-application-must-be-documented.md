---
title: Possíveis invasores do aplicativo devem ser documentados
---
## Descrição

As decisões de autenticação devem ser registradas juntamente com os metadados relevantes para investigações de segurança. Essas informações podem, por exemplo, ser usadas sempre que houver suspeita de comprometimento das contas. Além disso, senhas e outras informações confidenciais nunca devem ser armazenadas nesses arquivos de log. Sempre que um invasor obtém conhecimento desses arquivos, essas informações podem ser usadas para comprometer outras contas.

>Nota: Os nomes de usuário também nunca devem ser armazenados nos arquivos de log; os usuários nem sempre prestam atenção às suas ações e, às vezes, fornecem ao campo do formulário de nome de usuário sua senha. Se o aplicativo registrasse os nomes de usuário, essas senhas agora também serão armazenadas e podem ser usado para comprometer contas sempre que um invasor obtiver conhecimento desses arquivos.

## Solução

Verifique se todas as decisões de autenticação podem ser registradas, sem armazenar identificadores ou senhas de sessão confidenciais. Isso deve incluir solicitações com metadados relevantes necessários para investigações de segurança.