---
title: Testes de segurança contínuos
---
## Descrição

É desejável testar as aplicações e infraestrutura periodicamente para encontrar componentes desatualizados e serviços inseguros que estão sendo executados.

É possível configurar o ambiente de maneira que se tenha trabalhos em execução que fazem automação contínua (a cada hora, diariamente, semanalmente, mensalmente) verificação de segurança em nossa infraestrutura e aplicativos.

## Solução

Integre ferramentas de segurança em seus pipelines de CI / CD que façam a verificação de segurança contínua em relação a seus aplicativos e infraestrutura podendo utilizar por exemplo, as seguintes ferramentas:

* Nessus
* OpenVas
* Nmap
* Nikto
* OWASP Zap (varreduras passivas e ativas)

Essas ferramentas devem ser executadas periodicamente para verificar se há problemas conhecidas no sistema. vulnerabilidades e relate descobertas altas / críticas para seus desenvolvedores para eles possam tomar as ações apropriadas.
