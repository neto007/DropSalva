---
title: A funcionalidade de login deve sempre gerar um novo id de sessão
---
## Descrição

Sempre que um usuário é autenticado com sucesso, o aplicativo deve gerar um
novo cookie de sessão.

## Solução

A funcionalidade de login deve sempre gerar (e usar) um novo ID de sessão após um
login ser realizado com sucesso. Isso é feito para evitar que um invasor faça um ataque de fixação de sessão em seus usuários.

Algumas estruturas não oferecem a possibilidade de alterar o ID da sessão no login, como
aplicações .Net. Sempre que esse problema ocorrer, você pode definir um cookie aleatório extra em login com um token forte e armazenar esse valor em uma variável de sessão.

Agora você pode comparar o valor do cookie com a variável de sessão, a fim de evitar
fixação de sessão, uma vez que a autenticação não depende apenas do ID da sessão, pois
o cookie aleatório não pode ser previsto ou alterado pelo invasor.