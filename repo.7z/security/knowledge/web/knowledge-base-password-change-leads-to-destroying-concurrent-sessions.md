---
title: A alteração de senha e sessões simultâneas
---
## Descrição

Sempre que um usuário altera sua senha, ele deve ter a opção de eliminar todas as outras sessões simultâneas. Essa contramedida ajuda a excluir possíveis invasores que vivem em uma sessão seqüestrada.

>Nota: Sempre que for concedida aos usuários a possibilidade de alterar suas senhas, não se esqueça de fazê-los se autenticar novamente ou usar uma forma de mecanismo de autenticação adaptável ou de avanço.

## Solução

Verifique se é solicitado ao usuário a opção de encerrar todas as outras sessões ativas após um processo bem-sucedido de alteração de senha.