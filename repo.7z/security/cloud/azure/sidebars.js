module.exports = {
    type: "category",
    label: "Azure",
    items: [    
        "chapters/security/cloud/azure/app-services",
        "chapters/security/cloud/azure/event-hub",
        "chapters/security/cloud/azure/key-vault",
        "chapters/security/cloud/azure/load-balancer",
        "chapters/security/cloud/azure/sql",
        "chapters/security/cloud/azure/storage-account",
        "chapters/security/cloud/azure/virtual-machine",
    ],
};