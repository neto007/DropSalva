---
title: Redirecionamentos abertos
---
## Descrição

Redirecionamentos e encaminhamentos não validados são possíveis quando um aplicativo Web aceita entrada não confiável, o que poderia fazer com que o aplicativo Web redirecionasse a solicitação para um URL contido na entrada não confiável. Ao modificar a entrada de URL não confiável em um site mal-intencionado, um invasor pode iniciar com êxito um golpe de phishing e roubar credenciais de usuário. Como o nome do servidor no link modificado é idêntico ao site original, as tentativas de phishing podem ter uma aparência mais confiável. Os ataques de redirecionamento e encaminhamento não validados também podem ser usados para criar maliciosamente um URL que passaria na verificação de controle de acesso do aplicativo e depois encaminharia o invasor para funções privilegiadas que eles normalmente não poderiam acessar.

## Solução

Use um método de lista de permissões para determinar para onde o usuário deve ser redirecionado. Você também pode mostrar um aviso ao redirecionar para conteúdo potencialmente não confiável.
Se não for considerado necessário, a entrada fornecida pelo usuário não deve ser usada em redirecionamentos e encaminhamentos de qualquer maneira.