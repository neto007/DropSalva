---
title: Conteúdo de sandbox
---

Ambas as ferramentas podem ser usadas por sites para colocar em sandbox / limpar dados DOM.

`DOMPurify` é um sanitizer XSS rápido e tolerante para HTML, MathML e SVG. DOMPurify funciona com um padrão seguro, mas oferece muitas possibilidades de configuração e ganchos.

`MentalJS` é um analisador e sandbox de JavaScript. Ele lista o código JavaScript adicionando um sufixo "$" a variáveis ​​e acessadores.

**Integridade de sub-recursos**

Garantirá que apenas o código que foi revisado seja executado. O desenvolvedor gera metadados de integridade para o javascript do fornecedor e os adiciona ao elemento de script como este:

```js

<script src="https://analytics.vendor.com/v1.1/script.js"
   integrity="sha384-MBO5IDfYaE6c6Aao94oZrIOiC7CGiSNE64QUbHNPhzk8Xhm0djE6QqTpL0HzTUxk"
   crossorigin="anonymous">
</script>

```

É importante saber que, para que o SRI funcione, o host do fornecedor precisa do CORS ativado. Também é uma boa ideia monitorar o JavaScript do fornecedor quanto a alterações de maneira regular. Porque às vezes você pode obter código de terceiros seguro, mas não funciona , quando o fornecedor decide atualizá-lo.


### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)