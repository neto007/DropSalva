---
title: Exibir sessões simultâneas e ativas
---
## Descrição

Sempre que é apresentado ao usuário um resumo de todas as sessões simultâneas, isso diminui ataque de seqüestro bem-sucedido, já que o usuário agora pode ver todas as sessões e encerrar uma sempre que não parece confiável.

## Solução

O usuário deve receber todas as sessões simultâneas e ativas em seu perfil/conta
resumo. Dessa forma, o usuário pode acompanhar o que está acontecendo e optar por encerrar um sessão sempre que parecer não confiável.

Sempre que o usuário compartilhava permissão para outros aplicativos por exemplo, por exemplo, OAuth, do que o usuário também deve ser apresentado com permissões compartilhadas, juntamente com o tipo de permissão e data de ativação.