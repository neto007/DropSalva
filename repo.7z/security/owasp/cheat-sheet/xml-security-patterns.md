---
title: Patterns
---

Certos elementos ou atributos podem seguir uma sintaxe específica. Você pode adicionar `pattern` restrições ao usar esquemas XML. Quando você deseja garantir que os dados estejam em conformidade com um padrão específico, você pode criar uma definição específica para eles. O número da previdência social (SSN) pode servir como um bom exemplo; eles devem usar um conjunto específico de caracteres, um comprimento específico e um específico pattern:

```xml

<xs:element name="SSN">
 <xs:simpleType>
  <xs:restriction base="xs:token">
   <xs:pattern value="[0-9]{3}-[0-9]{2}-[0-9]{4}"/>
  </xs:restriction>
 </xs:simpleType>
</xs:element>

```

Somente números entre `000-00-0000` e `999-99-9999` serão permitidos como valores para um `SSN`.

## Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/cheatsheets/XML_Security_Cheat_Sheet.html)