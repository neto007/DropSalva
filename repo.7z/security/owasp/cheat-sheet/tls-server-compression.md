---
title: Desativar compressão
---

A compactação TLS deve ser desabilitada para proteger contra uma vulnerabilidade (apelidada de [CRIME](https://threatpost.com/crime-attack-uses-compression-ratio-tls-requests-side-channel-hijack-secure-sessions-091312/77006/) ) que pode permitir que informações confidenciais, como cookies de sessão, sejam recuperadas por um invasor.

### Referência externa

- [OWASP](https://cheatsheetseries.owasp.org/)