---
title: Acesso a informação sigilosa 
---
## Descrição

O acesso a qualquer informação sigilosa deve ser protegido contra acesso não autorizado, a fim de preservar a integridade e a confidencialidade dos dados.

## Solução

Sempre que dados confidenciais forem armazenados no servidor, considere armazenar esses dados em uma pasta separada com regras de permissão para impedir que usuários não autorizados leiam esses arquivos. Também é altamente recomendável criptografar/hash a senha para reforçar a segurança.