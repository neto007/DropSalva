---
title: OOB não criptografado
---
## Descrição

Na autenticação, fora de banda refere-se à utilização de duas redes ou canais separados, um dos quais diferente da rede ou canal primário, usado simultaneamente para se comunicar entre duas partes ou dispositivos para identificar um usuário. Uma rede celular é comumente usada para autenticação fora da banda. Um exemplo de autenticação fora de banda é quando um usuário de banco on-line está acessando sua conta bancária on-line com um login e uma senha única é enviada para seu telefone celular via SMS para identificá-los. O canal principal seria a tela de login on-line, na qual o usuário digita suas informações de login e o segundo canal separado seria a rede celular. Essa camada adicional de segurança evita que a probabilidade de hackers e malware comprometam o acesso ao processo completo de autenticação.


## Solução

A solução mais eficaz para eliminar o uso de mídias como e-mails não criptografados ou VOIP e alternar para canais mais seguros ou implementar mecanismos como autenticação TLS mútua entre as partes que interagem, sempre que possível.