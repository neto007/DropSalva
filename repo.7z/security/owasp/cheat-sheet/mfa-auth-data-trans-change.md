---
title: Dados da transação são Protegidos contra modificação
---

O processo de autorização da transação deve proteger contra cenários de ataque que modificam os dados da transação após a entrada inicial pelo usuário. Por exemplo, uma má implementação de um processo de autorização de transação pode permitir os seguintes ataques (para referência, consulte as etapas de autorização de transação descritas no parágrafo 2.5):

- Repetição da etapa 1 (envio de dados da transação) em segundo plano e substituição dos detalhes da transação por transação fraudulenta, antes que o usuário insira as credenciais de autorização.

- Adicionar parâmetros com dados de transação a uma solicitação HTTP que autoriza a transação. Nesse caso, uma implementação deficiente irá autorizar a transação inicial e, em seguida, executar uma transação fraudulenta (exemplo específico de [vulnerabilidade](https://cwe.mitre.org/data/definitions/367.html) de Tempo de verificação até o tempo de uso ).

A proteção contra modificação pode ser implementada usando várias técnicas, dependendo da estrutura usada, mas um ou mais dos seguintes devem estar presentes:

- Qualquer modificação dos dados da transação deve causar a invalidação de todos os dados de autorização inseridos anteriormente. Por exemplo, OTP gerado ou o desafio é invalidado.

- Qualquer modificação dos dados da transação deve acionar a redefinição do processo de autorização.

- Qualquer tentativa de modificar os dados da transação após a entrada inicial pelo usuário é um sintoma de manipulação de um aplicativo e deve ser registrada, monitorada e cuidadosamente investigada.

### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)