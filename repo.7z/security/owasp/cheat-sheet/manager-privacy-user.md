---
title: Privacidade do usuário
---

Esta referência do OWASP apresenta métodos de mitigação que os desenvolvedores da web podem utilizar para proteger seus usuários de uma vasta gama de ameaças e agressões potenciais que podem tentar minar sua privacidade e anonimato. Esta folha de dicas concentra-se nas ameaças à privacidade e ao anonimato que os usuários podem enfrentar ao usar serviços online, especialmente em contextos como redes sociais e plataformas de comunicação.

- [Diretrizes](manager-crypto-strong.md)

- [Suporta HTTP Strict Transport Security](manager-hsts.md)

- [Certificado digital](manager-digital-cert.md)

- [Modo Panico](manager-panic.md)

- [Invalidar Sessão Remota](manager-invalid-sessions.md)

- [Honestidade e Transparência](manager-honest-transparency.md)


### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)

