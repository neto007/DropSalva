---
title: Negação de serviço bloqueando contas
---
## Descrição

Sempre que a oportunidade de efetuar login no aplicativo é oferecida, ele não deve bloquear contas. Um hacker pode abusar dessa função para fazer com que o aplicativo negue acesso a seus usuários avançados.

## Solução

O aplicativo não deve bloquear os usuários quando eles inserem credenciais de login falsas.
