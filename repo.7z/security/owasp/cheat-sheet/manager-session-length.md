---
title: Comprimento do ID da sessão
---

O ID da sessão deve ser longo o suficiente para evitar ataques de força bruta, onde um invasor pode percorrer toda a gama de valores de ID e verificar a existência de sessões válidas.

A duração do ID da sessão deve ser de pelo menos 128 bits (16 bytes).

NOTA:

O comprimento do ID da sessão de 128 bits é fornecido como uma referência com base nas suposições feitas na próxima seção Entropia do ID da sessão . No entanto, este número não deve ser considerado como um valor mínimo absoluto, pois outros fatores de implementação podem influenciar sua resistência.
Por exemplo, existem implementações bem conhecidas, como IDs de sessão Microsoft ASP.NET : " O identificador de sessão ASP .NET é um número gerado aleatoriamente codificado em uma string de 24 caracteres que consiste em caracteres minúsculos de a a z e números de 0 a 5 ".
Pode fornecer uma entropia efetiva muito boa e, como resultado, pode ser considerado longo o suficiente para evitar ataques de adivinhação ou de força bruta.

### Referência Externa

- [OWASP](https://cheatsheetseries.owasp.org/)