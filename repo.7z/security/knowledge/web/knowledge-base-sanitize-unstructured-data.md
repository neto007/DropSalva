---
title: Sanitizar dados não estruturados
---
## Descrição

Verifique se os dados não estruturados são higienizados para impor medidas de segurança genéricas. Quando isso não é na configuração, um invasor pode usar esses dados não estruturados para prejudicar o aplicativo e executar injeções.

## Solução

Dados não estruturados precisam ser higienizados para impor medidas de segurança genéricas, por exemplo:

- caracteres permitidos
- comprimento dos caracteres

Além disso, alguns caracteres são potencialmente prejudiciais em um determinado contexto e, portanto, devem ser evitados. (por exemplo, nomes naturais com Unicode ou apóstrofes, como & # x306D; & # x3053)