---
title: Injeção de upload de arquivo
---
## Descrição

Os arquivos enviados representam um risco significativo para os aplicativos.
O primeiro passo em muitos ataques é obter algum código no sistema a ser atacado.
Então o ataque precisa apenas encontrar uma maneira de executar o código. Usando um upload de arquivo ajuda o invasor a realizar o primeiro passo.

As consequências do upload irrestrito de arquivos podem variar, incluindo a aquisição completa do sistema, um sistema de arquivos ou banco de dados sobrecarregado, encaminhando ataques para sistemas de back-end e desfiguração do sistema.

Existem realmente duas classes de problemas aqui.
O primeiro é com os metadados do arquivo, como o caminho e o nome do arquivo.
Eles geralmente são fornecidos pelo transporte, como codificação HTTP com várias partes.
Esses dados podem induzir o aplicativo a substituir um arquivo crítico ou a armazená-lo
em uma localização ruim. Você deve validar os metadados com muito cuidado antes de usá-los.

A outra classe de problemas está no tamanho ou no conteúdo do arquivo.
Um invasor pode criar facilmente um arquivo de imagem válido com código PHP dentro.

## Solução

- Os arquivos enviados sempre precisam ser colocados fora da raiz do documento do servidor da web

- Marque para não aceitar arquivos grandes que possam encher o armazenamento ou causar um ataque de negação de serviço

- Verifique a entrada do usuário (nome do arquivo) para ter as extensões permitidas corretas, como .jpg, .png etc.

- Verifique a entrada do usuário (nome do arquivo) para conter possíveis padrões de passagem de caminho, a fim de impedir que ele faça upload fora do diretório pretendido.

>Nota: ao verificar essas extensões, verifique sempre se o seu aplicativo valida a última
possível extensão para que um invasor não possa simplesmente injetar ".jpg.php" e ignorar sua validação.

Você também pode verificar se os nomes dos arquivos já existem antes do upload para poder
impedir a substituição de arquivos.

Também para servir os arquivos de volta, é necessário haver uma função de manipulador de arquivos que pode selecionar o arquivo com base em um identificador que enviará o arquivo de volta ao usuário.

A maioria dos desenvolvedores também fazem uma verificação do tipo MIME. Esta é uma boa proteção, mas não sempre que você estiver verificando esse tipo de mímica através da solicitação de postagem. Este cabeçalho não pode ser confiável, pois pode ser facilmente manipulado por um invasor.

A melhor maneira de verificar o tipo MIME
é extrair o arquivo do servidor após o upload e verificá-lo do próprio arquivo.
Excluindo-o sempre que não estiver em conformidade com os valores esperados.